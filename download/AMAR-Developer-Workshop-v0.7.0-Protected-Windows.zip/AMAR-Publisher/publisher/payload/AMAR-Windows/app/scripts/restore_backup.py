#!/usr/bin/env python3
"""Offline restore to a NEW data directory; never overwrites existing data."""
import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import re
from zipfile import ZipFile

def restore(archive_path, target):
    target = Path(target).resolve()
    if target.exists():
        raise ValueError("Destination already exists. Use a new directory; no files were replaced.")
    target.parent.mkdir(parents=True, exist_ok=True)
    allowed = {"manifest.json", "amar.sqlite3", "secret.key", "transfer-identity.json", "developer-trust.json"}
    with ZipFile(archive_path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or any(name not in allowed and not re.fullmatch(r'documents/[0-9a-f]{32}\.(pdf|png|jpg)|branding/[0-9a-f]{32}\.png',name) for name in names) or not {"manifest.json", "amar.sqlite3", "transfer-identity.json"}.issubset(names):
            raise ValueError("Unsupported backup structure")
        if archive.getinfo("manifest.json").file_size > 32*1024**2:
            raise ValueError("Invalid manifest")
        manifest = json.loads(archive.read("manifest.json"))
        if manifest["version"] not in (1,2) or set(manifest["files"]) != set(names) - {"manifest.json"}:
            raise ValueError("Invalid manifest")
        tmp = Path(tempfile.mkdtemp(prefix="amar-restore-", dir=target.parent))
        try:
            for name, checksum in manifest["files"].items():
                limit=64*1024**3 if name=='amar.sqlite3' else 20*1024**2 if name.startswith('documents/') else 6*1024**2 if name.startswith('branding/') else 8192
                if archive.getinfo(name).file_size > limit:
                    raise ValueError("Backup file too large")
                dest = tmp / name
                dest.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
                with archive.open(name) as source, dest.open("wb") as out:
                    shutil.copyfileobj(source, out)
                dest.chmod(0o600)
                with dest.open("rb") as f:
                    if hashlib.file_digest(f, "sha256").hexdigest() != checksum:
                        raise ValueError("Backup checksum mismatch")
            with closing(sqlite3.connect(tmp / "amar.sqlite3")) as db:
                if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValueError("Database integrity check failed")
                if manifest['version']==2 and db.execute("SELECT 1 FROM sqlite_master WHERE name='core_documentversion'").fetchone():
                    for filename,digest in db.execute('SELECT filename,digest FROM core_documentversion'):
                        if manifest['files'].get('documents/'+filename)!=digest:raise ValueError('A registered document is missing from the backup')
                if manifest['version']==2 and db.execute("SELECT 1 FROM sqlite_master WHERE name='core_brandlogo'").fetchone():
                    for filename,digest in db.execute('SELECT filename,digest FROM core_brandlogo'):
                        if manifest['files'].get('branding/'+filename)!=digest:raise ValueError('A registered logo is missing from the backup')
            os.rename(tmp, target)
        except Exception:
            shutil.rmtree(tmp, ignore_errors=True)
            raise
    return target

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive")
    parser.add_argument("new_data_directory")
    args = parser.parse_args()
    try:
        target = restore(args.archive, args.new_data_directory)
    except (ValueError, KeyError, OSError) as exc:
        parser.exit(1, f"Restore failed: {exc}\n")
    print(f"Restored to {target}. Stop the old server, set AMAR_DATA_DIR to this directory, then start.")
    print("This restores the SAME installation identity. Never run both copies or use it as a new branch.")
