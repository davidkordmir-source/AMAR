document.addEventListener('DOMContentLoaded',()=>{
 const form=document.querySelector('#brand-editor'),preview=document.querySelector('#brand-preview');if(!form||!preview)return;
 const get=name=>form.elements.namedItem(name)?.value||'',checked=name=>!!form.elements.namedItem(name)?.checked;
 const number=(name,min,max)=>Math.min(max,Math.max(min,Number(get(name))||min));
 const set=(name,value)=>preview.style.setProperty('--preview-'+name,value);
 const originalLogo=preview.querySelector('.preview-logo').innerHTML,desktop=document.querySelector('.desktop-icon-preview'),originalDesktop=desktop.innerHTML;
 const urls={};
 const repaint=()=>{
  const dark=get('mode')==='dark',custom=checked('custom_colors');preview.dataset.mode=get('mode');
  const palette=custom?{bg:get('page_color'),panel:get('card_color'),ink:get('text_color'),sidebar:get('sidebar_color'),navInk:get('sidebar_text'),header:get('header_color'),muted:get('muted_color'),border:get('border_color')}:
   dark?{bg:'#141a27',panel:'#1d2535',ink:'#e9edf8',sidebar:'#1d2535',navInk:'#b7c3dc',header:'#1d2535',muted:'#a5b0c5',border:'#344056'}:{bg:'#f7f8fc',panel:'#ffffff',ink:'#222538',sidebar:'#ffffff',navInk:'#62667d',header:'#ffffff',muted:'#6d7285',border:'#ececf3'};
  for(const [key,value] of Object.entries(palette))if(/^#[0-9a-f]{6}$/i.test(value))set(key,value);
  const color=get('primary');if(/^#[0-9a-f]{6}$/i.test(color)){
   set('primary',color);const rgb=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4),l=rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722;set('on-primary',(l+.05)/.05>1.05/(l+.05)?'#111827':'#ffffff');
  }
  preview.style.fontFamily={segoe:'"Segoe UI",Tahoma,sans-serif',tahoma:'Tahoma,sans-serif',arial:'Arial,sans-serif',calibri:'Calibri,Tahoma,sans-serif',verdana:'Verdana,Tahoma,sans-serif'}[get('font')];
  preview.style.fontSize=number('font_size',12,20)+'px';set('radius',number('radius',0,28)+'px');set('button-radius',number('button_radius',0,24)+'px');set('logo-size',Math.round(number('logo_size',32,96)*.7)+'px');set('sidebar-size',Math.round(number('sidebar_width',200,360)/3)+'px');
  set('row-padding',get('density')==='compact'?'5px':'10px');set('shadow',{none:'none',soft:'0 3px 12px #0000000a',strong:'0 8px 22px #00000024'}[get('shadow')]);
  preview.querySelector('[data-preview-name]').textContent=get('product_name');preview.querySelector('[data-preview-tagline]').textContent=get('tagline');preview.querySelector('[data-preview-tagline]').hidden=!checked('show_tagline');
  for(const item of preview.querySelectorAll('[data-preview-nav]'))item.textContent=get('nav_'+item.dataset.previewNav);
  for(const item of preview.querySelectorAll('[data-preview-copy]'))item.textContent=get('copy_'+item.dataset.previewCopy);
  preview.querySelector('.preview-footer').hidden=!checked('show_footer');
  document.querySelector('[data-preview-desktop-name]').textContent=get('product_name');document.querySelector('[data-preview-exe]').textContent=(get('product_code')||'AMAR')+'.exe';
  document.querySelector('[data-preview-setup]').textContent=(get('product_code')||'AMAR')+'-Setup-v'+document.querySelector('meta[name=application-version]').content+'-x64.exe';
  set('background-opacity',number('background_opacity',0,100)/100);set('background-blur',number('background_blur',0,16)+'px');set('background-fit',get('background_fit')==='repeat'?'auto':get('background_fit'));set('background-repeat',get('background_fit')==='repeat'?'repeat':'no-repeat');set('background-position',get('background_position'));
  const background=checked('remove_background')?'':urls.background||preview.dataset.currentBackground;set('background',background?'url("'+background+'")':'none');
  if(checked('remove_logo'))preview.querySelector('.preview-logo').textContent=(get('product_name')||'آ').slice(0,1);else if(urls.logo)image(preview.querySelector('.preview-logo'),urls.logo);else preview.querySelector('.preview-logo').innerHTML=originalLogo;
  if(checked('remove_desktop_icon')){if(urls.logo&&!checked('remove_logo'))image(desktop,urls.logo);else desktop.textContent=(get('product_name')||'آ').slice(0,1);}else if(urls.desktop_icon)image(desktop,urls.desktop_icon);else desktop.innerHTML=originalDesktop;
 };
 function image(container,url){if(container.querySelector('img')?.src===url)return;const img=document.createElement('img');img.src=url;img.alt='پیش‌نمایش تصویر انتخابی';container.replaceChildren(img);}
 for(const kind of ['logo','desktop_icon','background'])form.elements.namedItem(kind)?.addEventListener('change',()=>{
  if(urls[kind])URL.revokeObjectURL(urls[kind]);delete urls[kind];const file=form.elements.namedItem(kind).files[0];
  if(file&&['image/png','image/jpeg'].includes(file.type)&&file.size<=(kind==='background'?6:2)*1024*1024)urls[kind]=URL.createObjectURL(file);repaint();
 });
 form.addEventListener('input',repaint);form.addEventListener('change',repaint);
 for(const button of document.querySelectorAll('[data-brand-color]'))button.addEventListener('click',()=>{form.elements.namedItem('primary').value=button.dataset.brandColor;repaint();});
 const tabs=[...document.querySelectorAll('[data-studio-tab]')],panels=[...document.querySelectorAll('[data-studio-panel]')];
 const activate=id=>{for(const panel of panels)panel.hidden=panel.dataset.studioPanel!==id;for(const tab of tabs){tab.classList.toggle('active',tab.dataset.studioTab===id);tab.setAttribute('aria-current',tab.dataset.studioTab===id?'true':'false');}};
 for(const tab of tabs)tab.addEventListener('click',event=>{event.preventDefault();activate(tab.dataset.studioTab);});
 form.addEventListener('invalid',event=>{const panel=event.target.closest('[data-studio-panel]');if(panel)activate(panel.dataset.studioPanel);},true);
 activate(document.querySelector('.studio-section .has-error')?.closest('.studio-section').dataset.studioPanel||'identity');repaint();
});
