"use strict";
document.addEventListener("DOMContentLoaded", () => {
  const menu = document.querySelector(".mobile-menu");
  const sidebar = document.querySelector(".sidebar");
  menu?.addEventListener("click", () => {
    const open = sidebar.classList.toggle("open");
    menu.setAttribute("aria-expanded", String(open));
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && sidebar) {
      sidebar.classList.remove("open");
      menu?.setAttribute("aria-expanded", "false");
    }
  });
  document.addEventListener("click", (event) => {
    if (sidebar && !sidebar.contains(event.target) && !menu?.contains(event.target)) {
      sidebar.classList.remove("open");
      menu?.setAttribute("aria-expanded", "false");
    }
  });
  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });
  document.querySelectorAll("[data-print]").forEach((button) => {
    button.addEventListener("click", () => window.print());
  });
  const add = document.querySelector("#add-line");
  add?.addEventListener("click", () => {
    const total = document.querySelector("#id_lines-TOTAL_FORMS");
    const index = Number(total.value);
    const maximum=Number(document.querySelector('#id_lines-MAX_NUM_FORMS')?.value || 100);
    if (index >= maximum) return;
    const fragment = document.querySelector("#empty-line").innerHTML.replaceAll("__prefix__", String(index));
    document.querySelector("#contract-lines").insertAdjacentHTML("beforeend", fragment);
    total.value = String(index + 1);
    if (index + 1 >= maximum) add.disabled = true;
  });
});

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.geo-picker').forEach((picker) => {
    const input=picker.querySelector('.geo-query');
    const results=picker.querySelector('.geo-results');
    const selected=picker.querySelector('.geo-selected');
    const target=document.getElementById(picker.dataset.target);
    let timer, controller;
    input.addEventListener('input', () => {
      clearTimeout(timer); controller?.abort(); results.replaceChildren();
      target.value=''; selected.textContent='هنوز محل جدیدی انتخاب نشده است.';
      if(input.value.trim().length<2)return;
      timer=setTimeout(async () => {
        controller=new AbortController();
        try{
          const response=await fetch('/geography/search/?q='+encodeURIComponent(input.value.trim()),{signal:controller.signal,credentials:'same-origin'});
          if(!response.ok)throw new Error('Search unavailable');
          const data=await response.json(); results.replaceChildren();
          for(const place of data.results){
            const button=document.createElement('button'); button.type='button';
            button.textContent=place.path+' — '+place.level;
            button.addEventListener('click',()=>{
              target.value=String(place.id); selected.textContent=place.path;
              const city=document.getElementById('id_city'); if(city)city.value=place.name;
              results.replaceChildren();
            }); results.append(button);
          }
          if(!data.results.length)results.textContent='موردی پیدا نشد؛ حساب ارشد می‌تواند محل جدید اضافه کند.';
        }catch(error){if(error.name!=='AbortError')results.textContent='جست‌وجوی محلی انجام نشد؛ دوباره تلاش کنید.';}
      },250);
    });
    picker.querySelector('.geo-clear')?.addEventListener('click',()=>{target.value='';input.value='';selected.textContent='انتخاب نشده';results.replaceChildren();});
  });
});

document.addEventListener('DOMContentLoaded',()=>{const target=document.querySelector('[data-ocr-url]');if(!target||!['pending','running'].includes(target.dataset.ocrStatus))return;let tries=0;const timer=setInterval(async()=>{if(++tries>90){clearInterval(timer);return;}try{const response=await fetch(target.dataset.ocrUrl,{credentials:'same-origin',cache:'no-store'});if(!response.ok){clearInterval(timer);return;}const data=await response.json();if(['ready','failed'].includes(data.status)){clearInterval(timer);location.reload();}}catch(error){clearInterval(timer);}},2000);});

for (const form of document.querySelectorAll('[data-batch-import]')) {
 form.addEventListener('submit', async event => {
  event.preventDefault(); const files = Array.from(form.querySelector('[name=report_file]').files);
  if (!files.length) return;
  const button=form.querySelector('button'), result=form.querySelector('.import-results');
  button.disabled=true; result.replaceChildren(); let count=0;
  for (const file of files) {
   const line=document.createElement('li'); line.textContent=file.name+' — در حال بررسی'; result.appendChild(line);
   try {
    if (file.size>10*1024*1024) throw new Error('بیشتر از ۱۰ مگابایت');
    const data=new FormData(); data.append('report_file',file);data.append('csrfmiddlewaretoken',form.querySelector('[name=csrfmiddlewaretoken]').value);
    const response=await fetch(form.action,{method:'POST',body:data,credentials:'same-origin',headers:{'X-AMAR-Batch':'1'}});
    const value=await response.json(); if(!response.ok || !value.ok)throw new Error(value.error || 'ورود انجام نشد');
    line.textContent=file.name+' — ثبت شد: '+value.source+'، نوبت '+value.sequence;
   } catch (error) {line.textContent=file.name+' — '+(error.message || 'خطای ورود؛ ورود به حساب را بررسی کنید');}
   button.textContent=(++count)+' / '+files.length;
  }
  button.disabled=false;button.textContent='بررسی و ورود گزارش‌ها';
  const refresh=document.createElement('a');refresh.href=window.location.pathname;refresh.className='button';refresh.textContent='تازه‌سازی آمار پس از ورود فایل‌ها';result.appendChild(refresh);
 });
}

function prepareLookups(root=document) {
 for(const select of root.querySelectorAll('select[data-lookup]:not([data-ready])')) {
  if(select.name.includes('__prefix__'))continue;
  select.dataset.ready='yes'; const input=document.createElement('input');input.type='search';input.className='lookup-query';
  input.disabled=select.disabled;input.placeholder='جست‌وجوی نام یا کد…';input.setAttribute('aria-label','جست‌وجو برای '+(select.labels?.[0]?.textContent || select.name));
  select.before(input);const message=document.createElement('small');message.className='muted';select.after(message);
  let controller,timer;
  async function search(){
   controller?.abort();controller=new AbortController();
   try {
    const response=await fetch(select.dataset.lookup+'?q='+encodeURIComponent(input.value.trim()),{credentials:'same-origin',signal:controller.signal});
    if(!response.ok)throw new Error();const data=await response.json();const current=select.selectedOptions[0];
    const keep=current && current.value ? new Option(current.text,current.value,true,true):null;
    select.replaceChildren(new Option('انتخاب کنید…',''));if(keep)select.add(keep);
    for(const row of data.results)if(!keep || String(row.id)!==keep.value)select.add(new Option(row.label,String(row.id)));
    message.textContent=data.results.length===30?'۳۰ نتیجهٔ نخست؛ برای محدود کردن، نام یا کد دقیق‌تری بنویسید.':data.results.length?'نتیجه را از فهرست انتخاب کنید.':'موردی پیدا نشد.';
   }catch(error){if(error.name!=='AbortError')message.textContent='جست‌وجو انجام نشد؛ دوباره تلاش کنید.';}
  }
  input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(search,250);});
  input.addEventListener('focus',()=>{if(select.options.length<=2)search();});
 }
}
document.addEventListener('DOMContentLoaded',()=>prepareLookups());
new MutationObserver(()=>prepareLookups()).observe(document.documentElement,{childList:true,subtree:true});


// Per-tab GET navigation: Back never resubmits a financial or stock POST.
(()=>{
 const initialize=event=>{
  const button=document.querySelector('[data-app-back]');if(!button)return;
  const current=location.pathname+location.search,scope=document.body.dataset.navigationScope||'public';
  const key='amar-navigation:'+scope,pendingKey=key+':pending';
  const safe=value=>{
   if(typeof value!=='string'||!value.startsWith('/')||value.startsWith('//'))return null;
   try{const url=new URL(value,location.origin);if(url.origin!==location.origin||/[\u0000-\u001f]/.test(value)||url.searchParams.has('token'))return null;return url.pathname+url.search;}catch{return null;}
  };
  let trail=[],available=true;
  try{
   trail=JSON.parse(sessionStorage.getItem(key)||'[]');if(!Array.isArray(trail))trail=[];trail=trail.map(safe).filter(Boolean).slice(-80);
   const returning=sessionStorage.getItem(pendingKey)===current;sessionStorage.removeItem(pendingKey);
   const nativeBack=event?.persisted||performance.getEntriesByType('navigation')[0]?.type==='back_forward';
   if(nativeBack&&trail.includes(current))trail=trail.slice(0,trail.lastIndexOf(current)+1);
   if(trail.at(-1)!==current)trail.push(current);
   sessionStorage.setItem(key,JSON.stringify(trail));
  }catch{available=false;trail=[current];}
  const fallback=safe(button.getAttribute('href'))||'/';button.href=trail.length>1?trail.at(-2):fallback;
  const snapshots=new Map();
  const snapshot=form=>JSON.stringify([...new FormData(form)].filter(([name])=>name!=='csrfmiddlewaretoken').map(([name,value])=>[name,value instanceof File?(value.name?[value.name,value.size,value.lastModified]:null):value]));
  for(const form of document.forms)if(form.method.toLowerCase()==='post')snapshots.set(form,snapshot(form));
  button.onclick=event=>{
   event.preventDefault();const target=safe(button.getAttribute('href'))||fallback;
   if(target===current)return;
   if([...snapshots].some(([form,before])=>form.isConnected&&snapshot(form)!==before)&&!confirm('تغییرات این صفحه ذخیره نشده است. به صفحهٔ قبل برگردید؟'))return;
   if(available)try{
    const next=trail.slice(0,-1);sessionStorage.setItem(key,JSON.stringify(next));sessionStorage.setItem(pendingKey,target);
   }catch{}
   location.assign(target);
  };
 };
 document.addEventListener('DOMContentLoaded',initialize);
 window.addEventListener('pageshow',event=>{if(event.persisted)initialize(event);});
})();
