"""Windows identity resources and carefully owned desktop shortcuts."""
import ctypes,json,os,re,struct,uuid
from pathlib import Path

def shortcut_name(value):
    result=re.sub(r'[<>:"/\\|?*\x00-\x1f]','',value).strip(' .')[:80] or 'AMAR'
    reserved={'CON','PRN','AUX','NUL','CONIN$','CONOUT$',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}
    if result.split('.')[0].upper() in reserved or result=='حذف برنامه':result='اجرای '+result
    return result

def version_resource(name,code,publisher,tagline,version):
    def block(key,value=b'',kind=1,children=()):
        key=(key+'\0').encode('utf-16le');head=b'\0'*6+key;head+=b'\0'*((-len(head))%4)
        data=head+value;data+=b'\0'*((-len(data))%4)
        for child in children:data+=child;data+=b'\0'*((-len(data))%4)
        return struct.pack('<HHH',len(data),len(value)//2 if kind==1 else len(value),kind)+data[6:]
    major,minor,patch=[int(x) for x in version.split('.')]
    if any(not 0<=v<=65535 for v in [major,minor,patch]):raise ValueError('Version too large')
    ms=(major<<16)|minor;ls=patch<<16
    fixed=struct.pack('<13I',0xFEEF04BD,0x10000,ms,ls,ms,ls,0x3f,0,0x40004,1,0,0,0)
    values={'CompanyName':publisher,'FileDescription':name+' — '+tagline,'FileVersion':version,'InternalName':code,'OriginalFilename':code+'.exe','ProductName':name,'ProductVersion':version}
    strings=[block(key,(value+'\0').encode('utf-16le')) for key,value in values.items()]
    return block('VS_VERSION_INFO',fixed,0,[block('StringFileInfo',children=[block('040904B0',children=strings)]),block('VarFileInfo',children=[block('Translation',struct.pack('<HH',0x409,1200),0)])])

def update_shortcuts(package_root,name,tagline,icon,product_code='AMAR'):
    if os.name!='nt':raise ValueError('تغییر میان‌بر فقط در نسخهٔ ویندوز ممکن است.')
    from ctypes import wintypes as w
    root=Path(package_root).resolve();manifest=json.loads((root/'package-manifest.json').read_text(encoding='utf-8'));filename=manifest.get('executable','AMAR.exe')
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,39}\.exe',filename):raise ValueError('نام فایل اجرایی نصب معتبر نیست.')
    executable=root/filename
    if not executable.is_file():raise ValueError('فایل اجرایی نصب پیدا نشد.')
    class GUID(ctypes.Structure):_fields_=[('data',ctypes.c_ubyte*16)]
    def guid(value):return GUID((ctypes.c_ubyte*16).from_buffer_copy(uuid.UUID(value).bytes_le))
    ole=ctypes.OleDLL('ole32');shell=ctypes.WinDLL('shell32')
    ole.CoInitializeEx.argtypes=[ctypes.c_void_p,w.DWORD];ole.CoCreateInstance.argtypes=[ctypes.POINTER(GUID),ctypes.c_void_p,w.DWORD,ctypes.POINTER(GUID),ctypes.POINTER(ctypes.c_void_p)]
    ole.CoTaskMemFree.argtypes=[ctypes.c_void_p]
    shell.SHGetKnownFolderPath.argtypes=[ctypes.POINTER(GUID),w.DWORD,w.HANDLE,ctypes.POINTER(ctypes.c_void_p)];shell.SHGetKnownFolderPath.restype=ctypes.c_long
    def method(pointer,index,result,*args):
        address=ctypes.cast(pointer,ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents[index]
        return ctypes.WINFUNCTYPE(result,ctypes.c_void_p,*args)(address)
    def check(result):
        if result<0:raise OSError('Windows shortcut error: '+hex(result&0xffffffff))
    def folder(identity):
        value=ctypes.c_void_p();check(shell.SHGetKnownFolderPath(ctypes.byref(guid(identity)),0,None,ctypes.byref(value)))
        try:return Path(ctypes.wstring_at(value))
        finally:ole.CoTaskMemFree(value)
    coinit=ole.CoInitializeEx(None,2)
    cls=guid('00021401-0000-0000-c000-000000000046');iid=guid('000214f9-0000-0000-c000-000000000046');persist_iid=guid('0000010b-0000-0000-c000-000000000046')
    def link(path,write):
        pointer=ctypes.c_void_p();persist=ctypes.c_void_p();check(ole.CoCreateInstance(ctypes.byref(cls),None,1,ctypes.byref(iid),ctypes.byref(pointer)))
        try:
            check(method(pointer,0,ctypes.c_long,ctypes.POINTER(GUID),ctypes.POINTER(ctypes.c_void_p))(pointer,ctypes.byref(persist_iid),ctypes.byref(persist)))
            if write:
                for index,value in [(20,str(executable)),(9,str(root)),(7,tagline)]:check(method(pointer,index,ctypes.c_long,w.LPCWSTR)(pointer,value))
                check(method(pointer,17,ctypes.c_long,w.LPCWSTR,ctypes.c_int)(pointer,str(icon),0))
                check(method(persist,6,ctypes.c_long,w.LPCWSTR,w.BOOL)(persist,str(path),True))
            else:
                check(method(persist,5,ctypes.c_long,w.LPCWSTR,w.DWORD)(persist,str(path),0))
                buffer=ctypes.create_unicode_buffer(32768);check(method(pointer,3,ctypes.c_long,w.LPWSTR,ctypes.c_int,ctypes.c_void_p,w.DWORD)(pointer,buffer,len(buffer),None,0))
                return str(Path(buffer.value).resolve()).casefold()==str(executable).casefold()
        finally:
            if persist:method(persist,2,w.ULONG)(persist)
            if pointer:method(pointer,2,w.ULONG)(pointer)
    temporary=[];targets=[];removed=[]
    try:
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,39}',product_code):raise ValueError('شناسهٔ گروه میان‌بر معتبر نیست.')
        desktop=folder('b4bfcc3a-db2c-424c-b029-7fe99a87c641');programs_root=folder('a77f5d77-2e2b-44c3-a6a2-aba601054a51');programs=programs_root/product_code;programs.mkdir(parents=True,exist_ok=True)
        new_name=shortcut_name(name)
        import winreg
        previous=None;previous_group='AMAR';install_key=None
        try:
            install_key=winreg.OpenKey(winreg.HKEY_CURRENT_USER,r'Software\AMAR\Install',0,winreg.KEY_READ|winreg.KEY_WRITE)
            installed=Path(winreg.QueryValueEx(install_key,'InstallDir')[0]).resolve()
            if root.parent.name!='versions' or root.parent.parent!=installed:winreg.CloseKey(install_key);install_key=None
            else:
                previous=winreg.QueryValueEx(install_key,'ShortcutName')[0]
                try:previous_group=winreg.QueryValueEx(install_key,'StartGroupName')[0]
                except OSError:pass
        except OSError:
            if install_key:winreg.CloseKey(install_key);install_key=None
        for directory in [desktop,programs]:
            target=directory/(new_name+'.lnk')
            if target.exists() and not link(target,False):raise ValueError('میان‌بر هم‌نام متعلق به برنامهٔ دیگری است و بازنویسی نشد.')
            tmp=directory/('AMAR-'+uuid.uuid4().hex+'.lnk');temporary.append(tmp);link(tmp,True);targets.append(target)
        for tmp,target in zip(temporary,targets):tmp.replace(target)
        if previous and (previous!=new_name or previous_group!=product_code) and shortcut_name(previous)==previous and re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,39}',previous_group):
            for directory in [desktop,programs_root/previous_group]:
                old=directory/(previous+'.lnk')
                if old in targets:continue
                if old.exists() and link(old,False):old.unlink();removed.append(str(old))
        if install_key:
            winreg.SetValueEx(install_key,'ShortcutName',0,winreg.REG_SZ,new_name);winreg.SetValueEx(install_key,'StartGroupName',0,winreg.REG_SZ,product_code);winreg.CloseKey(install_key)
            sub=r'Software\Microsoft\Windows\CurrentVersion\Uninstall\{B428B1F0-83D0-467F-8B7C-79554A1FEA2D}_is1'
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER,sub,0,winreg.KEY_WRITE|winreg.KEY_WOW64_64KEY) as registry:winreg.SetValueEx(registry,'DisplayName',0,winreg.REG_SZ,name)
            except OSError:pass
        return {'created':[str(p) for p in targets],'removed':removed}
    finally:
        for path in temporary:path.unlink(missing_ok=True)
        if coinit in [0,1]:ole.CoUninitialize()
