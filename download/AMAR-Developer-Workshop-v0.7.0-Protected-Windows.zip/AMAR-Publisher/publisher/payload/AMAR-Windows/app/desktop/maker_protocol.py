"""Offline challenge/response; the private signing key stays in the maker workshop."""
import base64,hashlib,json,secrets,time,uuid
from pathlib import Path
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey

class MakerError(ValueError):pass
MAX_FILE=32768
CHALLENGE_TTL=600
SESSION_TTL=1800

def canonical(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf-8')

def load(data):
 try:
  if len(data)>MAX_FILE:raise ValueError()
  def unique(pairs):
   result={}
   for key,value in pairs:
    if key in result:raise ValueError()
    result[key]=value
   return result
  value=json.loads(data,object_pairs_hook=unique)
  if not isinstance(value,dict):raise ValueError()
  return value
 except (ValueError,TypeError,RecursionError) as error:raise MakerError('فایل ورود سازنده معتبر نیست.') from error

def public_document(key):
 raw=key.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
 return {'format':'AMAR-Developer-Public','version':1,'public_key':base64.b64encode(raw).decode(),'fingerprint':hashlib.sha256(raw).hexdigest()}

def read_public(data):
 try:
  value=load(data);key=Ed25519PublicKey.from_public_bytes(base64.b64decode(value['public_key'],validate=True))
  if value!=public_document(key):raise ValueError()
  return key
 except (ValueError,KeyError,TypeError) as error:raise MakerError('هویت عمومی سازنده معتبر نیست.') from error

def ensure_identity(private_folder):
 folder=Path(private_folder);folder.mkdir(mode=0o700,parents=True,exist_ok=True);path=folder/'developer-key.pem'
 if path.exists():key=serialization.load_pem_private_key(path.read_bytes(),password=None)
 else:
  key=Ed25519PrivateKey.generate();data=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
  import os
  descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
  with os.fdopen(descriptor,'wb') as file:file.write(data)
 if not isinstance(key,Ed25519PrivateKey):raise MakerError('کلید خصوصی سازنده معتبر نیست.')
 return key

def challenge(installation,key,now=None):
 now=int(time.time() if now is None else now)
 return {'format':'AMAR-Developer-Challenge','version':1,'installation':str(uuid.UUID(installation)),'nonce':secrets.token_hex(32),
  'issuer':public_document(key)['fingerprint'],'issued_at':now,'expires_at':now+CHALLENGE_TTL,'capabilities':['branding']}

def validate_challenge(value,now=None):
 now=int(time.time() if now is None else now)
 try:
  if set(value)!={'format','version','installation','nonce','issuer','issued_at','expires_at','capabilities'} or value['format']!='AMAR-Developer-Challenge' or type(value['version']) is not int or value['version']!=1:raise ValueError()
  if str(uuid.UUID(value['installation']))!=value['installation'] or len(value['nonce'])!=64 or len(value['issuer'])!=64 or len(bytes.fromhex(value['nonce']))!=32 or len(bytes.fromhex(value['issuer']))!=32:raise ValueError()
  if type(value['issued_at']) is not int or type(value['expires_at']) is not int or not value['issued_at']<=now+30 or not now<value['expires_at']<=value['issued_at']+CHALLENGE_TTL:raise ValueError()
  if value['capabilities']!=['branding']:raise ValueError()
 except (KeyError,TypeError,ValueError) as error:raise MakerError('درخواست ورود معتبر نیست یا مهلتش تمام شده است؛ درخواست تازه بگیرید.') from error
 return value

def sign_challenge(content,key,now=None):
 value=validate_challenge(load(content),now)
 if value['issuer']!=public_document(key.public_key())['fingerprint']:raise MakerError('این نصب متعلق به کلید سازندهٔ دیگری است.')
 return canonical({'format':'AMAR-Developer-Access','version':1,'challenge':value,'signature':base64.b64encode(key.sign(canonical(value))).decode()})

def verify_access(content,key,expected,now=None):
 try:
  value=load(content)
  if set(value)!={'format','version','challenge','signature'} or value['format']!='AMAR-Developer-Access' or type(value['version']) is not int or value['version']!=1:raise ValueError()
  received=validate_challenge(value['challenge'],now)
  if received!=expected or received['issuer']!=public_document(key)['fingerprint']:raise ValueError()
  key.verify(base64.b64decode(value['signature'],validate=True),canonical(received));return received
 except (KeyError,TypeError,ValueError,InvalidSignature) as error:raise MakerError('مجوز ورود با این نصب و این نشست مطابقت ندارد یا امضا معتبر نیست.') from error
