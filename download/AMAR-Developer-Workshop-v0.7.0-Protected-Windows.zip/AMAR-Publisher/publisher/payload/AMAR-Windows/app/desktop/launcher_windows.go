//go:build windows

// AMAR.exe only starts the bundled, isolated Python runtime. No system Python,
// shell, package installer, network download, or administrator access is used.
package main

import (
	"os"
 "encoding/json"
	"os/exec"
	"path/filepath"
	"syscall"
	"unsafe"
)

func fail(message string) {
	user32 := syscall.NewLazyDLL("user32.dll")
	text, _ := syscall.UTF16PtrFromString(message)
	name := "AMAR"
 if self, err := os.Executable(); err == nil {
  if data, err := os.ReadFile(filepath.Join(filepath.Dir(self), "app", "data", "brand-defaults", "branding.json")); err == nil {
   var profile struct { Name string `json:"product_name"` }
   if json.Unmarshal(data, &profile) == nil && profile.Name != "" { name = profile.Name }
  }
 }
 title, _ := syscall.UTF16PtrFromString(name)
	user32.NewProc("MessageBoxW").Call(0, uintptr(unsafe.Pointer(text)), uintptr(unsafe.Pointer(title)), 0x10)
	os.Exit(1)
}

func main() {
	self, err := os.Executable()
	if err != nil { fail("Unable to locate AMAR.exe.") }
	root := filepath.Dir(self)
	python := filepath.Join(root, "runtime", "pythonw.exe")
	script := filepath.Join(root, "app", "desktop", "windows_app.py")
	if _, err := os.Stat(python); err != nil { fail("The runtime folder is missing. Run the AMAR installer again to repair the application.") }
	if _, err := os.Stat(script); err != nil { fail("The app folder is missing. Run the AMAR installer again to repair the application.") }
	args := append([]string{"-B", "-I", "-X", "utf8", script}, os.Args[1:]...)
	command := exec.Command(python, args...)
	command.Dir = root
	command.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if len(os.Args) > 1 { // Automated checks wait for the application exit code.
		if err := command.Run(); err != nil { os.Exit(1) }
		return
	}
	if err := command.Start(); err != nil { fail("Unable to start the bundled Windows runtime: " + err.Error()) }
}
