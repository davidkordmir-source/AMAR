from .access import profile
from .models import SystemConfiguration
from amar.version import VERSION,VERSION_FA

def workspace(request):
    from desktop.control import session
    from . import branding,developer,navigation
    configuration=branding.configuration() or SystemConfiguration()
    brand=branding.profile(configuration)
    p=profile(request.user) if request.user.is_authenticated else None
    principal=developer.current(request) if request.session.get(developer.SESSION_KEY) else None
    match=getattr(request,'resolver_match',None)
    maker_area=request.path.startswith('/developer/') or (match and match.url_name in ['branding_studio','branding_export'])
    return {'workspace_config':configuration,'workspace_profile':p,'app_version':VERSION,'app_version_fa':VERSION_FA,'desktop_can_close':session.available(),
        'brand_profile':brand,'brand_css':branding.css(brand,configuration),'brand_navigation':{**branding.NAVIGATION,**brand['navigation']},'brand_icon_asset':configuration.brand_desktop_icon or configuration.brand_logo,
        'developer_session':principal,'maker_area':bool(maker_area),'back_fallback':navigation.fallback(request),'navigation_scope':(('maker-'+str(principal.ticket) if principal else 'maker-login') if maker_area else str(request.user.pk or 'public')),
        'workspace_name':p.display_name if p and p.display_name else (request.user.get_full_name() or request.user.get_username()) if request.user.is_authenticated else '',
        'workspace_title':p.position_title if p and p.position_title else configuration.owner_title if request.user.is_superuser else p.role.name if p and p.role else ''}
