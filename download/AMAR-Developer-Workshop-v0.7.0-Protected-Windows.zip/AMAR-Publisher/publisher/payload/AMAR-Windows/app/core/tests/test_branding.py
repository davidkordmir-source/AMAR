import io,json,tempfile,zipfile
from pathlib import Path
from datetime import timedelta
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client,override_settings,SimpleTestCase,TransactionTestCase
from django.utils import timezone
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from core import branding,developer,models as m
from desktop import maker_protocol as protocol
from desktop.brand_profile import DEFAULT,NAVIGATION,COPY,BrandError,validate,write_bundle,read_bundle,install_defaults
from .test_enterprise import EnterpriseBase

def logo_bytes(color='#087f83'):
 from PIL import Image,ImageDraw
 image=Image.new('RGBA',(180,180),(255,255,255,0));ImageDraw.Draw(image).rounded_rectangle((20,20,160,160),radius=25,fill=color)
 stream=io.BytesIO();image.save(stream,format='PNG');return stream.getvalue()

class MakerFixture:
 def maker_setup(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);self.data_dir=self.root/'data';self.data_dir.mkdir();self.app_dir=self.root/'app';(self.app_dir/'data').mkdir(parents=True)
  self.override=override_settings(DATA_DIR=self.data_dir,BASE_DIR=self.app_dir);self.override.enable();self.addCleanup(self.override.disable)
  self.key=Ed25519PrivateKey.generate();(self.app_dir/'data/developer-public.json').write_bytes(protocol.canonical(protocol.public_document(self.key.public_key())))
  self.maker=Client();self.grant=self.authorize(self.maker)
 def authorize(self,client):
  client.get('/developer/login/');challenge=client.get('/developer/challenge/').json();grant=protocol.sign_challenge(protocol.canonical(challenge),self.key)
  kwargs={}
  if client.cookies.get('csrftoken'):kwargs['HTTP_X_CSRFTOKEN']=client.cookies['csrftoken'].value
  response=client.post('/developer/login/',{'access_file':SimpleUploadedFile('access.json',grant)},**kwargs)
  self.assertEqual(response.status_code,302);return grant
 def principal(self):
  value=self.maker.session[developer.SESSION_KEY];return developer.Principal(value['ticket'],value['issuer'],value['expires'])
 def form_data(self,**changes):
  result={'product_name':'سامانهٔ سپید','product_code':'Sepid','tagline':'کنترل مجموعهٔ کارخانه‌ها','publisher':'شرکت نمونه',**DEFAULT['theme']}
  result.update({'nav_'+key:label for key,label in NAVIGATION.items()});result.update({'copy_'+key:value[0] for key,value in COPY.items()});result.update(changes);return result

class MakerBrandingTests(MakerFixture,EnterpriseBase):
 def setUp(self):super().setUp();self.maker_setup();self.client.force_login(self.owner)
 def test_every_company_role_including_ceo_is_denied_without_maker_grant(self):
  another=get_user_model().objects.create_superuser(username='other-root')
  for user in [self.owner,self.requester,self.finance,another]:
   self.client.force_login(user)
   for path in ['/configuration/branding/','/configuration/branding/export/','/configuration/branding/shortcuts/']:
    self.assertEqual(self.client.post(path,self.form_data()).status_code,403,path)
   self.assertNotContains(self.client.get('/'),'href="/configuration/branding/"')
  with self.assertRaises(PermissionDenied):branding.save_profile(self.owner,DEFAULT)
  self.assertEqual(self.maker.get('/configuration/branding/').status_code,200)
 def test_separate_maker_can_edit_detailed_theme_and_three_images_without_business_access(self):
  before=(self.account.balance,m.StockMovement.objects.count(),m.MoneyEntry.objects.count())
  data=self.form_data(mode='dark',primary='#147d53',font_size=17,sidebar_width=320,background_opacity=36,nav_inventory='موجودی مجموعه')
  for kind,color in [('logo','#087f83'),('desktop_icon','#1d4ed8'),('background','#f7ceaa')]:data[kind]=SimpleUploadedFile(kind+'.png',logo_bytes(color),'image/png')
  self.assertEqual(self.maker.post('/configuration/branding/',data).status_code,302)
  cfg=m.SystemConfiguration.objects.get(pk=1);self.assertEqual(cfg.brand_name,'سامانهٔ سپید');self.assertEqual(cfg.brand_product_code,'Sepid');self.assertEqual(cfg.brand_theme['font_size'],17)
  self.assertEqual(len({cfg.brand_logo_id,cfg.brand_desktop_icon_id,cfg.brand_background_id}),3)
  self.assertEqual(before,(self.account.balance,m.StockMovement.objects.count(),m.MoneyEntry.objects.count()))
  self.assertFalse(self.maker.session.get('_auth_user_id'))
  self.assertEqual(self.maker.get('/finance/').status_code,302)
  response=self.client.get('/inventory/');self.assertContains(response,'data-brand-mode="dark"');self.assertContains(response,'موجودی مجموعه');self.assertContains(response,'--brand-font-size:17px')
  self.assertEqual(self.client.get('/identity/background.png').content,branding.read_logo(cfg.brand_background))
  self.assertNotEqual(self.client.get('/identity/desktop-icon.png').content,self.client.get('/identity/logo.png').content)
 def test_ceo_cannot_rename_from_legacy_form_or_settings(self):
  cfg=m.SystemConfiguration.objects.create(pk=1,brand_owner=self.owner,brand_name='نام ثابت')
  self.assertEqual(self.client.post('/configuration/name/',{'brand_name':'نام جعلی'}).status_code,403)
  from core.enterprise_forms import SystemForm
  data={key:getattr(cfg,key) for key in SystemForm.base_fields};data['brand_name']='نام جعلی';data['owner_title']='عنوان دلخواه'
  self.assertEqual(self.client.post('/configuration/',data).status_code,302);cfg.refresh_from_db();self.assertEqual(cfg.brand_name,'نام ثابت');self.assertEqual(cfg.owner_title,'عنوان دلخواه')
 def test_another_superuser_cannot_take_over_business_owner_or_global_admin(self):
  other=get_user_model().objects.create_superuser(username='takeover-root');self.client.force_login(other)
  self.assertEqual(self.client.post(f'/access/users/{self.owner.pk}/',{'password':'takeover'}).status_code,403)
  from django.contrib import admin
  from types import SimpleNamespace
  self.assertFalse(admin.site.has_permission(SimpleNamespace(user=other)))
 def test_export_contains_only_presentation_and_reimports_all_assets(self):
  assets={'logo':logo_bytes(),'background':logo_bytes('#cf811d'),'desktop_icon':logo_bytes('#734fe0')}
  branding.save_profile(self.principal(),{**DEFAULT,'product_name':'برند صادراتی'},assets)
  response=self.maker.post('/configuration/branding/export/');value,received=read_bundle(response.content)
  self.assertEqual(value['product_name'],'برند صادراتی');self.assertEqual(set(received),set(assets))
  with zipfile.ZipFile(io.BytesIO(response.content)) as archive:self.assertEqual(set(archive.namelist()),{'branding.json','logo.png','background.png','desktop-icon.png','README-fa.txt'})
  branding.save_profile(self.principal(),DEFAULT,remove=assets)
  self.assertEqual(self.maker.post('/configuration/branding/',{'action':'import','brand_bundle':SimpleUploadedFile('AMAR-Branding.zip',response.content)}).status_code,302)
  cfg=m.SystemConfiguration.objects.get(pk=1);self.assertIsNotNone(cfg.brand_background_id);self.assertEqual(cfg.brand_name,'برند صادراتی')
 def test_invalid_colors_svg_ranges_and_executable_names_are_rejected(self):
  for change in [{'primary':'red;display:none'},{'mode':'custom'},{'font_size':999},{'product_code':'../../app'},{'product_code':'CON'},{'logo':SimpleUploadedFile('bad.svg',b'<svg/>','image/svg+xml')}]:
   self.assertEqual(self.maker.post('/configuration/branding/',self.form_data(**change)).status_code,200)
  self.assertFalse(m.BrandLogo.objects.exists())
 def test_expiry_and_logout_revoke_maker_rights(self):
  m.DeveloperChallenge.objects.filter(pk=self.principal().ticket).update(access_expires_at=timezone.now()-timedelta(seconds=1))
  self.assertEqual(self.maker.post('/configuration/branding/',self.form_data()).status_code,403)
  self.authorize(self.maker);self.assertEqual(self.maker.post('/developer/logout/').status_code,302)
  self.assertEqual(self.maker.post('/configuration/branding/export/').status_code,403)
 def test_copying_company_session_data_cannot_impersonate_the_maker(self):
  stolen=Client();stolen.cookies['sessionid']=self.maker.session.session_key
  self.assertEqual(stolen.post('/configuration/branding/',self.form_data()).status_code,403)
  self.assertNotContains(stolen.get('/login/'),'استودیوی اختصاصی سازنده')
 def test_grant_cannot_be_reused_by_another_browser_or_after_logout(self):
  other=Client();other.get('/developer/login/')
  result=other.post('/developer/login/',{'access_file':SimpleUploadedFile('access.json',self.grant)})
  self.assertEqual(result.status_code,200);self.assertNotIn(developer.SESSION_KEY,other.session)
  self.maker.post('/developer/logout/');self.maker.get('/developer/login/')
  self.maker.post('/developer/login/',{'access_file':SimpleUploadedFile('access.json',self.grant)})
  self.assertNotIn(developer.SESSION_KEY,self.maker.session)
 def test_forged_signature_and_wrong_maker_key_cannot_authenticate(self):
  other=Client();value=other.get('/developer/challenge/').json()
  forged={'format':'AMAR-Developer-Access','version':1,'challenge':value,'signature':'AAAA'}
  self.assertEqual(other.post('/developer/login/',{'access_file':SimpleUploadedFile('fake.json',protocol.canonical(forged))}).status_code,200)
  self.assertNotIn(developer.SESSION_KEY,other.session)
  with self.assertRaises(protocol.MakerError):protocol.sign_challenge(protocol.canonical(value),Ed25519PrivateKey.generate())
 def test_csrf_is_required_even_after_valid_maker_login(self):
  client=Client(enforce_csrf_checks=True);self.authorize(client)
  self.assertEqual(client.post('/configuration/branding/',self.form_data()).status_code,403)
  self.assertEqual(client.post('/configuration/branding/export/').status_code,403)
 def test_pinned_maker_key_survives_replacement_of_the_packaged_key(self):
  expected=protocol.public_document(developer.trusted_key());other=Ed25519PrivateKey.generate()
  (self.app_dir/'data/developer-public.json').write_bytes(protocol.canonical(protocol.public_document(other.public_key())))
  self.assertEqual(protocol.public_document(developer.trusted_key()),expected)
 def test_packaged_defaults_seed_only_new_install_and_preserve_local_edits(self):
  install_defaults(self.app_dir/'data/brand-defaults',{**DEFAULT,'product_name':'نام نسخهٔ نصبی'},{'logo':logo_bytes()})
  first=branding.apply_packaged_defaults();self.assertEqual(first.brand_name,'نام نسخهٔ نصبی')
  branding.save_profile(self.principal(),{**DEFAULT,'product_name':'نام سازنده'})
  self.assertEqual(branding.apply_packaged_defaults().brand_name,'نام سازنده')

class BrandingArchiveTests(SimpleTestCase):
 def test_version_one_profiles_upgrade_without_losing_choices(self):
  old={'format':'AMAR-Branding','version':1,'product_name':'قدیمی','theme':{'size':'large','rounding':'square','sidebar':'wide'},'navigation':{}}
  value=validate(old);self.assertEqual((value['theme']['font_size'],value['theme']['radius'],value['theme']['sidebar_width']),(15,4,280));self.assertEqual(value['version'],2)
 def test_archive_roundtrip_and_css_injection_guard(self):
  profile,assets=read_bundle(write_bundle(DEFAULT,logo_bytes()));self.assertEqual(profile['theme'],DEFAULT['theme']);self.assertTrue(assets['logo'])
  for theme in [{'primary':'#ffffff;--ink:red'},{'font':[]},{'sidebar':'9999px'},{'background_blur':False},{'background_opacity':-1}]:
   with self.assertRaises(BrandError):validate({**DEFAULT,'theme':theme})
 def test_archive_rejects_traversal_unexpected_files_and_private_keys(self):
  for bad in ['../secret.key','amar.sqlite3','logo.svg','developer-key.pem']:
   stream=io.BytesIO()
   with zipfile.ZipFile(stream,'w') as archive:archive.writestr('branding.json',json.dumps(DEFAULT));archive.writestr(bad,b'bad')
   with self.assertRaises(BrandError):read_bundle(stream.getvalue())
 def test_maker_protocol_rejects_expired_grants_and_duplicate_json_keys(self):
  key=Ed25519PrivateKey.generate();value=protocol.challenge('11111111-1111-1111-1111-111111111111',key.public_key(),now=100)
  with self.assertRaises(protocol.MakerError):protocol.sign_challenge(protocol.canonical(value),key,now=701)
  with self.assertRaises(protocol.MakerError):protocol.load(b'{"version":1,"version":2}')

class BrandingBackupTests(MakerFixture,TransactionTestCase):
 def setUp(self):self.maker_setup()
 def test_backup_preserves_all_image_versions_and_pinned_trust_and_refuses_missing_file(self):
  import sqlite3
  from contextlib import closing
  from django.core.management import call_command
  from django.core.management.base import CommandError
  from scripts.restore_backup import restore
  branding.save_profile(self.principal(),{**DEFAULT,'product_name':'هویت نخست'},{'logo':logo_bytes(),'background':logo_bytes('#ddaa55')})
  branding.save_profile(self.principal(),{**DEFAULT,'product_name':'هویت تازه'},{'logo':logo_bytes('#113355')})
  target=self.root/'complete.zip';call_command('backup_local',output=str(target),stdout=io.StringIO());restored=restore(target,self.root/'restored')
  with closing(sqlite3.connect(restored/'amar.sqlite3')) as database:
   rows=database.execute('SELECT filename,digest FROM core_brandlogo').fetchall();name=database.execute('SELECT brand_name FROM core_systemconfiguration').fetchone()[0]
  self.assertEqual(name,'هویت تازه');self.assertEqual(len(rows),3)
  self.assertEqual((restored/'developer-trust.json').read_bytes(),(self.data_dir/'developer-trust.json').read_bytes())
  for filename,digest in rows:self.assertEqual((self.data_dir/'branding'/filename).read_bytes(),(restored/'branding'/filename).read_bytes())
  (self.data_dir/'branding'/rows[0][0]).unlink()
  with self.assertRaises(CommandError):call_command('backup_local',output=str(self.root/'incomplete.zip'),stdout=io.StringIO())
