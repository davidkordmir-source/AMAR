"""Safe local fallback when a page has no per-tab visit history."""
from django.urls import reverse

def fallback(request):
    path=request.path
    routes=[('/contracts/','contracts'),('/finance/','finance'),('/inventory/','inventory'),('/documents/','documents'),('/access/','access_center'),('/master/','directory'),('/directory/','directory'),('/control/','control'),('/structure/','structure'),('/geography/','geography'),('/exchange/','exchange'),('/configuration/','dashboard'),('/developer/','login')]
    for prefix,name in routes:
        if path.startswith(prefix):
            destination=reverse(name)
            return reverse('dashboard') if destination==path else destination
    return reverse('dashboard')
