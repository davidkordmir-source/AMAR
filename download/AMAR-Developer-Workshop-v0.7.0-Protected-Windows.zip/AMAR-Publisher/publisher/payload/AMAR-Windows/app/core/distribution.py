"""Explicit, recipient-bound delivery of a subsidiary's permitted report data."""
import re,json
from django import forms
from django.contrib.auth.decorators import login_required,permission_required
from django.core.exceptions import ValidationError
from django.http import HttpResponse
from django.shortcuts import render
from . import models as m,sync
from .access import factory_ids

class RecipientField(forms.ModelChoiceField):
    def label_from_instance(self,obj):return obj.label+' / '+obj.branch.name

class DistributionForm(forms.Form):
    recipient=RecipientField(label='نصب مقصدِ معرفی‌شده',queryset=m.TrustedSource.objects.none(),help_text='ابتدا هویت عمومی نصب زیرمجموعه را در تبادلات اطلاعات معرفی و به موقعیت خودش متصل کنید.')
    sections=forms.MultipleChoiceField(label='فقط این داده‌ها ارسال شوند',choices=[('inventory','موجودی انبار موقعیت'),('contracts','قراردادهای صریحاً مجاز موقعیت'),('accounts','اطلاعات مالی موقعیت')],widget=forms.CheckboxSelectMultiple,initial=['inventory','contracts'])
    include_descendants=forms.BooleanField(label='زیرموقعیت‌های همین مقصد هم در گزارش باشند',required=False,initial=False)
    def __init__(self,*args,actor,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['recipient'].queryset=m.TrustedSource.objects.filter(branch_id__in=factory_ids(actor)).select_related('branch').order_by('label')

@login_required
@permission_required('core.export_branch_data',raise_exception=True)
def prepare(request):
    form=DistributionForm(request.POST or None,actor=request.user)
    if request.method=='POST' and form.is_valid():
        try:
            data=form.cleaned_data;recipient=data['recipient']
            # Refresh the mapping immediately before export; a changed mapping fails closed.
            content=sync.export_report(request.user,target_branch=recipient.branch_id,recipient=recipient.source_id,sections=data['sections'],include_descendants=data['include_descendants'])
            code=re.sub(r'[^A-Za-z0-9_-]','',recipient.branch.code)[:40] or str(recipient.source_id)[:8]
            sequence=json.loads(content)['payload']['sequence']
            response=HttpResponse(content,content_type='application/json');response['Content-Disposition']=f'attachment; filename="AMAR-{code}-Report-{sequence}.amar"';response['Cache-Control']='private, no-store';return response
        except ValidationError as error:form.add_error(None,error)
    return render(request,'core/distribution.html',{'page_title':'آماده‌سازی اطلاعات محدود زیرمجموعه','active_page':'exchange','form':form})
