import io,json,tempfile,uuid
from pathlib import Path
from unittest.mock import patch
from django.contrib.auth.models import Permission
from django.core.exceptions import ValidationError,PermissionDenied
from django.test import override_settings
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from desktop.maker_protocol import public_document
from core import models as m,sync
from .test_enterprise import EnterpriseBase

class RecipientReportTests(EnterpriseBase):
 def setUp(self):
  super().setUp();self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.override=override_settings(DATA_DIR=Path(self.temp.name));self.override.enable();self.addCleanup(self.override.disable)
  self.child_key=Ed25519PrivateKey.generate();self.child_id=uuid.uuid4()
  self.destination=m.TrustedSource.objects.create(label='نصب مستقل کارخانه یک',source_id=self.child_id,public_key=public_document(self.child_key.public_key())['public_key'],branch=self.leaf)
  self.allowed,_=self.contract('CHILD-ALLOWED',True)
  self.hidden,_=self.contract('SECRET-LARGE-HQ-CONTRACT')
  self.foreign_contract,_=self.contract('FOREIGN-CONTRACT',True,warehouse=self.dest)
  self.client.force_login(self.owner)
 def report(self,**changes):
  options={'target_branch':self.leaf.pk,'recipient':self.child_id,'sections':['inventory','contracts'],'include_descendants':False};options.update(changes)
  return sync.export_report(self.owner,**options)
 def register_parent(self):
  parent=sync.public_identity();m.TrustedSource.objects.create(label='مرکز',source_id=parent['source_id'],public_key=parent['public_key']);return parent
 def test_only_destination_records_explicit_contract_grants_and_selected_sections_are_exported(self):
  report=self.report();value=json.loads(report);payload=value['payload']
  self.assertEqual(value['version'],2);self.assertEqual(payload['recipient_id'],str(self.child_id));self.assertEqual([b['code'] for b in payload['branches']],['SMALL-A'])
  self.assertEqual([c['number'] for c in payload['contracts']],['CHILD-ALLOWED']);self.assertEqual(payload['accounts'],[])
  self.assertNotIn(b'SECRET-LARGE-HQ-CONTRACT',report);self.assertNotIn(b'FOREIGN-CONTRACT',report)
 def test_financial_section_is_opt_in_and_pending_does_not_leak_excluded_contracts(self):
  payload=json.loads(self.report(sections=['inventory']))['payload'];self.assertEqual(payload['accounts'],[]);self.assertEqual(payload['contracts'],[])
  self.assertTrue(all(row['pending']=='0' for row in payload['inventory']))
  payload=json.loads(self.report(sections=['accounts']))['payload'];self.assertEqual(len(payload['accounts']),1);self.assertEqual(payload['inventory'],[])
 def test_wrong_installation_is_denied_even_for_company_superuser(self):
  report=self.report();self.register_parent()
  with patch('core.sync.identity',return_value=(str(uuid.uuid4()),Ed25519PrivateKey.generate())):
   with self.assertRaisesMessage(ValidationError,'نصب دیگری'):sync.import_report(report,self.owner)
  self.assertFalse(m.ImportedSnapshot.objects.exists())
 def test_bound_report_is_accepted_by_its_intended_installation(self):
  report=self.report();self.register_parent()
  with patch('core.sync.identity',return_value=(str(self.child_id),self.child_key)):
   snapshot=sync.import_report(report,self.owner)
   self.assertEqual(snapshot.payload['recipient_id'],str(self.child_id))
 def test_downgrading_envelope_version_cannot_remove_recipient_binding(self):
  value=json.loads(self.report());value['version']=1;self.register_parent()
  with self.assertRaises(ValidationError):sync.import_report(sync.canonical(value),self.owner)
  self.assertFalse(m.ImportedSnapshot.objects.exists())
 def test_revoked_branch_contract_grants_are_removed_from_later_deliveries(self):
  m.ContractGrant.objects.filter(contract=self.allowed).delete()
  self.assertEqual(json.loads(self.report())['payload']['contracts'],[])
 def test_wizard_defaults_exclude_finance_and_rejects_wrong_recipient_mapping(self):
  response=self.client.get('/exchange/prepare/');self.assertEqual(response.status_code,200);self.assertNotIn('accounts',response.context['form'].fields['sections'].initial)
  response=self.client.post('/exchange/prepare/',{'recipient':self.destination.pk,'sections':['inventory','contracts']});self.assertEqual(response.status_code,200);self.assertEqual(json.loads(response.content)['version'],2)
  self.destination.branch=self.foreign;self.destination.save()
  with self.assertRaises(ValidationError):self.report()
 def test_scoped_user_cannot_pick_foreign_installation_or_export_foreign_branch(self):
  self.requester.factory_profile.role.permissions.add(Permission.objects.get(content_type__app_label='core',codename='export_branch_data'))
  other=m.TrustedSource.objects.create(label='نصب دیگر',source_id=uuid.uuid4(),public_key=self.destination.public_key,branch=self.foreign)
  self.client.force_login(self.requester)
  response=self.client.post('/exchange/prepare/',{'recipient':other.pk,'sections':['accounts']});self.assertEqual(response.status_code,200);self.assertTrue(response.context['form'].errors)
  with self.assertRaises(PermissionDenied):sync.export_report(self.requester,target_branch=self.foreign.pk,recipient=other.source_id,sections=['inventory'])
