"""Maker-only presentation changes and sanitized public presentation assets."""
import hashlib,json,os,uuid
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied,ValidationError
from django.db import transaction
from . import models as m
from .request_cache import memo
from desktop.brand_profile import DEFAULT,NAVIGATION,ASSETS,BrandError,validate,normalize_asset,icon_bytes

def configuration():
 return memo(('brand-configuration',),lambda:m.SystemConfiguration.objects.select_related('brand_logo','brand_background','brand_desktop_icon').filter(pk=1).first())

def owner_id(config=None):
 config=config if config is not None else configuration()
 if config and config.brand_owner_id:return config.brand_owner_id
 return memo(('brand-owner',),lambda:get_user_model().objects.filter(is_superuser=True,is_active=True).order_by('date_joined','pk').values_list('pk',flat=True).first())

def is_owner(actor,config=None):
 # This remains the business installation owner; it grants no maker privileges.
 return bool(actor and actor.is_authenticated and actor.is_active and actor.is_superuser and actor.pk==owner_id(config))

def require_owner(actor,config=None):
 raise PermissionDenied('تغییر هویت نرم‌افزار نیازمند ورود جداگانهٔ سازنده است.')

def profile(config=None):
 config=config if config is not None else configuration()
 if not config:return validate(DEFAULT)
 value={**DEFAULT,'product_name':config.brand_name,'product_code':config.brand_product_code,'tagline':config.brand_tagline,'publisher':config.brand_publisher,
  'theme':config.brand_theme,'copy':config.brand_copy,'navigation':config.brand_navigation}
 # An old theme is upgraded through v1 defaults without rewriting the saved appearance.
 if config.brand_theme and 'font_size' not in config.brand_theme:value['version']=1
 try:return validate(value)
 except BrandError:return {**validate(DEFAULT),'product_name':config.brand_name}

def css(value,config=None):
 value=validate(value);theme=value['theme'];color=theme['primary']
 rgb=[int(color[index:index+2],16)/255 for index in [1,3,5]]
 luminance=sum(weight*(x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4) for x,weight in zip(rgb,[.2126,.7152,.0722]))
 ink='#111827' if (luminance+.05)/.05>1.05/(luminance+.05) else '#ffffff'
 pale='rgb('+','.join(str(round(255*.92+c*255*.08)) for c in rgb)+')'
 palette={'page_color':'#f7f8fc','card_color':'#ffffff','sidebar_color':'#ffffff','sidebar_text':'#62667d','header_color':'#ffffff','text_color':'#222538','muted_color':'#6d7285','border_color':'#ececf3'}
 if theme['mode']=='dark':palette.update(page_color='#141a27',card_color='#1d2535',sidebar_color='#1d2535',sidebar_text='#b7c3dc',header_color='#1d2535',text_color='#e9edf8',muted_color='#a5b0c5',border_color='#344056')
 if theme['custom_colors']:palette={key:theme[key] for key in palette}
 crgb=[int(palette['card_color'][i:i+2],16) for i in [1,3,5]]
 properties={'purple':color,'purple-pale':pale,'brand-on-primary':ink,'ink':palette['text_color'],'muted':palette['muted_color'],'bg':palette['page_color'],
  'surface':palette['card_color'],'line':palette['border_color'],'brand-sidebar-bg':palette['sidebar_color'],'brand-sidebar-ink':palette['sidebar_text'],'brand-header-bg':palette['header_color'],
  'brand-surface-alpha':f'rgba({crgb[0]},{crgb[1]},{crgb[2]},{theme["card_opacity"]/100})','green':theme['success_color'],'brand-warning':theme['warning_color'],'brand-danger':theme['danger_color'],
  'radius':str(theme['radius'])+'px','sidebar':str(theme['sidebar_width'])+'px','brand-font-size':str(theme['font_size'])+'px','brand-heading-size':str(theme['heading_size'])+'px',
  'brand-logo-size':str(theme['logo_size'])+'px','brand-button-radius':str(theme['button_radius'])+'px','brand-background-opacity':str(theme['background_opacity']/100),
  'brand-background-blur':str(theme['background_blur'])+'px','brand-background-fit':'auto' if theme['background_fit']=='repeat' else theme['background_fit'],
  'brand-background-repeat':'repeat' if theme['background_fit']=='repeat' else 'no-repeat','brand-background-position':theme['background_position'],
  'brand-row-padding':'8px 12px' if theme['density']=='compact' else '14px 18px','brand-shadow':{'none':'none','soft':'0 4px 22px #18203a06','strong':'0 10px 35px #18203a24'}[theme['shadow']]}
 if config and config.brand_background_id:properties['brand-background-image']=f'url("/identity/background.png?v={config.brand_background.digest}")'
 return ''.join('--'+key+':'+val+';' for key,val in properties.items())

def logo_path(logo,icon=False):return settings.DATA_DIR/'branding'/(logo.filename+('.ico' if icon else ''))

def read_logo(logo):
 path=logo_path(logo)
 if not path.is_file():raise ValidationError('فایل تصویر هویت در محل نگهداری موجود نیست.')
 data=path.read_bytes()
 if hashlib.sha256(data).hexdigest()!=logo.digest:raise ValidationError('فایل تصویر با نسخهٔ ثبت‌شده همخوانی ندارد.')
 return data

def current_assets(config=None):
 config=config if config is not None else configuration()
 if not config:return {}
 return {kind:read_logo(asset) for kind in ASSETS if (asset:=getattr(config,'brand_'+kind,None)) is not None}

def native_icon(config):
 asset=config.brand_desktop_icon or config.brand_logo
 if asset:
  path=logo_path(asset,True)
  if not path.is_file():path.write_bytes(icon_bytes(read_logo(asset)))
  return path
 color=profile(config)['theme']['primary'];folder=settings.DATA_DIR/'branding';folder.mkdir(mode=0o700,parents=True,exist_ok=True);path=folder/('fallback-'+color[1:]+'.ico')
 if not path.is_file():
  temporary=folder/(uuid.uuid4().hex+'.ico.tmp')
  try:temporary.write_bytes(icon_bytes(primary=color));temporary.replace(path)
  finally:temporary.unlink(missing_ok=True)
 return path

def _store_logo(data,actor=None,kind='logo'):
 data,width,height=normalize_asset(data,kind);folder=settings.DATA_DIR/'branding';folder.mkdir(mode=0o700,parents=True,exist_ok=True)
 filename=uuid.uuid4().hex+'.png';path=folder/filename;descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(descriptor,'wb') as file:file.write(data)
 try:
  if kind!='background':(folder/(filename+'.ico')).write_bytes(icon_bytes(data))
  return m.BrandLogo.objects.create(filename=filename,digest=hashlib.sha256(data).hexdigest(),width=width,height=height,created_by=actor)
 except Exception:path.unlink(missing_ok=True);(folder/(filename+'.ico')).unlink(missing_ok=True);raise

def save_profile(principal,value,assets=None,remove=()):
 from .developer import require_principal
 require_principal(principal);value=validate(value);created=[];assets=assets or {}
 if set(assets)-set(ASSETS) or set(remove)-set(ASSETS):raise BrandError('نوع تصویر هویت معتبر نیست.')
 try:
  with transaction.atomic():
   config,_=m.SystemConfiguration.objects.get_or_create(pk=1);config=m.SystemConfiguration.objects.select_for_update().get(pk=1);require_principal(principal);before=profile(config)
   for kind in ASSETS:
    if assets.get(kind):record=_store_logo(assets[kind],kind=kind);created.append(record);setattr(config,'brand_'+kind,record)
    elif kind in remove:setattr(config,'brand_'+kind,None)
   config.brand_name=value['product_name'];config.brand_product_code=value['product_code'];config.brand_tagline=value['tagline'];config.brand_publisher=value['publisher'];config.brand_theme=value['theme'];config.brand_copy=value['copy'];config.brand_navigation=value['navigation'];config.save()
   from .services import audit
   audit('ویرایش هویت نرم‌افزار توسط سازنده',config.brand_name,None,json.dumps({'before':before,'after':value,'maker':principal.issuer},ensure_ascii=False))
   from desktop.backend import set_brand_assets
   icon=native_icon(config);transaction.on_commit(lambda:set_brand_assets(config.brand_name,icon))
   return config
 except Exception:
  for record in created:logo_path(record).unlink(missing_ok=True);logo_path(record,True).unlink(missing_ok=True)
  raise

@transaction.atomic
def apply_packaged_defaults():
 path=settings.BASE_DIR/'data/brand-defaults';manifest=path/'branding.json'
 try:value=validate(json.loads(manifest.read_text(encoding='utf-8')))
 except (OSError,ValueError):value=validate(DEFAULT)
 config,created=m.SystemConfiguration.objects.get_or_create(pk=1,defaults={'brand_name':value['product_name'],'brand_product_code':value['product_code'],'brand_tagline':value['tagline'],'brand_publisher':value['publisher'],'brand_theme':value['theme'],'brand_copy':value['copy'],'brand_navigation':value['navigation']})
 if created:
  for kind,name in ASSETS.items():
   if (path/name).is_file():setattr(config,'brand_'+kind,_store_logo((path/name).read_bytes(),kind=kind))
 if not config.brand_owner_id:config.brand_owner_id=owner_id(config)
 config.save()
 from .request_cache import invalidate
 invalidate();return config
