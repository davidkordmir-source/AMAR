"""Maker authentication is independent of every company role, including superusers."""
from dataclasses import dataclass
from datetime import datetime,timedelta,timezone as dt_timezone
from functools import wraps
import hashlib,json,secrets,time
from pathlib import Path
from django.conf import settings
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.shortcuts import redirect,render
from django.http import HttpResponse
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_POST,require_http_methods
from amar.localfiles import private_file
from desktop import maker_protocol as protocol
from . import models as m

SESSION_KEY='developer_access'
COOKIE='AMARDeveloper'

def digest(value):return hashlib.sha256(value.encode()).hexdigest()

def trusted_key():
    """Pin the first maker key outside the editable database; preserve it on upgrade."""
    path=settings.DATA_DIR/'developer-trust.json'
    if path.is_file():return protocol.read_public(path.read_bytes())
    packaged=settings.BASE_DIR/'data/developer-public.json'
    if not packaged.is_file():raise protocol.MakerError('هویت سازنده برای این بسته تنظیم نشده است؛ بستهٔ رسمی سازنده را نصب کنید.')
    data=packaged.read_bytes();protocol.read_public(data)
    return protocol.read_public(private_file(path,lambda:data))

@dataclass(frozen=True)
class Principal:
    ticket:int
    issuer:str
    expires:int

def require_principal(value):
    if not isinstance(value,Principal) or value.expires<=int(time.time()):raise PermissionDenied('ورود معتبر سازنده لازم است.')
    if not m.DeveloperChallenge.objects.filter(pk=value.ticket,issuer=value.issuer,consumed_at__isnull=False,access_expires_at__gt=timezone.now()).exists():raise PermissionDenied('مجوز سازنده پایان یافته است.')
    return value

def current(request):
    access=request.session.get(SESSION_KEY)
    if not isinstance(access,dict):return None
    token=request.COOKIES.get(COOKIE,'')
    if not 32<=len(token)<=128:return None
    try:
        value=Principal(access['ticket'],access['issuer'],access['expires'])
        row=m.DeveloperChallenge.objects.filter(pk=value.ticket,session_hash=digest(request.session.session_key or ''),issuer=value.issuer,consumed_at__isnull=False,access_expires_at__gt=timezone.now()).first()
        if value.expires<=int(time.time()) or not row or not secrets.compare_digest(row.access_token_hash,digest(token)):return None
        if protocol.public_document(trusted_key())['fingerprint']!=value.issuer:return None
        return value
    except (KeyError,TypeError,ValueError):return None

def required(view):
    @never_cache
    @wraps(view)
    def guarded(request,*args,**kwargs):
        principal=current(request)
        if principal is None:
            if request.method=='GET':return redirect('developer_login')
            raise PermissionDenied('ویرایش هویت نرم‌افزار فقط پس از ورود جداگانهٔ سازنده مجاز است.')
        request.developer_principal=principal
        return view(request,*args,**kwargs)
    return guarded

def get_challenge(request,renew=False):
    key=trusted_key()
    from .sync import identity
    installation=identity()[0]
    existing=request.session.get('developer_challenge')
    if existing and not renew:
        try:
            protocol.validate_challenge(existing)
            if existing['issuer']==protocol.public_document(key)['fingerprint'] and m.DeveloperChallenge.objects.filter(nonce_hash=digest(existing['nonce']),session_hash=digest(request.session.session_key or ''),consumed_at__isnull=True).exists():return existing
        except protocol.MakerError:pass
    # Keep only one outstanding challenge per browser; retries cannot grow the table.
    if not request.session.session_key:request.session.create()
    m.DeveloperChallenge.objects.filter(session_hash=digest(request.session.session_key),consumed_at__isnull=True).delete()
    m.DeveloperChallenge.objects.filter(expires_at__lt=timezone.now()-timedelta(days=1),access_expires_at__isnull=True).delete()
    value=protocol.challenge(installation,key)
    m.DeveloperChallenge.objects.create(nonce_hash=digest(value['nonce']),session_hash=digest(request.session.session_key),installation=installation,issuer=value['issuer'],expires_at=datetime.fromtimestamp(value['expires_at'],dt_timezone.utc))
    request.session['developer_challenge']=value
    return value

@never_cache
@require_http_methods(['GET','POST'])
def login(request):
    if current(request):return redirect('branding_studio')
    error='';value=None
    try:
        value=get_challenge(request)
        if request.method=='POST':
            upload=request.FILES.get('access_file')
            if not upload:raise protocol.MakerError('فایل مجوز امضاشدهٔ سازنده را انتخاب کنید.')
            protocol.verify_access(upload.read(protocol.MAX_FILE+1),trusted_key(),value)
            now=timezone.now();expiry=now+timedelta(seconds=protocol.SESSION_TTL)
            with transaction.atomic():
                row=m.DeveloperChallenge.objects.select_for_update().get(nonce_hash=digest(value['nonce']))
                if row.consumed_at or row.expires_at<=now or row.session_hash!=digest(request.session.session_key):raise protocol.MakerError('این مجوز قبلاً استفاده شده یا مهلت آن تمام شده است.')
                # Rotate the cookie after verification; the grant cannot authenticate another browser.
                token=secrets.token_urlsafe(32)
                request.session.cycle_key();row.consumed_at=now;row.access_expires_at=expiry;row.session_hash=digest(request.session.session_key);row.access_token_hash=digest(token);row.save(update_fields=['consumed_at','access_expires_at','session_hash','access_token_hash'])
                request.session.pop('developer_challenge',None)
                request.session[SESSION_KEY]={'ticket':row.pk,'issuer':row.issuer,'expires':int(expiry.timestamp())}
                from .services import audit
                audit('ورود جداگانهٔ سازنده','هویت نرم‌افزار',None,'اثر انگشت سازنده: '+row.issuer)
            response=redirect('branding_studio');response.set_cookie(COOKIE,token,max_age=protocol.SESSION_TTL,httponly=True,samesite='Strict',secure=settings.SESSION_COOKIE_SECURE)
            return response
    except protocol.MakerError as exception:error=str(exception)
    return render(request,'developer/login.html',{'page_title':'ورود سازندهٔ نرم‌افزار','challenge':value,'developer_error':error})

@never_cache
def download_challenge(request):
    try:value=get_challenge(request)
    except protocol.MakerError as error:return HttpResponse(str(error),status=409,content_type='text/plain; charset=utf-8')
    response=HttpResponse(protocol.canonical(value),content_type='application/json');response['Content-Disposition']='attachment; filename="AMAR-Developer-Challenge.json"';return response

@require_POST
@never_cache
def logout(request):
    access=request.session.pop(SESSION_KEY,None)
    if isinstance(access,dict):m.DeveloperChallenge.objects.filter(pk=access.get('ticket'),session_hash=digest(request.session.session_key or '')).update(access_expires_at=timezone.now())
    request.session.pop('developer_challenge',None);request.session.cycle_key()
    response=redirect('developer_login');response.delete_cookie(COOKIE,samesite='Strict');return response
