from django import forms
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import Http404,HttpResponse
from django.shortcuts import redirect,render
from django.views.decorators.http import require_POST
from desktop.brand_profile import DEFAULT,NAVIGATION,ASSETS,CHOICES,COLORS,NUMBERS,FLAGS,COPY,MAX_LOGO,MAX_BACKGROUND,MAX_BUNDLE,BrandError,read_bundle,write_bundle,normalize_asset,validate,icon_bytes
from . import branding,developer

LABELS={'light':'روشن','dark':'تیره','comfortable':'آزاد','compact':'فشرده','none':'بدون سایه','soft':'ملایم','strong':'پررنگ','cover':'پوشاندن زمینه','contain':'نمایش کامل تصویر','repeat':'تکرار تصویر','center':'وسط','top':'بالا','bottom':'پایین','right':'راست','left':'چپ'}

class StudioForm(forms.Form):
 product_name=forms.CharField(label='نام اصلی نرم‌افزار',max_length=100)
 product_code=forms.CharField(label='نام فایل اجرایی و فایل نصب؛ انگلیسی',max_length=40,help_text='مثلاً Sepid؛ خروجی با نام Sepid.exe ساخته می‌شود. اعمال بر نام میان‌بر و Apps پس از ساخت و نصب بستهٔ تازه است.')
 tagline=forms.CharField(label='زیرعنوان کنار لوگو',max_length=140,required=False)
 publisher=forms.CharField(label='نام سازنده / ناشر در ویندوز',max_length=80)
 def __init__(self,*args,current,**kwargs):
  initial={**current,**current['theme'],**{'copy_'+k:v for k,v in current['copy'].items()},**{'nav_'+k:current['navigation'].get(k,v) for k,v in NAVIGATION.items()}}
  super().__init__(*args,initial=initial,**kwargs)
  for kind,label in [('logo','لوگوی داخل برنامه'),('desktop_icon','تصویر آیکن دسکتاپ و فایل اجرایی'),('background','تصویر پس‌زمینه')]:
   self.fields[kind]=forms.FileField(label=label+'؛ PNG یا JPEG',required=False,widget=forms.FileInput(attrs={'accept':'image/png,image/jpeg'}),help_text='حداکثر '+('۶' if kind=='background' else '۲')+' مگابایت')
   self.fields['remove_'+kind]=forms.BooleanField(label='حذف '+label+' فعلی',required=False)
  for key,(_,label) in COLORS.items():self.fields[key]=forms.CharField(label=label,max_length=7,widget=forms.TextInput(attrs={'type':'color'}))
  for key,(choices,label) in CHOICES.items():
   if key in ['size','rounding','sidebar']:continue
   self.fields[key]=forms.ChoiceField(label=label,choices=[(v,LABELS.get(v,v)) for v in choices])
  for key,(_,low,high,label) in NUMBERS.items():self.fields[key]=forms.IntegerField(label=label,min_value=low,max_value=high,widget=forms.NumberInput(attrs={'min':low,'max':high}))
  for key,(_,label) in FLAGS.items():self.fields[key]=forms.BooleanField(label=label,required=False)
  for key,(_,maximum,label) in COPY.items():self.fields['copy_'+key]=forms.CharField(label=label,max_length=maximum,required=False,widget=forms.Textarea(attrs={'rows':2}) if maximum>150 else forms.TextInput())
  for key,label in NAVIGATION.items():self.fields['nav_'+key]=forms.CharField(label=label,max_length=48)
 def clean(self):
  data=super().clean();self.assets={}
  for kind in ASSETS:
   upload=data.get(kind)
   if upload:
    if data.get('remove_'+kind):self.add_error(kind,'بارگذاری و حذف این تصویر را هم‌زمان انتخاب نکنید.');continue
    limit=MAX_BACKGROUND if kind=='background' else MAX_LOGO
    try:
     if upload.size>limit:raise BrandError('حجم تصویر بیش از حد مجاز است.')
     self.assets[kind]=normalize_asset(upload.read(limit+1),kind)[0]
    except BrandError as error:self.add_error(kind,str(error))
  if not self.errors:
   theme={**DEFAULT['theme'],**{key:data[key] for key in DEFAULT['theme'] if key in data}}
   try:self.profile=validate({**DEFAULT,**{key:data[key] for key in ['product_name','product_code','tagline','publisher']},'theme':theme,'copy':{key:data['copy_'+key] for key in COPY},'navigation':{key:data['nav_'+key] for key in NAVIGATION}})
   except BrandError as error:raise forms.ValidationError(str(error))
  return data

@developer.required
def studio(request):
 current=branding.profile();form=StudioForm(request.POST or None,request.FILES or None,current=current)
 if request.method=='POST':
  if request.POST.get('action')=='import':
   upload=request.FILES.get('brand_bundle')
   try:
    if not upload:raise BrandError('فایل AMAR-Branding.zip را انتخاب کنید.')
    value,assets=read_bundle(upload.read(MAX_BUNDLE+1));branding.save_profile(request.developer_principal,value,assets,remove=set(ASSETS)-set(assets))
    messages.success(request,'هویت نرم‌افزار توسط سازنده وارد شد.');return redirect('branding_studio')
   except (BrandError,ValidationError) as error:messages.error(request,str(error))
  elif form.is_valid():
   try:
    branding.save_profile(request.developer_principal,form.profile,form.assets,[kind for kind in ASSETS if form.cleaned_data.get('remove_'+kind)])
    messages.success(request,'هویت، پس‌زمینه و جزئیات ظاهر توسط سازنده ذخیره شد.');return redirect('branding_studio')
   except (BrandError,ValidationError) as error:form.add_error(None,str(error))
 groupkeys=[('identity','هویت و فایل اجرایی',['product_name','product_code','tagline','publisher','logo','remove_logo','desktop_icon','remove_desktop_icon']),
  ('palette','رنگ‌های جزئی',['mode','custom_colors',*COLORS]),
  ('layout','قلم و چیدمان',['font','font_size','heading_size','logo_size','sidebar_width','radius','button_radius','density','shadow','card_opacity','show_tagline','show_footer']),
  ('background','پس‌زمینه',['background','remove_background','background_fit','background_position','background_opacity','background_blur']),
  ('copy','متن‌های رابط',['copy_'+k for k in COPY]),('menus','عنوان‌های منو',['nav_'+k for k in NAVIGATION])]
 return render(request,'core/branding_studio.html',{'page_title':'استودیوی اختصاصی سازنده','form':form,'studio_groups':[{'id':key,'title':title,'fields':[form[name] for name in keys]} for key,title,keys in groupkeys],'current_brand':current})

@developer.required
@require_POST
def export_brand(request):
 response=HttpResponse(write_bundle(branding.profile(),branding.current_assets()),content_type='application/zip');response['Content-Disposition']='attachment; filename="AMAR-Branding.zip"';response['Cache-Control']='private, no-store';return response

def public_logo(request,kind='logo'):
 config=branding.configuration()
 if kind not in [*ASSETS,'ico'] or not config:raise Http404
 asset=(config.brand_desktop_icon or config.brand_logo) if kind=='ico' else getattr(config,'brand_'+kind)
 if not asset:raise Http404
 try:data=branding.read_logo(asset)
 except ValidationError:raise Http404
 response=HttpResponse(icon_bytes(data) if kind=='ico' else data,content_type='image/x-icon' if kind=='ico' else 'image/png')
 response['X-Content-Type-Options']='nosniff';response['Cache-Control']='public, max-age=86400, immutable' if request.GET.get('v')==asset.digest else 'no-cache';return response

@developer.required
@require_POST
def apply_shortcuts(request):
 from pathlib import Path
 from desktop.windows_identity import update_shortcuts
 from .services import audit
 config=branding.configuration()
 try:
  result=update_shortcuts(Path(__file__).resolve().parent.parent.parent,config.brand_name,config.brand_tagline,branding.native_icon(config),config.brand_product_code)
  audit('تغییر میان‌برهای ویندوز توسط سازنده',config.brand_name,None,str(result))
  messages.success(request,'نام و آیکن میان‌بر دسکتاپ و Start به‌روز شد. نام در فهرست Apps هم برای نصب ثبت‌شده به‌روز می‌شود.')
 except (OSError,ValueError) as error:messages.error(request,'تغییر میان‌بر انجام نشد: '+str(error))
 return redirect('branding_studio')
