@echo off
setlocal
"%~dp0payload\AMAR-Windows\runtime\pythonw.exe" -I -B -X utf8 "%~dp0sign_access.py"
