@echo off
setlocal
cd /d "%~dp0.."
"%~dp0payload\AMAR-Windows\runtime\python.exe" -I -B -X utf8 "%~dp0build_release.py" --workspace "%~dp0.."
if errorlevel 1 (
 echo Build failed. Read the error above. Existing output and factory data were preserved.
 pause
 exit /b 1
)
echo Setup is ready in the output folder.
pause
exit /b 0
