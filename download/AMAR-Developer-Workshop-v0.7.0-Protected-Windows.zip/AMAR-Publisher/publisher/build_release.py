"""Offline Windows publication kit. Consumes only a pristine application payload."""
import argparse,ctypes,hashlib,json,os,re,runpy,struct,subprocess,sys,tempfile,shutil,uuid
from pathlib import Path

APP_ID='{{B428B1F0-83D0-467F-8B7C-79554A1FEA2D}'

def winpath(path):
 path=Path(path).resolve()
 return str(path) if os.name=='nt' else 'Z:'+str(path).replace('/','\\')

def inno_literal(value):
 if '\n' in value or '\r' in value or '\x00' in value:raise ValueError('Invalid installer text')
 return value.replace('{','{{')

def patch_icon(executable,icon_data,identity=None):
 """Use the Windows resource API; no Go compiler is needed on the owner's PC."""
 if os.name!='nt':return
 from ctypes import wintypes as w
 kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 kernel.BeginUpdateResourceW.argtypes=[w.LPCWSTR,w.BOOL];kernel.BeginUpdateResourceW.restype=w.HANDLE
 kernel.UpdateResourceW.argtypes=[w.HANDLE,ctypes.c_void_p,ctypes.c_void_p,w.WORD,ctypes.c_void_p,w.DWORD]
 kernel.EndUpdateResourceW.argtypes=[w.HANDLE,w.BOOL]
 reserved,kind,count=struct.unpack_from('<HHH',icon_data)
 if reserved or kind!=1 or not 1<=count<=20:raise ValueError('Invalid icon')
 group=bytearray(struct.pack('<HHH',0,1,count));updates=[]
 for index in range(count):
  width,height,colors,reserved,planes,bits,size,offset=struct.unpack_from('<BBBBHHII',icon_data,6+16*index)
  chunk=icon_data[offset:offset+size]
  if len(chunk)!=size:raise ValueError('Invalid icon image length')
  group.extend(struct.pack('<BBBBHHIH',width,height,colors,reserved,planes,bits,size,index+1));updates.append((3,index+1,chunk))
 updates.append((14,1,bytes(group)))
 if identity:
  from desktop.windows_identity import version_resource
  updates.append((16,1,version_resource(**identity)))
 handle=kernel.BeginUpdateResourceW(str(executable),False)
 if not handle:raise ctypes.WinError(ctypes.get_last_error())
 try:
  for resource_type,identity,content in updates:
   buffer=ctypes.create_string_buffer(content)
   if not kernel.UpdateResourceW(handle,ctypes.c_void_p(resource_type),ctypes.c_void_p(identity),0,buffer,len(content)):raise ctypes.WinError(ctypes.get_last_error())
 except Exception:kernel.EndUpdateResourceW(handle,True);raise
 if not kernel.EndUpdateResourceW(handle,False):raise ctypes.WinError(ctypes.get_last_error())

def verify_payload(payload):
 payload=Path(payload).resolve();manifest_path=payload/'package-manifest.json'
 manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
 files=manifest.get('files')
 if not isinstance(files,dict):raise ValueError('Invalid payload manifest')
 actual={path.relative_to(payload).as_posix() for path in payload.rglob('*') if path.is_file() and path!=manifest_path}
 if actual!=set(files):raise ValueError('The publication payload contains missing or unexpected files')
 for name,digest in files.items():
  relative=Path(name)
  if relative.is_absolute() or '..' in relative.parts or '\\' in name:raise ValueError('Invalid payload path')
  target=payload/relative
  if target.is_symlink() or hashlib.sha256(target.read_bytes()).hexdigest()!=digest:raise ValueError('Payload file checksum mismatch: '+name)
 return manifest

def build(payload,branding,output,compiler_command):
 sys.dont_write_bytecode=True
 payload=Path(payload).resolve();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
 sys.path.insert(0,str(payload/'app'))
 from desktop.brand_profile import from_folder,install_defaults
 value,logo=from_folder(branding)
 version=runpy.run_path(str(payload/'app/amar/version.py'))['VERSION']
 if not re.fullmatch(r'\d+\.\d+\.\d+',version):raise ValueError('Invalid application version')
 manifest_path=payload/'package-manifest.json';manifest=verify_payload(payload)
 defaults=payload/'app/data/brand-defaults';install_defaults(defaults,value,logo)
 from desktop.maker_protocol import ensure_identity,public_document,canonical,read_public
 private=Path(__file__).parent/'private'
 if not (private/'developer-key.pem').is_file():raise ValueError('کلید خصوصی سازنده موجود نیست؛ پوشهٔ private را از پشتیبان کارگاه بازیابی کنید.')
 maker_key=ensure_identity(private);embedded=payload/'app/data/developer-public.json'
 if not embedded.is_file() or public_document(read_public(embedded.read_bytes()))!=public_document(maker_key.public_key()):raise ValueError('کلید کارگاه با هویت سازندهٔ این بسته مطابقت ندارد.')
 previous_executable=manifest.get('executable','AMAR.exe')
 if not isinstance(previous_executable,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,39}\.exe',previous_executable):raise ValueError('نام فایل اجرایی بسته معتبر نیست.')
 original=payload/previous_executable;executable=value['product_code']+'.exe'
 patch_icon(original,(defaults/'app.ico').read_bytes(),{'name':value['product_name'],'code':value['product_code'],'publisher':value['publisher'],'tagline':value['tagline'],'version':version})
 if original.name!=executable:original.rename(payload/executable)
 manifest['executable']=executable;manifest['product_code']=value['product_code']
 manifest['files']={path.relative_to(payload).as_posix():hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(payload.rglob('*')) if path.is_file() and path!=manifest_path}
 manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 from desktop.windows_identity import shortcut_name
 shortcut=shortcut_name(value['product_name'])
 name=inno_literal(value['product_name']);publisher=inno_literal(value['publisher']);short=inno_literal(shortcut)
 basename=f'{value["product_code"]}-Setup-v{version}-x64'
 with tempfile.TemporaryDirectory(prefix='amar-installer-') as work:
  compiled=Path(work)/'release';compiled.mkdir()
  script=Path(work)/'setup.iss'
  template=(Path(__file__).parent/'setup-template.iss').read_text(encoding='utf-8')
  replacements={'APP_ID':APP_ID,'PRODUCT':name,'PRODUCT_QUOTED':name.replace('"','""'),'PRODUCT_CODE':value['product_code'],'EXECUTABLE':executable,'PUBLISHER':publisher,'VERSION':version,'SHORTCUT':short,'SHORTCUT_PASCAL':shortcut.replace("'","''"),'PAYLOAD':winpath(payload),'OUTPUT':winpath(compiled),'BASENAME':basename,'ICON':winpath(defaults/'app.ico')}
  template=re.sub(r'@([A-Z_]+)@',lambda match:replacements[match.group(1)],template)
  script.write_text(template,encoding='utf-8-sig')
  subprocess.run([*compiler_command,winpath(script)],check=True)
  result=compiled/(basename+'.exe')
  if not result.is_file():raise RuntimeError('Installer output was not created')
  temporary=output/(basename+'.'+uuid.uuid4().hex+'.tmp')
  try:shutil.copyfile(result,temporary);temporary.replace(output/(basename+'.exe'))
  finally:temporary.unlink(missing_ok=True)
 target=output/(basename+'.exe')
 if not target.is_file():raise RuntimeError('Installer output was not created')
 digest=hashlib.sha256(target.read_bytes()).hexdigest();target.with_suffix('.sha256').write_text(digest+'  '+target.name+'\n',encoding='ascii')
 (output/'READ-ME-fa.txt').write_text('نسخهٔ نصبی '+version+'\nنام: '+value['product_name']+'\n\nفایل '+target.name+' را روی ویندوز ۱۰ یا ۱۱، ۶۴ بیتی اجرا کنید. پایتون و خواندن اسکن همراه نصب‌اند و به اینترنت نیاز نیست.\nپیش از ارتقا پشتیبان بگیرید و برنامه را از پنجرهٔ کنترل با × کامل ببندید. داده‌ها و مسیر AMAR_DATA_DIR حفظ می‌شوند.\n\nبازگشت: دکمهٔ بازگشت بالای صفحه یک پله به صفحهٔ قبلی می‌رود و سند مالی را دوباره ارسال نمی‌کند.\nهویت نرم‌افزار: فقط ورود جداگانهٔ سازنده مجاز است؛ مدیرعامل و حساب ارشد شرکت این اختیار را ندارند. از صفحهٔ ورود سازنده، درخواست بگیرید، در کارگاه خصوصی Sign-Developer-Access.cmd را اجرا و فایل مجوز را وارد کنید.\nساخت نسخهٔ اختصاصی: فایل AMAR-Branding.zip را در branding کارگاه بگذارید و Build-Release.cmd را اجرا کنید. فایل نصب با نام و آیکن دلخواه در output ساخته می‌شود.\nاطلاعات زیرمجموعه: در تبادلات اطلاعات، گزینهٔ تهیهٔ اطلاعات محدود برای نصب زیرمجموعه را باز و مقصد، بخش‌های مجاز و زیرموقعیت‌ها را مشخص کنید. قرارداد بدون مجوز وارد بسته نمی‌شود. گزارش‌ها خواندنی و مخصوص همان نصب مقصدند.\n\nفقط فایل نصب، راهنما و SHA256 را منتشر کنید؛ کارگاه خصوصی سازنده و کلید آن را در اختیار شرکت‌ها نگذارید.\n',encoding='utf-8-sig')
 guide=Path(__file__).parent/'Release-Guide-fa.pdf'
 if guide.is_file():shutil.copyfile(guide,output/f'AMAR-Install-and-Branding-v{version}-fa.pdf')
 print('Installer ready:',target);print('SHA256:',digest)
 return target

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--workspace',type=Path,required=True)
 args=parser.parse_args();workspace=args.workspace.resolve();compiler=workspace/'publisher/tools/inno/ISCC.exe'
 if os.name!='nt':parser.error('The publication workshop runs on Windows.')
 source=workspace/'publisher/payload/AMAR-Windows'
 verify_payload(source)
 work=workspace/'publisher/work';work.mkdir(parents=True,exist_ok=True)
 # Every release starts from a new copy; building cannot edit the running
 # owner's application, canonical payload, accounts, or factory database.
 with tempfile.TemporaryDirectory(prefix='build-',dir=work) as temporary:
  target=Path(temporary)/'AMAR-Windows';shutil.copytree(source,target)
  build(target,workspace/'branding',workspace/'output',[str(compiler)])

if __name__=='__main__':
 sys.dont_write_bytecode=True
 main()
