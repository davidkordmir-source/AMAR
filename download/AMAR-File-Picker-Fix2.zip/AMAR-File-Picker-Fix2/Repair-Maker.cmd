@echo off
setlocal
set "AMAR_REPAIR_ROOT=%USERPROFILE%\Downloads\Compressed\AMAR-Developer-Workshop-v0.7.0-Fix1-Windows\AMAR-Maker-Fix1"
if not "%~1"=="" set "AMAR_REPAIR_ROOT=%~1"
if not exist "%~dp0repair_file_picker.py" (
  echo Use Extract All on the repair ZIP before running Repair-Maker.cmd.
  pause
  exit /b 1
)
if not exist "%AMAR_REPAIR_ROOT%\publisher\payload\AMAR-Windows\runtime\python.exe" (
  echo Workshop folder was not found:
  echo "%AMAR_REPAIR_ROOT%"
  pause
  exit /b 1
)
"%AMAR_REPAIR_ROOT%\publisher\payload\AMAR-Windows\runtime\python.exe" -I -B -X utf8 "%~dp0repair_file_picker.py" --root "%AMAR_REPAIR_ROOT%"
if errorlevel 1 (
  pause
  exit /b 1
)
call "%AMAR_REPAIR_ROOT%\Start-Maker.cmd"
exit /b %errorlevel%
