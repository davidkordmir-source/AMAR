"""Repair the reviewed Fix 1 file-picker script without touching maker keys."""
import argparse
import hashlib
import os
from pathlib import Path
import tempfile

OLD_HASH = '1cc4d091c4822cd1a21202e92c5d36e1c710729f18bb27f69d9d5e620c3d2d2b'
NEW_HASH = 'c854f7c3e4e66e4dc2cb037014a4c97dd04e6ccb3315bdd3a700662240f5d913'

def digest(data):
    return hashlib.sha256(data.decode('utf-8-sig').replace('\r\n','\n').encode()).hexdigest()

def repair(root):
    target = Path(root).resolve() / 'publisher/sign_access.py'
    fixed = Path(__file__).resolve().parent / 'sign_access.fixed.py'
    replacement = fixed.read_bytes()
    if digest(replacement) != NEW_HASH:
        raise ValueError('Repair download is incomplete or damaged. Extract the complete repair ZIP again.')
    original = target.read_bytes()
    if digest(original) == NEW_HASH:
        print('Fix 2 is already installed.')
        return target
    if digest(original) != OLD_HASH:
        raise ValueError('This is not the expected Fix 1 script. The original file was left unchanged.')
    backup = target.with_name('sign_access.py.before-fix2')
    if not backup.exists():
        with backup.open('xb') as stream:
            stream.write(original)
    descriptor, temporary = tempfile.mkstemp(prefix='amar-file-picker-', suffix='.tmp', dir=target.parent)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(replacement)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
    print('File picker repaired successfully. Workshop:', target.parent.parent)
    return target

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    try:
        repair(args.root)
        return 0
    except (OSError, ValueError) as error:
        print('Repair failed:', str(error))
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
