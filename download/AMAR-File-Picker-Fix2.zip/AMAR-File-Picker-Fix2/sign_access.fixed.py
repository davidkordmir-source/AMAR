"""Private maker utility: activate this workshop and sign an offline login request."""
import argparse
import ctypes
import getpass
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'publisher/payload/AMAR-Windows/app'))
from publisher.workshop_key import WorkshopKeyError, read_key
from desktop.maker_protocol import MakerError, sign_challenge


def file_dialog_type():
    """The complete OPENFILENAMEW layout; x64 size must be 152 bytes."""
    from ctypes import wintypes as w
    class OPENFILENAMEW(ctypes.Structure):
        _fields_ = [
            ('lStructSize', w.DWORD),
            ('hwndOwner', w.HWND),
            ('hInstance', w.HINSTANCE),
            ('lpstrFilter', w.LPCWSTR),
            ('lpstrCustomFilter', w.LPWSTR),
            ('nMaxCustFilter', w.DWORD),
            ('nFilterIndex', w.DWORD),
            ('lpstrFile', w.LPWSTR),
            ('nMaxFile', w.DWORD),
            ('lpstrFileTitle', w.LPWSTR),
            ('nMaxFileTitle', w.DWORD),
            ('lpstrInitialDir', w.LPCWSTR),
            ('lpstrTitle', w.LPCWSTR),
            ('Flags', w.DWORD),
            ('nFileOffset', w.WORD),
            ('nFileExtension', w.WORD),
            ('lpstrDefExt', w.LPCWSTR),
            ('lCustData', w.LPARAM),
            ('lpfnHook', ctypes.c_void_p),
            ('lpTemplateName', w.LPCWSTR),
            ('pvReserved', ctypes.c_void_p),
            ('dwReserved', w.DWORD),
            ('FlagsEx', w.DWORD),
        ]
    return OPENFILENAMEW


def choose_file():
    from ctypes import wintypes as w
    OPENFILENAMEW = file_dialog_type()
    buffer = ctypes.create_unicode_buffer(32768)
    dialog = OPENFILENAMEW()
    dialog.lStructSize = ctypes.sizeof(dialog)
    dialog.lpstrFilter = 'درخواست ورود سازنده\0*.json\0همهٔ فایل‌ها\0*.*\0\0'
    dialog.lpstrFile = ctypes.cast(buffer, w.LPWSTR)
    dialog.nMaxFile = len(buffer)
    dialog.lpstrTitle = 'فایل AMAR-Developer-Challenge.json را انتخاب کنید'
    dialog.lpstrDefExt = 'json'
    dialog.Flags = 0x1000 | 0x800 | 0x80000 | 0x8
    fn = ctypes.windll.comdlg32.GetOpenFileNameW
    fn.argtypes = [ctypes.POINTER(OPENFILENAMEW)]
    fn.restype = w.BOOL
    if fn(ctypes.byref(dialog)):
        return Path(buffer.value)
    extended_error = ctypes.windll.comdlg32.CommDlgExtendedError
    extended_error.argtypes = []
    extended_error.restype = w.DWORD
    code = extended_error()
    if code:
        raise MakerError(f'پنجرهٔ انتخاب فایل باز نشد؛ کد ویندوز: 0x{code:04X}.')
    return None


def status(code):
    """Local diagnostics contain paths and status only; no passwords, keys or grants."""
    folder = ROOT / 'publisher/private'
    content = ('AMAR Workshop Fix 2\nStatus: ' + code + '\nWorkshop: ' + str(ROOT)
        + '\nPython: ' + sys.executable
        + '\nKey present: ' + str((folder / 'developer-key.pem').is_file())
        + '\nEncrypted key present: ' + str((folder / 'developer-key.encrypted.json').is_file()) + '\n')
    try:
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'last-access-status.txt').write_text(content, encoding='utf-8-sig')
    except OSError:
        pass


def create_access(path, output=None, password_provider=None):
    path = Path(path)
    if path.stat().st_size > 32768:
        raise MakerError('درخواست بیش از حد بزرگ است.')
    key = read_key(ROOT, password_provider)
    grant = sign_challenge(path.read_bytes(), key)
    target = output or ROOT / 'publisher/private/authorizations/AMAR-Developer-Access.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(grant)
    return target


def ask_password():
    if sys.stdin is None or sys.stderr is None:
        raise WorkshopKeyError('console-required',
            'برای واردکردن رمز کارگاه، Start-Maker.cmd را اجرا کنید.')
    print('This workshop is protected. Enter the private workshop download password.')
    print('Password input is hidden. Activation and signing use this same folder:')
    print(ROOT)
    return getpass.getpass('Workshop password: ')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--challenge', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if os.name != 'nt':
        parser.error('Use the private workshop on Windows.')
    interactive = args.challenge is None
    try:
        print('AMAR Maker Workshop - Fix 2')
        print('Workshop:', ROOT)
        status('selecting-request')
        path = args.challenge or choose_file()
        if not path:
            status('selection-cancelled')
            return 0
        target = create_access(path, args.output, ask_password if interactive else None)
        status('access-created')
        print('Developer access file created:', target)
        if interactive:
            ctypes.windll.user32.MessageBoxW(None,
                'مجوز ورود ساخته شد.\n\n' + str(target) + '\n\nهمین فایل را در صفحهٔ ورود سازندهٔ شرکت انتخاب کنید.',
                'مجوز سازنده', 0x40)
            os.startfile(str(target.parent))
        return 0
    except (MakerError, WorkshopKeyError, OSError, ValueError, KeyboardInterrupt, EOFError) as error:
        code = getattr(error, 'code', 'access-failed')
        status(code)
        message = str(error) or 'عملیات لغو شد.'
        print(message, file=sys.stderr)
        print('Workshop:', ROOT, file=sys.stderr)
        print('Diagnostic file: publisher\\private\\last-access-status.txt', file=sys.stderr)
        if interactive:
            ctypes.windll.user32.MessageBoxW(None,
                message + '\n\nپوشهٔ همین کارگاه:\n' + str(ROOT), 'ورود سازنده', 0x10)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
