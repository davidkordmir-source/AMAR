"""Private maker utility: activate this workshop and sign an offline login request."""
import argparse
import ctypes
import getpass
import hashlib
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'publisher/payload/AMAR-Windows/app'))
from publisher.workshop_key import WorkshopKeyError, read_key
from desktop.maker_protocol import MakerError, sign_challenge


def file_dialog_type():
    """The complete OPENFILENAMEW layout; x64 size must be 152 bytes."""
    from ctypes import wintypes as w
    class OPENFILENAMEW(ctypes.Structure):
        _fields_ = [
            ('lStructSize', w.DWORD),
            ('hwndOwner', w.HWND),
            ('hInstance', w.HINSTANCE),
            ('lpstrFilter', w.LPCWSTR),
            ('lpstrCustomFilter', w.LPWSTR),
            ('nMaxCustFilter', w.DWORD),
            ('nFilterIndex', w.DWORD),
            ('lpstrFile', w.LPWSTR),
            ('nMaxFile', w.DWORD),
            ('lpstrFileTitle', w.LPWSTR),
            ('nMaxFileTitle', w.DWORD),
            ('lpstrInitialDir', w.LPCWSTR),
            ('lpstrTitle', w.LPCWSTR),
            ('Flags', w.DWORD),
            ('nFileOffset', w.WORD),
            ('nFileExtension', w.WORD),
            ('lpstrDefExt', w.LPCWSTR),
            ('lCustData', w.LPARAM),
            ('lpfnHook', ctypes.c_void_p),
            ('lpTemplateName', w.LPCWSTR),
            ('pvReserved', ctypes.c_void_p),
            ('dwReserved', w.DWORD),
            ('FlagsEx', w.DWORD),
        ]
    return OPENFILENAMEW


def choose_file():
    from ctypes import wintypes as w
    OPENFILENAMEW = file_dialog_type()
    buffer = ctypes.create_unicode_buffer(32768)
    dialog = OPENFILENAMEW()
    dialog.lStructSize = ctypes.sizeof(dialog)
    dialog.lpstrFilter = 'درخواست ورود سازنده\0*.json\0همهٔ فایل‌ها\0*.*\0\0'
    dialog.lpstrFile = ctypes.cast(buffer, w.LPWSTR)
    dialog.nMaxFile = len(buffer)
    dialog.lpstrTitle = 'فایل AMAR-Developer-Challenge.json را انتخاب کنید'
    dialog.lpstrDefExt = 'json'
    dialog.Flags = 0x1000 | 0x800 | 0x80000 | 0x8
    fn = ctypes.windll.comdlg32.GetOpenFileNameW
    fn.argtypes = [ctypes.POINTER(OPENFILENAMEW)]
    fn.restype = w.BOOL
    if fn(ctypes.byref(dialog)):
        return Path(buffer.value)
    extended_error = ctypes.windll.comdlg32.CommDlgExtendedError
    extended_error.argtypes = []
    extended_error.restype = w.DWORD
    code = extended_error()
    if code:
        raise MakerError(f'پنجرهٔ انتخاب فایل باز نشد؛ کد ویندوز: 0x{code:04X}.')
    return None


def status(code):
    """Local diagnostics contain paths and status only; no passwords, keys or grants."""
    folder = ROOT / 'publisher/private'
    content = ('AMAR Workshop Fix 3\nStatus: ' + code + '\nWorkshop: ' + str(ROOT)
        + '\nPython: ' + sys.executable
        + '\nKey present: ' + str((folder / 'developer-key.pem').is_file())
        + '\nEncrypted key present: ' + str((folder / 'developer-key.encrypted.json').is_file()) + '\n')
    try:
        encrypted = folder / 'developer-key.encrypted.json'
        if encrypted.stat().st_size <= 8192:
            content += 'Encrypted file SHA256: ' + hashlib.sha256(encrypted.read_bytes()).hexdigest() + '\n'
    except OSError:
        pass
    try:
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'last-access-status.txt').write_text(content, encoding='utf-8-sig')
    except OSError:
        pass


def create_access(path, output=None, password_provider=None):
    path = Path(path)
    if path.stat().st_size > 32768:
        raise MakerError('درخواست بیش از حد بزرگ است.')
    key = read_key(ROOT, password_provider)
    grant = sign_challenge(path.read_bytes(), key)
    target = output or ROOT / 'publisher/private/authorizations/AMAR-Developer-Access.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(grant)
    return target


def clipboard_password():
    """Read clipboard text only after an explicit Ctrl+V in the password prompt."""
    from ctypes import wintypes as w
    user = ctypes.WinDLL('user32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    user.OpenClipboard.argtypes = [w.HWND]
    user.OpenClipboard.restype = w.BOOL
    user.CloseClipboard.argtypes = []
    user.CloseClipboard.restype = w.BOOL
    user.GetClipboardData.argtypes = [w.UINT]
    user.GetClipboardData.restype = w.HANDLE
    kernel.GlobalSize.argtypes = [w.HANDLE]
    kernel.GlobalSize.restype = ctypes.c_size_t
    kernel.GlobalLock.argtypes = [w.HANDLE]
    kernel.GlobalLock.restype = ctypes.c_void_p
    kernel.GlobalUnlock.argtypes = [w.HANDLE]
    kernel.GlobalUnlock.restype = w.BOOL
    message = 'چسباندن رمز انجام نشد. رمز را دوباره کپی و با راست‌کلیک در پنجره بچسبانید.'
    if not user.OpenClipboard(None):
        raise WorkshopKeyError('clipboard-unavailable', message)
    try:
        handle = user.GetClipboardData(13)  # CF_UNICODETEXT
        if not handle:
            raise WorkshopKeyError('clipboard-unavailable', message)
        size = kernel.GlobalSize(handle)
        if not 2 <= size <= 16384 or size % ctypes.sizeof(ctypes.c_wchar):
            raise WorkshopKeyError('clipboard-unavailable', message)
        pointer = kernel.GlobalLock(handle)
        if not pointer:
            raise WorkshopKeyError('clipboard-unavailable', message)
        try:
            return ctypes.wstring_at(pointer, size // ctypes.sizeof(ctypes.c_wchar)).split('\0', 1)[0]
        finally:
            kernel.GlobalUnlock(handle)
    finally:
        user.CloseClipboard()


def prepare_workshop_password(raw, clipboard_reader=None):
    if '\x16' in raw:
        # msvcrt.getwch() can return the Ctrl+V control character instead of
        # pasted text on older console hosts. getpass preserves that character.
        raw = raw.replace('\x16', (clipboard_reader or clipboard_password)())
    digits = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
    formatting = '\u200b\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069\ufeff'
    candidate = ''.join(c for c in raw.translate(digits) if not c.isspace() and c not in formatting)
    candidate = candidate.strip('`\"\'').lower()
    if len(candidate) != 32 or any(c not in '0123456789abcdef' for c in candidate):
        raise WorkshopKeyError('password-format',
            'رمز کارگاه باید دقیقاً ۳۲ نویسه از اعداد انگلیسی و حروف a تا f باشد. رمز دانلود کارگاه را دوباره کپی کنید؛ بدون متن توضیح یا علامت اضافه.')
    return candidate


def ask_password():
    if sys.stdin is None or sys.stderr is None:
        raise WorkshopKeyError('console-required',
            'برای واردکردن رمز کارگاه، Start-Maker.cmd را اجرا کنید.')
    print('This workshop is protected. Enter the private workshop download password.')
    print('Password input is hidden. Activation and signing use this same folder:')
    print(ROOT)
    return prepare_workshop_password(getpass.getpass('Workshop password: '))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--challenge', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if os.name != 'nt':
        parser.error('Use the private workshop on Windows.')
    interactive = args.challenge is None
    try:
        print('AMAR Maker Workshop - Fix 3')
        print('Workshop:', ROOT)
        status('selecting-request')
        path = args.challenge or choose_file()
        if not path:
            status('selection-cancelled')
            return 0
        target = create_access(path, args.output, ask_password if interactive else None)
        status('access-created')
        print('Developer access file created:', target)
        if interactive:
            ctypes.windll.user32.MessageBoxW(None,
                'مجوز ورود ساخته شد.\n\n' + str(target) + '\n\nهمین فایل را در صفحهٔ ورود سازندهٔ شرکت انتخاب کنید.',
                'مجوز سازنده', 0x40)
            os.startfile(str(target.parent))
        return 0
    except (MakerError, WorkshopKeyError, OSError, ValueError, KeyboardInterrupt, EOFError) as error:
        code = getattr(error, 'code', 'access-failed')
        status(code)
        message = str(error) or 'عملیات لغو شد.'
        print(message, file=sys.stderr)
        print('Workshop:', ROOT, file=sys.stderr)
        print('Diagnostic file: publisher\\private\\last-access-status.txt', file=sys.stderr)
        if interactive:
            ctypes.windll.user32.MessageBoxW(None,
                message + '\n\nپوشهٔ همین کارگاه:\n' + str(ROOT), 'ورود سازنده', 0x10)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
