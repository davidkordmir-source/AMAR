@echo off
setlocal
if not exist "%~dp0payload\AMAR-Windows\runtime\python.exe" (
  echo Workshop files are missing. Use Extract All on the complete ZIP first.
  pause
  exit /b 1
)
"%~dp0payload\AMAR-Windows\runtime\python.exe" -I -B -X utf8 "%~dp0sign_access.py"
set "AMAR_ACCESS_RESULT=%errorlevel%"
echo.
pause
exit /b %AMAR_ACCESS_RESULT%
