"""Cache authorization inputs for one HTTP request, never across requests."""
from contextvars import ContextVar
_cache=ContextVar('amar_request_cache',default=None)

def memo(key,load):
    cache=_cache.get()
    if cache is None:return load()
    if key not in cache:cache[key]=load()
    return cache[key]

def invalidate():
    cache=_cache.get()
    if cache is not None:cache.clear()

class AccessRequestCache:
    def __init__(self,get_response):self.get_response=get_response
    def __call__(self,request):
        token=_cache.set({})
        try:return self.get_response(request)
        finally:_cache.reset(token)
