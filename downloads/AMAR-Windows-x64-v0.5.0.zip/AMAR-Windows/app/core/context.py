from .access import profile
from .models import SystemConfiguration
from amar.version import VERSION,VERSION_FA

def workspace(request):
    from desktop.control import session
    configuration=SystemConfiguration.objects.filter(pk=1).first() or SystemConfiguration()
    p=profile(request.user) if request.user.is_authenticated else None
    return {'workspace_config':configuration,'workspace_profile':p,'app_version':VERSION,'app_version_fa':VERSION_FA,'desktop_can_close':session.available(),
        'workspace_name':p.display_name if p and p.display_name else (request.user.get_full_name() or request.user.get_username()) if request.user.is_authenticated else '',
        'workspace_title':p.position_title if p and p.position_title else configuration.owner_title if request.user.is_superuser else p.role.name if p and p.role else ''}
