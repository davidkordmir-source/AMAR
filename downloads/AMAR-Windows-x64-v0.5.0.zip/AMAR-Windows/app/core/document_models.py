import uuid
from django.conf import settings
from django.db import models
from django.core.validators import MinValueValidator
from .models import ImmutableRecord

class ActiveDocumentManager(models.Manager):
    def get_queryset(self):return super().get_queryset().filter(archived_at__isnull=True)

class Document(models.Model):
    objects=ActiveDocumentManager()
    all_objects=models.Manager()
    branch=models.ForeignKey('Branch',on_delete=models.PROTECT,verbose_name='موقعیت')
    kind=models.CharField('نوع سند',max_length=16,choices=[('contract','قرارداد'),('financial','سند مالی'),('other','سایر مدارک')])
    title=models.CharField('عنوان سند',max_length=180)
    reference=models.CharField('شماره سند',max_length=80,blank=True)
    amount=models.BigIntegerField('مبلغ تأییدشده (ریال)',null=True,blank=True,validators=[MinValueValidator(0)])
    document_date=models.CharField('تاریخ درج‌شده در سند',max_length=40,blank=True)
    contract=models.ForeignKey('Contract',on_delete=models.PROTECT,null=True,blank=True,verbose_name='قرارداد مرتبط')
    account=models.ForeignKey('Account',on_delete=models.PROTECT,null=True,blank=True,verbose_name='حساب مرتبط')
    money_entry=models.ForeignKey('MoneyEntry',on_delete=models.PROTECT,null=True,blank=True,verbose_name='سند مالی مرتبط')
    payment_request=models.ForeignKey('PaymentRequest',on_delete=models.PROTECT,null=True,blank=True,verbose_name='درخواست پرداخت مرتبط')
    notes=models.TextField('توضیحات',blank=True)
    current_version=models.ForeignKey('DocumentVersion',on_delete=models.PROTECT,null=True,blank=True,related_name='+')
    ocr_status=models.CharField(max_length=12,default='pending',choices=[('pending','در انتظار خواندن'),('running','در حال خواندن'),('ready','آمادهٔ بررسی'),('failed','نیازمند ورود دستی')])
    confirmed_at=models.DateTimeField(null=True,blank=True)
    confirmed_by=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,null=True,blank=True,related_name='+')
    created_by=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+')
    creation_key=models.UUIDField(default=uuid.uuid4,unique=True,editable=False)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    archived_at=models.DateTimeField(null=True,blank=True,db_index=True)
    archived_by=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,null=True,blank=True,related_name='+')
    archive_reason=models.CharField(max_length=240,blank=True)
    class Meta:
        ordering=['-pk']
        verbose_name='سند اسکن‌شده'
        indexes=[models.Index(fields=['branch','kind','archived_at'])]
    def __str__(self):return self.reference+' · '+self.title if self.reference else self.title

class DocumentVersion(ImmutableRecord):
    document=models.ForeignKey(Document,on_delete=models.PROTECT,related_name='versions')
    number=models.PositiveIntegerField()
    filename=models.CharField(max_length=100)
    original_name=models.CharField(max_length=200)
    content_type=models.CharField(max_length=60)
    size=models.PositiveBigIntegerField()
    digest=models.CharField(max_length=64)
    created_by=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-number']
        constraints=[models.UniqueConstraint(fields=['document','number'],name='unique_document_version')]
        verbose_name='نسخه فایل سند'

class DocumentExtraction(ImmutableRecord):
    version=models.ForeignKey(DocumentVersion,on_delete=models.PROTECT,related_name='extractions')
    success=models.BooleanField()
    text=models.TextField(blank=True)
    suggestions=models.JSONField(default=dict)
    engine=models.CharField(max_length=100)
    error_code=models.CharField(max_length=40,blank=True)
    partial=models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-pk']
        verbose_name='خواندن متن سند'

class DocumentReview(ImmutableRecord):
    document=models.ForeignKey(Document,on_delete=models.PROTECT,related_name='reviews')
    version=models.ForeignKey(DocumentVersion,on_delete=models.PROTECT)
    extraction=models.ForeignKey(DocumentExtraction,on_delete=models.PROTECT,null=True,blank=True)
    values=models.JSONField()
    actor=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-pk']
        verbose_name='تأیید اطلاعات اسکن'
