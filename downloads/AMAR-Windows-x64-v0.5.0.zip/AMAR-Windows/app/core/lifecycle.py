"""Revisions and conditional deletion retain the complete business history."""
import uuid
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from . import models as m,services
from .access import require_permission,require_contract,require_factory,contracts_for,factory_ids

def reason_text(value):
    value=(value or '').strip()
    if len(value)<10:raise ValidationError('علت ویرایش یا حذف را با دست‌کم ۱۰ حرف ثبت کنید.')
    return value[:240]

def contract_delete_reasons(contract):
    reasons=[]
    if contract.paid:reasons.append('پرداخت مالی برای این قرارداد ثبت شده است؛ حذف مجاز نیست.')
    if contract.receipts.exists():reasons.append('کالا برای این قرارداد تحویل شده است؛ پیش از حذف، برگشت کالا باید تعیین تکلیف شود.')
    return reasons

def _reset_contract(contract,actor):
    accounts=list(contract.allocations.filter(active=True).values_list('account_id',flat=True))
    list(m.Account.objects.select_for_update().filter(pk__in=accounts).order_by('pk'))
    m.PaymentRequest.objects.filter(allocation__contract=contract,status='pending').update(status='cancelled')
    contract.allocations.update(active=False)
    contract.status=m.Contract.Status.DRAFT;contract.approved_at=None;contract.approved_by=None

@transaction.atomic
def archive_contract(actor,pk,reason):
    require_permission(actor,'delete_contract');require_contract(actor,pk,True)
    contract=m.Contract.objects.select_for_update().get(pk=pk)
    reason=reason_text(reason)
    reasons=contract_delete_reasons(contract)
    if reasons:raise ValidationError(reasons)
    if contract.status!=m.Contract.Status.DRAFT:require_permission(actor,'approve_contract')
    _reset_contract(contract,actor)
    contract.status=m.Contract.Status.CANCELLED;contract.archived_at=timezone.now();contract.archived_by=actor;contract.archive_reason=reason
    contract.save()
    services.audit('حذف قرارداد بدون پرداخت',contract.number,actor,reason,branch=contract.warehouse.branch,contract=contract)
    return contract

@transaction.atomic
def save_contract_revision(actor,pk,form,formset,reason):
    require_permission(actor,'change_contract');require_contract(actor,pk,True)
    contract=m.Contract.objects.select_for_update().get(pk=pk)
    reason=reason_text(reason)
    before={'number':contract.number,'title':contract.title,'status':contract.status,'supplier_id':contract.supplier_id,'warehouse_id':contract.warehouse_id,
        'lines':list(contract.lines.values('item_id','quantity','unit_price'))}
    if formset is None:
        for name in ['title','due_date','notes']:setattr(contract,name,form.cleaned_data[name])
        contract.save(update_fields=['title','due_date','notes'])
    else:
        if contract.paid or contract.receipts.exists():raise ValidationError('هم‌زمان پرداخت یا تحویل ثبت شده است؛ فقط عنوان و توضیحات قابل ویرایش‌اند.')
        _reset_contract(contract,actor)
        for name in ['number','title','supplier','warehouse','due_date','notes']:setattr(contract,name,form.cleaned_data[name])
        contract.revised_by=actor;contract.save()
        formset.instance=contract;formset.save()
        services.positive(contract.total,money=True)
        m.Document.objects.filter(contract=contract).update(confirmed_at=None,confirmed_by=None)
    import json
    services.audit('ویرایش قرارداد'+(' و نیاز به تأیید دوباره' if formset is not None else '؛ مشخصات توضیحی'),contract.number,actor,
        json.dumps({'reason':reason,'before':before},ensure_ascii=False,default=str),branch=contract.warehouse.branch,contract=contract)
    return contract

def entries_for(actor):
    from django.db.models import Q
    return m.MoneyEntry.objects.filter(account__branch_id__in=factory_ids(actor)).filter(Q(allocation__isnull=True)|Q(allocation__contract__in=contracts_for(actor)))

def entry_has_payments(entry):
    if entry.kind==m.MoneyEntry.Kind.PAYMENT:return True
    return m.MoneyEntry.objects.filter(account_id=entry.account_id,kind=m.MoneyEntry.Kind.PAYMENT).exists() or m.Document.all_objects.filter(
        money_entry=entry,contract__allocations__payments__kind=m.MoneyEntry.Kind.PAYMENT).exists()

def entry_delete_reasons(entry):
    if not entry.is_active or entry.kind==m.MoneyEntry.Kind.REVERSAL:return ['این سند قبلاً ابطال شده یا سند ابطال است.']
    if entry_has_payments(entry):return ['پرداخت مالی مرتبط وجود دارد؛ حذف سند مجاز نیست.']
    if entry.account.balance-entry.amount+entry.account.credit_limit-entry.account.reserved<0:return ['وجه این دریافت، پشتوانهٔ تخصیص‌های فعال است؛ ابتدا تخصیص‌ها را تعیین تکلیف کنید.']
    return []

def _metadata(entry,**changes):
    if not set(changes)<={'is_active','display_reference','display_description'}:raise AssertionError('Only lifecycle metadata may change')
    # The immutable accounting values remain untouched; this change is audited below.
    m.MoneyEntry._base_manager.filter(pk=entry.pk).update(**changes)

def _reverse_deposit(entry,actor,key):
    reversal=m.MoneyEntry(account_id=entry.account_id,kind=m.MoneyEntry.Kind.REVERSAL,amount=entry.amount,
        reference=f'VOID-{entry.pk}-{key.hex[:16]}',description='ابطال دریافت وجه',operation_key=key,created_by=actor,reverses=entry,is_active=False)
    reversal.save();_metadata(entry,is_active=False)
    return reversal

@transaction.atomic
def delete_entry(actor,pk,reason,key):
    require_permission(actor,'delete_moneyentry')
    entry=entries_for(actor).get(pk=pk);require_factory(actor,entry.account.branch_id)
    account=m.Account.objects.select_for_update().get(pk=entry.account_id)
    entry=m.MoneyEntry.objects.select_for_update().get(pk=pk);entry.account=account
    reason=reason_text(reason)
    previous=m.MoneyEntryAmendment.objects.filter(operation_key=key).first()
    if previous:
        if previous.entry_id!=pk:raise ValidationError('شناسهٔ عملیات برای سند دیگری استفاده شده است.')
        return entry
    reasons=entry_delete_reasons(entry)
    if reasons:raise ValidationError(reasons)
    _reverse_deposit(entry,actor,key)
    m.MoneyEntryAmendment.objects.create(entry=entry,before={'active':True,'amount':entry.amount},after={'active':False},reason=reason,actor=actor,operation_key=key)
    services.audit('حذف سند مالی بدون پرداخت؛ ابطال دریافت',entry.reference,actor,reason,branch=account.branch)
    return entry

@transaction.atomic
def edit_entry(actor,pk,amount,reference,description,reason,key):
    require_permission(actor,'change_moneyentry')
    entry=entries_for(actor).get(pk=pk);require_factory(actor,entry.account.branch_id)
    account=m.Account.objects.select_for_update().get(pk=entry.account_id)
    entry=m.MoneyEntry.objects.select_for_update().get(pk=pk);entry.account=account
    reason=reason_text(reason);amount=services.positive(amount,money=True)
    reference=reference.strip()
    if not reference:raise ValidationError('شماره سند الزامی است.')
    previous=m.MoneyEntryAmendment.objects.filter(operation_key=key).first()
    if previous:
        if previous.entry_id!=pk:raise ValidationError('شناسهٔ عملیات برای سند دیگری استفاده شده است.')
        return m.MoneyEntry.objects.get(pk=previous.after.get('replacement_id',pk))
    if not entry.is_active or entry.kind==m.MoneyEntry.Kind.REVERSAL:raise ValidationError('سند ابطال‌شده قابل بازنویسی نیست.')
    if m.MoneyEntry.objects.filter(account=account,is_active=True,display_reference=reference).exclude(pk=pk).exists():raise ValidationError('شماره سند فعال در این حساب تکراری است.')
    before={'reference':entry.display_reference,'description':entry.display_description,'amount':entry.amount}
    result=entry
    if amount!=entry.amount:
        if entry_has_payments(entry):raise ValidationError('پس از ثبت پرداخت، مبلغ قابل تغییر نیست؛ مشخصات توضیحی قابل اصلاح‌اند.')
        if account.current_balance-entry.amount+amount+account.credit_limit-account.reserved<0:raise ValidationError('مبلغ جدید پشتوانهٔ تعهدهای فعال را تأمین نمی‌کند.')
        _reverse_deposit(entry,actor,uuid.uuid4())
        result=services.deposit(account.pk,amount,reference,key,actor,description)
    else:_metadata(entry,display_reference=reference,display_description=description)
    after={'reference':reference,'description':description,'amount':int(amount),'replacement_id':result.pk}
    m.MoneyEntryAmendment.objects.create(entry=entry,before=before,after=after,reason=reason,actor=actor,operation_key=key)
    services.audit('ویرایش سند مالی با حفظ سابقه',entry.reference,actor,reason,branch=account.branch)
    return result

@transaction.atomic
def revise_allocation(actor,pk,reason,key,amount=None):
    require_permission(actor,'change_allocation' if amount is not None else 'delete_allocation')
    info=m.Allocation.objects.get(pk=pk);require_contract(actor,info.contract_id,True)
    contract=m.Contract.objects.select_for_update().get(pk=info.contract_id)
    account=m.Account.objects.select_for_update().get(pk=info.account_id);require_factory(actor,account.branch_id)
    allocation=m.Allocation.objects.select_for_update().get(pk=pk);reason=reason_text(reason)
    if not allocation.active:raise ValidationError('این تخصیص قبلاً غیرفعال شده است.')
    if allocation.paid:raise ValidationError('پرداخت مالی روی این تخصیص ثبت شده است؛ حذف یا تغییر مبلغ مجاز نیست.')
    m.PaymentRequest.objects.filter(allocation=allocation,status='pending').update(status='cancelled')
    allocation.active=False;allocation.save(update_fields=['active'])
    replacement=services.allocate(contract.pk,account.pk,amount,key,actor) if amount is not None else None
    services.audit('ویرایش تخصیص با حفظ سابقه' if replacement else 'حذف تخصیص بدون پرداخت',f'#{pk}',actor,reason+(f' → #{replacement.pk}' if replacement else ''),branch=account.branch,contract=contract)
    return replacement or allocation
