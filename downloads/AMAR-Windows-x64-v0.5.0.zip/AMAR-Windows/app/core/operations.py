"""Approval, custody, transfers and counts. Every state change is serialized.

Warehouse locks are acquired by ascending primary key, then trace-unit locks.
Request/transfer locks precede warehouse locks. Global audit lock is always last.
"""
import uuid
from decimal import Decimal
from django.core.exceptions import PermissionDenied,ValidationError
from django.db import transaction
from django.db.models import Max
from django.utils import timezone
from .access import factory_ids,require_contract,require_factory,require_permission,root
from .models import (Allocation, CustodyEvent, Item, MaterialRequest, PaymentRequest, StockCorrection,
    StockCount,StockCountLine,StockMovement,StockBalance,StockTransfer,StorageLocation,TraceUnit,TransferRoute,Warehouse,ZERO,summed)
from .services import audit,item_quantity,pay,positive,replay


def bucket_stock(warehouse,item,location=None,trace=None):
    return summed(StockBalance.objects.filter(warehouse=warehouse,item=item,location=location,trace=trace),'quantity')

def reserved(warehouse,item,location=None,trace=None,exclude_request=None,exclude_transfer=None):
    requests=MaterialRequest.objects.filter(warehouse=warehouse,item=item,location=location,trace=trace,status='approved')
    transfers=StockTransfer.objects.filter(source=warehouse,item=item,location=location,trace=trace,status='approved')
    if exclude_request: requests=requests.exclude(pk=exclude_request)
    if exclude_transfer: transfers=transfers.exclude(pk=exclude_transfer)
    return summed(requests,'quantity')+summed(transfers,'quantity')

def validate_bucket(warehouse,item,location,trace,quantity,incoming=False,require_location=False,ignore_request=None,ignore_transfer=None):
    quantity=item_quantity(item,quantity)
    if require_location and location is None: raise ValidationError('محل دقیق نگهداری را انتخاب کنید.')
    if location and location.warehouse_id!=warehouse.pk: raise ValidationError('محل نگهداری متعلق به این انبار نیست.')
    if trace and trace.item_id!=item.pk: raise ValidationError('بچ یا سریال متعلق به این کالا نیست.')
    if item.tracking!='bulk' and not trace: raise ValidationError('این کالا به بچ یا سریال نیاز دارد.')
    if item.tracking=='serial':
        if quantity!=1: raise ValidationError('هر سریال فقط یک قلم است؛ برای هر سریال سند جدا ثبت کنید.')
        TraceUnit.objects.select_for_update().get(pk=trace.pk)
        if incoming:
            accounted=summed(StockBalance.objects.filter(trace=trace),'quantity')
            for request in MaterialRequest.objects.filter(trace=trace,status__in=['issued','closed']).exclude(pk=ignore_request):
                accounted+=request.remaining
            accounted+=summed(CustodyEvent.objects.filter(request__trace=trace,kind='consume'),'quantity')
            accounted+=summed(StockTransfer.objects.filter(trace=trace,status='transit').exclude(pk=ignore_transfer),'quantity')
            if accounted: raise ValidationError('این سریال قبلاً در موجودی، تحویل اشخاص، مصرف یا کالای در مسیر ثبت شده است.')
    return quantity

def _post(warehouse,item,quantity,location,trace,reference,actor,note=''):
    balance=bucket_stock(warehouse,item,location,trace)+quantity
    if balance<0: raise ValidationError('مقدار از موجودی همین محل و بچ بیشتر است.')
    if balance: positive(balance)
    return StockMovement.objects.create(warehouse=warehouse,item=item,quantity=quantity,location=location,trace=trace,
        kind='in' if quantity>0 else 'out',reference=reference,note=note,created_by=actor)

def _independent(document,actor):
    if document.requested_by_id==actor.pk: raise ValidationError('ثبت‌کننده نمی‌تواند تأییدکننده همان درخواست باشد.')

def _permission(actor,name,branch):
    require_permission(actor,name); require_factory(actor,branch)

def _pending(document):
    if document.status!='pending': raise ValidationError('این درخواست دیگر در انتظار تأیید نیست.')

def _log(document,actor,action,branch,detail=''):
    audit(action,f'{document._meta.verbose_name} #{document.pk}',actor,detail,branch=branch)

@transaction.atomic
def request_material(actor,warehouse,item,location,trace,quantity,recipient,work_order,purpose,key):
    _permission(actor,'add_materialrequest',warehouse.branch_id)
    warehouse=Warehouse.objects.select_for_update().get(pk=warehouse.pk)
    quantity=validate_bucket(warehouse,item,location,trace,quantity,require_location=True)
    if recipient.branch_id!=warehouse.branch_id or work_order.branch_id!=warehouse.branch_id or not recipient.active or not work_order.active:
        raise ValidationError('تحویل‌گیرنده و دستور کار باید فعال و متعلق به واحد همان انبار باشند.')
    if not purpose.strip(): raise ValidationError('شرح نیاز الزامی است.')
    previous=replay(MaterialRequest,key,warehouse_id=warehouse.pk,item_id=item.pk,location_id=location.pk,trace_id=trace.pk if trace else None,quantity=quantity,recipient_id=recipient.pk,work_order_id=work_order.pk,purpose=purpose,requested_by_id=actor.pk)
    if previous:return previous
    result=MaterialRequest.objects.create(warehouse=warehouse,item=item,location=location,trace=trace,quantity=quantity,
        recipient=recipient,work_order=work_order,purpose=purpose,operation_key=key,requested_by=actor)
    _log(result,actor,'درخواست قطعه',warehouse.branch)
    return result

@transaction.atomic
def approve_material(actor,pk,reject=False):
    d=MaterialRequest.objects.select_for_update().get(pk=pk)
    _permission(actor,'approve_operations',d.warehouse.branch_id)
    if d.status==('rejected' if reject else 'approved'):return d
    _pending(d); _independent(d,actor)
    w=Warehouse.objects.select_for_update().get(pk=d.warehouse_id)
    if not reject:
        validate_bucket(w,d.item,d.location,d.trace,d.quantity)
        if d.quantity>bucket_stock(w,d.item,d.location,d.trace)-reserved(w,d.item,d.location,d.trace):
            raise ValidationError('موجودی آزاد این محل برای رزرو کافی نیست.')
    d.status='rejected' if reject else 'approved'; d.approved_by=actor; d.save()
    _log(d,actor,'رد درخواست قطعه' if reject else 'تأیید و رزرو قطعه',w.branch)
    return d

@transaction.atomic
def issue_material(actor,pk):
    d=MaterialRequest.objects.select_for_update().get(pk=pk)
    _permission(actor,'add_stockmovement',d.warehouse.branch_id)
    if d.status in ('issued','closed'):return d
    if d.status!='approved':raise ValidationError('فقط درخواست تأییدشده قابل تحویل است.')
    if d.approved_by_id==actor.pk: raise ValidationError('تحویل‌دهنده باید از تأییدکننده مستقل باشد.')
    w=Warehouse.objects.select_for_update().get(pk=d.warehouse_id)
    validate_bucket(w,d.item,d.location,d.trace,d.quantity)
    if d.quantity>bucket_stock(w,d.item,d.location,d.trace)-reserved(w,d.item,d.location,d.trace,exclude_request=d.pk):
        raise ValidationError('موجودی آزاد برای تحویل کافی نیست.')
    movement=_post(w,d.item,-d.quantity,d.location,d.trace,f'MAT-{d.pk}',actor,f'{d.recipient.name}؛ {d.work_order.number}')
    d.status='issued'; d.issued_by=actor;d.issued_at=timezone.now();d.issue_movement=movement;d.save()
    _log(d,actor,'تحویل قطعه به عهده شخص',w.branch,f'{d.quantity}؛ {d.recipient.name}؛ {d.work_order.number}')
    return d

@transaction.atomic
def settle_material(actor,pk,kind,quantity,reference,key):
    d=MaterialRequest.objects.select_for_update().get(pk=pk)
    _permission(actor,'add_custodyevent',d.warehouse.branch_id)
    if kind not in ('consume','return'):raise ValidationError('نوع تعیین تکلیف معتبر نیست.')
    quantity=item_quantity(d.item,quantity)
    previous=replay(CustodyEvent,key,request_id=pk,kind=kind,quantity=quantity,reference=reference,actor_id=actor.pk)
    if previous:return previous
    if d.status not in ('issued','closed') or quantity>d.remaining:raise ValidationError('مقدار از مانده به عهده شخص بیشتر است.')
    if not reference.strip():raise ValidationError('شماره سند الزامی است.')
    w=Warehouse.objects.select_for_update().get(pk=d.warehouse_id)
    movement=None
    if kind=='return':
        validate_bucket(w,d.item,d.location,d.trace,quantity,incoming=True,ignore_request=d.pk)
        movement=_post(w,d.item,quantity,d.location,d.trace,reference,actor,f'برگشت MAT-{d.pk}')
    event=CustodyEvent.objects.create(request=d,kind=kind,quantity=quantity,reference=reference,operation_key=key,actor=actor,movement=movement)
    if d.remaining==0:d.status='closed';d.save(update_fields=['status'])
    _log(d,actor,'برگشت قطعه' if kind=='return' else 'مصرف قطعه در دستور کار',w.branch,f'{quantity}؛ سند {reference}')
    return event

@transaction.atomic
def request_transfer(actor,source,destination,item,location,trace,quantity,reference,key):
    _permission(actor,'add_stocktransfer',source.branch_id)
    if source.pk==destination.pk:raise ValidationError('انبار مبدأ و مقصد باید متفاوت باشند.')
    if not root(actor) and not TransferRoute.objects.filter(source_id=source.branch_id,destination_id=destination.branch_id).exists():
        raise PermissionDenied('این مسیر انتقال مجاز نشده است.')
    locked={w.pk:w for w in Warehouse.objects.select_for_update().filter(pk__in=[source.pk,destination.pk]).order_by('pk')}
    quantity=validate_bucket(locked[source.pk],item,location,trace,quantity,require_location=True)
    previous=replay(StockTransfer,key,source_id=source.pk,destination_id=destination.pk,item_id=item.pk,location_id=location.pk,trace_id=trace.pk if trace else None,quantity=quantity,reference=reference,requested_by_id=actor.pk)
    if previous:return previous
    d=StockTransfer.objects.create(source=source,destination=destination,item=item,location=location,trace=trace,quantity=quantity,reference=reference,operation_key=key,requested_by=actor)
    _log(d,actor,'درخواست انتقال',source.branch,reference)
    return d

@transaction.atomic
def approve_transfer(actor,pk,reject=False):
    d=StockTransfer.objects.select_for_update().get(pk=pk)
    _permission(actor,'approve_operations',d.source.branch_id)
    if d.status==('rejected' if reject else 'approved'):return d
    _pending(d);_independent(d,actor)
    w=Warehouse.objects.select_for_update().get(pk=d.source_id)
    if not reject and d.quantity>bucket_stock(w,d.item,d.location,d.trace)-reserved(w,d.item,d.location,d.trace):raise ValidationError('موجودی آزاد کافی نیست.')
    d.status='rejected' if reject else 'approved';d.approved_by=actor;d.save()
    _log(d,actor,'رد انتقال' if reject else 'تأیید و رزرو انتقال',w.branch,d.reference)
    return d

@transaction.atomic
def send_transfer(actor,pk):
    d=StockTransfer.objects.select_for_update().get(pk=pk)
    _permission(actor,'add_stockmovement',d.source.branch_id)
    if d.status in ('transit','received'):return d
    if d.status!='approved':raise ValidationError('انتقال باید قبلاً تأیید شود.')
    if actor.pk==d.approved_by_id:raise ValidationError('ارسال‌کننده باید از تأییدکننده مستقل باشد.')
    w=Warehouse.objects.select_for_update().get(pk=d.source_id)
    if d.quantity>bucket_stock(w,d.item,d.location,d.trace)-reserved(w,d.item,d.location,d.trace,exclude_transfer=d.pk):raise ValidationError('موجودی آزاد کافی نیست.')
    d.sent_movement=_post(w,d.item,-d.quantity,d.location,d.trace,d.reference,actor,'ارسال به مقصد؛ موجودی در مسیر')
    d.sent_by=actor;d.status='transit';d.save()
    _log(d,actor,'ارسال و ثبت کالای در مسیر',w.branch,d.reference)
    return d

@transaction.atomic
def receive_transfer(actor,pk,location):
    d=StockTransfer.objects.select_for_update().get(pk=pk)
    _permission(actor,'add_stockmovement',d.destination.branch_id)
    if d.status=='received':return d
    if d.status!='transit':raise ValidationError('انتقال هنوز ارسال نشده است.')
    if d.sent_by_id==actor.pk:raise ValidationError('ارسال و دریافت مقصد باید توسط دو شخص مستقل انجام شوند.')
    w=Warehouse.objects.select_for_update().get(pk=d.destination_id)
    validate_bucket(w,d.item,location,d.trace,d.quantity,incoming=True,require_location=True,ignore_transfer=d.pk)
    d.received_movement=_post(w,d.item,d.quantity,location,d.trace,d.reference,actor,'تأیید دریافت انتقال در مقصد')
    d.destination_location=location;d.received_by=actor;d.status='received';d.save()
    _log(d,actor,'تأیید دریافت انتقال',w.branch,d.reference)
    return d

@transaction.atomic
def request_correction(actor,warehouse,item,location,trace,quantity,reason,key):
    _permission(actor,'add_stockcorrection',warehouse.branch_id)
    quantity=Decimal(str(quantity))
    if not quantity:raise ValidationError('اصلاح صفر قابل ثبت نیست.')
    w=Warehouse.objects.select_for_update().get(pk=warehouse.pk)
    validate_bucket(w,item,location,trace,abs(quantity),require_location=True)
    if len(reason.strip())<10:raise ValidationError('علت اصلاح باید روشن و حداقل ۱۰ حرف باشد.')
    previous=replay(StockCorrection,key,warehouse_id=w.pk,item_id=item.pk,location_id=location.pk,trace_id=trace.pk if trace else None,quantity=quantity,reason=reason,requested_by_id=actor.pk)
    if previous:return previous
    d=StockCorrection.objects.create(warehouse=w,item=item,location=location,trace=trace,quantity=quantity,reason=reason,operation_key=key,requested_by=actor)
    _log(d,actor,'درخواست سند اصلاحی',w.branch,reason)
    return d

@transaction.atomic
def approve_correction(actor,pk,reject=False):
    d=StockCorrection.objects.select_for_update().get(pk=pk)
    _permission(actor,'approve_operations',d.warehouse.branch_id)
    if d.status==('rejected' if reject else 'approved'):return d
    _pending(d);_independent(d,actor)
    w=Warehouse.objects.select_for_update().get(pk=d.warehouse_id)
    if not reject:
        validate_bucket(w,d.item,d.location,d.trace,abs(d.quantity),incoming=d.quantity>0)
        if bucket_stock(w,d.item,d.location,d.trace)+d.quantity<reserved(w,d.item,d.location,d.trace):raise ValidationError('اصلاح، موجودی رزروشده را نقض می‌کند.')
        d.movement=_post(w,d.item,d.quantity,d.location,d.trace,f'COR-{d.pk}',actor,d.reason)
    d.status='rejected' if reject else 'approved';d.approved_by=actor;d.save()
    _log(d,actor,'رد اصلاح موجودی' if reject else 'ثبت سند اصلاحی مستقل',w.branch,d.reason)
    return d

@transaction.atomic
def request_count(actor,warehouse,reference,rows,key):
    _permission(actor,'add_stockcount',warehouse.branch_id)
    w=Warehouse.objects.select_for_update().get(pk=warehouse.pk)
    previous=replay(StockCount,key,warehouse_id=w.pk,reference=reference,requested_by_id=actor.pk)
    if previous:return previous
    if not rows:raise ValidationError('حداقل یک ردیف شمارش لازم است.')
    balances={}
    for m in StockBalance.objects.filter(warehouse=w).values('item_id','location_id','trace_id','quantity'):
        bucket=(m['item_id'],m['location_id'],m['trace_id']);balances[bucket]=balances.get(bucket,ZERO)+m['quantity']
    keys=set();prepared=[]
    for row in rows:
        item,loc,trace=row['item'],row.get('location'),row.get('trace')
        counted=Decimal(str(row['counted']))
        if not counted.is_finite() or counted<0:raise ValidationError('شمارش نباید منفی باشد.')
        if counted:validate_bucket(w,item,loc,trace,counted,require_location=True)
        elif loc and loc.warehouse_id!=w.pk:raise ValidationError('محل متعلق به این انبار نیست.')
        if trace and trace.item_id!=item.pk:raise ValidationError('بچ یا سریال متعلق به این کالا نیست.')
        if item.tracking!='bulk' and not trace:raise ValidationError('بچ یا سریال کالای ردیابی‌شده الزامی است.')
        bucket=(item.pk,loc.pk if loc else None,trace.pk if trace else None)
        if bucket in keys:raise ValidationError('ردیف شمارش تکراری است.')
        keys.add(bucket);prepared.append((row,balances.get(bucket,ZERO),counted))
    if {k for k,v in balances.items() if v!=0}-keys:raise ValidationError('همهٔ محل‌ها و بچ‌های دارای موجودی این انبار باید در شمارش درج شوند.')
    baseline=StockMovement.objects.filter(warehouse=w).aggregate(v=Max('pk'))['v'] or 0
    d=StockCount.objects.create(warehouse=w,reference=reference,baseline=baseline,operation_key=key,requested_by=actor)
    for row,expected,counted in prepared:
        StockCountLine.objects.create(count=d,item=row['item'],location=row.get('location'),trace=row.get('trace'),expected=expected,counted=counted)
    _log(d,actor,'ثبت شمارش انبار',w.branch,reference)
    return d

@transaction.atomic
def approve_count(actor,pk,reject=False):
    d=StockCount.objects.select_for_update().get(pk=pk)
    _permission(actor,'approve_operations',d.warehouse.branch_id)
    if d.status==('rejected' if reject else 'approved'):return d
    _pending(d);_independent(d,actor)
    w=Warehouse.objects.select_for_update().get(pk=d.warehouse_id)
    if not reject:
        if StockMovement.objects.filter(warehouse=w,pk__gt=d.baseline).exists():raise ValidationError('پس از شمارش، گردش جدید ثبت شده؛ شمارش قدیمی قابل اعمال نیست. مجدداً شمارش کنید.')
        for line in sorted(d.lines.select_related('item','location','trace'),key=lambda r:r.difference):
            difference=line.difference
            if not difference:continue
            validate_bucket(w,line.item,line.location,line.trace,abs(difference),incoming=difference>0)
            if line.counted<reserved(w,line.item,line.location,line.trace):raise ValidationError('مغایرت با موجودی رزروشده تداخل دارد؛ ابتدا درخواست‌های رزرو را تعیین تکلیف کنید.')
            line.movement=_post(w,line.item,difference,line.location,line.trace,d.reference,actor,'سند مغایرت انبارگردانی')
            line.save(update_fields=['movement'])
    d.status='rejected' if reject else 'approved';d.approved_by=actor;d.save()
    _log(d,actor,'رد شمارش' if reject else 'تأیید و ثبت مغایرت انبارگردانی',w.branch,d.reference)
    return d

@transaction.atomic
def request_payment(actor,allocation,amount,reference,description,key):
    require_permission(actor,'add_moneyentry');require_contract(actor,allocation.contract_id,True)
    require_factory(actor,allocation.account.branch_id)
    from .models import Contract
    Contract.objects.select_for_update().get(pk=allocation.contract_id)
    allocation=Allocation.objects.select_for_update().get(pk=allocation.pk)
    amount=positive(amount,money=True)
    previous=replay(PaymentRequest,key,allocation_id=allocation.pk,amount=amount,reference=reference,description=description,requested_by_id=actor.pk)
    if previous:return previous
    if not reference.strip():raise ValidationError('شماره سند الزامی است.')
    pending=summed(PaymentRequest.objects.filter(allocation=allocation,status='pending'),'amount')
    if not allocation.active or amount>allocation.remaining-pending:raise ValidationError('مبلغ از مانده تخصیص پس از کسر درخواست‌های پرداخت باز بیشتر است.')
    if PaymentRequest.objects.filter(allocation__account=allocation.account,reference=reference).exclude(status__in=['rejected','cancelled']).exists():raise ValidationError('شماره سند درخواست تکراری است.')
    d=PaymentRequest.objects.create(allocation=allocation,amount=amount,reference=reference,description=description,operation_key=key,requested_by=actor)
    _log(d,actor,'درخواست پرداخت',allocation.account.branch,reference)
    return d

@transaction.atomic
def approve_payment(actor,pk,reject=False):
    contract_id=PaymentRequest.objects.values_list('allocation__contract_id',flat=True).get(pk=pk)
    from .models import Contract
    Contract.objects.select_for_update().get(pk=contract_id)
    d=PaymentRequest.objects.select_for_update().get(pk=pk)
    require_permission(actor,'approve_operations');require_contract(actor,d.allocation.contract_id,True)
    require_factory(actor,d.allocation.account.branch_id)
    if d.status==('rejected' if reject else 'approved'):return d
    _pending(d);_independent(d,actor)
    if not reject:d.entry=pay(d.allocation_id,d.amount,d.reference,d.operation_key,None,d.description)
    d.status='rejected' if reject else 'approved';d.approved_by=actor;d.save()
    audit('رد پرداخت' if reject else 'تأیید مستقل پرداخت',d.reference,actor,str(d.amount),branch=d.allocation.account.branch,contract=d.allocation.contract)
    return d

@transaction.atomic
def cancel_reservation(actor,kind,pk):
    model=MaterialRequest if kind=='material' else StockTransfer if kind=='transfer' else None
    if model is None:raise PermissionDenied
    d=model.objects.select_for_update().get(pk=pk)
    warehouse=d.warehouse if kind=='material' else d.source
    _permission(actor,'approve_operations',warehouse.branch_id)
    if d.status=='rejected':return d
    if d.status not in ('pending','approved'):raise ValidationError('پس از تحویل یا ارسال، لغو رزرو مجاز نیست؛ تعیین تکلیف یا برگشت ثبت کنید.')
    _independent(d,actor)
    Warehouse.objects.select_for_update().get(pk=warehouse.pk)
    d.status='rejected';d.approved_by=actor;d.save()
    _log(d,actor,'لغو درخواست و آزادسازی رزرو',warehouse.branch)
    return d
