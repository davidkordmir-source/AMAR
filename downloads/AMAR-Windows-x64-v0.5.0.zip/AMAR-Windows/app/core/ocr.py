"""Bounded offline extraction jobs. Suggestions never create financial entries."""
import json,os,re,subprocess,sys,tempfile,threading,shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from django.conf import settings
from django.db import connections

def propose(text):
    text=text.translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')).replace('\u200c',' ')
    text=re.sub('[\u200e\u200f\u202a-\u202e\u2066-\u2069]','',text)
    result={}
    match=re.search(r'(?:شماره\s*(?:قرارداد|سند|فاکتور)|(?:Contract|Invoice)\s*(?:No\.?|Number)?)[\s:#：-]*([A-Za-z0-9آ-ی/_.-]{1,80})',text,re.I)
    if match:result['reference']=match.group(1)
    match=re.search(r'(?:مبلغ|جمع\s*کل|قابل\s*پرداخت|Total|Amount)[\s:：]*([0-9][0-9,٬ \t]{0,35})\s*(ریال|تومان|IRR|Rial)?',text,re.I)
    if match:
        digits=re.sub(r'[^0-9]','',match.group(1))
        if digits and match.group(2):
            amount=int(digits)*(10 if match.group(2)=='تومان' else 1)
            if 0<=amount<=999999999999999999:result['amount']=amount
    match=re.search(r'(?<!\d)((?:13|14|20)\d{2}[/.-]\d{1,2}[/.-]\d{1,2})(?!\d)',text)
    if match:result['document_date']=match.group(1)
    return result

class ExtractionQueue:
    def __init__(self):
        self.lock=threading.Lock();self.executor=ThreadPoolExecutor(max_workers=2,thread_name_prefix='AMAR-OCR');self.queued=set();self.processes=set();self.closing=False
    def submit(self,version_id):
        with self.lock:
            if self.closing or version_id in self.queued:return False
            if len(self.queued)>=50:return False
            self.queued.add(version_id)
            try:self.executor.submit(self.run,version_id)
            except RuntimeError:
                self.queued.discard(version_id);return False
            return True
    def run(self,version_id):
        from .models import DocumentVersion,DocumentExtraction,Document
        process=None
        try:
            version=DocumentVersion.objects.select_related('document').get(pk=version_id)
            if version.document.archived_at:return
            Document.objects.filter(pk=version.document_id,current_version_id=version_id).update(ocr_status='running')
            with tempfile.TemporaryDirectory(dir=settings.DATA_DIR,prefix='ocr-job-') as folder:
                result_file=Path(folder)/'result.json'
                preview=Path(folder)/'preview.png'
                command=[sys.executable,'-I','-X','utf8',str(settings.BASE_DIR/'desktop/ocr_worker.py'),'--input',str(settings.DATA_DIR/'documents'/version.filename),'--mime',version.content_type,'--result',str(result_file),'--preview',str(preview)]
                if os.name!='nt':raise RuntimeError('Windows OCR runtime required')
                process=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
                with self.lock:
                    if self.closing:process.terminate()
                    self.processes.add(process)
                try:process.wait(timeout=120)
                except subprocess.TimeoutExpired:process.kill();process.wait();raise RuntimeError('extraction_timeout')
                with self.lock:closing=self.closing
                if closing:
                    Document.objects.filter(pk=version.document_id,current_version_id=version_id).update(ocr_status='pending');return
                result=json.loads(result_file.read_text(encoding='utf-8'))
                if preview.is_file() and preview.stat().st_size<=20*1024**2:
                    from PIL import Image
                    with Image.open(preview) as picture:picture.verify()
                    destination=settings.DATA_DIR/'document-previews';destination.mkdir(mode=0o700,exist_ok=True)
                    temporary=destination/(version.filename+'.tmp');shutil.copyfile(preview,temporary);temporary.replace(destination/(version.filename+'.png'))
                text=result.get('text','')[:200000]
                success=bool(result.get('success') and text.strip())
                DocumentExtraction.objects.create(version=version,success=success,text=text,suggestions=propose(text) if success else {},engine=result.get('engine','Tesseract')[:100],error_code='' if success else 'unreadable',partial=bool(result.get('partial')))
                Document.objects.filter(pk=version.document_id,current_version_id=version_id).update(ocr_status='ready' if success else 'failed')
        except Exception:
            Document.objects.filter(current_version_id=version_id).update(ocr_status='pending' if self.closing else 'failed')
        finally:
            with self.lock:
                self.queued.discard(version_id)
                if process:self.processes.discard(process)
                queued=list(self.queued);closing=self.closing
            if not closing:
                next_version=Document.objects.filter(ocr_status='pending',current_version__isnull=False).exclude(current_version_id__in=queued).order_by('pk').values_list('current_version_id',flat=True).first()
                if next_version:self.submit(next_version)
            connections.close_all()
    def close(self):
        with self.lock:
            self.closing=True;processes=list(self.processes)
        for process in processes:
            if process.poll() is None:process.terminate()
        self.executor.shutdown(wait=True,cancel_futures=True)

_queue=None
_lock=threading.Lock()
def enqueue(version_id):
    global _queue
    with _lock:
        if _queue is None:_queue=ExtractionQueue()
        queue=_queue
    return queue.submit(version_id)

def shutdown_jobs():
    global _queue
    with _lock:queue=_queue;_queue=None
    if queue:queue.close()

def resume_jobs():
    from .models import Document
    for version in Document.objects.filter(ocr_status__in=['pending','running'],current_version__isnull=False).order_by('pk').values_list('current_version_id',flat=True)[:50]:enqueue(version)
