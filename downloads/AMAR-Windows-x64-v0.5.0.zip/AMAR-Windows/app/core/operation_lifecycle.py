"""Revise unposted requests, preserving previous versions and approvals."""
from django.core.exceptions import PermissionDenied,ValidationError
from django.db import transaction
from django.utils import timezone
from . import models as m,services
from .access import require_permission,require_factory,require_contract,root
from .lifecycle import reason_text

MODELS={'material':m.MaterialRequest,'transfer':m.StockTransfer,'correction':m.StockCorrection,'count':m.StockCount,'payment':m.PaymentRequest}

def permission(kind,action):return action+'_'+('moneyentry' if kind=='payment' else MODELS[kind]._meta.model_name)

def branch_for(document,kind):return document.allocation.account.branch if kind=='payment' else document.source.branch if kind=='transfer' else document.warehouse.branch

def blockers(document,kind,editing=False):
    if document.archived_at:return ['این درخواست قبلاً از فهرست فعال حذف شده است.']
    if kind=='payment' and (document.entry_id or document.allocation.contract.paid):return ['پرداخت مالی مرتبط ثبت شده است؛ حذف یا تغییر مبلغ درخواست مجاز نیست.']
    allowed=['pending'] if editing else ['pending','rejected','cancelled']+(['approved'] if kind in ['material','transfer'] else [])
    if document.status not in allowed:return ['این درخواست تأیید یا اجرا شده است؛ برای تغییر موجودی یا مبلغ قطعی، سند اصلاحی ثبت کنید.']
    return []

@transaction.atomic
def revise(actor,kind,pk,reason,key,create=None):
    if kind not in MODELS:raise PermissionDenied
    require_permission(actor,permission(kind,'change' if create else 'delete'))
    model=MODELS[kind]
    if kind=='payment':
        contract=model.objects.values_list('allocation__contract_id',flat=True).get(pk=pk)
        require_contract(actor,contract,True);m.Contract.objects.select_for_update().get(pk=contract)
    document=model.objects.select_for_update().get(pk=pk)
    branch=branch_for(document,kind);require_factory(actor,branch.pk)
    if not root(actor) and document.requested_by_id!=actor.pk and not actor.has_perm('core.approve_operations'):raise PermissionDenied
    reason=reason_text(reason)
    if key==document.operation_key:raise ValidationError('شناسهٔ ویرایش باید تازه باشد؛ صفحهٔ ویرایش را دوباره باز کنید.')
    previous=m.OperationRevision.objects.filter(operation_key=key).first()
    if previous:
        if previous.kind!=kind or previous.original_id!=pk:raise ValidationError('شناسهٔ عملیات با درخواست دیگری استفاده شده است.')
        return model.objects.get(pk=previous.replacement_id) if previous.replacement_id else document
    errors=blockers(document,kind,editing=bool(create))
    if errors:raise ValidationError(errors)
    if document.status=='approved':
        require_permission(actor,'approve_operations')
        if actor.pk==document.requested_by_id:raise ValidationError('لغو درخواست رزروشده با تأیید شخص مستقل انجام می‌شود.')
    if kind=='payment':m.Account.objects.select_for_update().get(pk=document.allocation.account_id)
    else:m.Warehouse.objects.select_for_update().get(pk=document.source_id if kind=='transfer' else document.warehouse_id)
    document.archived_at=timezone.now();document.archived_by=actor;document.archive_reason=reason
    document.status='cancelled' if kind=='payment' else 'rejected';document.save()
    replacement=create() if create else None
    if kind=='payment':
        # A scan follows the revised, unposted request, retaining its review history.
        linked=m.Document.objects.filter(payment_request=document)
        for scan in linked.select_for_update():
            if replacement and (replacement.amount!=scan.amount or replacement.reference!=scan.reference):
                scan.confirmed_at=None;scan.confirmed_by=None
            if replacement:
                scan.payment_request=replacement;scan.contract=replacement.allocation.contract;scan.account=replacement.allocation.account;scan.branch=scan.account.branch;scan.save()
    m.OperationRevision.objects.create(kind=kind,original_id=pk,replacement_id=replacement.pk if replacement else None,reason=reason,operation_key=key,actor=actor)
    services.audit('ویرایش درخواست و ایجاد نسخهٔ جدید' if replacement else 'حذف مشروط درخواست بدون اجرای قطعی',f'{kind} #{pk}',actor,reason+(f' → #{replacement.pk}' if replacement else ''),branch=branch,contract=document.allocation.contract if kind=='payment' else None)
    return replacement or document
