from .helpers import body
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import io
import uuid

from django.contrib.auth.models import Group, User
from django.core.exceptions import ValidationError
from django.core.management import call_command
from django.db import close_old_connections
from django.test import Client, TestCase, TransactionTestCase
from django.urls import reverse

from core import services
from core.models import Account, Allocation, AuditEvent, Branch, Contract, ContractLine, Item, MoneyEntry, Organization, Receipt, StockMovement, Warehouse
from core.reporting import inventory_rows

def fixture():
    consumer = Organization.objects.create(name="مصرف‌کننده", role="consumer")
    producer = Organization.objects.create(name="تولیدکننده", role="producer")
    branch = Branch.objects.create(name="مرکزی", code="HQ", city="تهران", organization=consumer)
    warehouse = Warehouse.objects.create(name="اصلی", branch=branch)
    item = Item.objects.create(name="دستگاه", sku="M-1")
    account = Account.objects.create(name="عملیاتی", branch=branch, opening_balance=800, credit_limit=200)
    contract = Contract.objects.create(number="C-1", title="خرید دستگاه", supplier=producer, warehouse=warehouse)
    line = ContractLine.objects.create(contract=contract, item=item, quantity=5, unit_price=100)
    return branch, warehouse, item, account, contract, line

class WorkflowTests(TestCase):
    def setUp(self):
        self.branch, self.warehouse, self.item, self.account, self.contract, self.line = fixture()
    def approve(self):
        services.approve_contract(self.contract.pk)
    def allocation(self, amount=500):
        self.approve()
        return services.allocate(self.contract.pk, self.account.pk, amount, uuid.uuid4())
    def test_approval_creates_pending_and_financial_commitment_but_no_physical_stock(self):
        self.assertEqual(inventory_rows(), [])
        self.approve()
        self.contract.refresh_from_db()
        self.assertEqual(self.contract.outstanding, 500)
        self.assertEqual(services.stock(self.warehouse, self.item), 0)
        self.assertEqual(inventory_rows()[0]["pending"], 5)
        self.assertEqual(self.account.balance, 800)
        self.assertEqual(Allocation.objects.count(), 0)
    def test_partial_then_full_receipt_updates_correct_ledgers(self):
        self.approve()
        services.receive(self.contract.pk, {self.line.pk: 2}, "R-1", uuid.uuid4())
        self.contract.refresh_from_db()
        self.assertEqual(self.contract.status, "partial")
        self.assertEqual(services.stock(self.warehouse, self.item), 2)
        self.assertEqual(inventory_rows()[0]["pending"], 3)
        services.receive(self.contract.pk, {self.line.pk: 3}, "R-2", uuid.uuid4())
        self.contract.refresh_from_db()
        self.assertEqual(self.contract.status, "received")
        self.assertEqual(services.stock(self.warehouse, self.item), 5)
        self.assertEqual(inventory_rows()[0]["pending"], 0)
    def test_receipt_retries_do_not_double_count(self):
        self.approve()
        key = uuid.uuid4()
        first = services.receive(self.contract.pk, {self.line.pk: 2}, "R-1", key)
        again = services.receive(self.contract.pk, {self.line.pk: 2}, "R-1", key)
        self.assertEqual(first.pk, again.pk)
        self.assertEqual(services.stock(self.warehouse, self.item), 2)
        with self.assertRaises(ValidationError):
            services.receive(self.contract.pk, {self.line.pk: 3}, "R-1", key)
    def test_over_receipt_rolls_back_entire_document(self):
        self.approve()
        second_item = Item.objects.create(name="پمپ", sku="P-1")
        # Test fixture represents a contract with two lines, before any receipt.
        second = ContractLine.objects.create(contract=self.contract, item=second_item, quantity=1, unit_price=10)
        with self.assertRaises(ValidationError):
            services.receive(self.contract.pk, {self.line.pk: 1, second.pk: 2}, "BAD", uuid.uuid4())
        self.assertEqual(Receipt.objects.count(), 0)
        self.assertEqual(StockMovement.objects.count(), 0)
    def test_draft_cannot_be_received_or_funded(self):
        with self.assertRaises(ValidationError):
            services.receive(self.contract.pk, {self.line.pk: 1}, "R", uuid.uuid4())
        with self.assertRaises(ValidationError):
            services.allocate(self.contract.pk, self.account.pk, 100, uuid.uuid4())
    def test_wrong_contract_line_rejected(self):
        self.approve()
        with self.assertRaises(ValidationError):
            services.receive(self.contract.pk, {99999: 1}, "R", uuid.uuid4())
    def test_countable_items_cannot_have_fractional_quantity(self):
        with self.assertRaises(ValidationError):
            services.adjust_stock(self.warehouse.pk, self.item.pk, "in", "0.5", "R", uuid.uuid4())
    def test_fractional_weight_and_rial_rounding(self):
        self.item.unit = "kg"
        self.item.save()
        self.line.quantity = Decimal("1.125")
        self.line.unit_price = Decimal("100")
        self.line.save()
        self.assertEqual(self.line.total, 113)
        self.approve()
        services.receive(self.contract.pk, {self.line.pk: Decimal("1.125")}, "R", uuid.uuid4())
        self.assertEqual(services.stock(self.warehouse, self.item), Decimal("1.125"))
    def test_money_rejects_negative_fractional_nonfinite_and_overflow(self):
        for value in [0, -1, "1.5", "NaN", "Infinity", "1e50"]:
            with self.subTest(value=value), self.assertRaises(ValidationError):
                services.deposit(self.account.pk, value, "R", uuid.uuid4())
        self.assertEqual(MoneyEntry.objects.count(), 0)
    def test_large_rial_amount_keeps_every_digit(self):
        amount = 12345678901234567
        services.deposit(self.account.pk, amount, "LARGE", uuid.uuid4())
        entry = MoneyEntry.objects.get(reference="LARGE")
        self.assertEqual(entry.amount, amount)
        self.assertEqual(self.account.balance, amount + 800)
    def test_fixed_point_stock_sums_exactly_without_binary_rounding(self):
        self.item.unit = "kg"
        self.item.save()
        for i in range(10):
            services.adjust_stock(self.warehouse.pk, self.item.pk, "in", "0.1", f"I-{i}", uuid.uuid4())
        self.assertEqual(services.stock(self.warehouse, self.item), Decimal("1"))
        services.adjust_stock(self.warehouse.pk, self.item.pk, "out", 1, "O", uuid.uuid4())
        self.assertEqual(services.stock(self.warehouse, self.item), Decimal("0"))
    def test_allocation_reserves_then_payment_reduces_cash_and_reservation(self):
        a = self.allocation()
        self.assertEqual(self.account.balance, 800)
        self.assertEqual(self.account.reserved, 500)
        self.assertEqual(self.account.available, 500)
        services.pay(a.pk, 200, "PAY-1", uuid.uuid4())
        self.assertEqual(self.account.balance, 600)
        self.assertEqual(self.account.reserved, 300)
        self.assertEqual(self.account.available, 500)
        self.assertEqual(self.contract.outstanding, 300)
    def test_payment_idempotence_and_overpayment(self):
        a = self.allocation()
        key = uuid.uuid4()
        first = services.pay(a.pk, 300, "P", key)
        self.assertEqual(services.pay(a.pk, 300, "P", key).pk, first.pk)
        with self.assertRaises(ValidationError):
            services.pay(a.pk, 201, "P2", uuid.uuid4())
        with self.assertRaises(ValidationError):
            services.pay(a.pk, 301, "P", key)
        self.assertEqual(self.account.balance, 500)
        self.assertEqual(MoneyEntry.objects.count(), 1)
    def test_deposit_idempotence_and_unique_bank_reference(self):
        key = uuid.uuid4()
        services.deposit(self.account.pk, 100, "BANK-1", key)
        services.deposit(self.account.pk, 100, "BANK-1", key)
        self.assertEqual(self.account.balance, 900)
        with self.assertRaises(ValidationError):
            services.deposit(self.account.pk, 100, "BANK-1", uuid.uuid4())
    def test_overallocation_and_insufficient_resources_rejected(self):
        self.approve()
        with self.assertRaises(ValidationError):
            services.allocate(self.contract.pk, self.account.pk, 501, uuid.uuid4())
        self.account.opening_balance = 0
        self.account.save()
        with self.assertRaises(ValidationError):
            services.allocate(self.contract.pk, self.account.pk, 201, uuid.uuid4())
    def test_account_and_contract_branch_must_match(self):
        self.approve()
        b = Branch.objects.create(name="تبریز", code="TBZ", city="تبریز", organization=self.branch.organization)
        a = Account.objects.create(name="ب", branch=b, opening_balance=5000)
        with self.assertRaises(ValidationError):
            services.allocate(self.contract.pk, a.pk, 100, uuid.uuid4())
    def test_credit_can_be_used_but_not_exceeded(self):
        self.account.opening_balance = 0
        self.account.save()
        a = self.allocation(200)
        services.pay(a.pk, 200, "P", uuid.uuid4())
        self.assertEqual(self.account.balance, -200)
        self.assertEqual(self.account.available, 0)
        with self.assertRaises(ValidationError):
            services.allocate(self.contract.pk, self.account.pk, 1, uuid.uuid4())
    def test_cancel_releases_allocation_and_pending(self):
        a = self.allocation()
        services.cancel_contract(self.contract.pk)
        self.assertEqual(self.account.reserved, 0)
        self.assertEqual(self.account.balance, 800)
        self.assertEqual(inventory_rows(), [])
        with self.assertRaises(ValidationError):
            services.pay(a.pk, 1, "P", uuid.uuid4())
    def test_paid_or_delivered_contract_cannot_be_cancelled(self):
        a = self.allocation()
        services.pay(a.pk, 1, "P", uuid.uuid4())
        with self.assertRaises(ValidationError):
            services.cancel_contract(self.contract.pk)
    def test_stage_transitions_are_checked(self):
        with self.assertRaises(ValidationError):
            services.advance_contract(self.contract.pk, "ready")
        self.approve()
        services.advance_contract(self.contract.pk, "building")
        services.advance_contract(self.contract.pk, "ready")
        with self.assertRaises(ValidationError):
            services.advance_contract(self.contract.pk, "building")
    def test_outgoing_stock_cannot_be_negative_and_retry_is_safe(self):
        services.adjust_stock(self.warehouse.pk, self.item.pk, "in", 5, "I", uuid.uuid4())
        key = uuid.uuid4()
        services.adjust_stock(self.warehouse.pk, self.item.pk, "out", 3, "O", key)
        services.adjust_stock(self.warehouse.pk, self.item.pk, "out", 3, "O", key)
        with self.assertRaises(ValidationError):
            services.adjust_stock(self.warehouse.pk, self.item.pk, "out", 3, "O2", uuid.uuid4())
        self.assertEqual(services.stock(self.warehouse, self.item), 2)

class PermissionAndPageTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        fixture()
        call_command("setup_roles", stdout=io.StringIO())
        cls.owner = User.objects.create_superuser(username="owner", password="test-password-123")
        cls.clerk = User.objects.create_user(username="clerk", password="test-password-123")
        cls.clerk.groups.add(Group.objects.get(name="انباردار"))
        from core.models import AccessRole,UserProfile
        UserProfile.objects.create(user=cls.clerk,branch=Branch.objects.get(code='HQ'),role=AccessRole.objects.get(code='stock'))
    def test_pages_render_and_have_local_assets(self):
        self.client.force_login(self.owner)
        urls = ["/", "/contracts/", "/contracts/1/", "/contracts/new/", "/inventory/", "/finance/", "/directory/", "/audit/", "/exchange/", "/password/", "/finance/allocate/", "/finance/deposit/", "/finance/pay/", "/inventory/move/", "/contracts/1/receive/"]
        urls += [f"/directory/new/{k}/" for k in ["organization", "branch", "warehouse", "item", "account"]]
        for url in urls:
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'dir="rtl"')
                self.assertNotContains(response, "https://fonts.")
                self.assertNotContains(response, "cdn.")
    def test_login_required_and_stock_role_cannot_access_finance_or_approve(self):
        self.assertEqual(self.client.get("/").status_code, 302)
        self.client.force_login(self.clerk)
        self.assertEqual(self.client.get("/inventory/").status_code, 200)
        for url in ["/finance/", "/finance/deposit/", "/finance/pay/", "/exchange/", "/audit/"]:
            self.assertEqual(self.client.get(url).status_code, 403)
        self.assertEqual(self.client.post("/contracts/1/action/approve/").status_code, 403)
        self.assertEqual(Contract.objects.get(pk=1).status, "draft")
    def test_no_state_change_via_get_and_csrf_required(self):
        self.client.force_login(self.owner)
        self.assertEqual(self.client.get("/contracts/1/action/approve/").status_code, 405)
        csrf_client = Client(enforce_csrf_checks=True)
        csrf_client.force_login(self.owner)
        self.assertEqual(csrf_client.post("/contracts/1/action/approve/").status_code, 403)
    def test_bad_filters_do_not_crash_and_spreadsheet_export_is_safe(self):
        self.client.force_login(self.owner)
        for route in ["/", "/contracts/", "/inventory/", "/finance/"]:
            self.assertEqual(self.client.get(route, {"branch": "not-an-id", "page": "wrong"}).status_code, 200)
        item = Item.objects.get()
        item.name = "=WEBSERVICE(1)"
        item.save()
        services.adjust_stock(1, item.pk, "in", 1, "I", uuid.uuid4())
        response = self.client.get("/inventory/?export=csv")
        self.assertIn("'=WEBSERVICE(1)", body(response))
    def test_contract_form_creates_lines_and_recorded_audit(self):
        self.client.force_login(self.owner)
        response = self.client.post("/contracts/new/", {
            "number": "C-NEW", "title": "خرید", "supplier": Organization.objects.get(role="producer").pk,
            "warehouse": 1, "lines-TOTAL_FORMS": 1, "lines-INITIAL_FORMS": 0,
            "lines-MIN_NUM_FORMS": 1, "lines-MAX_NUM_FORMS": 100,
            "lines-0-item": 1, "lines-0-quantity": 2, "lines-0-unit_price": 100,
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Contract.objects.get(number="C-NEW").total, 200)
        self.assertTrue(AuditEvent.objects.filter(action="ایجاد پیش‌نویس قرارداد").exists())

class ConcurrentWriteTests(TransactionTestCase):
    """Real SQLite file is deliberate: validate serialized writers, not mock locks."""
    def setUp(self):
        self.branch, self.warehouse, self.item, self.account, self.contract, self.line = fixture()
        services.approve_contract(self.contract.pk)
    def test_two_payments_cannot_spend_the_same_allocation(self):
        a = services.allocate(self.contract.pk, self.account.pk, 500, uuid.uuid4())
        def payment(n):
            close_old_connections()
            try:
                services.pay(a.pk, 400, f"P-{n}", uuid.uuid4())
                return "paid"
            except ValidationError:
                return "rejected"
            finally:
                close_old_connections()
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(payment, [1, 2]))
        self.assertCountEqual(results, ["paid", "rejected"])
        self.assertEqual(MoneyEntry.objects.count(), 1)
        self.assertEqual(self.account.balance, 400)
    def test_two_receipts_cannot_exceed_order_quantity(self):
        def receive(n):
            close_old_connections()
            try:
                services.receive(self.contract.pk, {self.line.pk: 4}, f"R-{n}", uuid.uuid4())
                return "received"
            except ValidationError:
                return "rejected"
            finally:
                close_old_connections()
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(receive, [1, 2]))
        self.assertCountEqual(results, ["received", "rejected"])
        self.assertEqual(services.stock(self.warehouse, self.item), 4)
