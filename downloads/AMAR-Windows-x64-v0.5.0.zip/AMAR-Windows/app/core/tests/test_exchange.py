import base64
import copy
import io
import json
from pathlib import Path
import tempfile

from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.test import TestCase, override_settings

from core import sync
from core.models import Account, Contract, ImportedSnapshot, MoneyEntry, StockMovement, TrustedSource
from core.tests.test_workflows import fixture

class ExchangeTests(TestCase):
    def setUp(self):
        fixture()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.source_dir = Path(self.tmp.name) / "source"
        self.target_dir = Path(self.tmp.name) / "target"
        self.source_dir.mkdir()
        self.target_dir.mkdir()
        with override_settings(DATA_DIR=self.source_dir):
            self.identity = sync.public_identity()
            self.source_id, self.key = sync.identity()
            self.first = sync.export_report()
            self.second = sync.export_report()
        self.override = override_settings(DATA_DIR=self.target_dir)
        self.override.enable()
        self.addCleanup(self.override.disable)
    def trust(self):
        return sync.trust_source(sync.canonical(self.identity), "شعبه مستقل")
    def signed(self, envelope):
        envelope["signature"] = base64.b64encode(self.key.sign(sync.canonical(envelope["payload"]))).decode()
        return sync.canonical(envelope)
    def test_trusted_report_import_is_read_only_and_idempotent(self):
        self.trust()
        counts = (Contract.objects.count(), Account.objects.count(), StockMovement.objects.count(), MoneyEntry.objects.count())
        snapshot = sync.import_report(self.first)
        self.assertEqual(sync.import_report(self.first).pk, snapshot.pk)
        self.assertEqual(ImportedSnapshot.objects.count(), 1)
        self.assertEqual((Contract.objects.count(), Account.objects.count(), StockMovement.objects.count(), MoneyEntry.objects.count()), counts)
        self.assertEqual(snapshot.payload["contracts"][0]["total"], "500")
    def test_unknown_source_is_not_automatically_trusted(self):
        with self.assertRaisesMessage(ValidationError, "مبدأ ناشناخته"):
            sync.import_report(self.first)
        self.assertEqual(TrustedSource.objects.count(), 0)
    def test_tampering_is_rejected(self):
        self.trust()
        data = json.loads(self.first)
        data["payload"]["accounts"][0]["balance"] = "999999"
        with self.assertRaisesMessage(ValidationError, "امضای فایل"):
            sync.import_report(sync.canonical(data))
        self.assertEqual(ImportedSnapshot.objects.count(), 0)
    def test_latest_snapshot_replaces_view_without_adding_business_rows(self):
        source = self.trust()
        sync.import_report(self.first)
        second = sync.import_report(self.second)
        self.assertEqual(source.latest.pk, second.pk)
        self.assertEqual(ImportedSnapshot.objects.count(), 2)
        with self.assertRaisesMessage(ValidationError, "قدیمی"):
            sync.import_report(self.first)
        self.assertEqual(source.latest.pk, second.pk)
    def test_conflicting_signed_sequence_rejected(self):
        self.trust()
        sync.import_report(self.first)
        data = json.loads(self.first)
        data["payload"]["accounts"][0]["balance"] = "700"
        with self.assertRaisesMessage(ValidationError, "متعارض"):
            sync.import_report(self.signed(data))
    def test_central_totals_count_only_latest_report_per_source(self):
        from core.reporting import consolidate_sources
        source = self.trust()
        sync.import_report(self.first)
        data = json.loads(self.second)
        data["payload"]["accounts"][0]["balance"] = "900"
        sync.import_report(self.signed(data))
        totals, rows = consolidate_sources([source])
        self.assertEqual(totals["sources"], 1)
        self.assertEqual(totals["branches"], 1)
        self.assertEqual(totals["balance"], 900)
        self.assertEqual(Account.objects.get().balance, 800)
    def test_valid_signature_does_not_bypass_schema_validation(self):
        self.trust()
        data = json.loads(self.first)
        for bad in ["NaN", "Infinity", "1e99", {"not": "text"}]:
            test = copy.deepcopy(data)
            test["payload"]["accounts"][0]["balance"] = bad
            with self.subTest(value=bad), self.assertRaises(ValidationError):
                sync.import_report(self.signed(test))
    def test_malformed_files_and_oversize_are_rejected(self):
        for value in [b"[]", b'{"a":1,"a":2}', b"not json", b'{"x":NaN}', b"x" * (sync.MAX_FILE + 1)]:
            with self.assertRaises(ValidationError):
                sync.import_report(value)
        for source_id in [[], {}, 10, None]:
            malformed = json.loads(self.first)
            malformed["payload"]["source_id"] = source_id
            with self.subTest(source_id=source_id), self.assertRaises(ValidationError):
                sync.import_report(sync.canonical(malformed))
            identity = {**self.identity, "source_id": source_id}
            with self.assertRaises(ValidationError):
                sync.trust_source(sync.canonical(identity), "نامعتبر")
    def test_own_identity_cannot_be_trusted_as_another_branch(self):
        with self.assertRaises(ValidationError):
            sync.trust_source(sync.canonical(sync.public_identity()), "خودم")
    def test_imported_records_are_not_forwarded_as_local_records(self):
        self.trust()
        data = json.loads(self.first)
        data["payload"]["branches"].append({"code": "REMOTE", "name": "دور", "city": "تبریز", "consumer": "نمونه"})
        sync.import_report(self.signed(data))
        exported = json.loads(sync.export_report())
        self.assertEqual(len(exported["payload"]["branches"]), 1)
        self.assertNotEqual(exported["payload"]["source_id"], self.source_id)
    def test_imported_text_is_html_escaped_in_reports(self):
        source = self.trust()
        data = json.loads(self.first)
        data["payload"]["contracts"][0]["title"] = "<script>alert(1)</script>"
        sync.import_report(self.signed(data))
        user = User.objects.create_superuser(username="ceo", password="test-safe-password")
        self.client.force_login(user)
        response = self.client.get(f"/exchange/source/{source.pk}/?section=contracts")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "&lt;script&gt;")
        self.assertNotContains(response, "<script>alert")

    def test_current_report_index_is_replaced_and_signed_history_is_preserved(self):
        from core.models import RemoteRow,CurrentReport
        source=self.trust();first=sync.import_report(self.first)
        original_count=RemoteRow.objects.filter(source=source).count()
        data=json.loads(self.second);data['payload']['accounts'][0]['balance']='900'
        second=sync.import_report(self.signed(data))
        self.assertEqual(CurrentReport.objects.get(source=source).snapshot_id,second.pk)
        self.assertEqual(CurrentReport.objects.get(source=source).balance,'900')
        self.assertEqual(RemoteRow.objects.filter(source=source).count(),original_count)
        self.assertEqual(ImportedSnapshot.objects.get(pk=first.pk).payload['accounts'][0]['balance'],'800')

    def test_batched_import_returns_individual_result_and_rejects_bad_signature(self):
        from django.core.files.uploadedfile import SimpleUploadedFile
        self.trust();user=User.objects.create_superuser(username='batch-owner');self.client.force_login(user)
        response=self.client.post('/exchange/import/',{'report_file':SimpleUploadedFile('first.amar',self.first)},HTTP_X_AMAR_BATCH='1')
        self.assertEqual(response.status_code,200);self.assertTrue(response.json()['ok'])
        data=json.loads(self.second);data['payload']['accounts'][0]['balance']='1234'
        response=self.client.post('/exchange/import/',{'report_file':SimpleUploadedFile('bad.amar',sync.canonical(data))},HTTP_X_AMAR_BATCH='1')
        self.assertEqual(response.status_code,400);self.assertFalse(response.json()['ok']);self.assertEqual(ImportedSnapshot.objects.count(),1)
