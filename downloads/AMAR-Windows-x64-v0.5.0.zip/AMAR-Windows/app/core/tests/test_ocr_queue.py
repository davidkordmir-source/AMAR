from unittest import TestCase
from unittest.mock import Mock,patch
from core.ocr import ExtractionQueue

class ExtractionQueueTests(TestCase):
    def test_duplicate_and_full_queue_do_not_start_extra_workers(self):
        executor=Mock()
        with patch('core.ocr.ThreadPoolExecutor',return_value=executor):queue=ExtractionQueue()
        self.assertTrue(queue.submit(1));self.assertFalse(queue.submit(1))
        for number in range(2,51):self.assertTrue(queue.submit(number))
        self.assertFalse(queue.submit(51));self.assertEqual(executor.submit.call_count,50)
        queue.close();self.assertFalse(queue.submit(52))
    def test_executor_shutdown_race_leaves_document_available_for_retry(self):
        executor=Mock();executor.submit.side_effect=RuntimeError('executor closed')
        with patch('core.ocr.ThreadPoolExecutor',return_value=executor):queue=ExtractionQueue()
        self.assertFalse(queue.submit(1));self.assertNotIn(1,queue.queued)
        queue.close()
