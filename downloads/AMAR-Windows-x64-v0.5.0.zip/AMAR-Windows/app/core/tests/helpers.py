def body(response):
    return (b''.join(response.streaming_content) if response.streaming else response.content).decode('utf-8')
