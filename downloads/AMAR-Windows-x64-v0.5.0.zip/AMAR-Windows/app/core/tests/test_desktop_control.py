import os,threading,uuid
from unittest import TestCase,skipUnless
from unittest.mock import patch
from django.test import Client
from desktop.control import DesktopSession
from .test_enterprise import EnterpriseBase

class SessionIdentityTests(TestCase):
    def test_close_is_once_and_a_stale_request_does_not_close_new_instance(self):
        session=DesktopSession();called=[]
        session.register('old',lambda:called.append('old'))
        callbacks=[]
        class Timer:
            def __init__(self,delay,callback):callbacks.append(callback)
            def start(self):pass
        with patch('desktop.control.threading.Timer',Timer):
            self.assertTrue(session.request_close());self.assertFalse(session.request_close())
            session.register('new',lambda:called.append('new'));callbacks[0]()
            self.assertEqual(called,[])
            session.clear('old');self.assertTrue(session.available())
            self.assertTrue(session.request_close());callbacks[1]();self.assertEqual(called,['new'])

class DesktopCloseAuthorization(EnterpriseBase):
    def test_owner_post_requires_csrf_and_finishes_response_before_close(self):
        session=DesktopSession();closed=threading.Event();session.register('test-only',closed.set)
        with patch('desktop.control.session',session):
            client=Client(enforce_csrf_checks=True);client.force_login(self.owner)
            self.assertEqual(client.post('/desktop/close/').status_code,403);self.assertFalse(closed.is_set())
            response=client.get('/directory/');token=client.cookies['csrftoken'].value
            self.assertContains(response,'بستن برنامه')
            self.assertEqual(client.post('/desktop/close/',{'csrfmiddlewaretoken':token}).status_code,200)
            self.assertTrue(closed.wait(2))
    def test_scoped_user_cannot_stop_other_users_server(self):
        session=DesktopSession();called=[];session.register('test-only',lambda:called.append(True))
        with patch('desktop.control.session',session):
            self.client.force_login(self.requester)
            self.assertEqual(self.client.post('/desktop/close/').status_code,403)
            self.assertNotContains(self.client.get('/'),'action="/desktop/close/"');self.assertEqual(called,[])

@skipUnless(os.name=='nt','Requires the real Windows window API')
class LegacyWindowTests(TestCase):
    def test_only_control_window_with_matching_data_directory_is_revealed(self):
        import ctypes
        from ctypes import wintypes as w
        from desktop.legacy_window import reveal_running_window
        user=ctypes.WinDLL('user32',use_last_error=True);kernel=ctypes.WinDLL('kernel32')
        callback_type=ctypes.WINFUNCTYPE(ctypes.c_ssize_t,w.HWND,w.UINT,w.WPARAM,w.LPARAM)
        user.DefWindowProcW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];user.DefWindowProcW.restype=ctypes.c_ssize_t
        callback=callback_type(lambda *args:user.DefWindowProcW(*args))
        class WindowClass(ctypes.Structure):
            _fields_=[('style',w.UINT),('procedure',callback_type),('class_extra',ctypes.c_int),('window_extra',ctypes.c_int),('instance',w.HINSTANCE),('icon',w.HICON),('cursor',w.HANDLE),('background',w.HBRUSH),('menu',w.LPCWSTR),('name',w.LPCWSTR)]
        kernel.GetModuleHandleW.argtypes=[w.LPCWSTR];kernel.GetModuleHandleW.restype=w.HINSTANCE
        instance=kernel.GetModuleHandleW(None);klass=WindowClass();klass.procedure=callback;klass.instance=instance;klass.name='AMARControlWindow'
        user.RegisterClassW.argtypes=[ctypes.POINTER(WindowClass)];registered=user.RegisterClassW(ctypes.byref(klass))
        self.assertTrue(registered,'Test process must own its fixture window class')
        user.CreateWindowExW.argtypes=[w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,w.HWND,w.HMENU,w.HINSTANCE,ctypes.c_void_p];user.CreateWindowExW.restype=w.HWND
        user.DestroyWindow.argtypes=[w.HWND];user.IsWindowVisible.argtypes=[w.HWND]
        user.UnregisterClassW.argtypes=[w.LPCWSTR,w.HINSTANCE]
        windows=[];base='C:\\AMAR-Control-Test-'+uuid.uuid4().hex
        try:
            for suffix in ['other','matching']:
                window=user.CreateWindowExW(0,'AMARControlWindow','fixture',0x00CF0000,0,0,300,100,None,None,instance,None);self.assertTrue(window);windows.append(window)
                label=user.CreateWindowExW(0,'STATIC',base+'\\'+suffix,0x50000000,0,0,250,25,window,w.HMENU(201),instance,None);self.assertTrue(label)
            self.assertFalse(user.IsWindowVisible(windows[0]));self.assertFalse(user.IsWindowVisible(windows[1]))
            self.assertTrue(reveal_running_window(base+'\\matching'))
            self.assertTrue(user.IsWindowVisible(windows[1]));self.assertFalse(user.IsWindowVisible(windows[0]))
            self.assertFalse(reveal_running_window(base+'\\unknown'))
        finally:
            for window in windows:user.DestroyWindow(window)
            user.UnregisterClassW('AMARControlWindow',instance)
