from django.db import connection
from django.test.utils import CaptureQueriesContext
from core import models as m
from .test_enterprise import EnterpriseBase

class BoundedCatalogueTests(EnterpriseBase):
    def setUp(self):super().setUp();self.client.force_login(self.owner)
    def test_large_catalogue_form_does_not_render_every_item_or_warehouse(self):
        with CaptureQueriesContext(connection) as first:self.client.get('/contracts/new/')
        m.Item.objects.bulk_create([m.Item(sku=f'BIG-{n}',name=f'قطعه {n}') for n in range(1000)])
        m.Branch.objects.bulk_create([m.Branch(name=f'موقعیت {n}',code=f'BIG-{n}',organization=self.org,parent=self.hq,city='شهر آزمون') for n in range(1000)])
        branches=m.Branch.objects.filter(code__startswith='BIG-')
        m.Warehouse.objects.bulk_create([m.Warehouse(name='انبار آزمایشی',branch=b) for b in branches])
        with CaptureQueriesContext(connection) as second:response=self.client.get('/contracts/new/')
        self.assertLessEqual(len(second),len(first)+2)
        self.assertLess(len(response.content),45000);self.assertNotContains(response,'BIG-999')
        lookup=self.client.get('/lookup/item/').json()['results'];self.assertEqual(len(lookup),30)
        found=self.client.get('/lookup/item/?q=BIG-999').json()['results'];self.assertEqual(len(found),1)
    def test_structure_is_paginated_and_can_search_an_older_unit(self):
        m.Branch.objects.bulk_create([m.Branch(name=f'زیرمجموعه {n:04}',code=f'UNIT-{n}',organization=self.org,parent=self.hq,city='یزد') for n in range(1000)])
        response=self.client.get('/structure/');self.assertEqual(len(response.context['units']),40)
        self.assertEqual(response.context['units'].paginator.count,1006)
        searched=self.client.get('/structure/?q=UNIT-999');self.assertContains(searched,'UNIT-999');self.assertEqual(len(searched.context['units']),1)
    def test_lookup_respects_contract_grants_and_factory_boundaries(self):
        allowed,_=self.contract('VISIBLE-LOOKUP',True,True);hidden,_=self.contract('HIDDEN-LOOKUP')
        self.client.force_login(self.finance)
        rows=self.client.get('/lookup/contract/').json()['results'];self.assertEqual([row['id'] for row in rows],[allowed.pk])
        self.assertNotIn(hidden.pk,[row['id'] for row in rows])
        warehouse_rows=self.client.get('/lookup/warehouse/').json()['results'];self.assertNotIn(self.dest.pk,[row['id'] for row in warehouse_rows])
        self.assertEqual(self.client.get('/lookup/branch/?q=SMALL-B').json()['results'],[])
        m.ContractGrant.objects.filter(contract=allowed).delete()
        self.assertEqual(self.client.get('/lookup/contract/').json()['results'],[])
