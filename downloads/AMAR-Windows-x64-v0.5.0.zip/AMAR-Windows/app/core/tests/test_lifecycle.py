import uuid
from decimal import Decimal
from django.core.exceptions import ValidationError,PermissionDenied
from core import models as m,services,forms,lifecycle,operations as op
from core import operation_lifecycle as requests
from .test_enterprise import EnterpriseBase

REASON='اصلاح اشتباه ثبت اولیه پس از بررسی مدارک'

class ContractAndMoneyRevisions(EnterpriseBase):
    def setUp(self):
        super().setUp();self.client.force_login(self.owner)

    def test_contract_revision_releases_commitments_and_requires_another_approver(self):
        contract,line=self.contract('REVISE',True,True)
        allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        pending=op.request_payment(self.owner,allocation,100,'PENDING','',uuid.uuid4())
        data={'number':contract.number,'title':'موضوع ویرایش‌شده','supplier':self.supplier.pk,'warehouse':self.w.pk,'notes':'','due_date':''}
        line_data={'lines-TOTAL_FORMS':1,'lines-INITIAL_FORMS':1,'lines-MIN_NUM_FORMS':1,'lines-MAX_NUM_FORMS':100,
            'lines-0-id':line.pk,'lines-0-item':self.item.pk,'lines-0-quantity':20,'lines-0-unit_price':100}
        form=forms.ContractForm(data,instance=contract);lines=forms.ContractLineFormSet(line_data,instance=contract)
        self.assertTrue(form.is_valid(),form.errors);self.assertTrue(lines.is_valid(),lines.errors)
        lifecycle.save_contract_revision(self.owner,contract.pk,form,lines,REASON)
        contract.refresh_from_db();allocation.refresh_from_db();pending.refresh_from_db()
        self.assertEqual((contract.status,contract.total,contract.revised_by_id),('draft',2000,self.owner.pk))
        self.assertFalse(allocation.active);self.assertEqual(pending.status,'cancelled');self.assertEqual(self.account.reserved,0)
        with self.assertRaises(ValidationError):services.approve_contract(contract.pk,self.owner)
        services.approve_contract(contract.pk)
        self.assertEqual(m.Contract.objects.get(pk=contract.pk).status,'approved')

    def test_paid_contract_cannot_be_deleted_or_have_financial_fields_overposted(self):
        contract,line=self.contract('PAID',True,True);allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        services.pay(allocation.pk,100,'P1',uuid.uuid4())
        response=self.client.post(f'/contracts/{contract.pk}/edit/',{'title':'عنوان اصلاح شد','notes':'شرح جدید','due_date':'','number':'FORGED','supplier':self.org.pk,'warehouse':self.dest.pk,'reason':REASON})
        self.assertEqual(response.status_code,302)
        contract.refresh_from_db();self.assertEqual((contract.number,contract.warehouse_id,contract.total,contract.paid),('PAID',self.w.pk,1000,100))
        with self.assertRaises(ValidationError):lifecycle.archive_contract(self.owner,contract.pk,REASON)
        self.assertTrue(m.Contract.objects.filter(pk=contract.pk).exists())

    def test_unpaid_contract_delete_keeps_audit_and_versions_and_removes_pending_stock(self):
        contract,line=self.contract('ARCHIVE',True,True)
        lifecycle.archive_contract(self.owner,contract.pk,REASON)
        self.assertFalse(m.Contract.objects.filter(pk=contract.pk).exists())
        archived=m.Contract.all_objects.get(pk=contract.pk)
        self.assertEqual(archived.lines.count(),1);self.assertTrue(archived.access_grants.exists())
        self.assertTrue(m.AuditEvent.objects.filter(contract=archived,action='حذف قرارداد بدون پرداخت').exists())
        self.assertFalse(archived.is_open)
        from core.reporting import inventory_rows
        self.assertEqual(inventory_rows(user=self.owner)[0]['pending'],0)

    def test_received_contract_cannot_be_deleted_without_payment(self):
        contract,line=self.contract('RECEIVED')
        services.receive(contract.pk,{line.pk:1},'R',uuid.uuid4())
        with self.assertRaises(ValidationError):lifecycle.archive_contract(self.owner,contract.pk,REASON)

    def test_deposit_amount_revision_and_delete_reconcile_exact_balance(self):
        deposit=services.deposit(self.account.pk,1000,'D1',uuid.uuid4(),self.owner)
        key=uuid.uuid4()
        replacement=lifecycle.edit_entry(self.owner,deposit.pk,1200,'D2','اصلاح شرح',REASON,key)
        self.assertEqual(self.account.balance,101200)
        deposit.refresh_from_db();self.assertEqual((deposit.amount,deposit.reference,deposit.is_active),(1000,'D1',False))
        self.assertEqual(m.MoneyEntry.objects.filter(reverses=deposit).count(),1)
        self.assertEqual(lifecycle.edit_entry(self.owner,deposit.pk,1200,'D2','اصلاح شرح',REASON,key).pk,replacement.pk)
        self.assertEqual(self.account.balance,101200)
        deletion_key=uuid.uuid4();lifecycle.delete_entry(self.owner,replacement.pk,REASON,deletion_key)
        lifecycle.delete_entry(self.owner,replacement.pk,REASON,deletion_key)
        self.assertEqual(self.account.balance,100000);self.assertEqual(m.MoneyEntryAmendment.objects.count(),2)
        self.assertEqual(services.verify_audit_chain(),(True,None))

    def test_paid_financial_record_allows_metadata_only_and_refuses_delete(self):
        contract,_=self.contract('CASH',True,True);allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        payment=services.pay(allocation.pk,100,'P-ORIGINAL',uuid.uuid4());before=self.account.balance
        lifecycle.edit_entry(self.owner,payment.pk,100,'P-FIXED','شرح تصحیح شده',REASON,uuid.uuid4())
        payment.refresh_from_db();self.assertEqual((payment.reference,payment.display_reference,payment.amount),('P-ORIGINAL','P-FIXED',100))
        self.assertEqual(self.account.balance,before)
        for action in [lambda:lifecycle.edit_entry(self.owner,payment.pk,101,'P','',REASON,uuid.uuid4()),lambda:lifecycle.delete_entry(self.owner,payment.pk,REASON,uuid.uuid4())]:
            with self.assertRaises(ValidationError):action()
        with self.assertRaises(ValidationError):m.MoneyEntry.objects.filter(pk=payment.pk).update(amount=1)

    def test_reserved_deposit_is_not_deleted_and_credit_cannot_become_unbacked(self):
        self.account.opening_balance=0;self.account.save()
        deposit=services.deposit(self.account.pk,1000,'BACKING',uuid.uuid4(),self.owner)
        contract,_=self.contract('RESERVE',True,True);allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        with self.assertRaises(ValidationError):lifecycle.delete_entry(self.owner,deposit.pk,REASON,uuid.uuid4())
        lifecycle.revise_allocation(self.owner,allocation.pk,REASON,uuid.uuid4())
        lifecycle.delete_entry(self.owner,deposit.pk,REASON,uuid.uuid4());self.assertEqual(self.account.balance,0)

    def test_paid_allocation_is_fixed_but_unpaid_revision_cancels_old_requests(self):
        contract,_=self.contract('ALLOC',True,True);allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        pending=op.request_payment(self.owner,allocation,500,'BEFORE','',uuid.uuid4())
        replacement=lifecycle.revise_allocation(self.owner,allocation.pk,REASON,uuid.uuid4(),800)
        pending.refresh_from_db();self.assertEqual(pending.status,'cancelled');self.assertEqual(self.account.reserved,800)
        services.pay(replacement.pk,100,'AFTER',uuid.uuid4())
        with self.assertRaises(ValidationError):lifecycle.revise_allocation(self.owner,replacement.pk,REASON,uuid.uuid4())

class RequestRevisions(EnterpriseBase):
    def setUp(self):super().setUp();self.client.force_login(self.owner)

    def test_material_revision_preserves_old_request_and_approved_cannot_be_edited(self):
        original=self.material();key=uuid.uuid4()
        new=requests.revise(self.owner,'material',original.pk,REASON,key,lambda:op.request_material(self.owner,self.w,self.item,self.location,None,5,self.custodian,self.work,'ویرایش درخواست',key))
        original.refresh_from_db();self.assertIsNotNone(original.archived_at);self.assertEqual(original.quantity,20);self.assertEqual(new.status,'pending')
        op.approve_material(self.approver,new.pk)
        with self.assertRaises(ValidationError):requests.revise(self.owner,'material',new.pk,REASON,uuid.uuid4(),lambda:None)
        op.issue_material(self.requester,new.pk)
        with self.assertRaises(ValidationError):requests.revise(self.owner,'material',new.pk,REASON,uuid.uuid4())
        self.assertEqual(services.stock(self.w,self.item),95)

    def test_payment_request_delete_and_revision_never_post_money(self):
        contract,_=self.contract('REQUEST',True,True);allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        original=op.request_payment(self.owner,allocation,500,'P-REQ','',uuid.uuid4());key=uuid.uuid4()
        new=requests.revise(self.owner,'payment',original.pk,REASON,key,lambda:op.request_payment(self.owner,allocation,400,'P-REQ','',key))
        self.assertEqual(m.MoneyEntry.objects.count(),0);self.assertEqual(new.amount,400)
        requests.revise(self.owner,'payment',new.pk,REASON,uuid.uuid4());self.assertEqual(self.account.balance,100000)

    def test_transfer_and_count_keep_reference_in_new_version(self):
        transfer=op.request_transfer(self.owner,self.w,self.dest,self.item,self.location,None,5,'MOVE-1',uuid.uuid4());key=uuid.uuid4()
        new=requests.revise(self.owner,'transfer',transfer.pk,REASON,key,lambda:op.request_transfer(self.owner,self.w,self.dest,self.item,self.location,None,4,'MOVE-1',key))
        self.assertNotEqual(transfer.pk,new.pk);self.assertEqual(new.reference,'MOVE-1')
        rows=[{'item':self.item,'location':self.location,'trace':None,'counted':100}]
        count=op.request_count(self.owner,self.w,'COUNT-1',rows,uuid.uuid4());key=uuid.uuid4()
        revised=requests.revise(self.owner,'count',count.pk,REASON,key,lambda:op.request_count(self.owner,self.w,'COUNT-1',rows,key))
        self.assertEqual(revised.lines.count(),1);self.assertEqual(count.lines.count(),1)

    def test_correction_delete_pending_and_block_after_post(self):
        correction=op.request_correction(self.owner,self.w,self.item,self.location,None,5,REASON,uuid.uuid4())
        requests.revise(self.owner,'correction',correction.pk,REASON,uuid.uuid4());self.assertEqual(services.stock(self.w,self.item),100)
        posted=op.request_correction(self.owner,self.w,self.item,self.location,None,5,REASON,uuid.uuid4());op.approve_correction(self.approver,posted.pk)
        with self.assertRaises(ValidationError):requests.revise(self.owner,'correction',posted.pk,REASON,uuid.uuid4())

    def test_delete_is_csrf_protected_and_scoped_even_for_forged_ids(self):
        material=self.material();self.client.force_login(self.receiver)
        self.assertIn(self.client.post(f'/control/material/{material.pk}/delete/',{'reason':REASON,'operation_key':uuid.uuid4()}).status_code,[403,404])
        self.client.force_login(self.owner)
        response=self.client.post(f'/control/material/{material.pk}/delete/',{'reason':REASON,'operation_key':uuid.uuid4()})
        self.assertEqual(response.status_code,302);material.refresh_from_db();self.assertIsNotNone(material.archived_at)

    def test_pending_edit_form_is_functional_and_records_new_owner(self):
        material=self.material()
        response=self.client.post(f'/control/material/{material.pk}/edit/',{'warehouse':self.w.pk,'item':self.item.pk,'location':self.location.pk,'trace':'','quantity':7,'recipient':self.custodian.pk,'work_order':self.work.pk,'purpose':'تعمیر اصلاح شده','operation_key':uuid.uuid4(),'revision_reason':REASON})
        self.assertEqual(response.status_code,302)
        revision=m.OperationRevision.objects.get(kind='material',original_id=material.pk)
        new=m.MaterialRequest.objects.get(pk=revision.replacement_id);self.assertEqual((new.quantity,new.requested_by_id),(7,self.owner.pk))
