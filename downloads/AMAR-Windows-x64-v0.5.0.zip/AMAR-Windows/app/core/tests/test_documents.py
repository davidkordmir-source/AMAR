import io,uuid,tempfile,hashlib
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.exceptions import ValidationError,PermissionDenied
from django.test import override_settings,SimpleTestCase
from core import documents,models as m,services,operations as op
from core.ocr import propose
from .test_enterprise import EnterpriseBase
from .test_lifecycle import REASON

def scan(name='اسکن.png'):
    data=io.BytesIO();Image.new('RGB',(40,40),'white').save(data,format='PNG')
    return SimpleUploadedFile(name,data.getvalue(),content_type='image/png')

class DocumentWorkflowTests(EnterpriseBase):
    def setUp(self):
        super().setUp();self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.data=Path(self.temp.name);override=override_settings(DATA_DIR=self.data);override.enable();self.addCleanup(override.disable)
        queue=patch('core.ocr.enqueue');self.enqueue=queue.start();self.addCleanup(queue.stop)
        self.client.force_login(self.owner)
    def create(self,**changes):
        data={'branch':self.leaf,'kind':'financial','title':'مدرک آزمایشی','contract':None,'account':self.account,'money_entry':None,'notes':''};data.update(changes)
        return documents.create_document(self.owner,data,scan(),uuid.uuid4())
    def confirm(self,document,**changes):
        data={'reference':'SCAN-1','amount':1000,'document_date':'۱۴۰۵/۰۸/۱۴','notes':'متن تأییدشده'};data.update(changes)
        return documents.confirm_document(self.owner,document.pk,document.current_version_id,data)

    def test_upload_and_proposal_never_post_money_before_human_confirmation(self):
        with self.captureOnCommitCallbacks(execute=True):document=self.create()
        self.enqueue.assert_called_once_with(document.current_version_id)
        m.DocumentExtraction.objects.create(version=document.current_version,success=True,text='مبلغ: ۱٬۰۰۰ ریال',suggestions={'amount':1000,'reference':'SCAN-1'},engine='test')
        self.assertIsNone(document.confirmed_at);self.assertEqual(m.MoneyEntry.objects.count(),0)
        response=self.client.get(f'/documents/{document.pk}/review/')
        self.assertEqual(response.context['form'].initial['amount'],1000)
        self.assertEqual(m.MoneyEntry.objects.count(),0)
        self.confirm(document);self.assertEqual(m.DocumentReview.objects.count(),1);self.assertEqual(m.MoneyEntry.objects.count(),0)

    def test_confirmed_scan_prefills_finance_and_only_explicit_submit_creates_entry(self):
        document=self.confirm(self.create())
        response=self.client.get(f'/finance/deposit/?document={document.pk}')
        self.assertEqual(response.context['form'].initial['amount'],1000)
        data={'account':self.account.pk,'amount':1000,'reference':'SCAN-1','description':'','operation_key':uuid.uuid4(),'scan_document':document.pk,'scan_version':document.current_version_id}
        response=self.client.post('/finance/deposit/',data);self.assertEqual(response.status_code,302)
        document.refresh_from_db();self.assertIsNotNone(document.money_entry_id);self.assertEqual(self.account.balance,101000)
        self.client.post('/finance/deposit/',{**data,'operation_key':uuid.uuid4()})
        self.assertEqual(m.MoneyEntry.objects.count(),1)

    def test_missing_review_or_changed_amount_cannot_post_from_scan(self):
        document=self.create()
        data={'account':self.account.pk,'amount':1000,'reference':'SCAN-1','description':'','operation_key':uuid.uuid4(),'scan_document':document.pk,'scan_version':document.current_version_id}
        response=self.client.post('/finance/deposit/',data);self.assertEqual(response.status_code,200);self.assertEqual(m.MoneyEntry.objects.count(),0)
        self.confirm(document)
        response=self.client.post('/finance/deposit/',{**data,'amount':2000});self.assertEqual(response.status_code,200);self.assertEqual(m.MoneyEntry.objects.count(),0)

    def test_scan_to_contract_checks_total_and_remains_a_draft(self):
        document=self.confirm(self.create(kind='contract',account=None))
        data={'number':'SCAN-1','title':'خرید از اسکن','supplier':self.supplier.pk,'warehouse':self.w.pk,'due_date':'','notes':'','scan_document':document.pk,'scan_version':document.current_version_id,
            'lines-TOTAL_FORMS':1,'lines-INITIAL_FORMS':0,'lines-MIN_NUM_FORMS':1,'lines-MAX_NUM_FORMS':100,
            'lines-0-item':self.item.pk,'lines-0-quantity':10,'lines-0-unit_price':200}
        self.assertEqual(self.client.post('/contracts/new/',data).status_code,200);self.assertEqual(m.Contract.objects.count(),0)
        data['lines-0-unit_price']=100;self.assertEqual(self.client.post('/contracts/new/',data).status_code,302)
        document.refresh_from_db();self.assertEqual(document.contract.status,'draft');self.assertEqual(document.contract.total,1000)

    def test_scan_payment_is_a_request_and_still_needs_independent_approval(self):
        contract,_=self.contract('SCAN-PAYMENT',True,True);allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        document=self.confirm(self.create())
        response=self.client.post('/finance/pay/',{'allocation':allocation.pk,'amount':1000,'reference':'SCAN-1','description':'','operation_key':uuid.uuid4(),'scan_document':document.pk,'scan_version':document.current_version_id})
        self.assertEqual(response.status_code,302);document.refresh_from_db();self.assertIsNotNone(document.payment_request_id)
        self.assertEqual(self.account.balance,100000);self.assertEqual(m.MoneyEntry.objects.count(),0)
        with self.assertRaises(ValidationError):op.approve_payment(self.owner,document.payment_request_id)
        op.approve_payment(self.approver,document.payment_request_id)
        self.assertEqual(self.account.balance,99000)
        with self.assertRaises(ValidationError):documents.archive_document(self.owner,document.pk,REASON)

    def test_versions_remain_private_and_stale_review_does_not_confirm_new_file(self):
        document=self.create();old=document.current_version
        data={key:getattr(document,key) for key in ['branch','kind','title','contract','account','money_entry','notes']}
        revised=documents.edit_document(self.owner,document.pk,data,scan('نسخه جدید.png'),REASON)
        self.assertEqual(revised.versions.count(),2);self.assertTrue((self.data/'documents'/old.filename).is_file())
        with self.assertRaises(ValidationError):documents.confirm_document(self.owner,document.pk,old.pk,{'reference':'OLD','amount':1,'document_date':'','notes':''})
        with self.assertRaises(PermissionDenied):documents.file_for(self.receiver,old.pk)
        with self.assertRaises(ValidationError):old.delete()
        document.refresh_from_db();self.assertIsNone(document.confirmed_at)

    def test_unpaid_delete_archives_and_paid_delete_is_blocked(self):
        unpaid=self.create(account=None,kind='other')
        documents.archive_document(self.owner,unpaid.pk,REASON)
        self.assertFalse(m.Document.objects.filter(pk=unpaid.pk).exists());self.assertTrue((self.data/'documents'/unpaid.current_version.filename).is_file())
        contract,_=self.contract('PAID-SCAN',True,True);allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4());payment=services.pay(allocation.pk,100,'PAID-SCAN',uuid.uuid4())
        paid=self.create(money_entry=payment)
        with self.assertRaises(ValidationError):documents.archive_document(self.owner,paid.pk,REASON)
        with self.assertRaises(ValidationError):self.confirm(paid,amount=101)
        self.confirm(paid,amount=100)

    def test_contract_view_grant_does_not_allow_scan_mutation(self):
        contract,_=self.contract('VIEW-SCAN',True,False)
        document=self.create(kind='contract',account=None,contract=contract)
        role=self.requester.factory_profile.role
        from django.contrib.auth.models import Permission
        role.permissions.add(*Permission.objects.filter(content_type__app_label='core',codename__in=['view_document','change_document','delete_document']))
        self.assertTrue(documents.visible_documents(self.requester).filter(pk=document.pk).exists())
        with self.assertRaises(PermissionDenied):documents.archive_document(self.requester,document.pk,REASON)

    def test_invalid_file_and_corrupt_download_are_rejected(self):
        with self.assertRaises(ValidationError):documents.store_upload(SimpleUploadedFile('fake.pdf',b'<script>bad</script>'))
        document=self.create();path=self.data/'documents'/document.current_version.filename
        raw=bytearray(path.read_bytes());raw[-1]^=1;path.write_bytes(raw)
        with self.assertRaises(ValidationError):documents.file_for(self.owner,document.current_version_id)

    def test_creation_replay_does_not_store_a_second_scan(self):
        data={'branch':self.leaf,'kind':'other','title':'تکرار درخواست','notes':''};key=uuid.uuid4()
        first=documents.create_document(self.owner,data,scan(),key);second=documents.create_document(self.owner,data,scan(),key)
        self.assertEqual(first.pk,second.pk);self.assertEqual(len(list((self.data/'documents').iterdir())),1)

    def test_preview_is_authenticated_with_the_same_scope_as_source(self):
        document=self.create(kind='other',account=None)
        folder=self.data/'document-previews';folder.mkdir();(folder/(document.current_version.filename+'.png')).write_bytes(scan().read())
        response=self.client.get(f'/documents/preview/{document.current_version_id}/');self.assertEqual(response.status_code,200);b''.join(response.streaming_content)
        self.client.force_login(self.receiver);self.assertEqual(self.client.get(f'/documents/preview/{document.current_version_id}/').status_code,403)

class ProposalTests(SimpleTestCase):
    def test_persian_arabic_digits_currency_and_bidi_markers(self):
        result=propose('شماره قرارداد: \u200eCT-050\u200f\nمبلغ: ۱۲۳٬۴۵۶ ریال\nتاریخ ۱۴۰۵/۰۸/۱۴')
        self.assertEqual(result,{'reference':'CT-050','amount':123456,'document_date':'1405/08/14'})
        self.assertEqual(propose('مبلغ: ١٢٣ تومان')['amount'],1230)
    def test_money_requires_explicit_currency_and_bounded_amount(self):
        self.assertNotIn('amount',propose('مبلغ: 123456'))
        self.assertNotIn('amount',propose('مبلغ: 9999999999999999999 ریال'))
