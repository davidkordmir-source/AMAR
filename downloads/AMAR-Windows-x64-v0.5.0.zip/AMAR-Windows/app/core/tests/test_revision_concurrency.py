import uuid
from concurrent.futures import ThreadPoolExecutor
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import close_old_connections
from django.test import TransactionTestCase
from core import models as m,services,lifecycle
from .test_lifecycle import REASON

class ConcurrentRevisionTests(TransactionTestCase):
    def setUp(self):
        self.owner=get_user_model().objects.create_superuser(username='concurrent-owner')
        org=m.Organization.objects.create(name='مصرف‌کننده',role='consumer');supplier=m.Organization.objects.create(name='تولیدکننده',role='producer')
        branch=m.Branch.objects.create(name='واحد',code='CONCURRENT',city='تهران',organization=org);warehouse=m.Warehouse.objects.create(name='انبار',branch=branch)
        item=m.Item.objects.create(name='قطعه',sku='CONCURRENT')
        self.contract=m.Contract.objects.create(number='CONCURRENT',title='خرید',supplier=supplier,warehouse=warehouse)
        m.ContractLine.objects.create(contract=self.contract,item=item,quantity=10,unit_price=100)
        services.approve_contract(self.contract.pk)
        self.account=m.Account.objects.create(name='حساب',branch=branch,opening_balance=10000)
    def parallel(self,functions):
        def run(function):
            close_old_connections()
            try:return function()
            except ValidationError:return 'blocked'
            finally:close_old_connections()
        with ThreadPoolExecutor(max_workers=2) as pool:return list(pool.map(run,functions))
    def test_payment_and_contract_delete_cannot_both_succeed(self):
        allocation=services.allocate(self.contract.pk,self.account.pk,1000,uuid.uuid4())
        result=self.parallel([lambda:(services.pay(allocation.pk,100,'RACE-PAY',uuid.uuid4()),'paid')[1],lambda:(lifecycle.archive_contract(self.owner,self.contract.pk,REASON),'archived')[1]])
        self.assertEqual(result.count('blocked'),1)
        contract=m.Contract.all_objects.get(pk=self.contract.pk)
        if 'paid' in result:self.assertIsNone(contract.archived_at);self.assertEqual(contract.paid,100);self.assertEqual(self.account.balance,9900)
        else:self.assertIsNotNone(contract.archived_at);self.assertEqual(contract.paid,0);self.assertEqual(self.account.balance,10000)
        self.assertEqual(services.verify_audit_chain(),(True,None))
    def test_deposit_edit_and_delete_cannot_reverse_the_same_amount_twice(self):
        entry=services.deposit(self.account.pk,1000,'RACE-D',uuid.uuid4(),self.owner)
        result=self.parallel([lambda:(lifecycle.edit_entry(self.owner,entry.pk,1200,'RACE-EDIT','',REASON,uuid.uuid4()),'edited')[1],lambda:(lifecycle.delete_entry(self.owner,entry.pk,REASON,uuid.uuid4()),'deleted')[1]])
        self.assertEqual(result.count('blocked'),1)
        self.assertEqual(m.MoneyEntry.objects.filter(reverses=entry).count(),1)
        ledger=10000+sum(amount if kind=='deposit' else -amount for kind,amount in m.MoneyEntry.objects.values_list('kind','amount'))
        self.assertEqual(self.account.balance,ledger);self.assertEqual(ledger,11200 if 'edited' in result else 10000)
