import io,tempfile,uuid,sqlite3
from contextlib import closing
from pathlib import Path
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import CommandError
from django.db import connection
from django.db.migrations.executor import MigrationExecutor
from django.test import TransactionTestCase,override_settings
from django.utils import timezone
from core import models as m,documents
from .test_documents import scan
from .test_lifecycle import REASON
from scripts.restore_backup import restore

class DocumentBackupTests(TransactionTestCase):
    def test_backup_restore_includes_every_version_even_archived_and_refuses_missing_scan(self):
        with tempfile.TemporaryDirectory() as directory:
            folder=Path(directory);data=folder/'source';data.mkdir()
            actor=get_user_model().objects.create_superuser(username='backup-scans')
            org=m.Organization.objects.create(name='پشتیبان اسکن',role='consumer');branch=m.Branch.objects.create(name='موقعیت',code='BACKUP-SCAN',city='تهران',organization=org)
            with override_settings(DATA_DIR=data),patch('core.ocr.enqueue'):
                values={'branch':branch,'kind':'other','title':'سند دارای نسخه','notes':''}
                document=documents.create_document(actor,values,scan(),uuid.uuid4())
                documents.edit_document(actor,document.pk,values,scan('نسخه دوم.png'),REASON)
                documents.archive_document(actor,document.pk,REASON)
                target=folder/'backup.zip';call_command('backup_local',output=str(target),stdout=io.StringIO())
                restored=restore(target,folder/'restored')
                with closing(sqlite3.connect(restored/'amar.sqlite3')) as db:
                    rows=db.execute('SELECT filename,digest FROM core_documentversion').fetchall()
                self.assertEqual(len(rows),2)
                for filename,digest in rows:self.assertEqual((restored/'documents'/filename).read_bytes(),(data/'documents'/filename).read_bytes())
                (data/'documents'/rows[0][0]).unlink()
                with self.assertRaises(CommandError):call_command('backup_local',output=str(folder/'incomplete.zip'),stdout=io.StringIO())
                self.assertFalse((folder/'incomplete.zip').exists())

class UpgradeReadModelsTests(TransactionTestCase):
    def test_041_ledgers_upgrade_without_losing_refs_quantities_or_payments(self):
        target=('core','0006_warehouse_hierarchy_and_reference_labels')
        executor=MigrationExecutor(connection);executor.migrate([target])
        try:
            old=executor.loader.project_state([target]).apps
            Org=old.get_model('core','Organization');Branch=old.get_model('core','Branch');Warehouse=old.get_model('core','Warehouse')
            org=Org.objects.create(name='ارتقای مجموعه',role='consumer');supplier=Org.objects.create(name='ارتقای تولیدکننده',role='producer')
            branch=Branch.objects.create(name='واحد قدیمی',code='OLD-UNIT',city='تهران',organization=org);warehouse=Warehouse.objects.create(name='انبار قدیمی',branch=branch)
            item=old.get_model('core','Item').objects.create(name='کالای اعشاری',sku='OLD-ITEM',unit='kg')
            contract=old.get_model('core','Contract').objects.create(number='OLD-CONTRACT',title='قرارداد قدیمی',supplier=supplier,warehouse=warehouse,status='approved')
            old.get_model('core','ContractLine').objects.create(contract=contract,item=item,quantity='1.005',unit_price=101)
            account=old.get_model('core','Account').objects.create(name='حساب قدیمی',branch=branch,opening_balance=1000,current_balance=5950)
            allocation=old.get_model('core','Allocation').objects.create(contract=contract,account=account,amount=100)
            Entry=old.get_model('core','MoneyEntry')
            deposit=Entry.objects.create(account=account,kind='deposit',amount=5000,reference='OLD-DEPOSIT',description='شرح اصلی')
            Entry.objects.create(account=account,allocation=allocation,kind='payment',amount=50,reference='OLD-PAY')
            old.get_model('core','StockMovement').objects.create(warehouse=warehouse,item=item,kind='in',quantity='5.123',reference='OLD-STOCK')
            old.get_model('core','StockBalance').objects.create(warehouse=warehouse,item=item,quantity='5.123',bucket_key=f'{warehouse.pk}:{item.pk}:0:0')
            source=old.get_model('core','TrustedSource').objects.create(source_id=uuid.uuid4(),label='مبدأ قدیمی',public_key='AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=')
            payload={'branches':[{'code':'OLD-UNIT','name':'قدیمی','city':'تهران','consumer':'مجموعه'}],'contracts':[],'accounts':[{'branch':'OLD-UNIT','name':'حساب','balance':'5950','available':'5900','reserved':'50','credit':'0'}],'inventory':[]}
            old.get_model('core','ImportedSnapshot').objects.create(source=source,sequence=1,payload=payload,digest='0'*64,generated_at=timezone.now())
        finally:
            executor=MigrationExecutor(connection);executor.migrate(executor.loader.graph.leaf_nodes())
        migrated=m.Contract.objects.get(pk=contract.pk)
        self.assertEqual((migrated.total,migrated.paid),(102,50))
        migrated_deposit=m.MoneyEntry.objects.get(pk=deposit.pk);self.assertEqual((migrated_deposit.reference,migrated_deposit.display_reference,migrated_deposit.display_description),('OLD-DEPOSIT','OLD-DEPOSIT','شرح اصلی'))
        self.assertEqual(m.Account.objects.get(pk=account.pk).balance,5950)
        self.assertEqual(str(m.StockSummary.objects.get(warehouse_id=warehouse.pk,item_id=item.pk).quantity),'5.123')
        self.assertEqual(m.CurrentReport.objects.get(source_id=source.pk).balance,'5950');self.assertEqual(m.RemoteRow.objects.filter(source_id=source.pk).count(),2)
