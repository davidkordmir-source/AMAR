"""Small authenticated lookups for large catalogues; POST choices stay scoped."""
from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.http import JsonResponse
from django.urls import reverse
from . import models as m
from .access import root,factory_ids,contracts_for

class SearchSelect(forms.Select):
    def __init__(self,kind,attrs=None):
        super().__init__({**(attrs or {}),'data-lookup':reverse('record_lookup',args=[kind])})
    def optgroups(self,name,value,attrs=None):
        selected={str(v) for v in value if v not in [None,'']}
        field=self.choices.field
        groups=[(None,[self.create_option(name,'','جست‌وجو و انتخاب…',not selected,0)],0)]
        if selected:
            for index,obj in enumerate(field.queryset.filter(pk__in=selected),1):
                groups[0][1].append(self.create_option(name,str(obj.pk),field.label_from_instance(obj),True,index))
        return groups

KINDS={m.Item:'item',m.Warehouse:'warehouse',m.Account:'account',m.Allocation:'allocation',m.Branch:'branch',m.Contract:'contract',m.StorageLocation:'location',m.Custodian:'custodian',m.WorkOrder:'workorder',m.TraceUnit:'trace'}

def enhance(form):
    for field in form.fields.values():
        if isinstance(field,forms.ModelChoiceField) and field.queryset.model in KINDS and not field.widget.is_hidden:
            field.widget=SearchSelect(KINDS[field.queryset.model],field.widget.attrs);field.widget.choices=field.choices
    return form

@login_required
def record_lookup(request,kind):
    ids=factory_ids(request.user);query=request.GET.get('q','').strip()[:120]
    options={
        'item':('view_item',m.Item.objects.all(),['name','sku','barcode']),
        'warehouse':('view_warehouse',m.Warehouse.objects.filter(branch_id__in=ids),['name','branch__name','branch__city','parent__name']),
        'destination':('add_stocktransfer',m.Warehouse.objects.all() if root(request.user) else m.Warehouse.objects.filter(branch_id__in=m.TransferRoute.objects.filter(source_id__in=ids).values('destination_id')),['name','branch__name','branch__city']),
        'account':('view_account',m.Account.objects.filter(branch_id__in=ids),['name','branch__name']),
        'allocation':('add_moneyentry',m.Allocation.objects.filter(active=True,account__branch_id__in=ids,contract__in=contracts_for(request.user,True)),['contract__number','account__name']),
        'branch':('view_branch',m.Branch.objects.filter(pk__in=ids),['name','code','city']),
        'contract':('view_contract',contracts_for(request.user,True),['number','title']),
        'location':('view_warehouse',m.StorageLocation.objects.filter(warehouse__branch_id__in=ids),['code','warehouse__name','warehouse__branch__name']),
        'custodian':('view_materialrequest',m.Custodian.objects.filter(branch_id__in=ids,active=True),['name','code']),
        'workorder':('view_materialrequest',m.WorkOrder.objects.filter(branch_id__in=ids,active=True),['number','title','asset']),
        'trace':('view_item',m.TraceUnit.objects.all() if root(request.user) else m.TraceUnit.objects.filter(Q(stockmovement__warehouse__branch_id__in=ids)|Q(stockmovement__isnull=True)).distinct(),['code','item__name','item__sku']),
    }
    if kind not in options:raise PermissionDenied
    permission,objects,fields=options[kind]
    if not request.user.has_perm('core.'+permission):raise PermissionDenied
    if query:
        predicate=Q()
        for field in fields:predicate|=Q(**{field+'__icontains':query})
        objects=objects.filter(predicate)
    if objects.model==m.Warehouse:objects=objects.select_related('branch__locality__parent__parent__parent__parent__parent','parent__parent__parent__parent')
    elif objects.model==m.Allocation:objects=objects.select_related('contract','account__branch')
    elif objects.model==m.StorageLocation:objects=objects.select_related('warehouse__branch__locality__parent__parent__parent__parent__parent','warehouse__parent__parent__parent__parent')
    elif objects.model in [m.Account,m.Custodian,m.WorkOrder]:objects=objects.select_related('branch')
    elif objects.model==m.TraceUnit:objects=objects.select_related('item')
    result=[{'id':obj.pk,'label':str(obj)} for obj in objects.order_by('pk')[:30]]
    response=JsonResponse({'results':result});response['Cache-Control']='private, no-store';return response
