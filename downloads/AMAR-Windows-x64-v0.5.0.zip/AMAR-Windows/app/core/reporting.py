"""Reports never count ordered goods as physically present."""
from decimal import Decimal

from .models import Account, Contract, ContractLine, StockMovement, StockBalance, Warehouse, ZERO

def inventory_rows(branch=None, search="",user=None,allowed_factories=None,contract_ids=None):
    from .scalable_reports import inventory_keys,inventory_page_rows
    from itertools import islice
    query=inventory_keys(user,branch,search,allowed_factories,contract_ids)
    iterator=query.iterator(chunk_size=500)
    rows=[]
    while batch:=list(islice(iterator,100)):
        rows.extend(inventory_page_rows(batch,user,allowed_factories,contract_ids))
    return sorted(rows,key=lambda row:(row['warehouse'].branch.name,row['item'].name))

def financial_totals(accounts):
    from .scalable_reports import account_rows,totals_from_accounts
    return totals_from_accounts(account_rows(accounts))

def snapshot_totals(payload):
    return {
        "branches": len(payload["branches"]), "contracts": len(payload["contracts"]),
        "balance": sum((Decimal(row["balance"]) for row in payload["accounts"]), ZERO),
        "available": sum((Decimal(row["available"]) for row in payload["accounts"]), ZERO),
        "stock_rows": len(payload["inventory"]),
    }

def consolidate_sources(sources,user=None):
    """Count only each source's latest report. Never silently mix local records."""
    totals = {"sources": 0, "branches": 0, "contracts": 0, "balance": ZERO, "available": ZERO}
    inventory = []
    for source in sources:
        latest = source.latest
        if not latest:
            continue
        totals["sources"] += 1
        from .sync import visible_payload
        payload=visible_payload(latest.payload,user,source)
        report = snapshot_totals(payload)
        for name in ("branches", "contracts", "balance", "available"):
            totals[name] += report[name]
        inventory.extend({**row, "source": source, "generated_at": latest.generated_at} for row in payload["inventory"])
    return totals, inventory
