"""All stock and cash writes pass through atomic, serialized operations.

Lock order: contract -> account OR warehouse. Ledger rows are append-only in the UI.
SQLite serializes writes via IMMEDIATE transactions; PostgreSQL uses row locks.
"""
from decimal import Decimal, InvalidOperation
import hashlib
import json

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .access import require_contract, require_factory, require_permission

from .models import (
    Account, Allocation, AuditEvent, Contract, Item, MoneyEntry, Organization,
    Receipt, StockMovement, StockBalance, Warehouse, SyncState, summed,
)

def audit_digest(event):
    payload={name:getattr(event,name) for name in ('action','target','detail','actor_id','branch_id','contract_id','previous_digest')}
    payload['created_at']=event.created_at.isoformat()
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

@transaction.atomic
def audit(action, target, actor=None, detail="", branch=None, contract=None):
    state,_=SyncState.objects.get_or_create(pk=1)
    SyncState.objects.select_for_update().get(pk=state.pk)
    last=AuditEvent.objects.order_by('-pk').first()
    event=AuditEvent(action=action,target=str(target),actor=actor,detail=detail,branch=branch,contract=contract,
        previous_digest=last.digest if last else '',created_at=timezone.now())
    event.digest=audit_digest(event)
    event.save()
    from .request_cache import invalidate
    invalidate()
    return event

def verify_audit_chain():
    previous=''
    for event in AuditEvent.objects.order_by('pk').iterator():
        if event.previous_digest!=previous or event.digest!=audit_digest(event): return False,event.pk
        previous=event.digest
    return True,None

def positive(value, money=False):
    try:
        value = Decimal(str(value))
        step = Decimal("1") if money else Decimal("0.001")
        limit = Decimal("999999999999999999") if money else Decimal("9999999999999.999")
        if not value.is_finite() or value <= 0 or value > limit or value != value.quantize(step):
            raise ValidationError("مقدار باید مثبت و در محدوده مجاز باشد؛ مبلغ به ریال صحیح و مقدار با حداکثر سه رقم اعشار است.")
    except (InvalidOperation, ValueError, TypeError):
        raise ValidationError("مقدار عددی معتبر وارد کنید.")
    return value

def item_quantity(item, value):
    value = positive(value)
    if item.unit == Item.Unit.PIECE and value != value.to_integral_value():
        raise ValidationError("مقدار کالای شمارشی باید عدد صحیح باشد.")
    return value

@transaction.atomic
def set_credit(account_id, credit_limit, actor, description=''):
    require_permission(actor,'change_account')
    account=Account.objects.select_for_update().get(pk=account_id)
    require_factory(actor,account.branch_id)
    try:
        value=Decimal(str(credit_limit))
        if not value.is_finite() or value<0 or value>999999999999999999 or value!=value.to_integral_value():raise ValueError
    except (InvalidOperation,ValueError,TypeError):raise ValidationError('اعتبار باید ریال صحیح و در محدودهٔ ۱۸ رقم باشد.')
    if account.opening_balance+value>999999999999999999:raise ValidationError('جمع موجودی اولیه و اعتبار از سقف مجاز ۱۸ رقم بیشتر است.')
    if account.current_balance+value-account.reserved<0:raise ValidationError('اعتبار جدید برای تعهدها و ماندهٔ فعلی کافی نیست.')
    if account.credit_limit!=int(value):
        before=account.credit_limit
        account.credit_limit=int(value);account.save(update_fields=['credit_limit'])
        audit('تغییر اعتبار مصوب',account.name,actor,json.dumps({'before':before,'after':int(value),'description':description},ensure_ascii=False),branch=account.branch)
    return account

def stock(warehouse, item):
    return summed(StockBalance.objects.filter(warehouse=warehouse, item=item), "quantity")

def replay(model, key, **expected):
    previous = model.objects.filter(operation_key=key).first()
    if previous and any(getattr(previous, field) != value for field, value in expected.items()):
        raise ValidationError("شناسه عملیات قبلاً برای اطلاعات متفاوت استفاده شده است. فرم را دوباره باز کنید.")
    return previous

@transaction.atomic
def approve_contract(contract_id, actor=None):
    require_permission(actor,'approve_contract')
    require_contract(actor,contract_id,True)
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    if actor is not None and actor.pk in (contract.created_by_id,contract.revised_by_id):
        raise ValidationError('ثبت‌کننده قرارداد نمی‌تواند تأییدکننده همان قرارداد باشد.')
    if contract.status != Contract.Status.DRAFT:
        raise ValidationError("فقط قرارداد پیش‌نویس قابل تأیید است.")
    if not contract.lines.exists():
        raise ValidationError("قرارداد باید حداقل یک ردیف کالا داشته باشد.")
    if contract.supplier.role not in (Organization.Role.PRODUCER, Organization.Role.BOTH):
        raise ValidationError("طرف فروشنده باید تولیدکننده باشد.")
    if contract.warehouse.branch.organization.role not in (Organization.Role.OPERATOR, Organization.Role.CONSUMER, Organization.Role.BOTH):
        raise ValidationError("موقعیت مقصد باید متعلق به بهره‌بردار یا مصرف‌کننده باشد.")
    for line in contract.lines.select_related("item"):
        item_quantity(line.item, line.quantity)
        positive(line.unit_price, money=True)
    positive(contract.total, money=True)
    contract.status = Contract.Status.APPROVED
    contract.approved_at = timezone.now()
    contract.approved_by = actor
    contract.save(update_fields=["status", "approved_at", "approved_by"])
    audit("تأیید قرارداد و ایجاد تعهد", contract.number, actor, f"{contract.total} ریال؛ بدون تغییر موجودی واقعی",branch=contract.warehouse.branch,contract=contract)
    return contract

@transaction.atomic
def advance_contract(contract_id, target, actor=None):
    require_permission(actor,'approve_contract')
    require_contract(actor,contract_id,True)
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    allowed = {
        Contract.Status.APPROVED: Contract.Status.BUILDING,
        Contract.Status.BUILDING: Contract.Status.READY,
    }
    if allowed.get(contract.status) != target:
        raise ValidationError("این تغییر وضعیت برای مرحله فعلی مجاز نیست.")
    contract.status = target
    contract.save(update_fields=["status"])
    audit("تغییر مرحله قرارداد", contract.number, actor, contract.get_status_display(),branch=contract.warehouse.branch,contract=contract)
    return contract

@transaction.atomic
def cancel_contract(contract_id, actor=None):
    require_permission(actor,'approve_contract')
    require_contract(actor,contract_id,True)
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    if contract.status in (Contract.Status.CANCELLED, Contract.Status.RECEIVED) or contract.receipts.exists() or contract.paid:
        raise ValidationError("قرارداد دارای تحویل یا پرداخت قابل لغو نیست؛ برگشت آن نیاز به سند اصلاحی دارد.")
    from .models import PaymentRequest
    if PaymentRequest.objects.filter(allocation__contract=contract,status='pending').exists():raise ValidationError('ابتدا درخواست‌های پرداخت باز قرارداد را تعیین تکلیف کنید.')
    account_ids = list(contract.allocations.filter(active=True).values_list("account_id", flat=True))
    list(Account.objects.select_for_update().filter(pk__in=account_ids).order_by("pk"))
    contract.allocations.update(active=False)
    contract.status = Contract.Status.CANCELLED
    contract.save(update_fields=["status"])
    audit("لغو قرارداد و آزادسازی تخصیص‌ها", contract.number, actor,branch=contract.warehouse.branch,contract=contract)
    return contract

@transaction.atomic
def allocate(contract_id, account_id, amount, key, actor=None):
    require_permission(actor,'add_allocation')
    require_contract(actor,contract_id,True)
    amount = positive(amount, money=True)
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    account = Account.objects.select_for_update().get(pk=account_id)
    require_factory(actor,account.branch_id)
    previous = replay(Allocation, key, contract_id=contract_id, account_id=account_id, amount=amount)
    if previous:
        return previous
    if contract.status in (Contract.Status.DRAFT, Contract.Status.CANCELLED):
        raise ValidationError("تخصیص فقط برای قرارداد تأییدشده مجاز است.")
    if contract.warehouse.branch_id != account.branch_id:
        raise ValidationError("حساب و قرارداد باید متعلق به یک موقعیت باشند.")
    if amount > contract.total - contract.allocated:
        raise ValidationError("تخصیص از مبلغ باقیمانده قرارداد بیشتر است.")
    if amount > account.available:
        raise ValidationError("موجودی آزاد و اعتبار حساب برای این تخصیص کافی نیست.")
    allocation = Allocation.objects.create(contract=contract, account=account, amount=amount, operation_key=key)
    audit("تخصیص وجه", contract.number, actor, f"تخصیص #{allocation.pk}؛ {amount} ریال؛ {account}",branch=account.branch,contract=contract)
    return allocation

@transaction.atomic
def deposit(account_id, amount, reference, key, actor=None, description=""):
    require_permission(actor,'add_moneyentry')
    amount = positive(amount, money=True)
    account = Account.objects.select_for_update().get(pk=account_id)
    require_factory(actor,account.branch_id)
    previous = replay(MoneyEntry, key, account_id=account_id, amount=amount, kind=MoneyEntry.Kind.DEPOSIT, reference=reference, description=description)
    if previous:
        return previous
    if not reference.strip() or account.entries.filter(display_reference=reference,is_active=True).exists():
        raise ValidationError("شماره سند مالی الزامی و در هر حساب یکتا است.")
    positive(account.balance + amount + account.credit_limit, money=True)
    entry = MoneyEntry.objects.create(account=account, amount=amount, kind=MoneyEntry.Kind.DEPOSIT, reference=reference, operation_key=key, created_by=actor, description=description)
    audit("دریافت وجه", account, actor, f"{amount} ریال؛ سند {reference}",branch=account.branch)
    return entry

@transaction.atomic
def pay(allocation_id, amount, reference, key, actor=None, description=""):
    if actor is not None:
        raise ValidationError('پرداخت باید با درخواست و تأیید مستقل انجام شود.')
    amount = positive(amount, money=True)
    info = Allocation.objects.get(pk=allocation_id)
    Contract.objects.select_for_update().get(pk=info.contract_id)
    account = Account.objects.select_for_update().get(pk=info.account_id)
    allocation = Allocation.objects.select_for_update().get(pk=allocation_id)
    previous = replay(MoneyEntry, key, allocation_id=allocation_id, amount=amount, kind=MoneyEntry.Kind.PAYMENT, reference=reference, description=description)
    if previous:
        return previous
    if not allocation.active or allocation.contract.status in (Contract.Status.DRAFT, Contract.Status.CANCELLED):
        raise ValidationError("این تخصیص فعال نیست.")
    if amount > allocation.remaining:
        raise ValidationError("مبلغ پرداخت از مانده تخصیص بیشتر است.")
    if amount > account.balance + account.credit_limit:
        raise ValidationError("موجودی و اعتبار قابل پرداخت کافی نیست.")
    if not reference.strip() or account.entries.filter(display_reference=reference,is_active=True).exists():
        raise ValidationError("شماره سند مالی الزامی و در هر حساب یکتا است.")
    entry = MoneyEntry.objects.create(account=account, allocation=allocation, amount=amount, kind=MoneyEntry.Kind.PAYMENT, reference=reference, description=description, operation_key=key, created_by=actor)
    audit("پرداخت به تولیدکننده", allocation.contract.number, actor, f"{amount} ریال؛ سند {reference}")
    return entry

@transaction.atomic
def receive(contract_id, quantities, reference, key, actor=None, locations=None, traces=None):
    require_permission(actor,'add_stockmovement')
    require_contract(actor,contract_id,True)
    locations,traces=locations or {},traces or {}
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    warehouse = Warehouse.objects.select_for_update().get(pk=contract.warehouse_id)
    lines = {line.pk: line for line in contract.lines.select_related("item")}
    if set(quantities) - set(lines):
        raise ValidationError("ردیف تحویل متعلق به این قرارداد نیست.")
    quantities = {pk: item_quantity(lines[pk].item, qty) for pk, qty in quantities.items()}
    previous = replay(Receipt, key, contract_id=contract_id, reference=reference)
    if previous:
        expected_locations={pk:(locations[pk].pk if locations.get(pk) else None,traces[pk].pk if traces.get(pk) else None) for pk in quantities}
        prior_locations={m.contract_line_id:(m.location_id,m.trace_id) for m in previous.movements.all()}
        if expected_locations!=prior_locations:raise ValidationError('محل یا بچ رسید با درخواست قبلی متفاوت است.')
        if dict(previous.movements.values_list("contract_line_id", "quantity")) != quantities:
            raise ValidationError("اطلاعات این رسید با درخواست قبلی متفاوت است.")
        return previous
    if not contract.is_open:
        raise ValidationError("قرارداد در مرحله قابل تحویل نیست.")
    if not quantities:
        raise ValidationError("حداقل یک مقدار مثبت برای تحویل وارد کنید.")
    if not reference.strip() or contract.receipts.filter(reference=reference).exists():
        raise ValidationError("شماره رسید تحویل الزامی و در این قرارداد یکتا است.")
    from .operations import validate_bucket
    for pk, quantity in quantities.items():
        validate_bucket(warehouse,lines[pk].item,locations.get(pk),traces.get(pk),quantity,incoming=True)
        if quantity > lines[pk].quantity - lines[pk].received:
            raise ValidationError(f"مقدار تحویل {lines[pk].item.name} از باقیمانده سفارش بیشتر است.")
        positive(stock(warehouse, lines[pk].item) + quantity)
    receipt = Receipt.objects.create(contract=contract, reference=reference, operation_key=key, created_by=actor)
    for pk, quantity in quantities.items():
        StockMovement.objects.create(warehouse=warehouse, item=lines[pk].item, quantity=quantity, kind=StockMovement.Kind.RECEIPT, contract_line=lines[pk], receipt=receipt, reference=reference, created_by=actor, location=locations.get(pk), trace=traces.get(pk))
    contract.status = Contract.Status.RECEIVED if all(line.received == line.quantity for line in lines.values()) else Contract.Status.PARTIAL
    contract.save(update_fields=["status"])
    audit("ثبت تحویل و افزایش موجودی", contract.number, actor, f"رسید {reference}؛ {contract.get_status_display()}",branch=warehouse.branch,contract=contract)
    return receipt

@transaction.atomic
def adjust_stock(warehouse_id, item_id, kind, quantity, reference, key, actor=None, note=""):
    if actor is not None:
        raise ValidationError('گردش دستی باید با درخواست اصلاح و تأیید مستقل انجام شود.')
    warehouse = Warehouse.objects.select_for_update().get(pk=warehouse_id)
    item = Item.objects.get(pk=item_id)
    quantity = item_quantity(item, quantity)
    if kind not in (StockMovement.Kind.IN, StockMovement.Kind.OUT):
        raise ValidationError("نوع حرکت دستی معتبر نیست.")
    signed = -quantity if kind == StockMovement.Kind.OUT else quantity
    previous = replay(StockMovement, key, warehouse_id=warehouse_id, item_id=item_id, quantity=signed, kind=kind, reference=reference, note=note)
    if previous:
        return previous
    balance = stock(warehouse, item) + signed
    if balance < 0:
        raise ValidationError("خروج از موجودی واقعی انبار بیشتر است.")
    if balance:
        positive(balance)
    if not reference.strip():
        raise ValidationError("شماره سند الزامی است.")
    movement = StockMovement.objects.create(warehouse=warehouse, item=item, kind=kind, quantity=signed, reference=reference, operation_key=key, created_by=actor, note=note)
    audit(movement.get_kind_display(), f"{warehouse} / {item.sku}", actor, f"{signed} {item.get_unit_display()}؛ سند {reference}",branch=warehouse.branch)
    return movement
