from django import forms as df
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db import IntegrityError
from django.shortcuts import get_object_or_404,render,redirect
from . import models as m,forms,lifecycle
from .access import contracts_for,scope_form
from .views import access

class ReasonForm(df.Form):
    reason=df.CharField(label='علت ویرایش یا حذف',min_length=10,max_length=240,widget=df.Textarea(attrs={'rows':3}))

class ContractNotesForm(df.ModelForm):
    class Meta:
        model=m.Contract;fields=['title','due_date','notes']
        widgets={'due_date':df.DateInput(attrs={'type':'date'})}

class EntryForm(forms.OperationForm):
    reference=df.CharField(label='شماره سند / پیگیری',max_length=80)
    amount=df.DecimalField(label='مبلغ ریال',min_value=1,max_value=999999999999999999,decimal_places=0,max_digits=18)
    description=df.CharField(label='شرح',max_length=240,required=False)
    reason=df.CharField(label='علت اصلاح',min_length=10,max_length=240)

class DeleteEntryForm(forms.OperationForm):
    reason=df.CharField(label='علت حذف',min_length=10,max_length=240)

@access('change_contract')
def contract_edit(request,pk):
    contract=get_object_or_404(contracts_for(request.user,True),pk=pk)
    frozen=bool(contract.paid or contract.receipts.exists())
    klass=ContractNotesForm if frozen else forms.ContractForm
    form=scope_form(klass(request.POST or None,instance=contract),request.user)
    formset=None if frozen else forms.ContractLineFormSet(request.POST or None,instance=contract)
    reason=ReasonForm(request.POST or None)
    if request.method=='POST':
        valid=form.is_valid();valid_reason=reason.is_valid();valid_lines=formset.is_valid() if formset is not None else True
        if valid and valid_reason and valid_lines:
            try:
                lifecycle.save_contract_revision(request.user,pk,form,formset,reason.cleaned_data['reason'])
                messages.success(request,'ویرایش ثبت شد؛ تغییر مبلغ یا اقلام، قرارداد را برای تأیید مستقل دوباره به پیش‌نویس برمی‌گرداند.' if not frozen else 'مشخصات توضیحی ویرایش شد؛ مقادیر قطعی حفظ شدند.')
                return redirect('contract_detail',pk=pk)
            except ValidationError as error:form.add_error(None,error)
            except IntegrityError:form.add_error(None,'شماره یا اطلاعات قرارداد با سابقهٔ دیگری تداخل دارد.')
    return render(request,'core/contract_revision.html',{'page_title':'ویرایش قرارداد '+contract.number,'active_page':'contracts','contract':contract,'form':form,'formset':formset,'reason_form':reason,'frozen':frozen})

@access('delete_contract')
def contract_delete(request,pk):
    contract=get_object_or_404(contracts_for(request.user,True),pk=pk)
    form=ReasonForm(request.POST or None)
    reasons=lifecycle.contract_delete_reasons(contract)
    if request.method=='POST' and form.is_valid():
        try:
            lifecycle.archive_contract(request.user,pk,form.cleaned_data['reason'])
            messages.success(request,'قرارداد از فهرست فعال حذف شد؛ سابقه و مدارک آن در بایگانی باقی ماند.')
            return redirect('contracts')
        except ValidationError as error:reasons=error.messages
    return render(request,'core/record_delete.html',{'page_title':'بررسی حذف قرارداد','active_page':'contracts','record':contract,'form':form,'reasons':reasons,'back_url':'contracts'})

@access('change_moneyentry')
def entry_edit(request,pk):
    entry=get_object_or_404(lifecycle.entries_for(request.user),pk=pk)
    initial={'reference':entry.display_reference,'amount':entry.amount,'description':entry.display_description}
    form=EntryForm(request.POST or None,initial=initial)
    if lifecycle.entry_has_payments(entry):form.fields['amount'].disabled=True
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data
        try:
            lifecycle.edit_entry(request.user,pk,d['amount'],d['reference'],d['description'],d['reason'],d['operation_key'])
            messages.success(request,'اصلاح سند مالی با حفظ سابقه ثبت شد.');return redirect('finance')
        except ValidationError as error:form.add_error(None,error)
        except IntegrityError:form.add_error(None,'شماره سند با سند فعال دیگری تداخل دارد.')
    return render(request,'core/form.html',{'page_title':'ویرایش سند مالی','active_page':'finance','form':form,'help_text':'پس از پرداخت، مبلغ ثابت است؛ شرح و شمارهٔ نمایشی با ثبت سابقه اصلاح می‌شوند.'})

@access('delete_moneyentry')
def entry_delete(request,pk):
    entry=get_object_or_404(lifecycle.entries_for(request.user),pk=pk)
    form=DeleteEntryForm(request.POST or None);reasons=lifecycle.entry_delete_reasons(entry)
    if request.method=='POST' and form.is_valid():
        try:
            lifecycle.delete_entry(request.user,pk,form.cleaned_data['reason'],form.cleaned_data['operation_key'])
            messages.success(request,'دریافت وجه ابطال و از اسناد فعال حذف شد؛ موجودی حساب تطبیق داده شد.');return redirect('finance')
        except ValidationError as error:reasons=error.messages
    return render(request,'core/record_delete.html',{'page_title':'بررسی حذف سند مالی','active_page':'finance','record':entry.display_reference,'form':form,'reasons':reasons,'back_url':'finance'})

@access('change_allocation')
def allocation_edit(request,pk):
    from .access import factory_ids
    allocation=get_object_or_404(m.Allocation,pk=pk,active=True,account__branch_id__in=factory_ids(request.user),contract__in=contracts_for(request.user,True))
    class RevisionForm(forms.OperationForm):
        amount=df.DecimalField(label='مبلغ جدید تخصیص (ریال)',max_digits=18,decimal_places=0,min_value=1)
        reason=df.CharField(label='علت ویرایش',min_length=10,max_length=240)
    form=RevisionForm(request.POST or None,initial={'amount':allocation.amount})
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data
        try:
            lifecycle.revise_allocation(request.user,pk,d['reason'],d['operation_key'],d['amount']);messages.success(request,'تخصیص اصلاح شد؛ درخواست‌های پرداخت قبلی لغو شدند.');return redirect('finance')
        except ValidationError as error:form.add_error(None,error)
    return render(request,'core/form.html',{'page_title':'ویرایش تخصیص وجه','active_page':'finance','form':form,'help_text':'فقط تخصیص بدون پرداخت قابل ویرایش است؛ درخواست‌های پرداخت باز لغو می‌شوند.'})

@access('delete_allocation')
def allocation_delete(request,pk):
    from .access import factory_ids
    allocation=get_object_or_404(m.Allocation,pk=pk,active=True,account__branch_id__in=factory_ids(request.user),contract__in=contracts_for(request.user,True));form=DeleteEntryForm(request.POST or None)
    reasons=['پرداخت مالی روی تخصیص ثبت شده است؛ حذف مجاز نیست.'] if allocation.paid else []
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data
        try:
            lifecycle.revise_allocation(request.user,pk,d['reason'],d['operation_key']);messages.success(request,'تخصیص غیرفعال و وجه رزروشده آزاد شد.');return redirect('finance')
        except ValidationError as error:reasons=error.messages
    return render(request,'core/record_delete.html',{'page_title':'بررسی حذف تخصیص','active_page':'finance','record':f'تخصیص #{pk}','form':form,'reasons':reasons,'back_url':'finance'})
