import uuid
from django import forms
from django.contrib import messages
from django.core.exceptions import PermissionDenied,ValidationError
from django.db import transaction
from django.db.models import Q
from django.http import FileResponse,JsonResponse,Http404
from django.shortcuts import get_object_or_404,render,redirect
from django.views.decorators.http import require_POST
from . import models as m,documents
from .access import factory_ids,contracts_for,scope_form,root,require_permission
from .views import access,page
from .lifecycle_views import ReasonForm

FIELDS=['branch','kind','title','contract','account','money_entry','notes']

class ScanForm(forms.ModelForm):
    scan=forms.FileField(label='فایل اسکن (PDF، PNG یا JPEG، حداکثر ۲۰ مگابایت)')
    operation_key=forms.UUIDField(initial=uuid.uuid4,widget=forms.HiddenInput)
    class Meta:
        model=m.Document;fields=FIELDS
        widgets={'contract':forms.HiddenInput(),'money_entry':forms.HiddenInput(),'notes':forms.Textarea(attrs={'rows':3})}
    def __init__(self,*args,actor,**kwargs):
        super().__init__(*args,**kwargs);scope_form(self,actor)
        from .lifecycle import entries_for
        self.fields['contract'].queryset=contracts_for(actor,True)
        self.fields['money_entry'].queryset=entries_for(actor)
        if self.instance.pk:self.fields['scan'].required=False
        if not actor.has_perm('core.view_moneyentry'):
            self.fields['kind'].choices=[('contract','قرارداد'),('other','سایر مدارک')]
            self.fields['money_entry'].queryset=m.MoneyEntry.objects.none()
        if not actor.has_perm('core.view_account'):self.fields['account'].queryset=m.Account.objects.none()
    def clean_scan(self):
        upload=self.cleaned_data.get('scan')
        if upload and upload.size>documents.MAX_UPLOAD:raise forms.ValidationError('فایل بزرگ‌تر از ۲۰ مگابایت است.')
        return upload

class ReviewForm(forms.Form):
    version=forms.IntegerField(widget=forms.HiddenInput)
    reference=forms.CharField(label='شماره سند / قرارداد',max_length=80,required=False)
    amount=forms.DecimalField(label='مبلغ نهایی تأییدشده (ریال)',max_digits=18,decimal_places=0,min_value=0,required=False)
    document_date=forms.CharField(label='تاریخ درج‌شده روی سند',max_length=40,required=False)
    notes=forms.CharField(label='شرح و توضیحات تأییدشده',required=False,max_length=4000,widget=forms.Textarea(attrs={'rows':3}))

@access('view_document')
def document_list(request):
    objects=documents.visible_documents(request.user,archived=request.GET.get('archive')=='1').select_related('branch','current_version','contract')
    query=request.GET.get('q','').strip()[:120];kind=request.GET.get('kind','')
    if query:objects=objects.filter(Q(title__icontains=query)|Q(reference__icontains=query)|Q(contract__number__icontains=query))
    if kind in ['contract','financial','other']:objects=objects.filter(kind=kind)
    branch=request.GET.get('branch','')
    if branch:
        if not branch.isdigit() or int(branch) not in factory_ids(request.user):raise PermissionDenied
        objects=objects.filter(branch_id=int(branch))
    return render(request,'core/documents.html',{'page_title':'اسکن و مدارک','active_page':'documents','objects':page(request,objects),'search':query,'kind':kind})

@access('add_document')
def document_new(request):
    initial={};contract=None;entry=None
    value=request.GET.get('contract','')
    if value.isdigit():
        contract=get_object_or_404(contracts_for(request.user,True),pk=int(value));initial.update(contract=contract,branch=contract.warehouse.branch,kind='contract',title='اسکن قرارداد '+contract.number)
    value=request.GET.get('entry','')
    if value.isdigit():
        require_permission(request.user,'view_moneyentry')
        from .lifecycle import entries_for
        entry=get_object_or_404(entries_for(request.user),pk=int(value));initial.update(money_entry=entry,account=entry.account,branch=entry.account.branch,kind='financial',title='اسکن سند مالی '+entry.display_reference)
    form=ScanForm(request.POST or None,request.FILES or None,initial=initial,actor=request.user)
    if request.method=='POST' and form.is_valid():
        try:
            document=documents.create_document(request.user,{k:form.cleaned_data[k] for k in FIELDS},form.cleaned_data['scan'],form.cleaned_data['operation_key'])
            messages.success(request,'اسکن ذخیره شد. متن به‌صورت آفلاین خوانده می‌شود؛ اطلاعات پیشنهادی پیش از ثبت نهایی به تأیید شما نیاز دارند.')
            return redirect('document_detail',pk=document.pk)
        except ValidationError as error:form.add_error(None,error)
    return render(request,'core/document_form.html',{'page_title':'ورود با اسکن','active_page':'documents','form':form,'contract':contract,'entry':entry})

@access('view_document')
def document_detail(request,pk):
    document=get_object_or_404(documents.visible_documents(request.user,archived=root(request.user)).select_related('current_version','contract','account','money_entry','payment_request'),pk=pk)
    extraction=document.current_version.extractions.first() if document.current_version_id else None
    return render(request,'core/document_detail.html',{'page_title':document.title,'active_page':'documents','document':document,'extraction':extraction,
        'versions':document.versions.select_related('created_by')[:20],'paid':documents.has_payment(document)})

@access('change_document')
def document_edit(request,pk):
    document=get_object_or_404(documents.visible_documents(request.user),pk=pk)
    form=ScanForm(request.POST or None,request.FILES or None,instance=document,actor=request.user);reason=ReasonForm(request.POST or None)
    if documents.has_payment(document) or document.payment_request_id:
        for key in ['branch','kind','contract','account','money_entry']:form.fields[key].disabled=True
    if request.method=='POST' and form.is_valid() and reason.is_valid():
        try:
            documents.edit_document(request.user,pk,{k:form.cleaned_data[k] for k in FIELDS},form.cleaned_data.get('scan'),reason.cleaned_data['reason'])
            messages.success(request,'ویرایش با حفظ نسخهٔ قبلی فایل ثبت شد.');return redirect('document_detail',pk=pk)
        except ValidationError as error:form.add_error(None,error)
    return render(request,'core/document_form.html',{'page_title':'ویرایش سند اسکن‌شده','active_page':'documents','form':form,'reason_form':reason,'document':document})

@access('change_document')
def document_review(request,pk):
    document=get_object_or_404(documents.visible_documents(request.user),pk=pk)
    extraction=document.current_version.extractions.first()
    initial={'version':document.current_version_id,**(extraction.suggestions if extraction and extraction.success else {})}
    if document.confirmed_at:
        initial.update(reference=document.reference,amount=document.amount,document_date=document.document_date,notes=document.notes)
    else:
        initial.setdefault('reference',document.reference);initial.setdefault('notes',document.notes)
    form=ReviewForm(request.POST or None,initial=initial)
    form.fields['reference'].required=document.kind in ['contract','financial'];form.fields['amount'].required=document.kind=='financial'
    expected=documents.expected_amount(document)
    if expected is not None:
        form.fields['amount'].disabled=True;form.initial['amount']=expected
        form.fields['amount'].help_text='مبلغ از سند مرتبط می‌آید؛ برای اصلاح مبلغ، خود سند را ویرایش کنید.'
    if request.method=='POST' and form.is_valid():
        try:
            values={k:form.cleaned_data[k] for k in ['reference','amount','document_date','notes']}
            documents.confirm_document(request.user,pk,form.cleaned_data['version'],values)
            messages.success(request,'اطلاعات اسکن با تأیید شما ثبت شد. هیچ دریافت یا پرداختی خودکار ایجاد نشده است.');return redirect('document_detail',pk=pk)
        except ValidationError as error:form.add_error(None,error)
    from django.conf import settings
    preview=(settings.DATA_DIR/'document-previews'/(document.current_version.filename+'.png')).is_file()
    return render(request,'core/document_review.html',{'page_title':'بررسی و تأیید اطلاعات اسکن','active_page':'documents','document':document,'extraction':extraction,'form':form,'preview':preview})

@access('view_document')
def document_preview(request,version):
    from django.conf import settings
    record=get_object_or_404(m.DocumentVersion,pk=version)
    if not documents.visible_documents(request.user,archived=root(request.user)).filter(pk=record.document_id).exists():raise PermissionDenied
    path=settings.DATA_DIR/'document-previews'/(record.filename+'.png')
    if not path.is_file():raise Http404
    response=FileResponse(path.open('rb'),content_type='image/png');response['Cache-Control']='private, no-store';response['X-Content-Type-Options']='nosniff'
    return response

@access('delete_document')
def document_delete(request,pk):
    document=get_object_or_404(documents.visible_documents(request.user),pk=pk);form=ReasonForm(request.POST or None)
    reasons=['پرداخت مالی مرتبط ثبت شده است؛ حذف مجاز نیست.'] if documents.has_payment(document) else []
    if request.method=='POST' and form.is_valid():
        try:
            documents.archive_document(request.user,pk,form.cleaned_data['reason']);messages.success(request,'سند از فهرست فعال حذف شد؛ نسخه‌ها در سابقه نگهداری شدند.');return redirect('documents')
        except ValidationError as error:reasons=error.messages
    return render(request,'core/record_delete.html',{'page_title':'بررسی حذف سند اسکن‌شده','active_page':'documents','record':document,'form':form,'reasons':reasons,'back_url':'documents'})

@access('view_document')
def document_file(request,version):
    try:record,path=documents.file_for(request.user,version)
    except m.DocumentVersion.DoesNotExist:raise Http404
    except ValidationError as error:return render(request,'core/document_error.html',{'page_title':'فایل سند در دسترس نیست','errors':error.messages},status=409)
    response=FileResponse(path.open('rb'),as_attachment=True,filename=record.original_name,content_type=record.content_type)
    response['Content-Security-Policy']='sandbox';response['Cache-Control']='private, no-store'
    return response

@access('view_document')
def document_status(request,pk):
    document=get_object_or_404(documents.visible_documents(request.user),pk=pk)
    response=JsonResponse({'status':document.ocr_status,'version':document.current_version_id});response['Cache-Control']='no-store';return response

@access('change_document')
@require_POST
def document_retry(request,pk):
    document=get_object_or_404(documents.visible_documents(request.user),pk=pk)
    from .ocr import enqueue
    with transaction.atomic():
        document=m.Document.objects.select_for_update().get(pk=pk);documents._lock_related(document,request.user)
        document.ocr_status='pending';document.save(update_fields=['ocr_status'])
    if not enqueue(document.current_version_id):messages.info(request,'سند در صف است یا صف فعلاً پر است؛ کمی بعد دوباره بررسی کنید.')
    return redirect('document_detail',pk=pk)
