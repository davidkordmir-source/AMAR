"""Indexed current reports; signed originals remain the historical authority."""
from decimal import Decimal,localcontext
from django.db import transaction
from django.db.models import Q,Exists,OuterRef,Value,BooleanField
from . import models as m
from .access import root,factory_ids
from .request_cache import memo

@transaction.atomic
def index_snapshot(snapshot):
    payload=snapshot.payload
    m.RemoteRow.objects.filter(source_id=snapshot.source_id).delete()
    for kind in ['branches','accounts','contracts','inventory']:
        batch=[]
        for row in payload[kind]:
            batch.append(m.RemoteRow(source_id=snapshot.source_id,kind=kind,branch=row['code'] if kind=='branches' else row['branch'],number=row.get('number',''),
                search_text=' '.join(str(value) for value in row.values()),data=row,balance=row.get('balance','0'),available=row.get('available','0')))
            if len(batch)>=1000:m.RemoteRow.objects.bulk_create(batch);batch=[]
        if batch:m.RemoteRow.objects.bulk_create(batch)
    with localcontext() as context:
        context.prec=100
        balance=sum((Decimal(row['balance']) for row in payload['accounts']),Decimal(0))
        available=sum((Decimal(row['available']) for row in payload['accounts']),Decimal(0))
    m.CurrentReport.objects.update_or_create(source_id=snapshot.source_id,defaults={'snapshot':snapshot,'branches':len(payload['branches']),'contracts':len(payload['contracts']),'balance':str(balance),'available':str(available)})

def codes(user):
    return memo(('remote-codes',user.pk),lambda:list(m.Branch.objects.filter(pk__in=factory_ids(user)).values_list('code',flat=True)))

def rows_for(sources,user,kind,search=''):
    rows=m.RemoteRow.objects.filter(source__in=sources,kind=kind)
    if not root(user):
        rows=rows.filter(branch__in=codes(user))
        if kind=='contracts':
            if not user.has_perm('core.view_contract'):return rows.none()
            grants=m.RemoteContractGrant.objects.filter(source_id=OuterRef('source_id'),number=OuterRef('number'),user=user)
            rows=rows.annotate(permitted=Exists(grants)).filter(permitted=True)
        if kind=='accounts' and not user.has_perm('core.view_account'):return rows.none()
        if kind=='inventory':
            if not user.has_perm('core.view_stockmovement'):return rows.none()
            hidden=m.RemoteRow.objects.filter(source_id=OuterRef('source_id'),kind='contracts',branch__in=codes(user))
            if user.has_perm('core.view_contract'):
                grants=m.RemoteContractGrant.objects.filter(source_id=OuterRef('source_id'),number=OuterRef('number'),user=user)
                hidden=hidden.annotate(permitted=Exists(grants)).filter(permitted=False)
            rows=rows.annotate(pending_visible=~Exists(hidden))
    if kind=='inventory' and root(user):rows=rows.annotate(pending_visible=Value(True,output_field=BooleanField()))
    if search:rows=rows.filter(Q(search_text__icontains=search)|Q(source__label__icontains=search))
    return rows.order_by('source__label','pk')

def inventory_values(rows):
    for row in rows:
        yield {**row.data,'pending':row.data['pending'] if row.pending_visible else '', 'source':row.source,'generated_at':row.source.current_report.snapshot.generated_at}

def inventory_query(sources,user,search=''):
    return rows_for(sources,user,'inventory',search).select_related('source__current_report__snapshot').defer('source__current_report__snapshot__payload')

def totals(sources,user):
    heads=m.CurrentReport.objects.filter(source__in=sources)
    result={'sources':heads.count(),'branches':0,'contracts':0,'balance':Decimal(0),'available':Decimal(0)}
    with localcontext() as context:
        context.prec=100
        if root(user):
            for branches,contracts,balance,available in heads.values_list('branches','contracts','balance','available').iterator():
                result['branches']+=branches;result['contracts']+=contracts;result['balance']+=Decimal(balance);result['available']+=Decimal(available)
        else:
            result['branches']=rows_for(sources,user,'branches').count();result['contracts']=rows_for(sources,user,'contracts').count()
            for balance,available in rows_for(sources,user,'accounts').values_list('balance','available').iterator():
                result['balance']+=Decimal(balance);result['available']+=Decimal(available)
    return result
