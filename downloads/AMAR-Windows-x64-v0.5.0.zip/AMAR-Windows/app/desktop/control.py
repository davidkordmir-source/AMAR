"""Close only the desktop server registered in this process."""
import threading

class DesktopSession:
    def __init__(self):
        self.lock=threading.Lock()
        self.server_id=None
        self.callback=None
        self.closing=False

    def register(self,server_id,callback):
        with self.lock:
            self.server_id=server_id;self.callback=callback;self.closing=False

    def clear(self,server_id):
        with self.lock:
            if self.server_id==server_id:
                self.server_id=None;self.callback=None;self.closing=False

    def installed(self):
        with self.lock:return self.callback is not None

    def available(self):
        with self.lock:return self.callback is not None and not self.closing

    def request_close(self):
        with self.lock:
            if not self.callback or self.closing:return False
            self.closing=True;server_id=self.server_id
        def close_after_response():
            with self.lock:
                callback=self.callback if self.server_id==server_id else None
            if callback:callback()
        timer=threading.Timer(0.3,close_after_response)
        timer.daemon=False;timer.start()
        return True

session=DesktopSession()
