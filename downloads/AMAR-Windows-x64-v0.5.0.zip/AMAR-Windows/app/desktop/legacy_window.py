"""Reveal an AMAR control window by its exact data directory, without stopping it."""
import ctypes
from ctypes import wintypes
import ntpath
import os

def reveal_running_window(data_dir):
    if os.name!='nt':return False
    user32=ctypes.windll.user32
    callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    user32.EnumWindows.argtypes=[callback_type,wintypes.LPARAM]
    user32.GetClassNameW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    user32.GetDlgItem.argtypes=[wintypes.HWND,ctypes.c_int];user32.GetDlgItem.restype=wintypes.HWND
    user32.GetWindowTextLengthW.argtypes=[wintypes.HWND]
    user32.GetWindowTextW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    user32.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
    user32.SetForegroundWindow.argtypes=[wintypes.HWND]
    expected=ntpath.normcase(ntpath.normpath(str(data_dir)))
    found=[]
    @callback_type
    def inspect(hwnd,lparam):
        name=ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(hwnd,name,len(name))
        if name.value!='AMARControlWindow':return True
        field=user32.GetDlgItem(hwnd,201)
        if not field:return True
        length=user32.GetWindowTextLengthW(field)
        if not 0<length<4096:return True
        value=ctypes.create_unicode_buffer(length+1)
        user32.GetWindowTextW(field,value,len(value))
        if ntpath.normcase(ntpath.normpath(value.value))==expected:
            found.append(hwnd);return False
        return True
    user32.EnumWindows(inspect,0)
    if not found:return False
    user32.ShowWindow(found[0],9)
    user32.SetForegroundWindow(found[0])
    return True
