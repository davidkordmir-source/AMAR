"""Isolated, offline Windows OCR worker. No database access and no posting money."""
import argparse,ctypes,io,json,os,sys
from pathlib import Path

_job=None
def memory_limit():
    """Cap this disposable worker's committed memory on Windows."""
    global _job
    if os.name!='nt':return False
    from ctypes import wintypes as w
    class Basic(ctypes.Structure):
        _fields_=[('ProcessTime',ctypes.c_int64),('JobTime',ctypes.c_int64),('Flags',w.DWORD),('Minimum',ctypes.c_size_t),('Maximum',ctypes.c_size_t),('Active',w.DWORD),('Affinity',ctypes.c_size_t),('Priority',w.DWORD),('Scheduling',w.DWORD)]
    class Io(ctypes.Structure):
        _fields_=[(name,ctypes.c_uint64) for name in ['ReadOperations','WriteOperations','OtherOperations','ReadBytes','WriteBytes','OtherBytes']]
    class Extended(ctypes.Structure):
        _fields_=[('Basic',Basic),('Io',Io),('ProcessMemory',ctypes.c_size_t),('JobMemory',ctypes.c_size_t),('PeakProcess',ctypes.c_size_t),('PeakJob',ctypes.c_size_t)]
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateJobObjectW.argtypes=[ctypes.c_void_p,w.LPCWSTR];kernel.CreateJobObjectW.restype=w.HANDLE
    kernel.SetInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD]
    kernel.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE]
    kernel.GetCurrentProcess.restype=w.HANDLE;kernel.CloseHandle.argtypes=[w.HANDLE]
    handle=kernel.CreateJobObjectW(None,None);info=Extended();info.Basic.Flags=0x100;info.ProcessMemory=768*1024**2
    if handle and kernel.SetInformationJobObject(handle,9,ctypes.byref(info),ctypes.sizeof(info)) and kernel.AssignProcessToJobObject(handle,kernel.GetCurrentProcess()):_job=handle;return True
    if handle:kernel.CloseHandle(handle)
    return False

def native_path(path):
    value=str(path)
    if value.isascii():return value.encode('utf-8')
    # Legacy native builds may open model files through the Windows ANSI CRT.
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetShortPathNameW.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint]
    buffer=ctypes.create_unicode_buffer(32768)
    count=kernel.GetShortPathNameW(value,buffer,len(buffer))
    return (buffer.value if count and count<len(buffer) and buffer.value.isascii() else value).encode('utf-8')

def read_text(images,tools):
    dlls=tools/'bin'
    directory=os.add_dll_directory(str(dlls))
    lept=ctypes.CDLL(str(dlls/'leptonica-1.85.0.dll'))
    tess=ctypes.CDLL(str(dlls/'tesseract55.dll'))
    lept.pixReadMem.argtypes=[ctypes.c_void_p,ctypes.c_size_t];lept.pixReadMem.restype=ctypes.c_void_p
    lept.pixDestroy.argtypes=[ctypes.POINTER(ctypes.c_void_p)]
    tess.TessBaseAPICreate.restype=ctypes.c_void_p
    tess.TessBaseAPIInit3.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_char_p]
    tess.TessBaseAPISetImage2.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
    tess.TessBaseAPIGetUTF8Text.argtypes=[ctypes.c_void_p];tess.TessBaseAPIGetUTF8Text.restype=ctypes.c_void_p
    tess.TessDeleteText.argtypes=[ctypes.c_void_p]
    tess.TessBaseAPIDelete.argtypes=[ctypes.c_void_p]
    tess.TessVersion.restype=ctypes.c_char_p
    handle=tess.TessBaseAPICreate();result=[]
    try:
        model_path=native_path(tools/'tessdata')
        if tess.TessBaseAPIInit3(handle,model_path,b'fas+eng')!=0:raise RuntimeError('language_initialization_failed')
        for image in images:
            buffer=io.BytesIO();image.save(buffer,format='PNG');raw=buffer.getvalue();data=ctypes.create_string_buffer(raw)
            pix=ctypes.c_void_p(lept.pixReadMem(data,len(raw)))
            if not pix.value:raise RuntimeError('image_decode_failed')
            try:
                tess.TessBaseAPISetImage2(handle,pix)
                text=tess.TessBaseAPIGetUTF8Text(handle)
                if text:
                    try:result.append(ctypes.string_at(text).decode('utf-8',errors='replace'))
                    finally:tess.TessDeleteText(text)
            finally:lept.pixDestroy(ctypes.byref(pix))
        return '\n\n'.join(result)[:200000],tess.TessVersion().decode()
    finally:tess.TessBaseAPIDelete(handle);directory.close()

def extract(path,mime,tools,preview=None):
    from PIL import Image,ImageOps
    Image.MAX_IMAGE_PIXELS=16000000
    images=[];partial=False
    if mime=='application/pdf':
        import pypdfium2 as pdfium
        pdf=pdfium.PdfDocument(str(path));partial=len(pdf)>8
        try:
            for index in range(min(len(pdf),8)):
                page=pdf[index]
                try:
                    width,height=page.get_size();scale=min(3.2,2600/max(width,height))
                    bitmap=page.render(scale=scale)
                    try:images.append(bitmap.to_pil().convert('RGB').copy())
                    finally:bitmap.close()
                finally:page.close()
        finally:pdf.close()
    else:
        with Image.open(path) as original:
            original.load();image=ImageOps.exif_transpose(original).convert('RGB');image.thumbnail((2600,2600));images.append(image.copy())
    try:
        if images and preview:images[0].save(preview,format='PNG')
        text,engine=read_text(images,tools)
        return {'success':True,'text':text,'engine':engine,'partial':partial}
    finally:
        for image in images:image.close()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--mime',required=True);parser.add_argument('--result',required=True);parser.add_argument('--tools');parser.add_argument('--preview')
    args=parser.parse_args();os.environ['OMP_THREAD_LIMIT']='1'
    limited=memory_limit()
    tools=Path(args.tools) if args.tools else Path(sys.executable).parent/'ocr'
    try:result=extract(Path(args.input),args.mime,tools,Path(args.preview) if args.preview else None)
    except Exception as error:result={'success':False,'error_code':type(error).__name__,'text':'','engine':'Tesseract','partial':False}
    result['memory_limited']=limited
    Path(args.result).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
    return 0 if result['success'] else 1

if __name__=='__main__':raise SystemExit(main())
