"""Code 39, generated locally with the standard 3-of-9 character patterns."""
from html import escape
from django.core.exceptions import ValidationError
from django.utils.safestring import mark_safe
ALPHABET='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%'
ENCODINGS=[0x034,0x121,0x061,0x160,0x031,0x130,0x070,0x025,0x124,0x064,0x109,0x049,0x148,0x019,0x118,0x058,0x00D,0x10C,0x04C,0x01C,0x103,0x043,0x142,0x013,0x112,0x052,0x007,0x106,0x046,0x016,0x181,0x0C1,0x1C0,0x091,0x190,0x0D0,0x085,0x184,0x0C4,0x0A8,0x0A2,0x08A,0x02A]

def code39_svg(value):
    if not value or len(value)>60 or any(c not in ALPHABET for c in value):raise ValidationError('مقدار بارکد Code39 معتبر نیست.')
    patterns={**dict(zip(ALPHABET,ENCODINGS)),'*':0x094}
    x=14;bars=[]
    for char in '*'+value+'*':
        encoding=patterns[char]
        for n in range(9):
            width=3 if encoding&(1<<(8-n)) else 1
            if n%2==0:bars.append(f'<rect x="{x}" y="4" width="{width}" height="52"/>')
            x+=width
        x+=1
    return mark_safe(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {x+14} 78" role="img" aria-label="{escape(value)}" style="width:100%;height:120px;fill:#000;stroke:none"><rect width="100%" height="100%" fill="white"/>'+''.join(bars)+f'<text x="{(x+14)/2}" y="72" text-anchor="middle" font-size="10" font-family="monospace">{escape(value)}</text></svg>')
