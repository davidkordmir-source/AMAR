from decimal import Decimal, ROUND_HALF_UP, localcontext
import uuid

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q
from django.utils import timezone
from .fields import QuantityField

ZERO = Decimal("0")

class ImmutableQuerySet(models.QuerySet):
    def bulk_create(self,*args,**kwargs):
        from django.core.exceptions import ValidationError
        raise ValidationError("اسناد قطعی باید از مسیر ثبت تراکنشی ایجاد شوند.")
    def update(self,**kwargs):
        from django.core.exceptions import ValidationError
        raise ValidationError("سند قطعی فقط از مسیر سند اصلاحی تغییر می‌کند.")
    def delete(self):
        from django.core.exceptions import ValidationError
        raise ValidationError("اسناد قطعی قابل حذف نیستند.")

class ImmutableRecord(models.Model):
    objects = ImmutableQuerySet.as_manager()
    class Meta: abstract = True
    def save(self,*args,**kwargs):
        if self.pk and type(self).objects.filter(pk=self.pk).exists():
            from django.core.exceptions import ValidationError
            raise ValidationError("سند قطعی قابل بازنویسی نیست؛ سند اصلاحی ثبت کنید.")
        return super().save(*args,**kwargs)
    def delete(self,*args,**kwargs):
        from django.core.exceptions import ValidationError
        raise ValidationError("سند قطعی قابل حذف نیست.")

def summed(query, field):
    # Python's integer/Decimal totals do not overflow SQLite's signed 64-bit SUM
    # during long-lived ledgers with many deposits and payments.
    return sum(query.values_list(field, flat=True).iterator(), ZERO)

class Organization(models.Model):
    class Role(models.TextChoices):
        PRODUCER = "producer", "تولیدکننده"
        OPERATOR = "operator", "بهره‌بردار"
        CONSUMER = "consumer", "مصرف‌کننده"
        BOTH = "both", "تولیدکننده و مصرف‌کننده"
    name = models.CharField("نام مجموعه", max_length=180, unique=True)
    role = models.CharField("نقش", max_length=12, choices=Role.choices)
    national_id = models.CharField("شناسه ملی (اختیاری)", max_length=30, blank=True)
    contact = models.CharField("تلفن یا راه ارتباطی", max_length=120, blank=True)
    class Meta:
        ordering = ["name"]
        verbose_name = "مجموعه"
    def __str__(self):
        return self.name

class Branch(models.Model):
    class Kind(models.TextChoices):
        CENTRAL = "central", "مجموعه مرکزی"
        CITY = "city", "کارخانه اصلی شهر"
        FACTORY = "factory", "کارخانه زیرمجموعه"
    name = models.CharField("نام موقعیت", max_length=120)
    code = models.CharField("کد موقعیت", max_length=24, unique=True)
    organization = models.ForeignKey(Organization, on_delete=models.PROTECT, verbose_name="مجموعه بهره‌بردار / مصرف‌کننده")
    city = models.CharField("شهر", max_length=80)
    address = models.TextField("نشانی", blank=True)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT, related_name="children", verbose_name="واحد بالادست")
    kind = models.CharField("نوع واحد", max_length=10, choices=Kind.choices, default=Kind.FACTORY)
    active = models.BooleanField("فعال", default=True)
    locality = models.ForeignKey("GeoPlace",null=True,blank=True,on_delete=models.PROTECT,verbose_name="تقسیمات کشوری")
    class Meta:
        ordering = ["name"]
        verbose_name = "موقعیت"
    def __str__(self):
        return f"{self.name} · {self.city}"
    def clean(self):
        from django.core.exceptions import ValidationError
        seen = {self.pk} if self.pk else set()
        current = self.parent
        while current:
            if current.pk in seen:
                raise ValidationError("ساختار واحدها نباید چرخه یا ارجاع به خود داشته باشد.")
            if current.organization_id != self.organization_id:
                raise ValidationError("واحد بالادست باید متعلق به همان مجموعه باشد.")
            seen.add(current.pk)
            current = current.parent
    @property
    def depth(self):
        depth, current, seen = 0, self.parent, {self.pk}
        while current and current.pk not in seen:
            seen.add(current.pk)
            depth += 1
            current = current.parent
        return depth

class Warehouse(models.Model):
    name = models.CharField("نام انبار", max_length=120)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="warehouses", verbose_name="موقعیت")
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT,
        related_name="children", verbose_name="انبار بالادست", help_text="برای زیرانبار، انبار بالادست همان موقعیت را انتخاب کنید.")
    class Meta:
        ordering = ["branch__name", "name"]
        constraints = [models.UniqueConstraint(fields=["branch", "name"], name="unique_warehouse_in_branch")]
        verbose_name = "انبار"
    def __str__(self):
        return self.path
    @property
    def path(self):
        parts,seen,current=[],set(),self
        while current:
            identity=current.pk or id(current)
            if identity in seen:break
            seen.add(identity);parts.append(current.name);current=current.parent
        if not self.branch_id:return " / ".join(reversed(parts))
        place=self.branch.locality.path if self.branch.locality_id else self.branch.city
        if self.branch.city and self.branch.city not in place.split(' / '):place+=' / '+self.branch.city
        return " / ".join([place,self.branch.name,*reversed(parts)])
    def clean(self):
        from django.core.exceptions import ValidationError
        seen={self.pk} if self.pk else set()
        current=self.parent
        while current:
            if current.pk in seen:raise ValidationError({'parent':'ساختار انبارها نباید چرخه یا ارجاع به خود داشته باشد.'})
            if current.branch_id!=self.branch_id:raise ValidationError({'parent':'انبار بالادست باید در همان موقعیت باشد.'})
            seen.add(current.pk);current=current.parent
        if self.pk and self.children.exclude(branch_id=self.branch_id).exists():
            raise ValidationError({'branch':'موقعیت انبار دارای زیرانبار را تغییر ندهید؛ ابتدا زیرانبارها را بررسی کنید.'})

class Item(models.Model):
    class Unit(models.TextChoices):
        PIECE = "piece", "عدد"
        KG = "kg", "کیلوگرم"
        METER = "meter", "متر"
        LITER = "liter", "لیتر"
    name = models.CharField("نام کالا یا قطعه", max_length=160)
    sku = models.CharField("کد یکتای کالا", max_length=40, unique=True)
    unit = models.CharField("واحد اندازه‌گیری", max_length=10, choices=Unit.choices, default=Unit.PIECE)
    specification = models.TextField("مشخصات فنی و جزئیات", blank=True)
    minimum_stock = QuantityField("حد هشدار موجودی (برای هر انبار)", default=0, validators=[MinValueValidator(0)])
    barcode = models.CharField("بارکد", max_length=60, blank=True)
    tracking = models.CharField("روش ردیابی", max_length=10, choices=[("bulk", "کد کالا و مقدار"), ("lot", "بچ / سری ساخت"), ("serial", "سریال تک‌قلم")], default="bulk")
    class Meta:
        ordering = ["name"]
        verbose_name = "کالا"
        constraints = [models.CheckConstraint(condition=Q(minimum_stock__gte=0), name="nonnegative_minimum_stock"), models.UniqueConstraint(fields=["barcode"], condition=~Q(barcode=""), name="unique_nonempty_barcode")]
    def __str__(self):
        return f"{self.sku} · {self.name}"
    def save(self,*args,**kwargs):
        super().save(*args,**kwargs)
        if not self.barcode:
            candidate=f'ITEM-{self.pk:012d}'
            if Item.objects.exclude(pk=self.pk).filter(barcode=candidate).exists():candidate='ITEM-'+uuid.uuid4().hex[:20].upper()
            Item.objects.filter(pk=self.pk).update(barcode=candidate)
            self.barcode=candidate

class Contract(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "پیش‌نویس"
        APPROVED = "approved", "تأیید شده"
        BUILDING = "building", "در حال ساخت"
        READY = "ready", "آماده تحویل"
        PARTIAL = "partial", "تحویل بخشی"
        RECEIVED = "received", "تحویل کامل"
        CANCELLED = "cancelled", "لغو شده"
    number = models.CharField("شماره قرارداد", max_length=40, unique=True)
    title = models.CharField("موضوع قرارداد", max_length=180)
    supplier = models.ForeignKey(Organization, on_delete=models.PROTECT, related_name="supplied_contracts", verbose_name="تولیدکننده")
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="contracts", verbose_name="انبار مقصد / موقعیت مصرف‌کننده")
    status = models.CharField("وضعیت", choices=Status.choices, max_length=12, default=Status.DRAFT)
    due_date = models.DateField("موعد تحویل (میلادی)", null=True, blank=True)
    notes = models.TextField("توضیحات و شرایط قرارداد", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="approved_contracts")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="created_contracts")
    class Meta:
        ordering = ["-created_at", "-pk"]
        verbose_name = "قرارداد"
        permissions = [("approve_contract", "تأیید و تغییر وضعیت قرارداد")]
    def __str__(self):
        return self.number
    @property
    def total(self):
        return sum((line.total for line in self.lines.all()), ZERO)
    @property
    def paid(self):
        return summed(MoneyEntry.objects.filter(allocation__contract=self, kind=MoneyEntry.Kind.PAYMENT), "amount")
    @property
    def allocated(self):
        return summed(self.allocations.filter(active=True), "amount")
    @property
    def outstanding(self):
        return max(ZERO, self.total - self.paid)
    @property
    def is_open(self):
        return self.status not in (self.Status.DRAFT, self.Status.CANCELLED, self.Status.RECEIVED)

class ContractLine(models.Model):
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, related_name="lines")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, verbose_name="کالا / قطعه")
    quantity = QuantityField("مقدار", validators=[MinValueValidator(Decimal("0.001"))])
    unit_price = models.BigIntegerField("قیمت واحد (ریال)", validators=[MinValueValidator(1)])
    class Meta:
        ordering = ["pk"]
        constraints = [
            models.CheckConstraint(condition=Q(quantity__gt=0), name="positive_contract_quantity"),
            models.CheckConstraint(condition=Q(unit_price__gt=0), name="positive_contract_price"),
            models.UniqueConstraint(fields=["contract", "item"], name="unique_contract_item"),
        ]
    @property
    def total(self):
        with localcontext() as context:
            context.prec = 40
            return (Decimal(str(self.quantity)) * Decimal(str(self.unit_price))).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    @property
    def received(self):
        return summed(self.movements.all(), "quantity")
    @property
    def pending(self):
        return self.quantity - self.received if self.contract.is_open else ZERO

class Account(models.Model):
    name = models.CharField("نام حساب / صندوق", max_length=100)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, verbose_name="موقعیت")
    opening_balance = models.BigIntegerField("موجودی اولیه (ریال)", default=0, validators=[MinValueValidator(0)])
    credit_limit = models.BigIntegerField("سقف اعتبار (ریال)", default=0, validators=[MinValueValidator(0)])
    current_balance = models.BigIntegerField(default=0,editable=False)
    class Meta:
        ordering = ["branch__name", "name"]
        verbose_name = "حساب مالی"
        constraints = [
            models.CheckConstraint(condition=Q(opening_balance__gte=0), name="nonnegative_opening_balance"),
            models.CheckConstraint(condition=Q(credit_limit__gte=0), name="nonnegative_credit_limit"),
            models.UniqueConstraint(fields=["branch", "name"], name="unique_account_in_branch"),
        ]
    def __str__(self):
        return f"{self.branch.name} / {self.name}"
    def save(self,*args,**kwargs):
        from django.core.exceptions import ValidationError
        from django.db import transaction
        with transaction.atomic():
            if not self.pk:self.current_balance=self.opening_balance
            else:
                previous=Account.objects.select_for_update().get(pk=self.pk)
                self.current_balance=previous.current_balance
                if previous.opening_balance!=self.opening_balance:
                    if self.entries.exists():raise ValidationError('موجودی اولیه حساب دارای سند قابل بازنویسی نیست.')
                    self.current_balance+=self.opening_balance-previous.opening_balance
            return super().save(*args,**kwargs)
    @property
    def balance(self):
        return Account.objects.filter(pk=self.pk).values_list('current_balance',flat=True).get()
    @property
    def reserved(self):
        allocated = summed(self.allocations.filter(active=True), "amount")
        paid = summed(self.entries.filter(kind=MoneyEntry.Kind.PAYMENT, allocation__active=True), "amount")
        return allocated - paid
    @property
    def available(self):
        return self.balance + self.credit_limit - self.reserved

class Allocation(models.Model):
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, related_name="allocations", verbose_name="قرارداد")
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="allocations", verbose_name="حساب تأمین‌کننده وجه")
    amount = models.BigIntegerField("مبلغ تخصیص (ریال)", validators=[MinValueValidator(1)])
    active = models.BooleanField(default=True)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-pk"]
        verbose_name = "تخصیص وجه"
        constraints = [models.CheckConstraint(condition=Q(amount__gt=0), name="positive_allocation")]
    def __str__(self):
        return f"{self.contract.number} · {self.account} · تخصیص #{self.pk}"
    @property
    def paid(self):
        return summed(self.payments.all(), "amount")
    @property
    def remaining(self):
        return self.amount - self.paid

class MoneyEntry(ImmutableRecord):
    class Kind(models.TextChoices):
        DEPOSIT = "deposit", "دریافت وجه"
        PAYMENT = "payment", "پرداخت به تولیدکننده"
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="entries", verbose_name="حساب")
    allocation = models.ForeignKey(Allocation, on_delete=models.PROTECT, related_name="payments", null=True, blank=True)
    kind = models.CharField(max_length=10, choices=Kind.choices)
    amount = models.BigIntegerField("مبلغ (ریال)", validators=[MinValueValidator(1)])
    reference = models.CharField("شماره سند / پیگیری", max_length=80)
    description = models.CharField("شرح", max_length=240, blank=True)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    class Meta:
        ordering = ["-pk"]
        verbose_name = "سند مالی"
        constraints = [
            models.CheckConstraint(condition=Q(amount__gt=0), name="positive_money_entry"),
            models.CheckConstraint(condition=(Q(kind="deposit", allocation__isnull=True) | Q(kind="payment", allocation__isnull=False)), name="valid_money_entry_kind"),
            models.UniqueConstraint(fields=["account", "reference"], name="unique_financial_reference"),
        ]
    def save(self,*args,**kwargs):
        from django.db import transaction
        from django.db.models import F
        with transaction.atomic():
            result=super().save(*args,**kwargs)
            change=int(self.amount) if self.kind==self.Kind.DEPOSIT else -int(self.amount)
            Account.objects.filter(pk=self.account_id).update(current_balance=F('current_balance')+change)
            return result

class Receipt(ImmutableRecord):
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, related_name="receipts")
    reference = models.CharField("شماره رسید تحویل", max_length=80)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["contract", "reference"], name="unique_receipt_reference")]

class StockMovement(ImmutableRecord):
    class Kind(models.TextChoices):
        RECEIPT = "receipt", "تحویل قرارداد"
        IN = "in", "ورود دستی / موجودی اولیه"
        OUT = "out", "خروج / مصرف"
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="movements", verbose_name="انبار")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="movements", verbose_name="کالا")
    kind = models.CharField(max_length=10, choices=Kind.choices)
    quantity = QuantityField("مقدار")
    contract_line = models.ForeignKey(ContractLine, on_delete=models.PROTECT, null=True, related_name="movements")
    receipt = models.ForeignKey(Receipt, on_delete=models.PROTECT, null=True, related_name="movements")
    reference = models.CharField("شماره سند", max_length=80)
    note = models.CharField("شرح حرکت / محل مصرف", max_length=240, blank=True)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    location = models.ForeignKey("StorageLocation", on_delete=models.PROTECT, null=True, blank=True)
    trace = models.ForeignKey("TraceUnit", on_delete=models.PROTECT, null=True, blank=True)
    def save(self,*args,**kwargs):
        from django.db import transaction
        from django.core.exceptions import ValidationError
        with transaction.atomic():
            result=super().save(*args,**kwargs)
            key=StockBalance.make_key(self.warehouse_id,self.item_id,self.location_id,self.trace_id)
            balance,_=StockBalance.objects.select_for_update().get_or_create(bucket_key=key,defaults={'warehouse_id':self.warehouse_id,'item_id':self.item_id,'location_id':self.location_id,'trace_id':self.trace_id})
            balance.quantity+=Decimal(str(self.quantity))
            if balance.quantity<0:raise ValidationError('موجودی محل نمی‌تواند منفی شود.')
            balance.save(update_fields=['quantity'])
            return result
    class Meta:
        ordering = ["-pk"]
        verbose_name = "گردش انبار"
        constraints = [
            models.CheckConstraint(condition=Q(kind="out", quantity__lt=0, contract_line__isnull=True, receipt__isnull=True) | Q(kind="in", quantity__gt=0, contract_line__isnull=True, receipt__isnull=True) | Q(kind="receipt", quantity__gt=0, contract_line__isnull=False, receipt__isnull=False), name="valid_stock_movement"),
            models.UniqueConstraint(fields=["receipt", "contract_line"], name="unique_receipt_line"),
        ]

class AuditEvent(ImmutableRecord):
    action = models.CharField(max_length=100)
    target = models.CharField(max_length=180)
    detail = models.TextField(blank=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    created_at = models.DateTimeField(default=timezone.now)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, null=True, blank=True)
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, null=True, blank=True)
    previous_digest = models.CharField(max_length=64, blank=True)
    digest = models.CharField(max_length=64, blank=True)
    class Meta:
        ordering = ["-pk"]
        verbose_name = "رویداد عملیاتی"

class SyncState(models.Model):
    """Only one row per installation. Identity and private key live in DATA_DIR."""
    sequence = models.PositiveBigIntegerField(default=0)
    class Meta:
        permissions = [("export_branch_data", "صدور فایل گزارش موقعیت")]

class TrustedSource(models.Model):
    source_id = models.UUIDField(unique=True)
    label = models.CharField("نام موقعیت / نصب مبدأ", max_length=120)
    public_key = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.PROTECT, verbose_name="واحد مربوط به مبدأ")
    class Meta:
        ordering = ["label"]
        verbose_name = "مبدأ مورد اعتماد"
    def __str__(self):
        return self.label
    @property
    def latest(self):
        return self.snapshots.order_by("-sequence").first()

class ImportedSnapshot(models.Model):
    source = models.ForeignKey(TrustedSource, on_delete=models.PROTECT, related_name="snapshots")
    sequence = models.PositiveBigIntegerField()
    payload = models.JSONField()
    digest = models.CharField(max_length=64)
    generated_at = models.DateTimeField()
    imported_at = models.DateTimeField(auto_now_add=True)
    imported_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    class Meta:
        ordering = ["-imported_at"]
        constraints = [models.UniqueConstraint(fields=["source", "sequence"], name="unique_source_sequence")]
        verbose_name = "گزارش دریافتی موقعیت"

class AccessRole(models.Model):
    code = models.SlugField(unique=True, max_length=60)
    name = models.CharField('نام دلخواه نقش', max_length=120, unique=True)
    permissions = models.ManyToManyField('auth.Permission', blank=True)
    active = models.BooleanField('فعال', default=True)
    class Meta:
        ordering = ['name']
        verbose_name = 'نقش قابل تنظیم'
        permissions = [('manage_access', 'مدیریت کاربران و دسترسی‌ها'), ('manage_structure', 'مدیریت ساختار کارخانه‌ها'), ('manage_configuration', 'تغییر نام‌ها و تنظیمات'), ('grant_contract', 'تعیین دسترسی قرارداد'), ('approve_operations', 'تأیید درخواست‌ها و اصلاح اسناد')]
    def __str__(self): return self.name

class UserProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='factory_profile')
    display_name = models.CharField('نام نمایشی شخص', max_length=120, blank=True)
    position_title = models.CharField('عنوان دلخواه سمت', max_length=120, blank=True)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, null=True, blank=True, verbose_name='واحد مجاز')
    include_descendants = models.BooleanField('دسترسی به زیرمجموعه‌های همان واحد', default=False)
    role = models.ForeignKey(AccessRole, null=True, blank=True, on_delete=models.PROTECT, verbose_name='نقش دسترسی')
    enabled = models.BooleanField('دسترسی فعال', default=True)
    class Meta: verbose_name = 'پروفایل و محدوده دسترسی'
    def __str__(self): return self.display_name or self.user.username

class ContractGrant(models.Model):
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, related_name='access_grants')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, null=True, blank=True)
    include_descendants = models.BooleanField(default=False)
    can_operate = models.BooleanField('اجازه انجام عملیات قرارداد', default=False)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.CheckConstraint(condition=Q(user__isnull=False, branch__isnull=True) | Q(user__isnull=True, branch__isnull=False), name='single_grant_target')]
        verbose_name = 'دسترسی صریح قرارداد'

class RemoteContractGrant(models.Model):
    source = models.ForeignKey(TrustedSource, on_delete=models.PROTECT)
    number = models.CharField(max_length=40)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['source','number','user'], name='unique_remote_grant')]

class SystemConfiguration(models.Model):
    brand_name = models.CharField('نام نرم‌افزار / مجموعه', max_length=100, default='آمار')
    central_label = models.CharField('عنوان سطح مرکزی', max_length=80, default='مجموعه مرکزی')
    city_label = models.CharField('عنوان کارخانه‌های اصلی شهرها', max_length=80, default='کارخانه اصلی شهر')
    factory_label = models.CharField('عنوان کارخانه‌های زیرمجموعه', max_length=80, default='کارخانه زیرمجموعه')
    owner_title = models.CharField('عنوان دلخواه مسئول ارشد', max_length=80, default='راهبر مجموعه')
    person_label = models.CharField('عنوان عمومی افراد', max_length=80, default='همکار')
    large_contract_amount = models.BigIntegerField('حد هشدار مبلغ قرارداد (ریال)', default=1000000000, validators=[MinValueValidator(1)])
    abnormal_quantity = QuantityField('حد هشدار مقدار خروج', default=1000, validators=[MinValueValidator(1)])
    overdue_days = models.PositiveIntegerField('مهلت تعیین تکلیف اقلام تحویلی (روز)', default=7, validators=[MinValueValidator(1)])
    backup_hours = models.PositiveIntegerField('فاصله پشتیبان خودکار (ساعت)', default=24, validators=[MinValueValidator(1)])
    class Meta: verbose_name = 'نام‌ها و قواعد کنترل'

class StorageLocation(models.Model):
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT)
    code = models.CharField('کد محل', max_length=40)
    aisle = models.CharField('راهرو', max_length=40, blank=True)
    rack = models.CharField('قفسه', max_length=40, blank=True)
    shelf = models.CharField('طبقه', max_length=40, blank=True)
    bin = models.CharField('خانه / جایگاه', max_length=40, blank=True)
    class Meta:
        ordering = ['warehouse__branch__name','code']
        constraints = [models.UniqueConstraint(fields=['warehouse','code'],name='unique_storage_location')]
        verbose_name = 'محل دقیق نگهداری'
    def __str__(self): return f'{self.warehouse} / {self.code}'

class TraceUnit(models.Model):
    item = models.ForeignKey(Item, on_delete=models.PROTECT)
    code = models.CharField('بچ یا سریال', max_length=100)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['item','code'],name='unique_item_trace')]
        verbose_name = 'بچ یا سریال'
    def __str__(self): return f'{self.item.name} / {self.code}'
    @property
    def barcode(self): return f'TRACE-{self.pk:012d}'

class Custodian(models.Model):
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, verbose_name='واحد')
    code = models.CharField('کد شخص', max_length=40)
    name = models.CharField('نام دلخواه شخص', max_length=120)
    title = models.CharField('عنوان دلخواه سمت', max_length=120, blank=True)
    active = models.BooleanField('فعال', default=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['branch','code'],name='unique_custodian')]
        verbose_name = 'تحویل‌گیرنده کالا'
    def __str__(self): return f'{self.name} / {self.branch.name}'

class WorkOrder(models.Model):
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, verbose_name='واحد')
    number = models.CharField('شماره دستور کار', max_length=60, unique=True)
    title = models.CharField('عنوان کار', max_length=180)
    asset = models.CharField('دستگاه / دارایی / پروژه', max_length=160)
    active = models.BooleanField('فعال', default=True)
    class Meta: verbose_name = 'دستور کار'
    def __str__(self): return f'{self.number} / {self.title}'

class MaterialRequest(models.Model):
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, verbose_name='انبار')
    item = models.ForeignKey(Item, on_delete=models.PROTECT, verbose_name='کالا')
    location = models.ForeignKey(StorageLocation, on_delete=models.PROTECT, null=True, blank=True, verbose_name='محل نگهداری')
    trace = models.ForeignKey(TraceUnit, on_delete=models.PROTECT, null=True, blank=True, verbose_name='بچ / سریال')
    quantity = QuantityField('مقدار', validators=[MinValueValidator(Decimal('0.001'))])
    recipient = models.ForeignKey(Custodian, on_delete=models.PROTECT, verbose_name='تحویل‌گیرنده')
    work_order = models.ForeignKey(WorkOrder, on_delete=models.PROTECT, verbose_name='دستور کار')
    purpose = models.CharField('شرح نیاز', max_length=240)
    status = models.CharField(max_length=12, default='pending', choices=[('pending','منتظر تأیید'),('approved','تأیید و رزرو شده'),('issued','تحویل به شخص'),('closed','تعیین تکلیف کامل'),('rejected','رد شده')])
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+', null=True)
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+', null=True)
    issue_movement = models.OneToOneField(StockMovement, on_delete=models.PROTECT, null=True, related_name='material_issue')
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    issued_at = models.DateTimeField(null=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'درخواست و تحویل قطعه'
        constraints = [models.CheckConstraint(condition=Q(quantity__gt=0), name='positive_material_request')]
    @property
    def consumed(self): return summed(self.custody_events.filter(kind='consume'),'quantity')
    @property
    def returned(self): return summed(self.custody_events.filter(kind='return'),'quantity')
    @property
    def remaining(self): return self.quantity - self.consumed - self.returned if self.status in ('issued','closed') else ZERO

class CustodyEvent(ImmutableRecord):
    request = models.ForeignKey(MaterialRequest,on_delete=models.PROTECT,related_name='custody_events')
    kind = models.CharField(max_length=10, choices=[('consume','مصرف در دستور کار'),('return','برگشت به انبار')])
    quantity = QuantityField('مقدار')
    reference = models.CharField('شماره سند',max_length=80)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT)
    movement = models.OneToOneField(StockMovement,on_delete=models.PROTECT,null=True)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.CheckConstraint(condition=Q(quantity__gt=0),name='positive_custody_quantity')]

class TransferRoute(models.Model):
    source = models.ForeignKey(Branch,on_delete=models.PROTECT,related_name='outgoing_routes',verbose_name='واحد مبدأ')
    destination = models.ForeignKey(Branch,on_delete=models.PROTECT,related_name='+',verbose_name='واحد مقصد')
    class Meta:
        constraints = [models.UniqueConstraint(fields=['source','destination'],name='unique_transfer_route')]
        verbose_name = 'مسیر مجاز انتقال'

class StockTransfer(models.Model):
    source = models.ForeignKey(Warehouse,on_delete=models.PROTECT,related_name='outgoing_transfers',verbose_name='انبار مبدأ')
    destination = models.ForeignKey(Warehouse,on_delete=models.PROTECT,related_name='incoming_transfers',verbose_name='انبار مقصد')
    item = models.ForeignKey(Item,on_delete=models.PROTECT,verbose_name='کالا')
    location = models.ForeignKey(StorageLocation,on_delete=models.PROTECT,null=True,blank=True,related_name='+',verbose_name='محل مبدأ')
    destination_location = models.ForeignKey(StorageLocation,on_delete=models.PROTECT,null=True,blank=True,related_name='+')
    trace = models.ForeignKey(TraceUnit,on_delete=models.PROTECT,null=True,blank=True,verbose_name='بچ / سریال')
    quantity = QuantityField('مقدار')
    reference = models.CharField('شماره انتقال',max_length=80,unique=True)
    status = models.CharField(max_length=12,default='pending',choices=[('pending','منتظر تأیید'),('approved','تأیید و رزرو شده'),('transit','در مسیر'),('received','دریافت مقصد'),('rejected','رد شده')])
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+',null=True)
    sent_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+',null=True)
    received_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+',null=True)
    sent_movement = models.OneToOneField(StockMovement,on_delete=models.PROTECT,null=True,related_name='+')
    received_movement = models.OneToOneField(StockMovement,on_delete=models.PROTECT,null=True,related_name='+')
    operation_key = models.UUIDField(default=uuid.uuid4,unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'انتقال کنترل‌شده'
        constraints = [models.CheckConstraint(condition=Q(quantity__gt=0),name='positive_transfer_quantity')]

class StockCorrection(models.Model):
    warehouse = models.ForeignKey(Warehouse,on_delete=models.PROTECT,verbose_name='انبار')
    item = models.ForeignKey(Item,on_delete=models.PROTECT,verbose_name='کالا')
    location = models.ForeignKey(StorageLocation,on_delete=models.PROTECT,null=True,blank=True,verbose_name='محل')
    trace = models.ForeignKey(TraceUnit,on_delete=models.PROTECT,null=True,blank=True,verbose_name='بچ / سریال')
    quantity = QuantityField('تغییر مقدار (مثبت یا منفی)')
    reason = models.TextField('علت و مستند اصلاح')
    status = models.CharField(max_length=12,default='pending',choices=[('pending','منتظر تأیید'),('approved','ثبت سند اصلاحی'),('rejected','رد شده')])
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+',null=True)
    movement = models.OneToOneField(StockMovement,on_delete=models.PROTECT,null=True)
    operation_key = models.UUIDField(default=uuid.uuid4,unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'سند اصلاح موجودی'
        constraints = [models.CheckConstraint(condition=~Q(quantity=0),name='nonzero_correction')]

class StockCount(models.Model):
    warehouse = models.ForeignKey(Warehouse,on_delete=models.PROTECT,verbose_name='انبار')
    reference = models.CharField('شماره انبارگردانی',max_length=80,unique=True)
    baseline = models.PositiveBigIntegerField(default=0)
    status = models.CharField(max_length=12,default='pending',choices=[('pending','منتظر تأیید'),('approved','مغایرت ثبت شد'),('rejected','رد شده')])
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+',null=True)
    operation_key = models.UUIDField(default=uuid.uuid4,unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'انبارگردانی'

class StockCountLine(models.Model):
    count = models.ForeignKey(StockCount,on_delete=models.PROTECT,related_name='lines')
    item = models.ForeignKey(Item,on_delete=models.PROTECT,verbose_name='کالا')
    location = models.ForeignKey(StorageLocation,on_delete=models.PROTECT,null=True,blank=True,verbose_name='محل')
    trace = models.ForeignKey(TraceUnit,on_delete=models.PROTECT,null=True,blank=True,verbose_name='بچ / سریال')
    expected = QuantityField()
    counted = QuantityField('شمارش واقعی')
    movement = models.OneToOneField(StockMovement,on_delete=models.PROTECT,null=True)
    class Meta:
        constraints = [models.CheckConstraint(condition=Q(counted__gte=0),name='nonnegative_count')]
    @property
    def difference(self): return self.counted-self.expected

class PaymentRequest(models.Model):
    allocation = models.ForeignKey(Allocation,on_delete=models.PROTECT,verbose_name='تخصیص')
    amount = models.BigIntegerField('مبلغ (ریال)',validators=[MinValueValidator(1)])
    reference = models.CharField('شماره سند',max_length=80)
    description = models.CharField('شرح',max_length=240,blank=True)
    status = models.CharField(max_length=12,default='pending',choices=[('pending','منتظر تأیید'),('approved','پرداخت ثبت شد'),('rejected','رد شده')])
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='+',null=True)
    entry = models.OneToOneField(MoneyEntry,on_delete=models.PROTECT,null=True)
    operation_key = models.UUIDField(default=uuid.uuid4,unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'درخواست پرداخت'
        constraints = [models.CheckConstraint(condition=Q(amount__gt=0),name='positive_payment_request')]

class BackupStatus(models.Model):
    last_success = models.DateTimeField(null=True)
    last_file = models.CharField(max_length=200,blank=True)
    last_digest = models.CharField(max_length=64,blank=True)
    last_error = models.TextField(blank=True)
    class Meta: verbose_name = 'وضعیت پشتیبان خودکار'

class GeoPlace(models.Model):
    code = models.CharField('کد تقسیمات',max_length=40,unique=True)
    name = models.CharField('نام',max_length=180,db_index=True)
    level = models.CharField('نوع',max_length=12,choices=[('province','استان'),('county','شهرستان'),('district','بخش'),('rural','دهستان'),('city','شهر'),('village','روستا')],db_index=True)
    parent = models.ForeignKey('self',on_delete=models.PROTECT,null=True,blank=True,related_name='children')
    source = models.CharField(max_length=120,default='local')
    class Meta:
        ordering=['name','code']
        verbose_name='تقسیمات کشوری'
    def __str__(self): return f'{self.name} / {self.get_level_display()} / {self.code}'
    @property
    def path(self):
        result,seen,current=[],set(),self
        while current and current.pk not in seen:
            seen.add(current.pk); result.append(current.name); current=current.parent
        return ' / '.join(reversed(result))

class GeographyLoad(models.Model):
    digest = models.CharField(max_length=64)
    loaded_at = models.DateTimeField(auto_now=True)
    counts = models.JSONField(default=dict)

class StockBalance(models.Model):
    bucket_key=models.CharField(max_length=100,unique=True)
    warehouse=models.ForeignKey(Warehouse,on_delete=models.PROTECT)
    item=models.ForeignKey(Item,on_delete=models.PROTECT)
    location=models.ForeignKey(StorageLocation,on_delete=models.PROTECT,null=True)
    trace=models.ForeignKey(TraceUnit,on_delete=models.PROTECT,null=True)
    quantity=QuantityField(default=0)
    @staticmethod
    def make_key(warehouse,item,location=None,trace=None):return f'{warehouse}:{item}:{location or 0}:{trace or 0}'
