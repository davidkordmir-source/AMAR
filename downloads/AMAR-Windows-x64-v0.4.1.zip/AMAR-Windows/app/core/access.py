"""Capabilities and information scope are independent of editable titles."""
from django.contrib.auth.backends import ModelBackend
from django.core.exceptions import PermissionDenied
from django.db.models import Q

from .models import Branch, Contract, ContractGrant, UserProfile

def profile(user):
    if not user or not user.is_authenticated:
        return None
    return UserProfile.objects.select_related('branch','role').filter(user=user,enabled=True).first()

def root(user):
    return user is None or (user.is_active and user.is_superuser)

def descendants(branch_id, include_self=True):
    rows=list(Branch.objects.values_list('pk','parent_id'))
    selected={branch_id}
    while True:
        added={pk for pk,parent in rows if parent in selected}-selected
        if not added: break
        selected.update(added)
    return selected if include_self else selected-{branch_id}

def ancestors(branch_id):
    parents=dict(Branch.objects.values_list('pk','parent_id'))
    result=set()
    while branch_id and branch_id not in result:
        result.add(branch_id)
        branch_id=parents.get(branch_id)
    return result

def factory_ids(user):
    if root(user): return set(Branch.objects.values_list('pk',flat=True))
    p=profile(user)
    if not p or not p.branch_id or not p.role_id or not p.role.active: return set()
    if Branch.objects.filter(pk__in=ancestors(p.branch_id),active=False).exists(): return set()
    selected=descendants(p.branch_id) if p.include_descendants else {p.branch_id}
    return set(Branch.objects.filter(pk__in=selected,active=True).values_list('pk',flat=True))

def require_factory(user, branch_id):
    if branch_id not in factory_ids(user): raise PermissionDenied('این واحد در محدوده دسترسی شما نیست.')

def require_permission(user, permission):
    if user is not None and not user.has_perm('core.'+permission): raise PermissionDenied

def contracts_for(user, operate=False):
    objects=Contract.objects.all()
    if root(user): return objects
    if not user.has_perm("core.view_contract"):return objects.none()
    ids=factory_ids(user)
    inherited=set()
    for pk in ids: inherited.update(ancestors(pk))
    grants=ContractGrant.objects.filter(Q(user=user)|Q(branch_id__in=ids)|Q(branch_id__in=inherited,include_descendants=True))
    if operate: grants=grants.filter(can_operate=True)
    return objects.filter(warehouse__branch_id__in=ids,pk__in=grants.values('contract_id'))

def require_contract(user, contract_id, operate=False):
    if not contracts_for(user,operate).filter(pk=contract_id).exists(): raise PermissionDenied

class FactoryPermissionBackend(ModelBackend):
    def get_all_permissions(self,user_obj,obj=None):
        if not user_obj.is_active or not user_obj.is_authenticated: return set()
        if user_obj.is_superuser: return super().get_all_permissions(user_obj,obj)
        p=profile(user_obj)
        if not p or not p.role_id or not p.role.active or not factory_ids(user_obj): return set()
        return {f'{app}.{code}' for app,code in p.role.permissions.values_list('content_type__app_label','codename')}

def allowed_organization_ids(user):
    from .models import Organization
    if root(user): return Organization.objects.values_list('pk',flat=True)
    return Organization.objects.filter(Q(branch__pk__in=factory_ids(user))|Q(supplied_contracts__in=contracts_for(user))).distinct().values_list('pk',flat=True)

def scope_form(form,user):
    """Also restrict POST choices: hidden options are never an access boundary."""
    from .models import Account, Allocation, Branch, Contract, Custodian, StorageLocation, TraceUnit, Warehouse, WorkOrder
    ids=factory_ids(user)
    for field in form.fields.values():
        if not hasattr(field,'queryset') or field.queryset is None: continue
        model=field.queryset.model
        if model==Branch: field.queryset=field.queryset.filter(pk__in=ids)
        elif model==Warehouse: field.queryset=field.queryset.filter(branch_id__in=ids)
        elif model==Account: field.queryset=field.queryset.filter(branch_id__in=ids)
        elif model==Allocation: field.queryset=field.queryset.filter(account__branch_id__in=ids,contract__in=contracts_for(user,True))
        elif model==Contract: field.queryset=field.queryset.filter(pk__in=contracts_for(user,True).values('pk'))
        elif model==StorageLocation: field.queryset=field.queryset.filter(warehouse__branch_id__in=ids)
        elif model in (Custodian,WorkOrder): field.queryset=field.queryset.filter(branch_id__in=ids)
        elif model==TraceUnit and not root(user):
            field.queryset=field.queryset.filter(Q(stockmovement__warehouse__branch_id__in=ids)|Q(stockmovement__isnull=True)).distinct()
    return form
