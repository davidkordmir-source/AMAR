"""Owner-managed reference data: never cascade through posted business records."""
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Q
from django.db.models.deletion import Collector, ProtectedError, RestrictedError
from . import models as m, forms, enterprise_forms as ef, services
from .access import descendants

MASTER_FORMS = {
    'organization': (m.Organization, forms.OrganizationForm),
    'branch': (m.Branch, forms.BranchForm),
    'warehouse': (m.Warehouse, forms.WarehouseForm),
    'item': (m.Item, forms.ItemForm),
    'account': (m.Account, forms.AccountForm),
    'location': (m.StorageLocation, ef.LocationForm),
    'trace': (m.TraceUnit, ef.TraceForm),
    'custodian': (m.Custodian, ef.CustodianForm),
    'workorder': (m.WorkOrder, ef.WorkOrderForm),
    'route': (m.TransferRoute, ef.RouteForm),
    'geography': (m.GeoPlace, ef.GeoForm),
}

def has_references(obj):
    return any(relation.related_model._default_manager.filter(**{relation.field.name:obj}).exists()
        for relation in obj._meta.related_objects if not relation.many_to_many)

def validate_reference_edit(kind, previous, data):
    fields={'branch':['organization'],'warehouse':['branch'],'account':['branch'],
        'location':['warehouse'],'trace':['item'],'custodian':['branch'],'workorder':['branch']}.get(kind,[])
    if previous and any(getattr(previous,key+'_id')!=data[key].pk for key in fields) and has_references(previous):
        raise ValidationError('این رکورد سابقه یا وابستگی دارد؛ موقعیت و ارتباط اصلی آن قابل تغییر نیست. نام و مشخصات مجاز را ویرایش کنید.')

def payment_exists(obj):
    entries = m.MoneyEntry.objects.filter(kind=m.MoneyEntry.Kind.PAYMENT)
    if isinstance(obj, m.Organization):
        return entries.filter(Q(allocation__contract__supplier=obj) | Q(account__branch__organization=obj)
            | Q(allocation__contract__warehouse__branch__organization=obj)).exists()
    if isinstance(obj, m.Branch):
        ids = descendants(obj.pk)
        return entries.filter(Q(account__branch_id__in=ids) | Q(allocation__contract__warehouse__branch_id__in=ids)).exists()
    if isinstance(obj, m.Warehouse):
        return entries.filter(allocation__contract__warehouse=obj).exists()
    if isinstance(obj, m.Item):
        return entries.filter(allocation__contract__lines__item=obj).exists()
    if isinstance(obj, m.Account):
        return entries.filter(account=obj).exists()
    if isinstance(obj, m.StorageLocation):
        return entries.filter(allocation__contract__lines__movements__location=obj).exists()
    if isinstance(obj, m.TraceUnit):
        return entries.filter(allocation__contract__lines__movements__trace=obj).exists()
    return False

def deletion_blockers(obj):
    if payment_exists(obj):
        return ['پرداخت مالی مرتبط ثبت شده است؛ حذف این اطلاعات مجاز نیست.']
    try:
        collector = Collector(using=obj._state.db or 'default')
        collector.collect([obj])
    except (ProtectedError, RestrictedError) as error:
        related = getattr(error, 'protected_objects', getattr(error, 'restricted_objects', []))
        labels = sorted({value._meta.verbose_name for value in related})
        return ['این رکورد سند، زیرمجموعه یا وابستگی دارد: ' + '، '.join(labels) + '. ابتدا وابستگی‌های مجاز را بررسی کنید؛ اسناد قطعی حذف نمی‌شوند.']
    return []

@transaction.atomic
def delete_reference(user, kind, pk):
    if not user.is_active or not user.is_superuser:
        raise PermissionDenied
    if kind not in MASTER_FORMS:
        raise PermissionDenied
    model, _ = MASTER_FORMS[kind]
    obj = model.objects.select_for_update().get(pk=pk)
    reasons = deletion_blockers(obj)
    if reasons:
        raise ValidationError(reasons)
    before = dict(model.objects.filter(pk=pk).values().get())
    label = str(obj)
    obj.delete()
    import json
    services.audit('حذف اطلاعات پایه بدون پرداخت', label, user,
        json.dumps({'kind': kind, 'id': pk, 'before': before}, ensure_ascii=False, default=str))
