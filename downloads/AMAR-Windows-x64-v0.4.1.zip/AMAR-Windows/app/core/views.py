import csv
import io

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import IntegrityError, OperationalError, transaction
from django.db.models import Q, Case, When, Value, IntegerField
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

from . import forms, services, sync
from .access import factory_ids,contracts_for,require_contract,scope_form,allowed_organization_ids,root
from .models import Account, Allocation, AuditEvent, Branch, Contract, Item, MoneyEntry, Organization, StockMovement, TrustedSource, Warehouse
from .reporting import consolidate_sources, financial_totals, inventory_rows, snapshot_totals

def access(permission):
    def decorate(view):
        return login_required(permission_required(f"core.{permission}", raise_exception=True)(view))
    return decorate

def selection(request):
    branch = request.GET.get("branch", "")
    branch = int(branch) if branch.isascii() and branch.isdigit() and len(branch) <= 10 else None
    return branch, request.GET.get("q", "").strip()[:120]


def visible_audit(user):
    objects=AuditEvent.objects.select_related('actor','branch')
    if root(user):return objects
    return objects.filter(branch_id__in=factory_ids(user)).filter(Q(contract__isnull=True)|Q(contract__in=contracts_for(user)))

def visible_sources(user):
    if root(user):return TrustedSource.objects.all()
    return TrustedSource.objects.filter(branch_id__in=factory_ids(user))

def common(request):
    branch, search = selection(request)
    if branch is not None and branch not in factory_ids(request.user):
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    return {"branches": Branch.objects.filter(pk__in=factory_ids(request.user)), "selected_branch": branch, "search": search}

def page(request, objects):
    return Paginator(objects, 40).get_page(request.GET.get("page"))

def csv_response(filename, header, rows):
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    def safe(value):
        text = str(value)
        # CSV exports are for spreadsheets. Prevent formula evaluation of text.
        return "'" + text if text.lstrip().startswith(("=", "+", "-", "@")) else text
    writer.writerow(header)
    writer.writerows([[safe(cell) for cell in row] for row in rows])
    response = HttpResponse("\ufeff" + output.getvalue(), content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response

@access("view_branch")
def dashboard(request):
    context = common(request)
    branch, _ = selection(request)
    contracts = contracts_for(request.user).select_related("supplier", "warehouse__branch").prefetch_related("lines")
    if branch:
        contracts = contracts.filter(warehouse__branch_id=branch)
    active = contracts.exclude(status__in=[Contract.Status.DRAFT, Contract.Status.CANCELLED])
    context.update({
        "page_title": "نمای کلی", "active_page": "dashboard", "local_branch_count": Branch.objects.filter(pk=branch).count() if branch else Branch.objects.filter(pk__in=factory_ids(request.user)).count(),
        "active_contract_count": active.count(), "open_contract_count": sum(c.is_open for c in active),
        "recent_contracts": contracts[:5], "item_count": Item.objects.count(),
    })
    if request.user.has_perm("core.view_account"):
        accounts = Account.objects.filter(branch_id__in=factory_ids(request.user))
        if branch: accounts=accounts.filter(branch_id=branch)
        context["totals"] = financial_totals(accounts)
        context["commitment"] = sum((c.outstanding for c in active), services.Decimal("0"))
    if request.user.has_perm("core.view_stockmovement"):
        rows = inventory_rows(branch,user=request.user)
        context["low_stock"] = [r for r in rows if r["low"]][:5]
        context["pending_count"] = sum(r["pending"] > 0 for r in rows)
    if request.user.has_perm("core.view_auditevent"):
        context["events"] = visible_audit(request.user)[:6]
    if request.user.has_perm("core.view_importedsnapshot"):
        context["remote_sources"] = [{"source": source, "snapshot": source.latest} for source in visible_sources(request.user)]
    return render(request, "core/dashboard.html", context)

@access("view_contract")
def contracts(request):
    branch, search = selection(request)
    objects = contracts_for(request.user).select_related("supplier", "warehouse__branch").prefetch_related("lines")
    if branch:
        objects = objects.filter(warehouse__branch_id=branch)
    if search:
        objects = objects.filter(Q(number__icontains=search) | Q(title__icontains=search) | Q(supplier__name__icontains=search))
    status = request.GET.get("status", "")
    if status in Contract.Status.values:
        objects = objects.filter(status=status)
    context = {**common(request), "page_title": "قراردادها", "active_page": "contracts", "objects": page(request, objects), "statuses": Contract.Status.choices, "selected_status": status}
    return render(request, "core/contracts.html", context)

@access("add_contract")
def contract_new(request):
    contract = Contract()
    form = scope_form(forms.ContractForm(request.POST or None, instance=contract),request.user)
    formset = forms.ContractLineFormSet(request.POST or None, instance=contract)
    if request.method == "POST":
        valid_form, valid_lines = form.is_valid(), formset.is_valid()
        if valid_form and valid_lines:
            try:
                with transaction.atomic():
                    contract = form.save(commit=False)
                    contract.created_by=request.user
                    contract.save()
                    formset.instance = contract
                    formset.save()
                    from .models import ContractGrant
                    ContractGrant.objects.create(contract=contract,user=request.user,can_operate=True,created_by=request.user)
                    services.positive(contract.total, money=True)
                    services.audit("ایجاد پیش‌نویس قرارداد", contract.number, request.user,branch=contract.warehouse.branch,contract=contract)
                messages.success(request, "پیش‌نویس ثبت شد. برای ایجاد تعهد و سفارش در انتظار، قرارداد را تأیید کنید.")
                return redirect("contract_detail", pk=contract.pk)
            except ValidationError as e:
                form.add_error(None, e)
            except IntegrityError:
                form.add_error(None, "شماره قرارداد یا ردیف کالا تکراری است.")
    return render(request, "core/contract_form.html", {"form": form, "formset": formset, "page_title": "قرارداد جدید", "active_page": "contracts"})

@access("view_contract")
def contract_detail(request, pk):
    contract = get_object_or_404(contracts_for(request.user).select_related("supplier", "warehouse__branch__organization", "approved_by"), pk=pk)
    return render(request, "core/contract_detail.html", {"contract": contract, "page_title": contract.number, "active_page": "contracts"})

@access("approve_contract")
@require_POST
def contract_action(request, pk, action):
    get_object_or_404(contracts_for(request.user,True), pk=pk)
    try:
        if action == "approve":
            services.approve_contract(pk, request.user)
        elif action == "cancel":
            services.cancel_contract(pk, request.user)
        else:
            services.advance_contract(pk, action, request.user)
        messages.success(request, "وضعیت قرارداد به‌روز شد و در گزارش‌ها اعمال گردید.")
    except ValidationError as e:
        messages.error(request, " / ".join(e.messages))
    return redirect("contract_detail", pk=pk)

def run_form(request, form, title, section, action, destination, help_text=""):
    scope_form(form,request.user)
    if request.method == "POST" and form.is_valid():
        try:
            action(form.cleaned_data)
            messages.success(request, "عملیات با موفقیت ثبت شد.")
            return redirect(destination)
        except ValidationError as e:
            form.add_error(None, e)
        except IntegrityError:
            form.add_error(None, "اطلاعات یا شماره سند تکراری است. فهرست اسناد را بررسی کنید.")
    return render(request, "core/form.html", {"form": form, "page_title": title, "active_page": section, "help_text": help_text})

@access("add_stockmovement")
def receipt_new(request, pk):
    contract = get_object_or_404(contracts_for(request.user,True), pk=pk)
    form = forms.ReceiptForm(request.POST or None, contract=contract)
    return run_form(request, form, f"تحویل قرارداد {contract.number}", "inventory",
        lambda d: services.receive(pk, form.quantities, d["reference"], d["operation_key"], request.user,{line.pk:d.get(f"location_{line.pk}") for line in form.lines},{line.pk:d.get(f"trace_{line.pk}") for line in form.lines}),
        reverse("contract_detail", args=[pk]), "تنها مقدار دریافت‌شده در این نوبت را وارد کنید. صفر یعنی در این رسید تحویل نشده است.")

@access("view_stockmovement")
def inventory(request):
    branch, search = selection(request)
    rows = inventory_rows(branch, search,user=request.user)
    if request.GET.get("export") == "csv":
        return csv_response("inventory.csv", ["موقعیت", "انبار", "کد کالا", "کالا", "واحد", "موجودی واقعی", "در انتظار تحویل"],
            [(r["warehouse"].branch.name, r["warehouse"].path, r["item"].sku, r["item"].name, r["item"].get_unit_display(), r["on_hand"], r["pending"]) for r in rows])
    movements = StockMovement.objects.filter(warehouse__branch_id__in=factory_ids(request.user)).filter(Q(contract_line__isnull=True)|Q(contract_line__contract__in=contracts_for(request.user))).select_related("warehouse__branch", "item", "created_by")
    if branch:
        movements = movements.filter(warehouse__branch_id=branch)
    if search:
        movements = movements.filter(Q(item__name__icontains=search) | Q(item__sku__icontains=search) | Q(warehouse__name__icontains=search) | Q(warehouse__branch__name__icontains=search))
    return render(request, "core/inventory.html", {**common(request), "page_title": "انبار و قطعات", "active_page": "inventory", "objects": page(request, rows), "movements": movements[:30], "warehouse_count": Warehouse.objects.filter(branch_id=branch).count() if branch else Warehouse.objects.filter(branch_id__in=factory_ids(request.user)).count()})

@access("add_stockcorrection")
def stock_new(request):
    from .enterprise_views import operation_new
    return operation_new(request,'correction')

@access("view_account")
def finance(request):
    branch, search = selection(request)
    accounts = Account.objects.filter(branch_id__in=factory_ids(request.user)).select_related("branch")
    entries = MoneyEntry.objects.filter(account__branch_id__in=factory_ids(request.user)).filter(Q(allocation__isnull=True)|Q(allocation__contract__in=contracts_for(request.user))).select_related("account__branch", "allocation__contract", "created_by")
    allocations = Allocation.objects.filter(contract__in=contracts_for(request.user),account__branch_id__in=factory_ids(request.user)).select_related("account__branch", "contract").filter(active=True)
    if branch:
        accounts = accounts.filter(branch_id=branch)
        entries = entries.filter(account__branch_id=branch)
        allocations = allocations.filter(account__branch_id=branch)
    if search:
        entries = entries.filter(Q(reference__icontains=search) | Q(account__name__icontains=search) | Q(allocation__contract__number__icontains=search))
    if request.GET.get("export") == "csv":
        return csv_response("finance.csv", ["زمان (میلادی)", "موقعیت", "حساب", "نوع سند", "مبلغ ریال", "شماره سند", "قرارداد"],
            [(e.created_at.isoformat(), e.account.branch.name, e.account.name, e.get_kind_display(), e.amount, e.reference, e.allocation.contract.number if e.allocation else "") for e in entries])
    return render(request, "core/finance.html", {**common(request), "page_title": "امور مالی", "active_page": "finance", "accounts": accounts, "totals": financial_totals(accounts), "objects": page(request, entries), "allocations": allocations[:30]})

@access("add_allocation")
def allocation_new(request):
    form = forms.AllocationForm(request.POST or None)
    return run_form(request, form, "تخصیص اعتبار به قرارداد", "finance",
        lambda d: services.allocate(d["contract"].pk, d["account"].pk, d["amount"], d["operation_key"], request.user), "finance",
        "تخصیص، وجه را رزرو می‌کند؛ تا زمان پرداخت، موجودی حساب کاهش پیدا نمی‌کند.")

@access('change_account')
def credit_new(request):
    form=forms.CreditForm(request.POST or None)
    return run_form(request,form,'اعتبار','finance',lambda d:services.set_credit(d['account'].pk,d['credit_limit'],request.user,d['description']),'finance',
        'اعتبار مصوب حساب را تعیین کنید. این کار دریافت وجه یا پرداخت ایجاد نمی‌کند. اعتبار نباید تعهدهای فعلی را بدون پشتوانه بگذارد.')

@access("add_moneyentry")
def deposit_new(request):
    form = forms.DepositForm(request.POST or None)
    return run_form(request, form, "ثبت دریافت وجه", "finance",
        lambda d: services.deposit(d["account"].pk, d["amount"], d["reference"], d["operation_key"], request.user, d["description"]), "finance")

@access("add_moneyentry")
def payment_new(request):
    form = forms.PaymentForm(request.POST or None)
    return run_form(request, form, "پرداخت به تولیدکننده", "finance",
        lambda d: __import__("core.operations",fromlist=["request_payment"]).request_payment(request.user,d["allocation"],d["amount"],d["reference"],d["description"],d["operation_key"]), "finance",
        "این فرم درخواست پرداخت می‌سازد؛ پرداخت پس از تأیید شخص مستقل در بخش کنترل عملیات ثبت می‌شود.")

@login_required
def directory(request):
    if not request.user.has_perm("core.view_branch"):
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    return render(request, "core/directory.html", {"page_title": "اطلاعات پایه", "active_page": "directory",
        "organizations": Organization.objects.filter(pk__in=allowed_organization_ids(request.user)).annotate(role_order=Case(When(role='producer',then=Value(1)),When(role='operator',then=Value(2)),When(role='consumer',then=Value(3)),default=Value(4),output_field=IntegerField())).order_by('role_order','name'), "branches": Branch.objects.filter(pk__in=factory_ids(request.user)).select_related("organization"),
        "warehouses": Warehouse.objects.filter(branch_id__in=factory_ids(request.user)).select_related("branch"), "items": Item.objects.all()})

@login_required
def directory_new(request, kind):
    options = {
        "organization": (forms.OrganizationForm, "add_organization", "ثبت تولیدکننده / بهره‌بردار / مصرف‌کننده"),
        "branch": (forms.BranchForm, "add_branch", "ثبت موقعیت"),
        "warehouse": (forms.WarehouseForm, "add_warehouse", "ثبت انبار"),
        "item": (forms.ItemForm, "add_item", "ثبت کالا / قطعه"),
        "account": (forms.AccountForm, "add_account", "ایجاد حساب مالی"),
    }
    if kind not in options:
        from django.http import Http404
        raise Http404
    form_class, perm, title = options[kind]
    if not request.user.has_perm(f"core.{perm}"):
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    def save(data):
        with transaction.atomic():
            if kind=='branch' and not root(request.user):
                from .access import profile
                p=profile(request.user)
                if not data.get('parent') or not p or not p.include_descendants:
                    from django.core.exceptions import PermissionDenied
                    raise PermissionDenied
            obj = form.save()
            services.audit(title, obj, request.user,branch=getattr(obj,'branch',None))
    initial={}
    if kind=='warehouse':
        parent_id=request.GET.get('parent','')
        if parent_id.isascii() and parent_id.isdigit():
            parent=get_object_or_404(Warehouse,pk=int(parent_id),branch_id__in=factory_ids(request.user))
            initial={'parent':parent,'branch':parent.branch}
    form = form_class(request.POST or None,initial=initial)
    return run_form(request, form, title, "directory", save, "finance" if kind == "account" else "directory")

@access("view_auditevent")
def audit_log(request):
    query = request.GET.get("q", "").strip()[:120]
    events = visible_audit(request.user)
    if query:
        events = events.filter(Q(action__icontains=query) | Q(target__icontains=query) | Q(detail__icontains=query))
    return render(request, "core/audit.html", {"page_title": "رویدادهای سامانه", "active_page": "audit", "objects": page(request, events), "search": query})

@access("view_importedsnapshot")
def exchange(request):
    public = sync.public_identity()
    sources = [{"source": source, "latest": source.latest, "fingerprint": sync.fingerprint(source.public_key)} for source in visible_sources(request.user)]
    totals, inventory = consolidate_sources([row["source"] for row in sources],request.user)
    query = request.GET.get("q", "").strip()[:120]
    if query:
        inventory = [row for row in inventory if query.casefold() in f'{row["source"].label} {row["branch"]} {row["warehouse"]} {row["item"]} {row["sku"]}'.casefold()]
    if request.GET.get("export") == "csv":
        return csv_response("remote-inventory.csv", ["مبدأ", "کد موقعیت", "انبار", "کد کالا", "کالا", "واحد", "موجودی واقعی", "در انتظار", "زمان گزارش میلادی"],
            [(r["source"].label, r["branch"], r["warehouse"], r["sku"], r["item"], r["unit"], r["on_hand"], r["pending"], r["generated_at"].isoformat()) for r in inventory])
    return render(request, "core/exchange.html", {"page_title": "تبادلات اطلاعات", "active_page": "exchange", "sources": sources,"branches":Branch.objects.filter(pk__in=factory_ids(request.user)), "identity": public, "fingerprint": sync.fingerprint(public["public_key"]), "remote_totals": totals, "objects": page(request, inventory), "search": query})

@access("export_branch_data")
def identity_export(request):
    response = HttpResponse(sync.canonical(sync.public_identity()), content_type="application/json")
    response["Content-Disposition"] = 'attachment; filename="amar-public-identity.json"'
    return response

@access("export_branch_data")
@require_POST
def report_export(request):
    try:
        target=request.POST.get("target_branch","")
        target=int(target) if target.isascii() and target.isdigit() else None
        if target is None and request.POST.get('full_report')!='yes':raise ValidationError('مقصد گزارش را انتخاب کنید یا صدور گزارش کامل محدوده خودتان را صریحاً تأیید کنید.')
        content = sync.export_report(request.user,target_branch=target)
    except ValidationError as e:
        messages.error(request, " / ".join(e.messages))
        return redirect("exchange")
    except OperationalError:
        messages.error(request, "صدور هم‌زمان گزارش یا قفل پایگاه داده؛ چند لحظه بعد دوباره تلاش کنید.")
        return redirect("exchange")
    response = HttpResponse(content, content_type="application/json")
    response["Content-Disposition"] = 'attachment; filename="amar-branch-report.amar"'
    return response

@access("add_trustedsource")
@require_POST
def source_new(request):
    try:
        label = request.POST.get("label", "").strip()
        if not label or len(label) > 120:
            raise ValidationError("نام مبدأ الزامی و حداکثر ۱۲۰ حرف است.")
        if not request.FILES.get("identity_file"):
            raise ValidationError("فایل هویت عمومی را انتخاب کنید.")
        target=request.POST.get('branch','')
        if not target and not root(request.user):raise ValidationError('واحد مرتبط با مبدأ را انتخاب کنید.')
        source=sync.trust_source(request.FILES['identity_file'].read(sync.MAX_FILE + 1),label,request.user)
        if target:
            source.branch=get_object_or_404(Branch,pk__in=factory_ids(request.user),pk=target)
            source.save(update_fields=['branch'])
            services.audit('تعیین محدوده مبدأ گزارش',source.label,request.user,branch=source.branch)
        messages.success(request, "هویت مبدأ ثبت شد. اثر انگشت آن را با موقعیت مبدأ تطبیق دهید.")
    except ValidationError as e:
        messages.error(request, " / ".join(e.messages))
    return redirect("exchange")

@access("add_importedsnapshot")
@require_POST
def report_import(request):
    try:
        if not request.FILES.get("report_file"):
            raise ValidationError("فایل گزارش موقعیت را انتخاب کنید.")
        snapshot = sync.import_report(request.FILES["report_file"].read(sync.MAX_FILE + 1), request.user)
        messages.success(request, "گزارش امضاشده وارد شد. اسناد محلی بدون تغییر باقی ماندند.")
        return redirect("remote_detail", pk=snapshot.source_id)
    except ValidationError as e:
        messages.error(request, " / ".join(e.messages))
    return redirect("exchange")

@access("view_importedsnapshot")
def remote_detail(request, pk):
    source = get_object_or_404(visible_sources(request.user), pk=pk)
    snapshot = source.latest
    return render(request, "core/remote_detail.html", {"page_title": source.label, "active_page": "exchange", "source": source, "snapshot": snapshot, "remote_payload":sync.visible_payload(snapshot.payload,request.user,source) if snapshot else None, "totals": snapshot_totals(sync.visible_payload(snapshot.payload,request.user,source)) if snapshot else None})
