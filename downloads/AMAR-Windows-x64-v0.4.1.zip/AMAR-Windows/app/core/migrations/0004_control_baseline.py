import hashlib,json
from django.db import migrations

def baseline(apps,schema_editor):
    Event=apps.get_model('core','AuditEvent')
    previous=''
    for event in Event.objects.order_by('pk').iterator():
        payload={name:getattr(event,name) for name in ('action','target','detail','actor_id','branch_id','contract_id')}
        payload['previous_digest']=previous
        payload['created_at']=event.created_at.isoformat()
        digest=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        Event.objects.filter(pk=event.pk).update(previous_digest=previous,digest=digest)
        previous=digest
    Item=apps.get_model('core','Item')
    for item in Item.objects.filter(barcode='').iterator():
        value=f'ITEM-{item.pk:012d}'
        if Item.objects.exclude(pk=item.pk).filter(barcode=value).exists():value=f'LEGACY-ITEM-{item.pk:012d}'
        Item.objects.filter(pk=item.pk).update(barcode=value)

class Migration(migrations.Migration):
    dependencies=[('core','0003_accessrole_backupstatus_contractgrant_custodian_and_more')]
    operations=[migrations.RunPython(baseline,migrations.RunPython.noop)]
