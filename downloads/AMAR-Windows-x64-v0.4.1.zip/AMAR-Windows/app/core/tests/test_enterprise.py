import io,json,gzip,hashlib,uuid
from pathlib import Path
from decimal import Decimal
from unittest.mock import patch
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core.exceptions import PermissionDenied,ValidationError
from django.core.management import call_command
from django.db import connection
from django.test import TestCase,Client
from core import models as m,services,operations as op,sync
from core.access import factory_ids,contracts_for
from core.reporting import inventory_rows,consolidate_sources

User=get_user_model()

class EnterpriseBase(TestCase):
    def setUp(self):
        call_command('setup_roles',stdout=io.StringIO())
        self.org=m.Organization.objects.create(name='گروه نمونه',role='consumer')
        self.supplier=m.Organization.objects.create(name='سازنده',role='producer')
        self.hq=m.Branch.objects.create(name='مرکزی',code='ROOT',city='تهران',organization=self.org,kind='central')
        self.city=m.Branch.objects.create(name='مرکز یک',code='CITY-A',city='تهران',organization=self.org,parent=self.hq,kind='city')
        self.other_city=m.Branch.objects.create(name='مرکز دو',code='CITY-B',city='تبریز',organization=self.org,parent=self.hq,kind='city')
        self.leaf=m.Branch.objects.create(name='کارخانه یک',code='SMALL-A',city='تهران',organization=self.org,parent=self.city)
        self.sibling=m.Branch.objects.create(name='کارخانه خواهر',code='SMALL-A2',city='تهران',organization=self.org,parent=self.city)
        self.foreign=m.Branch.objects.create(name='کارخانه شهر دیگر',code='SMALL-B',city='تبریز',organization=self.org,parent=self.other_city)
        self.w=m.Warehouse.objects.create(name='انبار یک',branch=self.leaf)
        self.dest=m.Warehouse.objects.create(name='انبار مقصد',branch=self.foreign)
        self.location=m.StorageLocation.objects.create(warehouse=self.w,code='A-1',aisle='۱',rack='۲',shelf='۳',bin='۴')
        self.destination_location=m.StorageLocation.objects.create(warehouse=self.dest,code='B-1')
        self.item=m.Item.objects.create(name='پیچ',sku='M12',minimum_stock=5)
        self.custodian=m.Custodian.objects.create(branch=self.leaf,code='P1',name='مسئول نگهداری',title='عنوان دلخواه')
        self.work=m.WorkOrder.objects.create(branch=self.leaf,number='WO-1',title='تعمیر',asset='دستگاه ۲۷')
        self.account=m.Account.objects.create(branch=self.leaf,name='حساب',opening_balance=100000)
        self.owner=User.objects.create_superuser(username='owner',password='Owner-password-123!')
        self.requester=self.person('requester','stock',self.leaf)
        self.approver=self.person('approver','approval',self.city,True)
        self.receiver=self.person('receiver','stock',self.foreign)
        self.finance=self.person('finance','finance',self.leaf)
        m.StockMovement.objects.create(warehouse=self.w,item=self.item,location=self.location,kind='in',quantity=100,reference='OPEN')
    def person(self,name,role,branch,children=False):
        user=User.objects.create_user(username=name,password='Strong-user-password-123!')
        m.UserProfile.objects.create(user=user,display_name='نام '+name,position_title='سمت '+name,role=m.AccessRole.objects.get(code=role),branch=branch,include_descendants=children)
        return user
    def contract(self,number,grant=False,operate=False,warehouse=None):
        contract=m.Contract.objects.create(number=number,title=number,supplier=self.supplier,warehouse=warehouse or self.w)
        line=m.ContractLine.objects.create(contract=contract,item=self.item,quantity=10,unit_price=100)
        services.approve_contract(contract.pk)
        if grant:m.ContractGrant.objects.create(contract=contract,branch=self.leaf,can_operate=operate,created_by=self.owner)
        return contract,line
    def allow_approval(self,user):
        user.factory_profile.role.permissions.add(Permission.objects.get(content_type__app_label='core',codename='approve_operations'))
    def material(self,qty=20,key=None):
        return op.request_material(self.requester,self.w,self.item,self.location,None,qty,self.custodian,self.work,'تعمیر دستگاه',key or uuid.uuid4())

class HierarchyAndAccessTests(EnterpriseBase):
    def test_descendants_and_sibling_exclusion(self):
        self.assertEqual(factory_ids(self.requester),{self.leaf.pk})
        self.assertEqual(factory_ids(self.approver),{self.city.pk,self.leaf.pk,self.sibling.pk})
        self.assertNotIn(self.foreign.pk,factory_ids(self.approver))
        extra=m.Branch.objects.create(name='زیرمجموعه چهارم',code='SMALL-A4',city='تهران',organization=self.org,parent=self.city)
        self.assertIn(extra.pk,factory_ids(self.approver))
    def test_inactive_ancestor_disables_descendants(self):
        self.city.active=False;self.city.save()
        self.assertEqual(factory_ids(self.requester),set())
        self.assertFalse(self.requester.has_perm('core.view_branch'))
    def test_missing_profile_is_fail_closed(self):
        user=User.objects.create_user(username='unassigned')
        self.assertEqual(factory_ids(user),set())
        self.client.force_login(user)
        self.assertEqual(self.client.get('/').status_code,403)
    def test_hierarchy_cycle_and_cross_organization_are_rejected(self):
        self.hq.parent=self.leaf
        with self.assertRaises(ValidationError):self.hq.full_clean()
        org=m.Organization.objects.create(name='دیگری',role='consumer')
        self.leaf.organization=org
        with self.assertRaises(ValidationError):self.leaf.full_clean()
    def test_editable_role_name_does_not_change_permissions_and_survives_startup(self):
        role=m.AccessRole.objects.get(code='stock');before=set(role.permissions.values_list('pk',flat=True))
        role.name='عنوان کاملاً دلخواه';role.save()
        call_command('setup_roles',stdout=io.StringIO())
        role.refresh_from_db()
        self.assertEqual(role.name,'عنوان کاملاً دلخواه')
        self.assertEqual(set(role.permissions.values_list('pk',flat=True)),before)
        self.assertFalse(self.requester.has_perm('core.add_moneyentry'))
    def test_explicit_contract_grants_are_required_even_in_same_factory(self):
        allowed,_=self.contract('ALLOW',True)
        hidden,_=self.contract('SECRET-CONTRACT-700')
        self.assertEqual(set(contracts_for(self.requester).values_list('pk',flat=True)),{allowed.pk})
        self.assertIn(allowed.pk,contracts_for(self.approver).values_list('pk',flat=True))
        self.assertNotIn(hidden.pk,contracts_for(self.requester).values_list('pk',flat=True))
        self.assertEqual(contracts_for(self.receiver).count(),0)
    def test_ungranted_contract_does_not_leak_through_pages_or_csv(self):
        visible,_=self.contract('VISIBLE',True)
        hidden,line=self.contract('SECRET-CONTRACT-700')
        allocation=services.allocate(hidden.pk,self.account.pk,1000,uuid.uuid4())
        services.pay(allocation.pk,100,'SECRET-CONTRACT-700',uuid.uuid4())
        services.receive(hidden.pk,{line.pk:1},'SECRET-CONTRACT-700',uuid.uuid4())
        self.client.force_login(self.finance)
        for path in ['/','/contracts/','/finance/','/finance/?export=csv','/inventory/','/inventory/?export=csv','/alerts/']:
            if path.startswith('/inventory'):continue # Finance role does not have stock permission.
            response=self.client.get(path)
            self.assertEqual(response.status_code,200,path)
            self.assertNotIn('SECRET-CONTRACT-700',response.content.decode(),path)
        self.assertEqual(self.client.get(f'/contracts/{hidden.pk}/').status_code,404)
        self.client.force_login(self.requester)
        for path in ['/inventory/','/inventory/?export=csv','/contracts/','/']:
            self.assertNotIn('SECRET-CONTRACT-700',self.client.get(path).content.decode())
    def test_forged_finance_post_and_direct_service_are_rejected(self):
        hidden,_=self.contract('HIDDEN')
        self.client.force_login(self.finance)
        response=self.client.post('/finance/allocate/',{'operation_key':uuid.uuid4(),'contract':hidden.pk,'account':self.account.pk,'amount':100})
        self.assertEqual(response.status_code,200)
        self.assertFalse(m.Allocation.objects.exists())
        with self.assertRaises(PermissionDenied):services.allocate(hidden.pk,self.account.pk,100,uuid.uuid4(),self.finance)
    def test_view_grant_does_not_allow_operations(self):
        contract,_=self.contract('VIEW',True,False)
        with self.assertRaises(PermissionDenied):services.allocate(contract.pk,self.account.pk,100,uuid.uuid4(),self.finance)
    def test_revocation_takes_effect_without_restarting(self):
        contract,_=self.contract('ONLY',True)
        grant=contract.access_grants.get()
        self.client.force_login(self.requester)
        self.assertEqual(self.client.get(f'/contracts/{contract.pk}/').status_code,200)
        admin=Client();admin.force_login(self.owner)
        self.assertEqual(admin.post(f'/contracts/access/{grant.pk}/revoke/').status_code,302)
        self.assertEqual(self.client.get(f'/contracts/{contract.pk}/').status_code,404)
    def test_scoped_staff_cannot_use_global_admin(self):
        self.requester.is_staff=True;self.requester.save()
        self.client.force_login(self.requester)
        self.assertEqual(self.client.get('/admin/').status_code,302)
    def test_template_creates_30_leaves_is_repeatable_and_preserves_renamed_units(self):
        self.client.force_login(self.owner)
        data={'organization':self.org.pk,'root_name':'نام دلخواه','centers':10,'factories_per_center':3}
        self.assertEqual(self.client.post('/structure/template/',data).status_code,302)
        central=m.Branch.objects.get(code=f'G{self.org.pk}-ROOT')
        self.assertEqual(central.children.count(),10)
        self.assertEqual(m.Branch.objects.filter(parent__parent=central).count(),30)
        first=central.children.first();first.name='نام اصلاح‌شده';first.save()
        self.client.post('/structure/template/',data)
        first.refresh_from_db();self.assertEqual(first.name,'نام اصلاح‌شده')
        self.assertEqual(m.Branch.objects.filter(parent__parent=central).count(),30)
    def test_titles_and_person_display_names_are_editable(self):
        p=self.owner.factory_profile if m.UserProfile.objects.filter(user=self.owner).exists() else m.UserProfile.objects.create(user=self.owner)
        p.display_name='نام انتخابی من';p.position_title='عنوان اختصاصی';p.save()
        self.client.force_login(self.owner)
        response=self.client.get('/')
        self.assertContains(response,'نام انتخابی من');self.assertContains(response,'عنوان اختصاصی')
        contract,line=self.contract('CUSTOM-NAMES',True,True)
        contract.approved_by=self.owner;contract.save(update_fields=['approved_by'])
        services.receive(contract.pk,{line.pk:1},'CUSTOM-RECEIPT',uuid.uuid4(),self.requester)
        response=self.client.get(f'/contracts/{contract.pk}/')
        self.assertContains(response,'<dd>نام انتخابی من</dd>',html=True)
        self.assertContains(response,'<td>نام requester</td>',html=True)
        document=self.material()
        self.assertContains(self.client.get(f'/control/material/{document.pk}/'),'نام requester')
        services.audit('ثبت با نام انتخابی','نمونه',self.requester,branch=self.leaf)
        self.assertContains(self.client.get('/audit/'),'نام requester')
    def test_new_views_and_form_choices_render(self):
        self.client.force_login(self.owner)
        routes=['/structure/','/structure/template/','/configuration/','/access/','/access/users/new/','/access/roles/new/','/control/','/alerts/','/geography/',
            '/control/new/material/','/control/new/transfer/','/control/new/correction/','/control/count/new/',f'/labels/item/{self.item.pk}/']
        routes += [f'/master/{kind}/new/' for kind in ['branch','location','custodian','workorder','trace','route','geography']]
        for route in routes:
            with self.subTest(route=route):self.assertEqual(self.client.get(route).status_code,200)

class CustodyTests(EnterpriseBase):
    def test_request_approval_issue_consume_return_and_retry(self):
        d=self.material(80)
        self.allow_approval(self.requester)
        with self.assertRaises(ValidationError):op.approve_material(self.requester,d.pk)
        op.approve_material(self.approver,d.pk)
        self.assertEqual(op.reserved(self.w,self.item,self.location),80)
        with self.assertRaises(ValidationError):op.issue_material(self.approver,d.pk)
        op.issue_material(self.requester,d.pk);op.issue_material(self.requester,d.pk)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),20)
        key=uuid.uuid4();op.settle_material(self.requester,d.pk,'consume',50,'USED',key)
        op.settle_material(self.requester,d.pk,'consume',50,'USED',key)
        op.settle_material(self.requester,d.pk,'return',30,'BACK',uuid.uuid4())
        d.refresh_from_db();self.assertEqual(d.remaining,0);self.assertEqual(d.status,'closed')
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),50)
        self.assertEqual(d.consumed,50);self.assertEqual(d.returned,30)
    def test_reservations_prevent_double_allocation(self):
        first=self.material(80);second=self.material(30)
        op.approve_material(self.approver,first.pk)
        with self.assertRaises(ValidationError):op.approve_material(self.approver,second.pk)
        self.assertEqual(op.reserved(self.w,self.item,self.location),80)
    def test_custody_cannot_be_settled_twice_or_over_remaining(self):
        d=self.material(10);op.approve_material(self.approver,d.pk);op.issue_material(self.requester,d.pk)
        with self.assertRaises(ValidationError):op.settle_material(self.requester,d.pk,'return',11,'BAD',uuid.uuid4())
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),90)
    def test_recipient_workorder_and_location_must_belong_to_factory(self):
        with self.assertRaises(ValidationError):op.request_material(self.requester,self.w,self.item,self.destination_location,None,1,self.custodian,self.work,'نیاز',uuid.uuid4())
        self.custodian.branch=self.foreign;self.custodian.save()
        with self.assertRaises(ValidationError):self.material(1)
    def test_foreign_user_cannot_access_request_id(self):
        d=self.material(1)
        self.client.force_login(self.receiver)
        self.assertEqual(self.client.get(f'/control/material/{d.pk}/').status_code,404)
        self.assertEqual(self.client.post(f'/control/material/{d.pk}/issue/').status_code,404)
    def test_physical_and_person_held_are_separate(self):
        d=self.material(20);op.approve_material(self.approver,d.pk);op.issue_material(self.requester,d.pk)
        row=inventory_rows(user=self.requester)[0]
        self.assertEqual(row['on_hand'],80);self.assertEqual(row['held'],20);self.assertEqual(row['reserved'],0)

class TransferAndCountTests(EnterpriseBase):
    def test_transfer_requires_route_then_two_site_confirmation(self):
        with self.assertRaises(PermissionDenied):op.request_transfer(self.requester,self.w,self.dest,self.item,self.location,None,10,'T1',uuid.uuid4())
        m.TransferRoute.objects.create(source=self.leaf,destination=self.foreign)
        d=op.request_transfer(self.requester,self.w,self.dest,self.item,self.location,None,10,'T1',uuid.uuid4())
        op.approve_transfer(self.approver,d.pk);op.send_transfer(self.requester,d.pk)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),90)
        self.assertEqual(op.bucket_stock(self.dest,self.item,self.destination_location),0)
        with self.assertRaises(PermissionDenied):op.receive_transfer(self.requester,d.pk,self.destination_location)
        op.receive_transfer(self.receiver,d.pk,self.destination_location)
        op.receive_transfer(self.receiver,d.pk,self.destination_location)
        self.assertEqual(op.bucket_stock(self.dest,self.item,self.destination_location),10)
        self.assertEqual(m.StockMovement.objects.filter(reference='T1').count(),2)
    def test_manual_correction_needs_independent_approval(self):
        d=op.request_correction(self.requester,self.w,self.item,self.location,None,-5,'مغایرت مستند شمارش',uuid.uuid4())
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),100)
        self.allow_approval(self.requester)
        with self.assertRaises(ValidationError):op.approve_correction(self.requester,d.pk)
        op.approve_correction(self.approver,d.pk);op.approve_correction(self.approver,d.pk)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),95)
    def test_correction_cannot_reduce_reserved_stock(self):
        d=self.material(100);op.approve_material(self.approver,d.pk)
        correction=op.request_correction(self.requester,self.w,self.item,self.location,None,-1,'مغایرت مستند شمارش',uuid.uuid4())
        with self.assertRaises(ValidationError):op.approve_correction(self.approver,correction.pk)
    def test_count_records_difference_with_new_ledger_entry(self):
        d=op.request_count(self.requester,self.w,'COUNT',[{'item':self.item,'location':self.location,'trace':None,'counted':95}],uuid.uuid4())
        self.assertEqual(d.lines.get().difference,-5)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),100)
        self.allow_approval(self.requester)
        with self.assertRaises(ValidationError):op.approve_count(self.requester,d.pk)
        op.approve_count(self.approver,d.pk)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),95)
        self.assertEqual(m.StockMovement.objects.count(),2)
    def test_stale_count_and_incomplete_count_cannot_overwrite_new_movements(self):
        with self.assertRaises(ValidationError):op.request_count(self.requester,self.w,'EMPTY',[],uuid.uuid4())
        d=op.request_count(self.requester,self.w,'COUNT',[{'item':self.item,'location':self.location,'trace':None,'counted':90}],uuid.uuid4())
        m.StockMovement.objects.create(warehouse=self.w,item=self.item,location=self.location,kind='in',quantity=1,reference='LATER')
        with self.assertRaises(ValidationError):op.approve_count(self.approver,d.pk)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.location),101)
    def test_serial_cannot_be_registered_twice_or_resurrected_after_consumption(self):
        item=m.Item.objects.create(name='قطعه سریال‌دار',sku='SER',tracking='serial')
        trace=m.TraceUnit.objects.create(item=item,code='S-001')
        d=op.request_correction(self.requester,self.w,item,self.location,trace,1,'ثبت موجودی اولیه سریال',uuid.uuid4())
        op.approve_correction(self.approver,d.pk)
        second=op.request_correction(self.requester,self.w,item,self.location,trace,1,'ورود تکراری همان سریال',uuid.uuid4())
        with self.assertRaises(ValidationError):op.approve_correction(self.approver,second.pk)
        request=op.request_material(self.requester,self.w,item,self.location,trace,1,self.custodian,self.work,'نصب روی دستگاه',uuid.uuid4())
        op.approve_material(self.approver,request.pk);op.issue_material(self.requester,request.pk)
        op.settle_material(self.requester,request.pk,'consume',1,'INSTALL',uuid.uuid4())
        with self.assertRaises(ValidationError):op.approve_correction(self.approver,second.pk)

class FinancialAndAuditTests(EnterpriseBase):
    def test_payment_request_does_not_move_cash_until_independent_approval(self):
        contract,_=self.contract('FIN',True,True)
        a=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        d=op.request_payment(self.finance,a,600,'P1','شرح',uuid.uuid4())
        self.assertEqual(self.account.balance,100000)
        self.allow_approval(self.finance)
        with self.assertRaises(ValidationError):op.approve_payment(self.finance,d.pk)
        op.approve_payment(self.approver,d.pk);op.approve_payment(self.approver,d.pk)
        self.assertEqual(self.account.balance,99400);self.assertEqual(m.MoneyEntry.objects.count(),1)
    def test_pending_payments_cannot_exceed_allocation(self):
        contract,_=self.contract('FIN',True,True)
        a=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        op.request_payment(self.finance,a,600,'P1','',uuid.uuid4())
        with self.assertRaises(ValidationError):op.request_payment(self.finance,a,401,'P2','',uuid.uuid4())
    def test_direct_adjustment_and_payment_are_not_public_bypasses(self):
        with self.assertRaises(ValidationError):services.adjust_stock(self.w.pk,self.item.pk,'out',1,'BYPASS',uuid.uuid4(),self.owner)
        with self.assertRaises(ValidationError):services.pay(999,1,'BYPASS',uuid.uuid4(),self.owner)
    def test_contract_creator_cannot_approve_own_contract(self):
        c=m.Contract.objects.create(number='OWN',title='خرید',warehouse=self.w,supplier=self.supplier,created_by=self.owner)
        m.ContractLine.objects.create(contract=c,item=self.item,quantity=1,unit_price=1)
        with self.assertRaises(ValidationError):services.approve_contract(c.pk,self.owner)
    def test_ledger_rows_are_immutable_and_audit_chain_detects_raw_tampering(self):
        move=m.StockMovement.objects.first();move.quantity=999
        with self.assertRaises(ValidationError):move.save()
        with self.assertRaises(ValidationError):m.StockMovement.objects.filter(pk=move.pk).update(quantity=999)
        with self.assertRaises(ValidationError):move.delete()
        event=services.audit('آزمون','قطعه',self.owner,branch=self.leaf)
        self.assertEqual(services.verify_audit_chain(),(True,None))
        with connection.cursor() as cursor:cursor.execute('UPDATE core_auditevent SET detail=%s WHERE id=%s',['tampered',event.pk])
        self.assertEqual(services.verify_audit_chain(),(False,event.pk))
    def test_balances_are_transactional_and_not_overwritten_by_stale_account_instance(self):
        services.deposit(self.account.pk,100,'D1',uuid.uuid4())
        self.account.credit_limit=200;self.account.save()
        self.assertEqual(self.account.balance,100100)
        self.assertEqual(m.StockBalance.objects.get(warehouse=self.w,item=self.item).quantity,100)

class GeographySourceTests(TestCase):
    def test_dataset_integrity_counts_and_complete_parent_references(self):
        import csv,collections
        root=settings.BASE_DIR/'data/iran';meta=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
        packed=(root/'places.csv.gz').read_bytes()
        self.assertEqual(hashlib.sha256(packed).hexdigest(),meta['gzip_sha256'])
        raw=gzip.decompress(packed);self.assertEqual(hashlib.sha256(raw).hexdigest(),meta['sha256'])
        rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
        self.assertEqual(len(rows),105474)
        self.assertEqual(dict(collections.Counter(r['type'] for r in rows)),meta['counts'])
        self.assertEqual(meta['counts']['province'],31)
        ids={r['id'] for r in rows};self.assertEqual(len(ids),len(rows))
        for row in rows:
            parent=next((row[k] for k in ['rural_id','district_id','county_id','province_id'] if row[k]),None)
            self.assertTrue(parent is None or parent in ids)

class ScopedOfflineReportTests(EnterpriseBase):
    def setUp(self):
        super().setUp()
        from tempfile import TemporaryDirectory
        from django.test import override_settings
        self.temporary=TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.settings_override=override_settings(DATA_DIR=Path(self.temporary.name));self.settings_override.enable();self.addCleanup(self.settings_override.disable)
        extra=Permission.objects.filter(content_type__app_label='core',codename__in=['export_branch_data','view_importedsnapshot','add_importedsnapshot','view_trustedsource'])
        self.requester.factory_profile.role.permissions.add(*extra)
    def packet(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
        import base64
        key=Ed25519PrivateKey.generate();source_id=uuid.uuid4()
        source=m.TrustedSource.objects.create(source_id=source_id,label='شعبه گزارش‌دهنده',branch=self.leaf,
            public_key=base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).decode())
        self.contract('REMOTE-ALLOWED',True)
        self.contract('REMOTE-SECRET')
        envelope=json.loads(sync.export_report(self.owner))
        p=envelope['payload'];p['source_id']=str(source_id)
        p['branches']=[r for r in p['branches'] if r['code']==self.leaf.code]
        for name in ['contracts','inventory','accounts']:p[name]=[r for r in p[name] if r['branch']==self.leaf.code]
        envelope['signature']=base64.b64encode(key.sign(sync.canonical(p))).decode()
        return source,sync.canonical(envelope)
    def test_user_export_contains_only_scope_and_capabilities(self):
        self.contract('OWN-ALLOWED',True)
        self.contract('SECRET-ROOT')
        self.contract('FOREIGN',True,warehouse=self.dest)
        payload=json.loads(sync.export_report(self.requester))['payload']
        self.assertEqual([r['code'] for r in payload['branches']],[self.leaf.code])
        self.assertEqual([r['number'] for r in payload['contracts']],['OWN-ALLOWED'])
        self.assertEqual(payload['accounts'],[])
        self.assertNotIn('SECRET-ROOT',json.dumps(payload))
    def test_export_target_cannot_expand_scope(self):
        with self.assertRaises(PermissionDenied):sync.export_report(self.requester,target_branch=self.foreign.pk)
    def test_owner_downward_export_requires_explicit_factory_contract_grant(self):
        self.contract('FACTORY-SHARED',True)
        private,_=self.contract('INDIVIDUAL-ONLY')
        m.ContractGrant.objects.create(contract=private,user=self.requester,created_by=self.owner)
        payload=json.loads(sync.export_report(self.owner,target_branch=self.leaf.pk))['payload']
        self.assertEqual([r['number'] for r in payload['contracts']],['FACTORY-SHARED'])
    def test_imported_contracts_require_separate_explicit_user_grants(self):
        source,content=self.packet();snapshot=sync.import_report(content,self.owner)
        m.RemoteContractGrant.objects.create(source=source,number='REMOTE-ALLOWED',user=self.requester)
        payload=sync.visible_payload(snapshot.payload,self.requester,source)
        self.assertEqual([r['number'] for r in payload['contracts']],['REMOTE-ALLOWED'])
        self.assertEqual(payload['accounts'],[])
        self.assertTrue(all(row['pending']=='' for row in payload['inventory']))
        self.client.force_login(self.requester)
        for path in ['/exchange/',f'/exchange/source/{source.pk}/','/exchange/?export=csv']:
            response=self.client.get(path)
            self.assertEqual(response.status_code,200)
            self.assertNotIn('REMOTE-SECRET',response.content.decode())
        other=Client();other.force_login(self.receiver)
        self.assertEqual(other.get(f'/exchange/source/{source.pk}/').status_code,404)
    def test_source_cannot_claim_another_factory(self):
        source,content=self.packet();source.branch=self.foreign;source.save()
        with self.assertRaisesMessage(ValidationError,'بیرون از محدوده'):sync.import_report(content,self.owner)
    def test_export_web_form_does_not_default_to_whole_company(self):
        self.client.force_login(self.owner)
        self.assertEqual(self.client.post('/exchange/export/').status_code,302)
        response=self.client.post('/exchange/export/',{'target_branch':self.leaf.pk})
        self.assertEqual(response.status_code,200)
        self.assertIn('attachment',response.headers['Content-Disposition'])
        self.assertEqual(len(json.loads(response.content)['payload']['branches']),1)
    def test_capability_and_role_changes_take_effect_immediately(self):
        self.assertTrue(self.requester.has_perm('core.export_branch_data'))
        self.requester.factory_profile.role.permissions.remove(Permission.objects.get(content_type__app_label='core',codename='export_branch_data'))
        self.assertFalse(self.requester.has_perm('core.export_branch_data'))
        with self.assertRaises(PermissionDenied):sync.export_report(self.requester)

class ManagementBoundaryTests(EnterpriseBase):
    def test_scoped_user_cannot_create_accounts_or_change_hierarchy_through_owner_pages(self):
        self.client.force_login(self.requester)
        for path in ['/access/','/configuration/','/configuration/backup/','/access/users/new/','/access/roles/new/','/structure/template/','/master/branch/new/']:
            self.assertEqual(self.client.get(path).status_code,403)
    def test_posting_superuser_fields_does_not_elevate_new_account(self):
        self.client.force_login(self.owner)
        response=self.client.post('/access/users/new/',{'username':'new-person','display_name':'عنوان انتخابی','position_title':'هر نامی','branch':self.leaf.pk,
            'role':m.AccessRole.objects.get(code='stock').pk,'enabled':'on','password':'A-new-strong-password-123!','is_superuser':'on','is_staff':'on'})
        self.assertEqual(response.status_code,302)
        created=User.objects.get(username='new-person')
        self.assertFalse(created.is_superuser);self.assertFalse(created.is_staff)
        self.assertEqual(factory_ids(created),{self.leaf.pk})
    def test_count_csv_checks_warehouse_and_decimal_values(self):
        from django.core.files.uploadedfile import SimpleUploadedFile
        from core.enterprise_views import parse_count_csv
        content=f'sku,location,trace,counted\nM12,A-1,,90\n'.encode()
        rows=parse_count_csv(SimpleUploadedFile('count.csv',content),self.w)
        self.assertEqual(rows[0]['counted'],90)
        with self.assertRaises(ValidationError):parse_count_csv(SimpleUploadedFile('bad.csv',b'sku,location,trace,counted\nM12,B-1,,10\n'),self.w)
    def test_barcode_and_location_inventory_match_scanner_query(self):
        self.client.force_login(self.requester)
        response=self.client.get('/inventory/locations/',{'q':self.item.barcode})
        self.assertEqual(response.status_code,200);self.assertContains(response,self.item.sku)
        self.assertNotContains(response,'انبار مقصد')
        self.assertEqual(self.client.get(f'/labels/item/{self.item.pk}/').status_code,200)
    def test_count_keeps_expected_values_hidden_from_counter_role(self):
        count=op.request_count(self.requester,self.w,'COUNT',[{'item':self.item,'location':self.location,'trace':None,'counted':99}],uuid.uuid4())
        self.client.force_login(self.requester)
        response=self.client.get(f'/control/count/{count.pk}/')
        self.assertNotContains(response,'موجودی ثبت‌شده هنگام شمارش')
        self.client.force_login(self.approver)
        self.assertContains(self.client.get(f'/control/count/{count.pk}/'),'موجودی ثبت‌شده هنگام شمارش')
