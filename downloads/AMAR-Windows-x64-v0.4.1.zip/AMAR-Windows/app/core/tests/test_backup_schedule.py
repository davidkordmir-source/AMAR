from datetime import timedelta
import io,tempfile
from pathlib import Path
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.test import TransactionTestCase,override_settings
from django.utils import timezone
from core.backup_schedule import backup_if_due
from core.models import BackupStatus

class ScheduledBackupTests(TransactionTestCase):
    def setUp(self):
        get_user_model().objects.create_user(username='local')
    def test_due_backup_is_verified_and_not_repeated_within_interval(self):
        with tempfile.TemporaryDirectory() as directory,override_settings(DATA_DIR=Path(directory)):
            self.assertTrue(backup_if_due())
            status=BackupStatus.objects.get(pk=1)
            self.assertTrue(status.last_success);self.assertEqual(len(status.last_digest),64)
            self.assertTrue((Path(directory)/'backups'/status.last_file).exists())
            self.assertFalse(backup_if_due())
            self.assertEqual(len(list((Path(directory)/'backups').glob('*.zip'))),1)
    def test_failed_backup_is_recorded_without_false_success(self):
        with patch('core.backup_schedule.call_command',side_effect=OSError('disk unavailable')):
            with self.assertLogs(level='ERROR'):self.assertFalse(backup_if_due())
        status=BackupStatus.objects.get(pk=1)
        self.assertIsNone(status.last_success);self.assertEqual(status.last_error,'OSError')
