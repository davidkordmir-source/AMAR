import io, uuid
from decimal import Decimal
from django.contrib.auth.models import Permission
from django.core.exceptions import PermissionDenied, ValidationError
from django.test import Client
from core import forms, models as m, services
from core.master_data import MASTER_FORMS, delete_reference, deletion_blockers
from core.reporting import inventory_rows
from .test_enterprise import EnterpriseBase


class ReferenceRevisionTests(EnterpriseBase):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.owner)

    def paid_contract(self):
        contract,line=self.contract('PAID-REFERENCE',True,True)
        allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        services.pay(allocation.pk,100,'PAID-REFERENCE',uuid.uuid4())
        return contract,line

    def warehouse_data(self,warehouse,**changes):
        data={'name':warehouse.name,'branch':warehouse.branch_id,'parent':warehouse.parent_id or ''}
        data.update(changes)
        return data

    def test_requested_labels_and_finance_order(self):
        response=self.client.get('/directory/')
        self.assertContains(response,'<h1>اطلاعات پایه</h1>',html=True)
        self.assertContains(response,'تبادلات اطلاعات')
        self.assertNotContains(response,'اطلاعات پایه و شعب')
        form=self.client.get('/directory/new/branch/').context['form']
        self.assertEqual(form.fields['name'].label,'نام موقعیت')
        from core.enterprise_forms import RoleForm
        permission=Permission.objects.get(content_type__app_label='core',codename='export_branch_data')
        permission.name='صدور فایل گزارش شعبه'
        self.assertNotIn('شعبه',RoleForm().fields['permissions'].label_from_instance(permission))
        html=self.client.get('/finance/').content.decode()
        self.assertLess(html.index('/finance/credit/'),html.index('/finance/allocate/'))
        self.assertLess(html.index('/finance/allocate/'),html.index('/finance/pay/'))
        self.assertLess(html.index('id="credit"'),html.index('id="allocations"'))
        self.assertLess(html.index('id="allocations"'),html.index('id="payments"'))

    def test_three_organization_roles_in_order_and_legacy_value_preserved(self):
        operator=m.Organization.objects.create(name='آ بهره بردار',role='operator')
        self.assertEqual([value for value,label in forms.OrganizationForm().fields['role'].choices if value],['producer','operator','consumer'])
        response=self.client.get('/directory/')
        roles=list(response.context['organizations'].values_list('role',flat=True))
        self.assertEqual(roles,['producer','operator','consumer'])
        legacy=m.Organization.objects.create(name='ترکیبی قدیمی',role='both')
        self.assertIn('both',[value for value,label in forms.OrganizationForm(instance=legacy).fields['role'].choices])
        self.assertNotIn(operator,forms.ContractForm().fields['supplier'].queryset)

    def test_operator_can_own_destination_but_cannot_sell_as_producer(self):
        self.org.role='operator';self.org.save()
        contract,line=self.contract('OPERATOR-DESTINATION')
        contract.refresh_from_db();self.assertEqual(contract.status,'approved')
        draft=m.Contract.objects.create(number='BAD-OPERATOR',title='خرید',supplier=self.org,warehouse=self.w)
        m.ContractLine.objects.create(contract=draft,item=self.item,quantity=1,unit_price=100)
        with self.assertRaises(ValidationError):services.approve_contract(draft.pk)

    def test_warehouse_hierarchy_shows_city_location_and_all_parents(self):
        province=m.GeoPlace.objects.create(code='PROV-X',name='استان آزمون',level='province')
        county=m.GeoPlace.objects.create(code='COUNT-X',name='شهرستان آزمون',level='county',parent=province)
        self.leaf.locality=county;self.leaf.city='تهران';self.leaf.save()
        child=m.Warehouse.objects.create(branch=self.leaf,parent=self.w,name='انبار قطعات')
        grandchild=m.Warehouse.objects.create(branch=self.leaf,parent=child,name='قطعات ریز')
        second=m.Warehouse.objects.create(branch=self.leaf,parent=self.w,name='انبار ابزار')
        self.assertEqual(self.w.children.count(),2)
        self.assertEqual(str(grandchild),'استان آزمون / شهرستان آزمون / تهران / کارخانه یک / انبار یک / انبار قطعات / قطعات ریز')
        self.assertContains(self.client.get('/directory/'),str(grandchild))
        # Without selected geography the actual free-text city remains visible.
        self.assertIn('تبریز',str(self.dest))

    def test_warehouse_self_cycle_descendant_cycle_and_cross_location_rejected(self):
        child=m.Warehouse.objects.create(branch=self.leaf,parent=self.w,name='زیرانبار')
        for parent in [self.w,child]:
            form=forms.WarehouseForm(self.warehouse_data(self.w,parent=parent.pk),instance=m.Warehouse.objects.get(pk=self.w.pk))
            self.assertFalse(form.is_valid())
        form=forms.WarehouseForm({'branch':self.foreign.pk,'parent':self.w.pk,'name':'خارج از موقعیت'})
        self.assertFalse(form.is_valid())
        response=self.client.post(f'/master/warehouse/{self.w.pk}/',self.warehouse_data(self.w,parent=child.pk))
        self.assertEqual(response.status_code,200)
        self.w.refresh_from_db();self.assertIsNone(self.w.parent_id)

    def test_subwarehouse_form_prefill_and_city_search_csv(self):
        response=self.client.get(f'/directory/new/warehouse/?parent={self.w.pk}')
        self.assertEqual(response.context['form'].initial['parent'],self.w)
        self.assertEqual(response.context['form'].initial['branch'],self.leaf)
        self.assertIn('تهران',str(response.context['form'].fields['parent'].queryset.get(pk=self.w.pk)))
        self.assertTrue(inventory_rows(search='تهران',user=self.owner))
        self.assertIn('تهران',self.client.get('/inventory/?export=csv').content.decode())

    def test_unused_reference_data_all_categories_can_be_deleted_with_audit(self):
        unused={
            'organization':m.Organization.objects.create(name='حذف مجموعه بدون سند',role='producer'),
            'branch':m.Branch.objects.create(name='موقعیت بدون سند',code='UNUSED-BR',organization=self.org,city='یزد'),
            'warehouse':m.Warehouse.objects.create(name='انبار بدون سند',branch=self.leaf),
            'item':m.Item.objects.create(name='کالای بدون سند',sku='UNUSED-ITEM'),
            'account':m.Account.objects.create(name='حساب بدون سند',branch=self.leaf),
            'location':m.StorageLocation.objects.create(warehouse=self.w,code='UNUSED-L'),
            'trace':m.TraceUnit.objects.create(item=self.item,code='UNUSED-T'),
            'custodian':m.Custodian.objects.create(branch=self.leaf,code='UNUSED-C',name='شخص بدون سند'),
            'workorder':m.WorkOrder.objects.create(branch=self.leaf,number='UNUSED-WO',title='کار بدون سند'),
            'route':m.TransferRoute.objects.create(source=self.leaf,destination=self.foreign),
            'geography':m.GeoPlace.objects.create(code='UNUSED-GEO',name='مکان بدون وابستگی',level='province'),
        }
        self.assertEqual(set(unused),set(MASTER_FORMS))
        for kind,obj in unused.items():
            with self.subTest(kind=kind):
                pk=obj.pk
                response=self.client.post(f'/master/{kind}/{pk}/delete/')
                self.assertEqual(response.status_code,302)
                self.assertFalse(type(obj).objects.filter(pk=pk).exists())
        self.assertEqual(services.verify_audit_chain(),(True,None))
        self.assertEqual(m.AuditEvent.objects.filter(action='حذف اطلاعات پایه بدون پرداخت').count(),len(unused))

    def test_paid_reference_objects_are_rejected_by_ui_and_service(self):
        self.paid_contract()
        for kind,obj in [('organization',self.supplier),('organization',self.org),('branch',self.city),('warehouse',self.w),('item',self.item),('account',self.account)]:
            with self.subTest(kind=kind,pk=obj.pk):
                self.assertIn('پرداخت مالی',deletion_blockers(obj)[0])
                response=self.client.post(f'/master/{kind}/{obj.pk}/delete/')
                self.assertContains(response,'حذف مجاز نیست')
                with self.assertRaises(ValidationError):delete_reference(self.owner,kind,obj.pk)
                self.assertTrue(type(obj).objects.filter(pk=obj.pk).exists())
        self.assertEqual(m.MoneyEntry.objects.count(),1)
        self.assertEqual(services.verify_audit_chain(),(True,None))

    def test_unpaid_referenced_records_are_not_cascade_deleted(self):
        self.contract('UNPAID-REFERENCE')
        before=m.StockMovement.objects.count()
        self.assertTrue(deletion_blockers(self.w))
        response=self.client.post(f'/master/warehouse/{self.w.pk}/delete/')
        self.assertContains(response,'وابستگی')
        self.assertEqual(m.Contract.objects.count(),1)
        self.assertEqual(m.StockMovement.objects.count(),before)

    def test_delete_is_confirmation_get_then_csrf_post_and_rechecks_payment(self):
        item=m.Item.objects.create(name='قلم موقت',sku='DELETE-GET')
        url=f'/master/item/{item.pk}/delete/'
        self.assertContains(self.client.get(url),'حذف رکورد')
        self.assertTrue(m.Item.objects.filter(pk=item.pk).exists())
        client=Client(enforce_csrf_checks=True);client.force_login(self.owner)
        self.assertEqual(client.post(url).status_code,403)
        contract=m.Contract.objects.create(number='PAY-AFTER-GET',title='خرید',supplier=self.supplier,warehouse=self.w)
        m.ContractLine.objects.create(contract=contract,item=item,quantity=1,unit_price=100)
        services.approve_contract(contract.pk)
        a=services.allocate(contract.pk,self.account.pk,100,uuid.uuid4());services.pay(a.pk,100,'AFTER-GET',uuid.uuid4())
        self.assertContains(self.client.post(url),'پرداخت مالی')
        self.assertTrue(m.Item.objects.filter(pk=item.pk).exists())

    def test_scoped_accounts_cannot_bypass_owner_edit_delete_or_management(self):
        self.client.force_login(self.requester)
        for path in ['/directory/manage/item/',f'/master/item/{self.item.pk}/delete/',f'/master/warehouse/{self.w.pk}/']:
            self.assertEqual(self.client.post(path,{}).status_code,403)
        with self.assertRaises(PermissionDenied):delete_reference(self.requester,'item',self.item.pk)

    def test_paid_names_editable_but_warehouse_history_cannot_move_location(self):
        self.paid_contract()
        response=self.client.post(f'/master/warehouse/{self.w.pk}/',self.warehouse_data(self.w,name='نام اصلاح‌شده انبار'))
        self.assertEqual(response.status_code,302)
        self.w.refresh_from_db();self.assertEqual(self.w.name,'نام اصلاح‌شده انبار')
        response=self.client.post(f'/master/warehouse/{self.w.pk}/',self.warehouse_data(self.w,branch=self.foreign.pk))
        self.assertContains(response,'سابقه یا وابستگی')
        self.w.refresh_from_db();self.assertEqual(self.w.branch_id,self.leaf.pk)
        self.assertEqual(m.MoneyEntry.objects.count(),1)

    def test_warehouse_parent_location_cannot_move_even_without_money(self):
        child=m.Warehouse.objects.create(name='زیرانبار وابسته',branch=self.leaf,parent=self.w)
        form=forms.WarehouseForm(self.warehouse_data(self.w,branch=self.foreign.pk),instance=self.w)
        self.assertFalse(form.is_valid())
        self.assertTrue(m.Warehouse.objects.filter(pk=child.pk,branch=self.leaf).exists())

    def test_paid_account_initial_amount_and_location_are_protected(self):
        self.paid_contract()
        base={'name':'حساب با نام دلخواه','branch':self.leaf.pk,'opening_balance':100000,'credit_limit':0}
        self.assertEqual(self.client.post(f'/master/account/{self.account.pk}/',base).status_code,302)
        for change in [{'opening_balance':999999},{'branch':self.foreign.pk}]:
            response=self.client.post(f'/master/account/{self.account.pk}/',{**base,**change})
            self.assertEqual(response.status_code,200)
        self.account.refresh_from_db();self.assertEqual(self.account.opening_balance,100000)
        self.assertEqual(self.account.branch_id,self.leaf.pk);self.assertEqual(self.account.balance,99900)

    def test_credit_changes_do_not_create_cash_and_retries_are_idempotent(self):
        before=self.account.balance
        data={'account':self.account.pk,'credit_limit':5000,'description':'تصویب اعتبار جدید'}
        for _ in range(2):self.assertEqual(self.client.post('/finance/credit/',data).status_code,302)
        self.account.refresh_from_db();self.assertEqual(self.account.credit_limit,5000)
        self.assertEqual(self.account.balance,before);self.assertFalse(m.MoneyEntry.objects.exists())
        self.assertEqual(m.AuditEvent.objects.filter(action='تغییر اعتبار مصوب').count(),1)
        for value in [-1,'0.5','1000000000000000000']:
            self.assertEqual(self.client.post('/finance/credit/',{**data,'credit_limit':value}).status_code,200)
        self.assertEqual(services.verify_audit_chain(),(True,None))

    def test_credit_limits_respect_existing_commitments_and_information_scope(self):
        contract,_=self.contract('CREDIT-COMMITMENT')
        services.set_credit(self.account.pk,1000,self.owner)
        services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4())
        # A separate account with negative cash must retain enough approved credit.
        m.Account.objects.filter(pk=self.account.pk).update(current_balance=-500)
        with self.assertRaises(ValidationError):services.set_credit(self.account.pk,100,self.owner)
        self.finance.factory_profile.role.permissions.add(Permission.objects.get(content_type__app_label='core',codename='change_account'))
        other=m.Account.objects.create(branch=self.foreign,name='خارج از محدوده')
        self.client.force_login(self.finance)
        response=self.client.post('/finance/credit/',{'account':other.pk,'credit_limit':1000})
        self.assertEqual(response.status_code,200);other.refresh_from_db();self.assertEqual(other.credit_limit,0)
        with self.assertRaises(PermissionDenied):services.set_credit(other.pk,1000,self.finance)
        self.client.force_login(self.requester);self.assertEqual(self.client.get('/finance/credit/').status_code,403)

    def test_brand_name_changes_in_title_navigation_login_and_native_brand_state(self):
        from desktop.backend import set_brand_name,DesktopBackend
        self.addCleanup(set_brand_name,'آمار')
        cfg=m.SystemConfiguration.objects.create(pk=1)
        data={field.name:getattr(cfg,field.name) for field in cfg._meta.fields if field.name!='id'}
        data['brand_name']='صنعت نگارِ انتخابی'
        self.assertEqual(self.client.post('/configuration/',data).status_code,302)
        self.assertContains(self.client.get('/directory/'),'صنعت نگارِ انتخابی')
        self.assertEqual(DesktopBackend('.').brand_name,'صنعت نگارِ انتخابی')
        self.client.logout();self.assertContains(self.client.get('/login/'),'صنعت نگارِ انتخابی')

    def test_all_reference_edit_lists_and_forms_render_with_delete_link(self):
        for kind in MASTER_FORMS:
            with self.subTest(kind=kind):
                self.assertEqual(self.client.get(f'/directory/manage/{kind}/').status_code,200)
                self.assertEqual(self.client.get(f'/master/{kind}/new/').status_code,200)
        self.assertContains(self.client.get(f'/master/warehouse/{self.w.pk}/'),'بررسی حذف')
