import json
import tempfile
import threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest import TestCase
from unittest.mock import patch

from amar.version import VERSION
from desktop.windows_app import existing_url,ActiveVersionMismatch


class RunningDesktopVersionTests(TestCase):
    """Exercise the exact legacy health protocol over a real loopback socket."""
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.data=Path(self.temp.name)
        self.identity='version-test-server-identity'
        self.health={'application':'AMAR','server_id':self.identity,'version':VERSION}
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path!='/_desktop/health':self.send_error(404);return
                self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers()
                self.wfile.write(json.dumps(owner.health).encode())
            def log_message(self,*args):pass
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':0.01},daemon=True)
        self.thread.start();self.addCleanup(self.close_server)
        self.url=f'http://127.0.0.1:{self.server.server_port}/'
        self.state={'url':self.url,'server_id':self.identity,'version':VERSION}
        self.save_state()

    def close_server(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=2)

    def save_state(self):
        (self.data/'desktop-state.json').write_text(json.dumps(self.state),encoding='utf-8')

    def test_matching_running_release_is_reused(self):
        self.assertEqual(existing_url(self.data),self.url)

    def test_legacy_running_release_without_version_is_rejected(self):
        self.health.pop('version')
        with self.assertRaises(ActiveVersionMismatch) as result:existing_url(self.data)
        self.assertIn('بستن برنامه',str(result.exception))

    def test_another_release_cannot_silently_reopen_the_old_interface(self):
        self.health['version']='0.4.0'
        with self.assertRaises(ActiveVersionMismatch) as result:existing_url(self.data)
        self.assertEqual(result.exception.running_version,'0.4.0')

    def test_live_version_takes_precedence_over_stale_state_file(self):
        self.state['version']='0.1.0';self.save_state()
        self.assertEqual(existing_url(self.data),self.url)
        self.health.pop('version')
        with self.assertRaises(ActiveVersionMismatch):existing_url(self.data)

    def test_other_local_application_and_wrong_identity_are_not_reused(self):
        self.health={'application':'another-app','server_id':self.identity,'version':'0.1.0'}
        self.assertIsNone(existing_url(self.data))
        self.health={'application':'AMAR','server_id':'another-server','version':'0.1.0'}
        self.assertIsNone(existing_url(self.data))

    def test_external_addresses_and_credentials_are_never_opened(self):
        for url in ['https://127.0.0.1:1234/','http://example.invalid:1234/','http://name:password@127.0.0.1:1234/','http://:password@127.0.0.1:1234/']:
            with self.subTest(url=url),patch('desktop.windows_app.local_opener') as opener:
                self.state['url']=url;self.save_state()
                self.assertIsNone(existing_url(self.data));opener.assert_not_called()

    def test_corrupt_state_and_malformed_health_do_not_reuse_a_server(self):
        self.health=[];self.assertIsNone(existing_url(self.data))
        for value in [[],{}, {'url':self.url,'server_id':None}]:
            self.state=value;self.save_state();self.assertIsNone(existing_url(self.data))
        (self.data/'desktop-state.json').write_text('incomplete',encoding='utf-8')
        self.assertIsNone(existing_url(self.data))
