from concurrent.futures import ThreadPoolExecutor
import io,uuid
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.management import call_command
from django.db import close_old_connections
from django.test import TransactionTestCase
from core import models as m,operations as op

class ConcurrentReservationTests(TransactionTestCase):
    def setUp(self):
        User=get_user_model()
        self.requester=User.objects.create_superuser(username='requester')
        self.approvers=[User.objects.create_superuser(username=f'approve-{n}') for n in range(2)]
        org=m.Organization.objects.create(name='مجموعه',role='consumer')
        self.branch=m.Branch.objects.create(name='واحد',code='A',city='شهر',organization=org)
        self.w=m.Warehouse.objects.create(name='انبار',branch=self.branch)
        self.loc=m.StorageLocation.objects.create(warehouse=self.w,code='A1')
        self.item=m.Item.objects.create(name='پیچ',sku='P')
        self.person=m.Custodian.objects.create(branch=self.branch,code='PERSON',name='شخص')
        self.work=m.WorkOrder.objects.create(branch=self.branch,number='W',title='کار',asset='دستگاه')
        m.StockMovement.objects.create(warehouse=self.w,item=self.item,location=self.loc,quantity=100,kind='in',reference='OPEN')
    def test_concurrent_approvals_cannot_reserve_same_stock_twice(self):
        docs=[op.request_material(self.requester,self.w,self.item,self.loc,None,80,self.person,self.work,'کار تولید',uuid.uuid4()) for _ in range(2)]
        def approve(n):
            close_old_connections()
            try:
                actor=get_user_model().objects.get(pk=self.approvers[n].pk)
                op.approve_material(actor,docs[n].pk)
                return 'approved'
            except ValidationError:return 'rejected'
            finally:close_old_connections()
        with ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(approve,range(2)))
        self.assertCountEqual(result,['approved','rejected'])
        self.assertEqual(op.reserved(self.w,self.item,self.loc),80)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.loc),100)
    def test_cancel_releases_reservation_without_changing_physical_stock(self):
        doc=op.request_material(self.requester,self.w,self.item,self.loc,None,80,self.person,self.work,'کار تولید',uuid.uuid4())
        op.approve_material(self.approvers[0],doc.pk)
        op.cancel_reservation(self.approvers[1],'material',doc.pk)
        self.assertEqual(op.reserved(self.w,self.item,self.loc),0)
        self.assertEqual(op.bucket_stock(self.w,self.item,self.loc),100)
