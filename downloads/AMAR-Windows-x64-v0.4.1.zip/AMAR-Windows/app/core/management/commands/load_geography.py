import csv,gzip,hashlib,io,json
from pathlib import Path
from django.conf import settings
from django.core.management.base import BaseCommand,CommandError
from django.db import transaction
from core.models import GeoPlace,GeographyLoad

class Command(BaseCommand):
    help='Load the pinned offline Iranian administrative directory; preserve local names and additions.'
    @transaction.atomic
    def handle(self,*args,**options):
        base=settings.BASE_DIR/'data/iran'
        meta=json.loads((base/'manifest.json').read_text(encoding='utf-8'))
        packed=(base/'places.csv.gz').read_bytes()
        if hashlib.sha256(packed).hexdigest()!=meta['gzip_sha256']:raise CommandError('Checksum mismatch in bundled geography dataset')
        marker=GeographyLoad.objects.filter(pk=1,digest=meta['sha256']).first()
        if marker:
            self.stdout.write('فهرست جغرافیایی قبلاً وارد شده؛ نام‌ها و داده‌های محلی حفظ شدند.')
            return
        raw=gzip.decompress(packed)
        if hashlib.sha256(raw).hexdigest()!=meta['sha256']:raise CommandError('Checksum mismatch in geography source CSV')
        rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
        from collections import Counter
        if dict(Counter(r['type'] for r in rows))!=meta['counts']:raise CommandError('Unexpected geography record counts')
        mapping=dict(GeoPlace.objects.values_list('code','pk'))
        for level in ['province','county','district','rural','city','village']:
            prepared=[]
            for row in rows:
                if row['type']!=level or row['id'] in mapping:continue
                parent=next((row[k] for k in ['rural_id','district_id','county_id','province_id'] if row[k]),None)
                if parent and parent not in mapping:raise CommandError('Unknown geography parent')
                prepared.append(GeoPlace(code=row['id'],name=row['name'].replace('ي','ی').replace('ك','ک'),level=level,parent_id=mapping.get(parent),source='iran-1404-v3.1.2'))
            GeoPlace.objects.bulk_create(prepared,batch_size=150)
            mapping.update(GeoPlace.objects.filter(level=level).values_list('code','pk'))
        GeographyLoad.objects.update_or_create(pk=1,defaults={'digest':meta['sha256'],'counts':meta['counts']})
        self.stdout.write(self.style.SUCCESS(f"فهرست جغرافیایی آفلاین آماده شد: {meta['total']} رکورد بر اساس منبع ۱۴۰۴."))
