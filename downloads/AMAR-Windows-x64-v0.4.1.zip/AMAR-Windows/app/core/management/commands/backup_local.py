import hashlib
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import connection
from django.utils import timezone
from core.sync import identity
from core.models import BackupStatus

class Command(BaseCommand):
    help = "Create a consistent SQLite backup including this installation's signing/session keys."
    def add_arguments(self, parser):
        parser.add_argument("--output")
    def handle(self, *args, **options):
        if connection.vendor != "sqlite":
            raise CommandError("برای PostgreSQL از pg_dump همراه با پشتیبان امن کلیدهای DATA_DIR استفاده کنید.")
        identity()
        stamp = timezone.now().strftime("%Y%m%d-%H%M%S-%f")
        output = Path(options["output"]) if options["output"] else settings.DATA_DIR / "backups" / f"amar-{stamp}.zip"
        output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory() as tmp:
            snapshot = Path(tmp) / "amar.sqlite3"
            with closing(sqlite3.connect(str(connection.settings_dict["NAME"]))) as source:
                with closing(sqlite3.connect(str(snapshot))) as target:
                    source.backup(target)
                    if target.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                        raise CommandError("بررسی صحت پایگاه ناموفق بود.")
            files = {"amar.sqlite3": snapshot, "transfer-identity.json": settings.DATA_DIR / "transfer-identity.json"}
            key_path = settings.DATA_DIR / "secret.key"
            if key_path.exists():
                files["secret.key"] = key_path
            checksums = {}
            for name, path in files.items():
                with path.open("rb") as f:
                    checksums[name] = hashlib.file_digest(f, "sha256").hexdigest()
            manifest = {"version": 1, "created_at": timezone.now().isoformat(), "files": checksums}
            try:
                fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError:
                raise CommandError("فایل مقصد از قبل وجود دارد؛ بازنویسی نشد.")
            try:
                with os.fdopen(fd, "wb") as raw:
                    with ZipFile(raw, "w", ZIP_DEFLATED) as archive:
                        for name, path in files.items():
                            archive.write(path, name)
                        archive.writestr("manifest.json", json.dumps(manifest))
            except Exception:
                output.unlink(missing_ok=True)
                raise
        self.stdout.write(self.style.SUCCESS(f"پشتیبان ساخته شد: {output}\nاین فایل حاوی کلید خصوصی است؛ در محل امن نگهداری شود."))
        with ZipFile(output) as check:
            if check.testzip() is not None:raise CommandError('بررسی CRC پشتیبان ناموفق بود.')
            for name,checksum in checksums.items():
                with check.open(name) as stream:
                    if hashlib.file_digest(stream,'sha256').hexdigest()!=checksum:raise CommandError('Checksum verification failed after backup creation')
        with output.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
        if BackupStatus._meta.db_table in connection.introspection.table_names():
            BackupStatus.objects.update_or_create(pk=1,defaults={'last_success':timezone.now(),'last_file':output.name,'last_digest':digest,'last_error':''})
