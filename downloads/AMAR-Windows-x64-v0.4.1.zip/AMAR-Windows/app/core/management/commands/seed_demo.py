from datetime import timedelta
import uuid
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from core.models import Account, AuditEvent, Branch, Contract, ContractLine, Item, Organization, StockMovement, Warehouse
from core import services

class Command(BaseCommand):
    help = "Add explicitly fictitious demo data to an empty database; no users or passwords."
    @transaction.atomic
    def handle(self, *args, **options):
        if AuditEvent.objects.filter(action="داده نمونه ایجاد شد").exists():
            self.stdout.write("داده نمونه قبلاً ایجاد شده؛ تغییری انجام نشد.")
            return
        if Organization.objects.exists() or Item.objects.exists():
            raise CommandError("داده نمونه فقط روی پایگاه خالی ایجاد می‌شود؛ اطلاعات موجود دست‌نخورده ماند.")
        consumer = Organization.objects.create(name="گروه صنعتی شما (نمونه)", role="consumer")
        producer = Organization.objects.create(name="ماشین‌سازی آریا (نمونه)", role="producer")
        parts_supplier = Organization.objects.create(name="صنایع دقیق سپهر (نمونه)", role="producer")
        branches = []
        for name, city, code in [("کارخانه مرکزی", "تهران", "THR-01"), ("کارخانه اصفهان", "اصفهان", "IFN-02"), ("کارخانه تبریز", "تبریز", "TBZ-03")]:
            b = Branch.objects.create(name=name, city=city, code=code, organization=consumer)
            w = Warehouse.objects.create(name="انبار اصلی", branch=b)
            a = Account.objects.create(name="حساب عملیاتی", branch=b, opening_balance=1800000000, credit_limit=500000000)
            branches.append((b, w, a))
        items = []
        for name, sku, specification, minimum in [
            ("دستگاه تراش CNC", "M-CNC-01", "سه محور، کنترل عددی", 1),
            ("الکتروموتور ۱۵ کیلووات", "P-MTR-15", "سه‌فاز، ۱۵۰۰ دور", 3),
            ("بلبرینگ صنعتی 6205", "P-BRG-205", "قطر داخلی ۲۵ میلی‌متر", 20),
            ("پیچ شش‌گوش M12", "P-BLT-M12", "گرید 8.8، طول ۴۰ میلی‌متر", 100),
            ("پمپ هیدرولیک", "P-PMP-01", "دبی ۲۵ لیتر در دقیقه", 2),
        ]:
            items.append(Item.objects.create(name=name, sku=sku, specification=specification, minimum_stock=minimum))
        for idx, (b, w, a) in enumerate(branches):
            services.adjust_stock(w.pk, items[2].pk, "in", [14, 80, 42][idx], f"OPEN-BRG-{idx}", uuid.uuid4())
            services.adjust_stock(w.pk, items[3].pk, "in", [450, 75, 320][idx], f"OPEN-BLT-{idx}", uuid.uuid4())
            services.adjust_stock(w.pk, items[1].pk, "in", [2, 8, 5][idx], f"OPEN-MTR-{idx}", uuid.uuid4())
        configs = [
            ("CTR-1405-001", "تأمین دستگاه تراش خط تولید", producer, 0, items[0], 5, 120000000, "partial"),
            ("CTR-1405-002", "ساخت پمپ‌های هیدرولیک", producer, 1, items[4], 8, 18000000, "building"),
            ("CTR-1405-003", "تأمین الکتروموتورهای کارخانه", parts_supplier, 2, items[1], 10, 24000000, "approved"),
            ("CTR-1405-004", "خرید بلبرینگ برای تعمیرات", parts_supplier, 0, items[2], 200, 850000, "received"),
            ("CTR-1405-005", "پیشنهاد خرید قطعات یدکی", parts_supplier, 1, items[3], 1000, 90000, "draft"),
        ]
        for number, title, supplier, idx, item, qty, price, status in configs:
            _, w, account = branches[idx]
            contract = Contract.objects.create(number=number, title=title, supplier=supplier, warehouse=w, due_date=timezone.localdate()+timedelta(days=25), notes="اطلاعات نمایشی و غیرواقعی برای بررسی نسخهٔ اولیه.")
            line = ContractLine.objects.create(contract=contract, item=item, quantity=qty, unit_price=price)
            if status != "draft":
                services.approve_contract(contract.pk)
                allocation = services.allocate(contract.pk, account.pk, contract.total, uuid.uuid4())
                services.pay(allocation.pk, contract.total / 5, f"PAY-{number}", uuid.uuid4(), description="پیش‌پرداخت نمونه")
            if status in ("partial", "building"):
                services.advance_contract(contract.pk, "building")
            if status in ("partial", "received"):
                services.receive(contract.pk, {line.pk: 2 if status == "partial" else qty}, f"RCV-{number}", uuid.uuid4())
        services.audit("داده نمونه ایجاد شد", "صرفاً نمایشی؛ برای استفاده واقعی پایگاه خالی بسازید")
        self.stdout.write(self.style.SUCCESS("دادهٔ نمونه ایجاد شد؛ همهٔ نام‌ها و مبالغ نمایشی‌اند. کاربری ایجاد نشده است."))
