"""Back up while the desktop application is open and at orderly shutdown."""
import io
import logging
from datetime import timedelta
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.db import connections
from django.utils import timezone
from .models import BackupStatus,SystemConfiguration

def backup_if_due():
    try:
        if not get_user_model().objects.exists():return False
        cfg=SystemConfiguration.objects.filter(pk=1).first() or SystemConfiguration()
        status=BackupStatus.objects.filter(pk=1).first()
        if status and status.last_success and timezone.now()-status.last_success<timedelta(hours=cfg.backup_hours):return False
        call_command('backup_local',stdout=io.StringIO())
        return True
    except Exception as error:
        logging.exception('Automatic local backup failed')
        try:BackupStatus.objects.update_or_create(pk=1,defaults={'last_error':type(error).__name__})
        except Exception:logging.exception('Could not record backup failure')
        return False
    finally:connections.close_all()
