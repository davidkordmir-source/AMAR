"""Reports never count ordered goods as physically present."""
from decimal import Decimal

from .models import Account, Contract, ContractLine, StockMovement, StockBalance, Warehouse, ZERO

def inventory_rows(branch=None, search="",user=None,allowed_factories=None,contract_ids=None):
    from .access import factory_ids,contracts_for
    ids=factory_ids(user) if allowed_factories is None else set(allowed_factories)
    warehouses = Warehouse.objects.filter(branch_id__in=ids).select_related("branch")
    movements = StockBalance.objects.filter(warehouse__branch_id__in=ids).select_related("warehouse__branch", "item")
    lines = ContractLine.objects.filter(contract__in=contracts_for(user) if contract_ids is None else Contract.objects.filter(pk__in=contract_ids),contract__warehouse__branch_id__in=ids).select_related("contract__warehouse__branch", "item").exclude(
        contract__status__in=[Contract.Status.DRAFT, Contract.Status.CANCELLED, Contract.Status.RECEIVED])
    if branch:
        warehouses = warehouses.filter(branch_id=branch)
        movements = movements.filter(warehouse__branch_id=branch)
        lines = lines.filter(contract__warehouse__branch_id=branch)
    rows = {}
    for m in movements.values("warehouse_id", "item_id", "quantity").iterator():
        row = rows.setdefault((m["warehouse_id"], m["item_id"]), {"on_hand": ZERO, "pending": ZERO})
        row["on_hand"] += m["quantity"]
    for line in lines:
        row = rows.setdefault((line.contract.warehouse_id, line.item_id), {"on_hand": ZERO, "pending": ZERO})
        row["pending"] += line.pending
    from .models import Item
    wh = {w.pk: w for w in warehouses}
    items = Item.objects.in_bulk({item for _, item in rows})
    result = []
    for (warehouse_id, item_id), values in rows.items():
        warehouse, item = wh[warehouse_id], items[item_id]
        if search and search.casefold() not in f"{item.name} {item.sku} {item.barcode} {warehouse.path}".casefold():
            continue
        from .models import MaterialRequest,StockTransfer
        reserved=sum((r.quantity for r in MaterialRequest.objects.filter(warehouse=warehouse,item=item,status='approved')),ZERO)+sum((t.quantity for t in StockTransfer.objects.filter(source=warehouse,item=item,status='approved')),ZERO)
        held=sum((r.remaining for r in MaterialRequest.objects.filter(warehouse=warehouse,item=item,status__in=['issued','closed'])),ZERO)
        result.append({**values, "warehouse": warehouse, "item": item, "low": values["on_hand"] <= item.minimum_stock,'reserved':reserved,'available':values['on_hand']-reserved,'held':held})
    return sorted(result, key=lambda r: (r["warehouse"].branch.name, r["item"].name))

def financial_totals(accounts):
    totals = {name: ZERO for name in ["balance", "credit_limit", "reserved", "available"]}
    for account in accounts:
        for name in totals:
            totals[name] += getattr(account, name)
    return totals

def snapshot_totals(payload):
    return {
        "branches": len(payload["branches"]), "contracts": len(payload["contracts"]),
        "balance": sum((Decimal(row["balance"]) for row in payload["accounts"]), ZERO),
        "available": sum((Decimal(row["available"]) for row in payload["accounts"]), ZERO),
        "stock_rows": len(payload["inventory"]),
    }

def consolidate_sources(sources,user=None):
    """Count only each source's latest report. Never silently mix local records."""
    totals = {"sources": 0, "branches": 0, "contracts": 0, "balance": ZERO, "available": ZERO}
    inventory = []
    for source in sources:
        latest = source.latest
        if not latest:
            continue
        totals["sources"] += 1
        from .sync import visible_payload
        payload=visible_payload(latest.payload,user,source)
        report = snapshot_totals(payload)
        for name in ("branches", "contracts", "balance", "available"):
            totals[name] += report[name]
        inventory.extend({**row, "source": source, "generated_at": latest.generated_at} for row in payload["inventory"])
    return totals, inventory
