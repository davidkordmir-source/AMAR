"""Fixed-point quantities stored as integer thousandths on every database.

SQLite NUMERIC columns can silently lose decimal precision. Integer storage
keeps stock arithmetic exact, including SUM and quantity comparisons.
"""
from decimal import Decimal, InvalidOperation
from django import forms
from django.core.exceptions import ValidationError
from django.db import models

class QuantityField(models.BigIntegerField):
    def __init__(self, *args, **kwargs):
        kwargs.pop("max_digits", None)
        kwargs.pop("decimal_places", None)
        super().__init__(*args, **kwargs)

    def to_python(self, value):
        if value is None:
            return value
        try:
            result = Decimal(str(value))
            if not result.is_finite() or result != result.quantize(Decimal("0.001")) or abs(result) > Decimal("9999999999999.999"):
                raise InvalidOperation
            return result
        except (InvalidOperation, ValueError, TypeError):
            raise ValidationError("مقدار معتبر با حداکثر سه رقم اعشار وارد کنید.")

    def get_prep_value(self, value):
        value = self.to_python(value)
        return int(value * 1000) if value is not None else None

    def from_db_value(self, value, expression, connection):
        return Decimal(value) / 1000 if value is not None else None

    def formfield(self, **kwargs):
        defaults = {"form_class": forms.DecimalField, "max_digits": 16, "decimal_places": 3}
        defaults.update(kwargs)
        return models.Field.formfield(self, **defaults)
