"use strict";
document.addEventListener("DOMContentLoaded", () => {
  const menu = document.querySelector(".mobile-menu");
  const sidebar = document.querySelector(".sidebar");
  menu?.addEventListener("click", () => {
    const open = sidebar.classList.toggle("open");
    menu.setAttribute("aria-expanded", String(open));
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && sidebar) {
      sidebar.classList.remove("open");
      menu?.setAttribute("aria-expanded", "false");
    }
  });
  document.addEventListener("click", (event) => {
    if (sidebar && !sidebar.contains(event.target) && !menu?.contains(event.target)) {
      sidebar.classList.remove("open");
      menu?.setAttribute("aria-expanded", "false");
    }
  });
  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });
  document.querySelectorAll("[data-print]").forEach((button) => {
    button.addEventListener("click", () => window.print());
  });
  const add = document.querySelector("#add-line");
  add?.addEventListener("click", () => {
    const total = document.querySelector("#id_lines-TOTAL_FORMS");
    const index = Number(total.value);
    const maximum=Number(document.querySelector('#id_lines-MAX_NUM_FORMS')?.value || 100);
    if (index >= maximum) return;
    const fragment = document.querySelector("#empty-line").innerHTML.replaceAll("__prefix__", String(index));
    document.querySelector("#contract-lines").insertAdjacentHTML("beforeend", fragment);
    total.value = String(index + 1);
    if (index + 1 >= maximum) add.disabled = true;
  });
});

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.geo-picker').forEach((picker) => {
    const input=picker.querySelector('.geo-query');
    const results=picker.querySelector('.geo-results');
    const selected=picker.querySelector('.geo-selected');
    const target=document.getElementById(picker.dataset.target);
    let timer, controller;
    input.addEventListener('input', () => {
      clearTimeout(timer); controller?.abort(); results.replaceChildren();
      target.value=''; selected.textContent='هنوز محل جدیدی انتخاب نشده است.';
      if(input.value.trim().length<2)return;
      timer=setTimeout(async () => {
        controller=new AbortController();
        try{
          const response=await fetch('/geography/search/?q='+encodeURIComponent(input.value.trim()),{signal:controller.signal,credentials:'same-origin'});
          if(!response.ok)throw new Error('Search unavailable');
          const data=await response.json(); results.replaceChildren();
          for(const place of data.results){
            const button=document.createElement('button'); button.type='button';
            button.textContent=place.path+' — '+place.level;
            button.addEventListener('click',()=>{
              target.value=String(place.id); selected.textContent=place.path;
              const city=document.getElementById('id_city'); if(city)city.value=place.name;
              results.replaceChildren();
            }); results.append(button);
          }
          if(!data.results.length)results.textContent='موردی پیدا نشد؛ حساب ارشد می‌تواند محل جدید اضافه کند.';
        }catch(error){if(error.name!=='AbortError')results.textContent='جست‌وجوی محلی انجام نشد؛ دوباره تلاش کنید.';}
      },250);
    });
    picker.querySelector('.geo-clear')?.addEventListener('click',()=>{target.value='';input.value='';selected.textContent='انتخاب نشده';results.replaceChildren();});
  });
});
