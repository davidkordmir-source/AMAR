"""One release identifier for the desktop, web interface and Windows archive."""
VERSION = "0.4.1"
VERSION_FA = VERSION.translate(str.maketrans("0123456789.", "۰۱۲۳۴۵۶۷۸۹٫"))
