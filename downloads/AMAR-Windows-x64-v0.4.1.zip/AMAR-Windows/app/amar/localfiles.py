"""Create private files atomically, without ever replacing an existing key."""
import os
from pathlib import Path
import tempfile

def private_file(path, create_bytes):
    path = Path(path)
    if not path.exists():
        fd, temporary = tempfile.mkstemp(prefix=".amar-key-", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(create_bytes())
                f.flush()
                os.fsync(f.fileno())
            try:
                os.link(temporary, path)
            except FileExistsError:
                pass
        finally:
            Path(temporary).unlink(missing_ok=True)
    return path.read_bytes()
