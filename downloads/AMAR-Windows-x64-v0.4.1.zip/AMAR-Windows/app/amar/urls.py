from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("password/", auth_views.PasswordChangeView.as_view(template_name="core/form.html", success_url="/"), name="password_change"),
    path("", include("core.urls")),
]
admin.site.site_header = "مدیریت دسترسی سامانه آمار"
admin.site.site_title = "آمار"
