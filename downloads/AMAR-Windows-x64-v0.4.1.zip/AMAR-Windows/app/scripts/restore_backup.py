#!/usr/bin/env python3
"""Offline restore to a NEW data directory; never overwrites existing data."""
import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
from zipfile import ZipFile

def restore(archive_path, target):
    target = Path(target).resolve()
    if target.exists():
        raise ValueError("Destination already exists. Use a new directory; no files were replaced.")
    target.parent.mkdir(parents=True, exist_ok=True)
    allowed = {"manifest.json", "amar.sqlite3", "secret.key", "transfer-identity.json"}
    with ZipFile(archive_path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) - allowed or not {"manifest.json", "amar.sqlite3", "transfer-identity.json"}.issubset(names):
            raise ValueError("Unsupported backup structure")
        if archive.getinfo("manifest.json").file_size > 8192:
            raise ValueError("Invalid manifest")
        manifest = json.loads(archive.read("manifest.json"))
        if manifest["version"] != 1 or set(manifest["files"]) != set(names) - {"manifest.json"}:
            raise ValueError("Invalid manifest")
        tmp = Path(tempfile.mkdtemp(prefix="amar-restore-", dir=target.parent))
        try:
            for name, checksum in manifest["files"].items():
                if archive.getinfo(name).file_size > (2 * 1024**3 if name == "amar.sqlite3" else 8192):
                    raise ValueError("Backup file too large")
                dest = tmp / name
                with archive.open(name) as source, dest.open("wb") as out:
                    shutil.copyfileobj(source, out)
                dest.chmod(0o600)
                with dest.open("rb") as f:
                    if hashlib.file_digest(f, "sha256").hexdigest() != checksum:
                        raise ValueError("Backup checksum mismatch")
            with closing(sqlite3.connect(tmp / "amar.sqlite3")) as db:
                if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValueError("Database integrity check failed")
            os.rename(tmp, target)
        except Exception:
            shutil.rmtree(tmp, ignore_errors=True)
            raise
    return target

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive")
    parser.add_argument("new_data_directory")
    args = parser.parse_args()
    try:
        target = restore(args.archive, args.new_data_directory)
    except (ValueError, KeyError, OSError) as exc:
        parser.exit(1, f"Restore failed: {exc}\n")
    print(f"Restored to {target}. Stop the old server, set AMAR_DATA_DIR to this directory, then start.")
    print("This restores the SAME installation identity. Never run both copies or use it as a new branch.")
