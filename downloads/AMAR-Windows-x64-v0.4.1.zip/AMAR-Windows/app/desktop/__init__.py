"""Windows-only application distribution and its local backend."""
