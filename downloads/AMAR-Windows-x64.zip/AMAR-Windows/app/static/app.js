"use strict";
document.addEventListener("DOMContentLoaded", () => {
  const menu = document.querySelector(".mobile-menu");
  const sidebar = document.querySelector(".sidebar");
  menu?.addEventListener("click", () => {
    const open = sidebar.classList.toggle("open");
    menu.setAttribute("aria-expanded", String(open));
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && sidebar) {
      sidebar.classList.remove("open");
      menu?.setAttribute("aria-expanded", "false");
    }
  });
  document.addEventListener("click", (event) => {
    if (sidebar && !sidebar.contains(event.target) && !menu?.contains(event.target)) {
      sidebar.classList.remove("open");
      menu?.setAttribute("aria-expanded", "false");
    }
  });
  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });
  document.querySelectorAll("[data-print]").forEach((button) => {
    button.addEventListener("click", () => window.print());
  });
  const add = document.querySelector("#add-line");
  add?.addEventListener("click", () => {
    const total = document.querySelector("#id_lines-TOTAL_FORMS");
    const index = Number(total.value);
    if (index >= 100) return;
    const fragment = document.querySelector("#empty-line").innerHTML.replaceAll("__prefix__", String(index));
    document.querySelector("#contract-lines").insertAdjacentHTML("beforeend", fragment);
    total.value = String(index + 1);
    if (index + 1 >= 100) add.disabled = true;
  });
});
