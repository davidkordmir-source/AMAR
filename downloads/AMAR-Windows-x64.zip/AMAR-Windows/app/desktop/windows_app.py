"""Native Windows control window + bundled local AMAR server.

Run through AMAR.exe. --self-test uses fresh temporary data, never real records.
"""
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import io
import json
import logging
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import tempfile
import threading
import traceback
import urllib.parse
import urllib.request
import webbrowser

APP_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(APP_ROOT))
from desktop.backend import DesktopBackend

def data_directory():
    supplied = os.environ.get("AMAR_DATA_DIR")
    if supplied:
        return Path(supplied).resolve()
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        raise RuntimeError("Windows LOCALAPPDATA is unavailable.")
    return Path(local) / "AMAR"

def local_opener():
    from http.cookiejar import CookieJar
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPCookieProcessor(CookieJar()))

def existing_url(data):
    try:
        state = json.loads((data / "desktop-state.json").read_text(encoding="utf-8"))
        url = urllib.parse.urlsplit(state["url"])
        if url.scheme != "http" or url.hostname != "127.0.0.1" or url.username or not url.port:
            return None
        with local_opener().open(f"http://127.0.0.1:{url.port}/_desktop/health", timeout=3) as response:
            health = json.load(response)
        if health.get("application") == "AMAR" and health.get("server_id") == state["server_id"]:
            return state["url"]
    except (OSError, ValueError, KeyError):
        pass
    return None

def open_application(url, data):
    for variable in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(variable)
        if base:
            edge = Path(base) / "Microsoft/Edge/Application/msedge.exe"
            if edge.is_file():
                subprocess.Popen([str(edge), "--app=" + url, "--no-first-run", "--user-data-dir=" + str(data / "BrowserProfile")])
                return
    webbrowser.open(url)

def self_test(result_file):
    report = {"target": "Windows x64", "python": sys.version.split()[0], "passed": False}
    captured = io.StringIO()
    sys.stdout = sys.stderr = captured
    def checkpoint(stage):
        report["stage"] = stage
        Path(result_file).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    checkpoint("starting")
    try:
        with tempfile.TemporaryDirectory(prefix="AMAR-check-") as directory:
            backend = DesktopBackend(directory,enable_schedule=False)
            try:
                url = backend.start()
                checkpoint("local-server-started")
                client = local_opener()
                with client.open(url, timeout=20) as response:
                    html = response.read().decode("utf-8")
                assert "ساخت حساب ارشد" in html
                csrf = re.search(r'name="csrfmiddlewaretoken" value="([^"]+)"', html).group(1)
                setup_token = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)["token"][0]
                password = secrets.token_urlsafe(30)
                body = urllib.parse.urlencode({"csrfmiddlewaretoken": csrf, "setup_token": setup_token,
                    "username": "windows-check", "password1": password, "password2": password}).encode()
                with client.open(urllib.request.Request(url, data=body), timeout=20) as response:
                    assert "نمای کلی کارخانه" in response.read().decode("utf-8")
                checkpoint("first-manager-login-verified")
                from django.core.management import call_command
                from django.test.runner import DiscoverRunner
                failures = DiscoverRunner(verbosity=1, interactive=False).run_tests(["core"])
                if failures:
                    raise AssertionError(f"{failures} test failure(s)")
                report.update(passed=True, first_run="passed", authenticated_dashboard="passed", test_suite="passed")
                checkpoint("tests-passed")
            finally:
                backend.stop()
    except Exception:
        report["error"] = traceback.format_exc()
    report["test_output"] = captured.getvalue()
    Path(result_file).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if report["passed"] else 1

def run_window(data, ui_smoke=False):
    user32, kernel32, gdi32 = ctypes.windll.user32, ctypes.windll.kernel32, ctypes.windll.gdi32
    LRESULT = ctypes.c_ssize_t
    WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
    class WNDCLASS(ctypes.Structure):
        _fields_ = [("style", wintypes.UINT), ("proc", WNDPROC), ("class_extra", ctypes.c_int), ("window_extra", ctypes.c_int),
            ("instance", wintypes.HINSTANCE), ("icon", wintypes.HICON), ("cursor", wintypes.HANDLE),
            ("background", wintypes.HBRUSH), ("menu", wintypes.LPCWSTR), ("name", wintypes.LPCWSTR)]
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = wintypes.HINSTANCE
    kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    user32.CreateWindowExW.argtypes = [wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, ctypes.c_void_p]
    user32.CreateWindowExW.restype = wintypes.HWND
    user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.DefWindowProcW.restype = LRESULT
    user32.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASS)]
    user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.EnableWindow.argtypes = [wintypes.HWND, wintypes.BOOL]
    user32.SetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPCWSTR]
    user32.GetWindowTextW.argtypes = [wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.SetTimer.argtypes = [wintypes.HWND,wintypes.WPARAM,wintypes.UINT,ctypes.c_void_p]
    user32.SetTimer.restype = wintypes.WPARAM
    user32.KillTimer.argtypes = [wintypes.HWND,wintypes.WPARAM]
    user32.DestroyWindow.argtypes = [wintypes.HWND]
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
    user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
    user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
    user32.DispatchMessageW.restype = LRESULT
    user32.IsDialogMessageW.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.MSG)]
    user32.IsDialogMessageW.restype = wintypes.BOOL
    user32.MessageBoxW.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.UINT]
    gdi32.GetStockObject.argtypes = [ctypes.c_int]
    gdi32.GetStockObject.restype = wintypes.HANDLE

    mutex_name = "Local\\AMAR-" + hashlib.sha256(str(data).casefold().encode()).hexdigest()[:24]
    mutex = kernel32.CreateMutexW(None, False, mutex_name)
    if not mutex:
        raise ctypes.WinError()
    duplicate = kernel32.GetLastError() == 183
    if duplicate:
        try:
            url = existing_url(data)
            if url:
                open_application(url, data)
            else:
                user32.MessageBoxW(None, "سامانه در حال راه‌اندازی است؛ چند لحظه بعد دوباره باز کنید.", "آمار", 0x40)
        finally:
            kernel32.CloseHandle(mutex)
        return
    backend = DesktopBackend(data)
    state = {"ready": False, "closing": False, "error": "", "startup": None,"backup":None}
    controls = {}
    instance = kernel32.GetModuleHandleW(None)
    font = gdi32.GetStockObject(17)
    def message(text, error=False):
        user32.MessageBoxW(window, text, backend.brand_name, 0x10 if error else 0x40)
    def refresh_brand():
        if state.get('brand')!=backend.brand_name:
            state['brand']=backend.brand_name
            user32.SetWindowTextW(window,backend.brand_name)
            user32.SetWindowTextW(controls[202],backend.brand_name+' — سامانهٔ یکپارچه کارخانه')
    def shutdown():
        if state["startup"]:
            state["startup"].join()
        if state["backup"]:state["backup"].join()
        backend.stop()
        user32.PostMessageW(window, 0x8003, 0, 0)
    def backup():
        if backend.url:
            parsed=urllib.parse.urlsplit(backend.url)
            open_application(f'http://127.0.0.1:{parsed.port}/configuration/backup/',data)

    def startup():
        try:
            backend.start()
            state["ready"] = True
            user32.PostMessageW(window, 0x8001, 0, 0)
        except Exception:
            logging.exception("Windows application startup failed")
            state["error"] = "راه‌اندازی انجام نشد. جزئیات در desktop.log در پوشهٔ داده ذخیره شد."
            user32.PostMessageW(window, 0x8002, 0, 0)
    @WNDPROC
    def window_proc(hwnd, event, wparam, lparam):
        try:
            if event == 0x111:  # WM_COMMAND
                command = wparam & 0xFFFF
                if command == 101 and state["ready"]:
                    open_application(backend.url, data)
                elif command == 102 and state["ready"]:
                    backup()
                elif command == 103:
                    backup()
                elif command == 104:
                    user32.PostMessageW(hwnd, 0x10, 0, 0)
                return 0
            if event == 0x8001:
                if not state["closing"]:
                    refresh_brand()
                    user32.SetTimer(hwnd,1,3000,None)
                    user32.SetWindowTextW(controls[200], "سامانه آماده است؛ استفاده بدون نیاز به اینترنت")
                    user32.EnableWindow(controls[101], True)
                    user32.EnableWindow(controls[102], True)
                    if ui_smoke:
                        title=ctypes.create_unicode_buffer(user32.GetWindowTextLengthW(hwnd)+1)
                        user32.GetWindowTextW(hwnd,title,len(title))
                        if title.value!=backend.brand_name:raise RuntimeError('Native window title did not receive the configured name')
                        user32.PostMessageW(hwnd, 0x10, 0, 0)
                    else:
                        open_application(backend.url, data)
                return 0
            if event == 0x113 and wparam == 1:
                if state['ready'] and not state['closing']:refresh_brand()
                return 0
            if event == 0x8002:
                if not ui_smoke:
                    message(state["error"], True)
                user32.PostMessageW(hwnd, 0x10, 0, 0)
                return 0
            if event == 0x8003:
                user32.DestroyWindow(hwnd)
                return 0
            if event == 0x8004:
                if not state["closing"]:
                    user32.EnableWindow(controls[102], True)
                return 0
            if event == 0x10:  # WM_CLOSE: drain requests before exit
                if not state["closing"]:
                    state["closing"] = True
                    user32.SetWindowTextW(controls[200], "در حال پایان عملیات و بستن برنامه…")
                    for key in (101, 102, 104):
                        user32.EnableWindow(controls[key], False)
                    threading.Thread(target=shutdown, daemon=True).start()
                return 0
            if event == 2:  # WM_DESTROY
                user32.PostQuitMessage(0)
                return 0
        except Exception:
            logging.exception("Native window operation failed")
        return user32.DefWindowProcW(hwnd, event, wparam, lparam)
    cls = WNDCLASS(0, window_proc, 0, 0, instance, None, None, 6, None, "AMARControlWindow")
    if not user32.RegisterClassW(ctypes.byref(cls)):
        raise ctypes.WinError()
    window = user32.CreateWindowExW(0x10000, cls.name, "سامانهٔ کارخانه", 0x00CA0000,
        200, 150, 620, 340, None, None, instance, None)
    if not window:
        raise ctypes.WinError()
    def child(kind, text, x, y, width, height, identifier=0):
        style = 0x50000000 | (0x10000 if kind == "BUTTON" else 2)
        control = user32.CreateWindowExW(0x2000, kind, text, style, x, y, width, height, window, identifier, instance, None)
        if not control:
            raise ctypes.WinError()
        user32.SendMessageW(control, 0x30, font, True)
        controls[identifier] = control
        return control
    child("STATIC", "سامانهٔ یکپارچه کارخانه", 24, 22, 560, 30,202)
    child("STATIC", "در حال آماده‌سازی پایگاه داده…", 24, 64, 560, 26, 200)
    child("STATIC", "اطلاعات این رایانه در پوشهٔ زیر نگهداری می‌شود:", 24, 110, 560, 23)
    child("STATIC", str(data), 24, 139, 560, 48, 201)
    child("BUTTON", "باز کردن سامانه", 424, 210, 160, 38, 101)
    child("BUTTON", "پشتیبان‌گیری", 274, 210, 140, 38, 102)
    child("BUTTON", "پوشهٔ داده", 144, 210, 120, 38, 103)
    child("BUTTON", "بستن برنامه", 24, 210, 110, 38, 104)
    user32.EnableWindow(controls[101], False)
    user32.EnableWindow(controls[102], False)
    user32.ShowWindow(window, 5)
    logging.info("Native Windows control window initialized")
    state["startup"] = threading.Thread(target=startup, daemon=True)
    state["startup"].start()
    msg = wintypes.MSG()
    try:
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            if not user32.IsDialogMessageW(window, ctypes.byref(msg)):
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
    finally:
        kernel32.CloseHandle(mutex)
    if state['error']:raise RuntimeError(state['error'])
    return backend.brand_name
    if state["error"]:
        raise RuntimeError(state["error"])
    logging.info("Native Windows control window closed; backend stopped")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--result-file")
    parser.add_argument("--ui-smoke", action="store_true")
    args = parser.parse_args()
    if os.name != "nt":
        parser.error("AMAR is distributed exclusively for Windows 10/11 x64.")
    if args.self_test:
        if not args.result_file:
            parser.error("--self-test requires --result-file")
        return self_test(args.result_file)
    data = data_directory()
    data.mkdir(parents=True, exist_ok=True)
    log = (data / "desktop.log").open("a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = log
    logging.basicConfig(stream=log, level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        brand_name=run_window(data, args.ui_smoke)
        if args.ui_smoke and args.result_file:
            Path(args.result_file).write_text(json.dumps({"passed": True, "native_window": "passed", "local_startup_shutdown": "passed","brand_name":brand_name},ensure_ascii=False), encoding="utf-8")
        return 0
    except Exception:
        logging.exception("AMAR desktop failure")
        if not args.ui_smoke:
            ctypes.windll.user32.MessageBoxW(None, "اجرای آمار ناموفق بود. desktop.log را در پوشهٔ داده بررسی کنید.", "آمار", 0x10)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
