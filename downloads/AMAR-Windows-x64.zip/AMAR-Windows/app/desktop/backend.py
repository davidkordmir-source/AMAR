"""Local backend used by the Windows application; no downloads at startup."""
import io
import json
import os
from pathlib import Path
import secrets
import threading

_brand_name='آمار'

def set_brand_name(value):
    global _brand_name
    _brand_name=value

class DesktopBackend:
    @property
    def brand_name(self):
        return _brand_name
    def __init__(self, data_dir,enable_schedule=True):
        self.data_dir = Path(data_dir)
        self.server = None
        self.thread = None
        self.url = None
        self.server_id = secrets.token_urlsafe(24)
        self.state_file = self.data_dir / "desktop-state.json"
        self.backup_stop=threading.Event()
        self.backup_thread=None
        self.enable_schedule=enable_schedule

    def start(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        os.environ["AMAR_DATA_DIR"] = str(self.data_dir)
        os.environ["DJANGO_SETTINGS_MODULE"] = "amar.settings"
        # Packaged desktop instances are deliberately local SQLite installations.
        os.environ.pop("AMAR_DATABASE_URL", None)
        os.environ["AMAR_DEBUG"] = "0"
        os.environ["AMAR_ALLOWED_HOSTS"] = "localhost,127.0.0.1,[::1]"
        os.environ["AMAR_HTTPS"] = "0"
        import django
        django.setup()
        from django.contrib.auth import get_user_model
        from django.core.management import call_command
        from django.db import connection
        from django.db.migrations.executor import MigrationExecutor
        from django.core.wsgi import get_wsgi_application
        from waitress import create_server

        pending = MigrationExecutor(connection).migration_plan(MigrationExecutor(connection).loader.graph.leaf_nodes())
        db_file = self.data_dir / "amar.sqlite3"
        if pending and db_file.exists() and db_file.stat().st_size > 0:
            call_command("backup_local", stdout=io.StringIO())
        call_command("migrate", interactive=False, stdout=io.StringIO())
        call_command("setup_roles", stdout=io.StringIO())
        call_command("load_geography",stdout=io.StringIO())
        from core.models import SystemConfiguration
        configuration=SystemConfiguration.objects.filter(pk=1).first()
        set_brand_name(configuration.brand_name if configuration else 'آمار')
        setup_token = secrets.token_urlsafe(48) if not get_user_model().objects.exists() else ""
        os.environ["AMAR_DESKTOP_SETUP_TOKEN"] = setup_token
        application = get_wsgi_application()
        def local_application(environ, start_response):
            if environ.get("PATH_INFO") == "/_desktop/health":
                if environ.get("REQUEST_METHOD") != "GET":
                    start_response("405 Method Not Allowed", [("Content-Type", "text/plain")])
                    return [b"Method not allowed"]
                body = json.dumps({"application": "AMAR", "server_id": self.server_id}).encode()
                start_response("200 OK", [("Content-Type", "application/json"), ("Cache-Control", "no-store")])
                return [body]
            return application(environ, start_response)
        self.server = create_server(local_application, host="127.0.0.1", port=0, threads=4)
        base = f"http://127.0.0.1:{self.server.effective_port}"
        self.url = base + (f"/setup/?token={setup_token}" if setup_token else "/")
        self.thread = threading.Thread(target=self.server.run, name="AMAR-local-server", daemon=True)
        self.thread.start()
        temporary = self.state_file.with_suffix(".tmp")
        temporary.write_text(json.dumps({"url": self.url, "server_id": self.server_id}), encoding="utf-8")
        temporary.replace(self.state_file)
        connection.close()
        from core.backup_schedule import backup_if_due
        if self.enable_schedule:backup_if_due()
        def scheduled_backup():
            while not self.backup_stop.wait(60):backup_if_due()
        if self.enable_schedule:
            self.backup_thread=threading.Thread(target=scheduled_backup,name='AMAR-backup',daemon=True)
            self.backup_thread.start()
        return self.url

    def stop(self):
        self.backup_stop.set()
        if self.backup_thread:self.backup_thread.join()
        if self.server:
            # Finish in-flight operations before stopping the listening socket.
            self.server.task_dispatcher.shutdown(cancel_pending=False, timeout=30)
            self.server.close()
            if self.thread:
                self.thread.join(timeout=3)
        from django.db import connections
        if self.url and self.enable_schedule:
            from core.backup_schedule import backup_if_due
            backup_if_due()
        connections.close_all()
        try:
            if json.loads(self.state_file.read_text(encoding="utf-8")).get("server_id") == self.server_id:
                self.state_file.unlink()
        except (OSError, ValueError):
            pass
