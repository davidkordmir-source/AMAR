"""Signed, read-only consolidation, NOT a merge of distributed accounting ledgers."""
import base64
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import json
import uuid

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import connection, transaction
from django.utils import timezone
from amar.localfiles import private_file

from .models import Account, Branch, Contract, ContractGrant, ImportedSnapshot, RemoteContractGrant, SyncState, TrustedSource
from .access import ancestors,contracts_for,descendants,factory_ids,require_factory,require_permission,root
from .reporting import inventory_rows
from .services import audit

MAX_FILE = 10 * 1024 * 1024
FORMAT = "amar-branch-report"

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")

def identity():
    key_path = settings.DATA_DIR / "transfer-identity.json"
    def create():
        key = Ed25519PrivateKey.generate()
        value = {"source_id": str(uuid.uuid4()), "private_key": base64.b64encode(key.private_bytes(
            serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())).decode()}
        return canonical(value)
    value = json.loads(private_file(key_path, create))
    return value["source_id"], Ed25519PrivateKey.from_private_bytes(base64.b64decode(value["private_key"]))

def public_identity():
    source_id, key = identity()
    return {"format": "amar-public-identity", "version": 1, "source_id": source_id,
            "public_key": base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode()}

def fingerprint(public_key):
    return hashlib.sha256(base64.b64decode(public_key, validate=True)).hexdigest()

def load_json(content):
    if len(content) > MAX_FILE:
        raise ValidationError("حجم فایل نباید بیشتر از ۱۰ مگابایت باشد.")
    try:
        def unique_object(pairs):
            result = {}
            for k, v in pairs:
                if k in result:
                    raise ValueError("duplicate JSON key")
                result[k] = v
            return result
        data = json.loads(content, object_pairs_hook=unique_object, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
        if not isinstance(data, dict):
            raise ValueError("not an object")
        return data
    except (ValueError, TypeError, UnicodeError, RecursionError):
        raise ValidationError("فایل JSON معتبر نیست.")

@transaction.atomic
def trust_source(content, label, actor=None):
    data = load_json(content)
    try:
        if data["format"] != "amar-public-identity" or type(data["version"]) is not int or data["version"] != 1 or not isinstance(data["source_id"], str):
            raise ValueError()
        source_id = uuid.UUID(data["source_id"])
        public_key = data["public_key"]
        Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key, validate=True))
        if str(source_id) == identity()[0]:
            raise ValidationError("این هویت متعلق به همین نصب است؛ فقط نصب‌های مستقل را معرفی کنید.")
    except (KeyError, ValueError, TypeError):
        raise ValidationError("فایل هویت معتبر نیست.")
    source, created = TrustedSource.objects.get_or_create(source_id=source_id, defaults={"label": label, "public_key": public_key})
    if not created and source.public_key != public_key:
        raise ValidationError("کلید این مبدأ با کلید ثبت‌شده متفاوت است؛ پذیرش خودکار مجاز نیست.")
    if created:
        audit("اعتماد به مبدأ گزارش", label, actor, str(source_id))
    return source

@transaction.atomic
def export_report(actor=None,target_branch=None):
    if connection.vendor == "postgresql":
        # A single point-in-time view, including concurrent row insertions.
        # Concurrent exports may require retry after a serialization failure.
        with connection.cursor() as cursor:
            cursor.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ")
    require_permission(actor,'export_branch_data')
    ids=factory_ids(actor)
    visible=contracts_for(actor)
    if target_branch is not None:
        require_factory(actor,target_branch)
        ids=ids & descendants(target_branch)
        inherited=set()
        for pk in ids: inherited.update(ancestors(pk))
        from django.db.models import Q
        grants=ContractGrant.objects.filter(Q(branch_id__in=ids)|Q(branch_id__in=inherited,include_descendants=True))
        visible=visible.filter(pk__in=grants.values('contract_id'))
    visible=visible.filter(warehouse__branch_id__in=ids)
    if not root(actor) and not actor.has_perm("core.view_contract"):visible=visible.none()
    source_id, key = identity()
    state, _ = SyncState.objects.get_or_create(pk=1)
    state = SyncState.objects.select_for_update().get(pk=state.pk)
    state.sequence += 1
    state.save(update_fields=["sequence"])
    branches = [{"code": b.code, "name": b.name, "city": b.city, "consumer": b.organization.name}
                for b in Branch.objects.filter(pk__in=ids).select_related("organization")]
    accounts = [{"branch": a.branch.code, "name": a.name, "balance": str(a.balance), "reserved": str(a.reserved),
                 "credit": str(a.credit_limit), "available": str(a.available)} for a in Account.objects.filter(branch_id__in=ids).select_related("branch")]
    if not root(actor) and not actor.has_perm("core.view_account"):accounts=[]
    contracts = [{"branch": c.warehouse.branch.code, "number": c.number, "title": c.title, "supplier": c.supplier.name,
                  "status": c.get_status_display(), "total": str(c.total), "paid": str(c.paid)}
                 for c in visible.select_related("supplier", "warehouse__branch").prefetch_related("lines")]
    inventory = [{"branch": r["warehouse"].branch.code, "warehouse": r["warehouse"].name, "sku": r["item"].sku,
                  "item": r["item"].name, "unit": r["item"].get_unit_display(), "on_hand": str(r["on_hand"]), "pending": str(r["pending"])}
                 for r in inventory_rows(user=actor,allowed_factories=ids,contract_ids=visible.values_list("pk",flat=True))]
    if not root(actor) and not actor.has_perm("core.view_stockmovement"):inventory=[]
    payload = {"source_id": source_id, "sequence": state.sequence, "generated_at": timezone.now().isoformat(),
               "branches": branches, "accounts": accounts, "contracts": contracts, "inventory": inventory}
    signature = base64.b64encode(key.sign(canonical(payload))).decode()
    envelope = {"format": FORMAT, "version": 1, "payload": payload, "signature": signature}
    content = canonical(envelope)
    if len(content) > MAX_FILE:
        raise ValidationError("گزارش از سقف ۱۰ مگابایت بیشتر است؛ برای این حجم به بسته‌بندی چندبخشی نیاز است.")
    audit("صدور گزارش آفلاین", f"{source_id} / {state.sequence}", actor)
    return content

def validate_payload(payload):
    columns = {
        "branches": ("code", "name", "city", "consumer"),
        "accounts": ("branch", "name", "balance", "reserved", "credit", "available"),
        "contracts": ("branch", "number", "title", "supplier", "status", "total", "paid"),
        "inventory": ("branch", "warehouse", "sku", "item", "unit", "on_hand", "pending"),
    }
    for table, fields in columns.items():
        rows = payload[table]
        if not isinstance(rows, list) or len(rows) > 20000:
            raise ValueError("invalid rows")
        for row in rows:
            if not isinstance(row, dict) or set(row) != set(fields):
                raise ValueError("invalid columns")
            for field, value in row.items():
                if not isinstance(value, str) or len(value) > 500:
                    raise ValueError("invalid cell")
                if field in ("balance", "reserved", "credit", "available", "total", "paid", "on_hand", "pending"):
                    number = Decimal(value)
                    if not number.is_finite() or abs(number) > Decimal("1e25"):
                        raise ValueError("invalid amount")
    codes = [row["code"] for row in payload["branches"]]
    if len(codes) != len(set(codes)):
        raise ValueError("duplicate branch")
    for table in ("accounts", "contracts", "inventory"):
        if any(row["branch"] not in codes for row in payload[table]):
            raise ValueError("unknown branch")

@transaction.atomic
def import_report(content, actor=None):
    envelope = load_json(content)
    try:
        if envelope["format"] != FORMAT or type(envelope["version"]) is not int or envelope["version"] != 1:
            raise ValueError("version")
        payload = envelope["payload"]
        if not isinstance(payload, dict) or not isinstance(payload.get("source_id"), str):
            raise ValueError("payload")
        source_id = uuid.UUID(payload["source_id"])
        source = TrustedSource.objects.select_for_update().filter(source_id=source_id).first()
        if source is None:
            raise ValidationError("مبدأ ناشناخته است؛ ابتدا فایل هویت عمومی شعبه را با تطبیق اثر انگشت ثبت کنید.")
        require_permission(actor,'add_importedsnapshot')
        if not root(actor):
            if not source.branch_id: raise ValidationError('مبدأ بدون واحد سازمانی فقط برای حساب ارشد قابل ورود است.')
            require_factory(actor,source.branch_id)
        signature = base64.b64decode(envelope["signature"], validate=True)
        raw = canonical(payload)
        Ed25519PublicKey.from_public_bytes(base64.b64decode(source.public_key)).verify(signature, raw)
        sequence = payload["sequence"]
        if type(sequence) is not int or not 0 < sequence < 2**63:
            raise ValueError("sequence")
        generated_at = datetime.fromisoformat(payload["generated_at"])
        if timezone.is_naive(generated_at):
            raise ValueError("timezone")
        validate_payload(payload)
        if source.branch_id:
            allowed=set(Branch.objects.filter(pk__in=descendants(source.branch_id)).values_list('code',flat=True))
            if any(row['code'] not in allowed for row in payload['branches']):
                raise ValidationError('فایل شامل واحدی بیرون از محدوده مجاز این مبدأ است؛ فایل متناسب با مقصد صادر کنید.')
        digest = hashlib.sha256(raw).hexdigest()
    except InvalidSignature:
        raise ValidationError("امضای فایل معتبر نیست؛ اطلاعات تغییر کرده یا فایل از این شعبه صادر نشده است.")
    except (ValueError, KeyError, TypeError, InvalidOperation, OverflowError, RecursionError):
        raise ValidationError("ساختار یا نسخه فایل گزارش معتبر نیست.")
    latest = source.latest
    if latest and sequence <= latest.sequence:
        if sequence == latest.sequence and digest == latest.digest:
            return latest
        raise ValidationError("این گزارش قدیمی یا متعارض است؛ آخرین گزارش شعبه حفظ شد.")
    snapshot = ImportedSnapshot.objects.create(source=source, sequence=sequence, payload=payload, digest=digest, generated_at=generated_at, imported_by=actor)
    audit("ورود گزارش امضاشده شعبه", source.label, actor, f"نسخه {sequence}؛ صرفاً خواندنی")
    return snapshot


def visible_payload(payload,user,source):
    """Do not expose imported information through details, totals or CSV."""
    if root(user):return payload
    allowed=set(Branch.objects.filter(pk__in=factory_ids(user)).values_list('code',flat=True))
    result={**payload}
    result['branches']=[row for row in payload['branches'] if row['code'] in allowed]
    numbers=set(RemoteContractGrant.objects.filter(source=source,user=user).values_list('number',flat=True))
    result['contracts']=[row for row in payload['contracts'] if row['branch'] in allowed and row['number'] in numbers] if user.has_perm('core.view_contract') else []
    result['accounts']=[row for row in payload['accounts'] if row['branch'] in allowed] if user.has_perm('core.view_account') else []
    all_visible={row['number'] for row in result['contracts']}=={row['number'] for row in payload['contracts'] if row['branch'] in allowed}
    result['inventory']=[{**row,'pending':row['pending'] if all_visible else ''} for row in payload['inventory'] if row['branch'] in allowed] if user.has_perm('core.view_stockmovement') else []
    return result
