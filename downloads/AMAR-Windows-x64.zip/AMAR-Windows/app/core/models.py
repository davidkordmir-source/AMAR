from decimal import Decimal, ROUND_HALF_UP, localcontext
import uuid

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q
from .fields import QuantityField

ZERO = Decimal("0")

def summed(query, field):
    # Python's integer/Decimal totals do not overflow SQLite's signed 64-bit SUM
    # during long-lived ledgers with many deposits and payments.
    return sum(query.values_list(field, flat=True).iterator(), ZERO)

class Organization(models.Model):
    class Role(models.TextChoices):
        PRODUCER = "producer", "تولیدکننده"
        CONSUMER = "consumer", "مصرف‌کننده"
        BOTH = "both", "تولیدکننده و مصرف‌کننده"
    name = models.CharField("نام مجموعه", max_length=180, unique=True)
    role = models.CharField("نقش", max_length=12, choices=Role.choices)
    national_id = models.CharField("شناسه ملی (اختیاری)", max_length=30, blank=True)
    contact = models.CharField("تلفن یا راه ارتباطی", max_length=120, blank=True)
    class Meta:
        ordering = ["name"]
        verbose_name = "مجموعه"
    def __str__(self):
        return self.name

class Branch(models.Model):
    name = models.CharField("نام شعبه", max_length=120)
    code = models.CharField("کد شعبه", max_length=24, unique=True)
    organization = models.ForeignKey(Organization, on_delete=models.PROTECT, verbose_name="مجموعه مصرف‌کننده")
    city = models.CharField("شهر", max_length=80)
    address = models.TextField("نشانی", blank=True)
    class Meta:
        ordering = ["name"]
        verbose_name = "شعبه"
    def __str__(self):
        return f"{self.name} · {self.city}"

class Warehouse(models.Model):
    name = models.CharField("نام انبار", max_length=120)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="warehouses", verbose_name="شعبه")
    class Meta:
        ordering = ["branch__name", "name"]
        constraints = [models.UniqueConstraint(fields=["branch", "name"], name="unique_warehouse_in_branch")]
        verbose_name = "انبار"
    def __str__(self):
        return f"{self.branch.name} / {self.name}"

class Item(models.Model):
    class Unit(models.TextChoices):
        PIECE = "piece", "عدد"
        KG = "kg", "کیلوگرم"
        METER = "meter", "متر"
        LITER = "liter", "لیتر"
    name = models.CharField("نام کالا یا قطعه", max_length=160)
    sku = models.CharField("کد یکتای کالا", max_length=40, unique=True)
    unit = models.CharField("واحد اندازه‌گیری", max_length=10, choices=Unit.choices, default=Unit.PIECE)
    specification = models.TextField("مشخصات فنی و جزئیات", blank=True)
    minimum_stock = QuantityField("حد هشدار موجودی (برای هر انبار)", default=0, validators=[MinValueValidator(0)])
    class Meta:
        ordering = ["name"]
        verbose_name = "کالا"
        constraints = [models.CheckConstraint(condition=Q(minimum_stock__gte=0), name="nonnegative_minimum_stock")]
    def __str__(self):
        return f"{self.sku} · {self.name}"

class Contract(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "پیش‌نویس"
        APPROVED = "approved", "تأیید شده"
        BUILDING = "building", "در حال ساخت"
        READY = "ready", "آماده تحویل"
        PARTIAL = "partial", "تحویل بخشی"
        RECEIVED = "received", "تحویل کامل"
        CANCELLED = "cancelled", "لغو شده"
    number = models.CharField("شماره قرارداد", max_length=40, unique=True)
    title = models.CharField("موضوع قرارداد", max_length=180)
    supplier = models.ForeignKey(Organization, on_delete=models.PROTECT, related_name="supplied_contracts", verbose_name="تولیدکننده")
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="contracts", verbose_name="انبار مقصد / شعبه مصرف‌کننده")
    status = models.CharField("وضعیت", choices=Status.choices, max_length=12, default=Status.DRAFT)
    due_date = models.DateField("موعد تحویل (میلادی)", null=True, blank=True)
    notes = models.TextField("توضیحات و شرایط قرارداد", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="approved_contracts")
    class Meta:
        ordering = ["-created_at", "-pk"]
        verbose_name = "قرارداد"
        permissions = [("approve_contract", "تأیید و تغییر وضعیت قرارداد")]
    def __str__(self):
        return self.number
    @property
    def total(self):
        return sum((line.total for line in self.lines.all()), ZERO)
    @property
    def paid(self):
        return summed(MoneyEntry.objects.filter(allocation__contract=self, kind=MoneyEntry.Kind.PAYMENT), "amount")
    @property
    def allocated(self):
        return summed(self.allocations.filter(active=True), "amount")
    @property
    def outstanding(self):
        return max(ZERO, self.total - self.paid)
    @property
    def is_open(self):
        return self.status not in (self.Status.DRAFT, self.Status.CANCELLED, self.Status.RECEIVED)

class ContractLine(models.Model):
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, related_name="lines")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, verbose_name="کالا / قطعه")
    quantity = QuantityField("مقدار", validators=[MinValueValidator(Decimal("0.001"))])
    unit_price = models.BigIntegerField("قیمت واحد (ریال)", validators=[MinValueValidator(1)])
    class Meta:
        ordering = ["pk"]
        constraints = [
            models.CheckConstraint(condition=Q(quantity__gt=0), name="positive_contract_quantity"),
            models.CheckConstraint(condition=Q(unit_price__gt=0), name="positive_contract_price"),
            models.UniqueConstraint(fields=["contract", "item"], name="unique_contract_item"),
        ]
    @property
    def total(self):
        with localcontext() as context:
            context.prec = 40
            return (Decimal(str(self.quantity)) * Decimal(str(self.unit_price))).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    @property
    def received(self):
        return summed(self.movements.all(), "quantity")
    @property
    def pending(self):
        return self.quantity - self.received if self.contract.is_open else ZERO

class Account(models.Model):
    name = models.CharField("نام حساب / صندوق", max_length=100)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, verbose_name="شعبه")
    opening_balance = models.BigIntegerField("موجودی اولیه (ریال)", default=0, validators=[MinValueValidator(0)])
    credit_limit = models.BigIntegerField("سقف اعتبار (ریال)", default=0, validators=[MinValueValidator(0)])
    class Meta:
        ordering = ["branch__name", "name"]
        verbose_name = "حساب مالی"
        constraints = [
            models.CheckConstraint(condition=Q(opening_balance__gte=0), name="nonnegative_opening_balance"),
            models.CheckConstraint(condition=Q(credit_limit__gte=0), name="nonnegative_credit_limit"),
            models.UniqueConstraint(fields=["branch", "name"], name="unique_account_in_branch"),
        ]
    def __str__(self):
        return f"{self.branch.name} / {self.name}"
    @property
    def balance(self):
        return self.opening_balance + summed(self.entries.filter(kind=MoneyEntry.Kind.DEPOSIT), "amount") - summed(self.entries.filter(kind=MoneyEntry.Kind.PAYMENT), "amount")
    @property
    def reserved(self):
        allocated = summed(self.allocations.filter(active=True), "amount")
        paid = summed(self.entries.filter(kind=MoneyEntry.Kind.PAYMENT, allocation__active=True), "amount")
        return allocated - paid
    @property
    def available(self):
        return self.balance + self.credit_limit - self.reserved

class Allocation(models.Model):
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, related_name="allocations", verbose_name="قرارداد")
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="allocations", verbose_name="حساب تأمین‌کننده وجه")
    amount = models.BigIntegerField("مبلغ تخصیص (ریال)", validators=[MinValueValidator(1)])
    active = models.BooleanField(default=True)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-pk"]
        verbose_name = "تخصیص وجه"
        constraints = [models.CheckConstraint(condition=Q(amount__gt=0), name="positive_allocation")]
    def __str__(self):
        return f"{self.contract.number} · {self.account} · تخصیص #{self.pk}"
    @property
    def paid(self):
        return summed(self.payments.all(), "amount")
    @property
    def remaining(self):
        return self.amount - self.paid

class MoneyEntry(models.Model):
    class Kind(models.TextChoices):
        DEPOSIT = "deposit", "دریافت وجه"
        PAYMENT = "payment", "پرداخت به تولیدکننده"
    account = models.ForeignKey(Account, on_delete=models.PROTECT, related_name="entries", verbose_name="حساب")
    allocation = models.ForeignKey(Allocation, on_delete=models.PROTECT, related_name="payments", null=True, blank=True)
    kind = models.CharField(max_length=10, choices=Kind.choices)
    amount = models.BigIntegerField("مبلغ (ریال)", validators=[MinValueValidator(1)])
    reference = models.CharField("شماره سند / پیگیری", max_length=80)
    description = models.CharField("شرح", max_length=240, blank=True)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    class Meta:
        ordering = ["-pk"]
        verbose_name = "سند مالی"
        constraints = [
            models.CheckConstraint(condition=Q(amount__gt=0), name="positive_money_entry"),
            models.CheckConstraint(condition=(Q(kind="deposit", allocation__isnull=True) | Q(kind="payment", allocation__isnull=False)), name="valid_money_entry_kind"),
            models.UniqueConstraint(fields=["account", "reference"], name="unique_financial_reference"),
        ]

class Receipt(models.Model):
    contract = models.ForeignKey(Contract, on_delete=models.PROTECT, related_name="receipts")
    reference = models.CharField("شماره رسید تحویل", max_length=80)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["contract", "reference"], name="unique_receipt_reference")]

class StockMovement(models.Model):
    class Kind(models.TextChoices):
        RECEIPT = "receipt", "تحویل قرارداد"
        IN = "in", "ورود دستی / موجودی اولیه"
        OUT = "out", "خروج / مصرف"
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="movements", verbose_name="انبار")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="movements", verbose_name="کالا")
    kind = models.CharField(max_length=10, choices=Kind.choices)
    quantity = QuantityField("مقدار")
    contract_line = models.ForeignKey(ContractLine, on_delete=models.PROTECT, null=True, related_name="movements")
    receipt = models.ForeignKey(Receipt, on_delete=models.PROTECT, null=True, related_name="movements")
    reference = models.CharField("شماره سند", max_length=80)
    note = models.CharField("شرح حرکت / محل مصرف", max_length=240, blank=True)
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    class Meta:
        ordering = ["-pk"]
        verbose_name = "گردش انبار"
        constraints = [
            models.CheckConstraint(condition=Q(kind="out", quantity__lt=0, contract_line__isnull=True, receipt__isnull=True) | Q(kind="in", quantity__gt=0, contract_line__isnull=True, receipt__isnull=True) | Q(kind="receipt", quantity__gt=0, contract_line__isnull=False, receipt__isnull=False), name="valid_stock_movement"),
            models.UniqueConstraint(fields=["receipt", "contract_line"], name="unique_receipt_line"),
        ]

class AuditEvent(models.Model):
    action = models.CharField(max_length=100)
    target = models.CharField(max_length=180)
    detail = models.TextField(blank=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-pk"]
        verbose_name = "رویداد عملیاتی"

class SyncState(models.Model):
    """Only one row per installation. Identity and private key live in DATA_DIR."""
    sequence = models.PositiveBigIntegerField(default=0)
    class Meta:
        permissions = [("export_branch_data", "صدور فایل گزارش شعبه")]

class TrustedSource(models.Model):
    source_id = models.UUIDField(unique=True)
    label = models.CharField("نام شعبه / نصب مبدأ", max_length=120)
    public_key = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["label"]
        verbose_name = "مبدأ مورد اعتماد"
    def __str__(self):
        return self.label
    @property
    def latest(self):
        return self.snapshots.order_by("-sequence").first()

class ImportedSnapshot(models.Model):
    source = models.ForeignKey(TrustedSource, on_delete=models.PROTECT, related_name="snapshots")
    sequence = models.PositiveBigIntegerField()
    payload = models.JSONField()
    digest = models.CharField(max_length=64)
    generated_at = models.DateTimeField()
    imported_at = models.DateTimeField(auto_now_add=True)
    imported_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True)
    class Meta:
        ordering = ["-imported_at"]
        constraints = [models.UniqueConstraint(fields=["source", "sequence"], name="unique_source_sequence")]
        verbose_name = "گزارش دریافتی شعبه"
