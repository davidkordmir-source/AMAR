import uuid
from decimal import Decimal

from django import forms
from django.core.exceptions import ValidationError
from django.forms import inlineformset_factory

from .models import Account, Allocation, Branch, Contract, ContractLine, Item, Organization, StockMovement, Warehouse
from .services import item_quantity

class OrganizationForm(forms.ModelForm):
    class Meta:
        model = Organization
        fields = ["name", "role", "national_id", "contact"]

class BranchForm(forms.ModelForm):
    class Meta:
        model = Branch
        fields = ["name", "code", "organization", "city", "address"]
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["organization"].queryset = Organization.objects.exclude(role=Organization.Role.PRODUCER)

class WarehouseForm(forms.ModelForm):
    class Meta:
        model = Warehouse
        fields = ["name", "branch"]

class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ["name", "sku", "unit", "specification", "minimum_stock"]
    def clean(self):
        data = super().clean()
        minimum = data.get("minimum_stock")
        if data.get("unit") == Item.Unit.PIECE and minimum is not None and minimum != minimum.to_integral_value():
            self.add_error("minimum_stock", "حد هشدار کالای شمارشی باید صحیح باشد.")
        return data

class AccountForm(forms.ModelForm):
    class Meta:
        model = Account
        fields = ["name", "branch", "opening_balance", "credit_limit"]
    def clean(self):
        data = super().clean()
        total = (data.get("opening_balance") or 0) + (data.get("credit_limit") or 0)
        if total > 999999999999999999:
            raise ValidationError("جمع موجودی و اعتبار از سقف مجاز ۱۸ رقم بیشتر است.")
        return data

class ContractForm(forms.ModelForm):
    class Meta:
        model = Contract
        fields = ["number", "title", "supplier", "warehouse", "due_date", "notes"]
        widgets = {"due_date": forms.DateInput(attrs={"type": "date"})}
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["supplier"].queryset = Organization.objects.exclude(role=Organization.Role.CONSUMER)

class ContractLineForm(forms.ModelForm):
    class Meta:
        model = ContractLine
        fields = ["item", "quantity", "unit_price"]
    def clean(self):
        data = super().clean()
        if data.get("item") and data.get("quantity"):
            try:
                item_quantity(data["item"], data["quantity"])
            except ValidationError as e:
                self.add_error("quantity", e)
        return data

ContractLineFormSet = inlineformset_factory(Contract, ContractLine, form=ContractLineForm, extra=1, min_num=1, validate_min=True, max_num=100, validate_max=True, can_delete=True)

class OperationForm(forms.Form):
    operation_key = forms.UUIDField(widget=forms.HiddenInput, initial=uuid.uuid4)

class AllocationForm(OperationForm):
    contract = forms.ModelChoiceField(label="قرارداد", queryset=Contract.objects.exclude(status__in=[Contract.Status.DRAFT, Contract.Status.CANCELLED]))
    account = forms.ModelChoiceField(label="حساب تأمین‌کننده وجه", queryset=Account.objects.all())
    amount = forms.DecimalField(label="مبلغ تخصیص (ریال)", max_digits=20, decimal_places=0, min_value=1)

class DepositForm(OperationForm):
    account = forms.ModelChoiceField(label="حساب دریافت‌کننده", queryset=Account.objects.all())
    amount = forms.DecimalField(label="مبلغ دریافت (ریال)", max_digits=20, decimal_places=0, min_value=1)
    reference = forms.CharField(label="شماره سند / پیگیری", max_length=80)
    description = forms.CharField(label="شرح واریز / منبع وجه", max_length=240, required=False)

class PaymentForm(OperationForm):
    allocation = forms.ModelChoiceField(label="تخصیص وجه", queryset=Allocation.objects.filter(active=True).select_related("contract", "account__branch"))
    amount = forms.DecimalField(label="مبلغ پرداخت (ریال)", max_digits=20, decimal_places=0, min_value=1)
    reference = forms.CharField(label="شماره سند / پیگیری", max_length=80)
    description = forms.CharField(label="شرح پرداخت", max_length=240, required=False)

class StockForm(OperationForm):
    warehouse = forms.ModelChoiceField(label="انبار", queryset=Warehouse.objects.all())
    item = forms.ModelChoiceField(label="کالا / قطعه", queryset=Item.objects.all())
    kind = forms.ChoiceField(label="نوع حرکت", choices=[(StockMovement.Kind.IN, "ورود دستی / موجودی اولیه"), (StockMovement.Kind.OUT, "خروج / مصرف")])
    quantity = forms.DecimalField(label="مقدار (همیشه مثبت وارد کنید)", min_value=Decimal("0.001"), max_digits=16, decimal_places=3)
    reference = forms.CharField(label="شماره سند", max_length=80)
    note = forms.CharField(label="شرح / محل مصرف", max_length=240, required=False)

class ReceiptForm(OperationForm):
    reference = forms.CharField(label="شماره رسید تحویل", max_length=80)
    def __init__(self, *args, contract, **kwargs):
        super().__init__(*args, **kwargs)
        self.lines = list(contract.lines.select_related("item"))
        for line in self.lines:
            self.fields[f"line_{line.pk}"] = forms.DecimalField(
                label=f"{line.item.name} ({line.item.get_unit_display()}) — باقی‌مانده: {line.quantity - line.received:g}",
                min_value=0, max_digits=16, decimal_places=3, required=False, initial=0,
            )
    def clean(self):
        data = super().clean()
        self.quantities = {}
        for line in self.lines:
            quantity = data.get(f"line_{line.pk}")
            if quantity:
                try:
                    self.quantities[line.pk] = item_quantity(line.item, quantity)
                except ValidationError as e:
                    self.add_error(f"line_{line.pk}", e)
        if not self.quantities:
            raise forms.ValidationError("مقدار حداقل یک ردیف باید بیشتر از صفر باشد.")
        return data
