import os
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import Client, TestCase

class DesktopFirstRunTests(TestCase):
    token = "desktop-test-token-" + "a" * 48
    def setUp(self):
        self.override = patch.dict(os.environ, {"AMAR_DESKTOP_SETUP_TOKEN": self.token})
        self.override.start()
        self.addCleanup(self.override.stop)
    def test_first_run_requires_the_launcher_token(self):
        self.assertEqual(self.client.get("/setup/").status_code, 403)
        self.assertEqual(self.client.get("/setup/?token=wrong").status_code, 403)
        self.assertContains(self.client.get("/setup/", {"token": self.token}), "ساخت حساب مدیر")
    def test_setup_disabled_without_desktop_launcher(self):
        os.environ.pop("AMAR_DESKTOP_SETUP_TOKEN")
        self.assertEqual(self.client.get("/setup/", {"token": self.token}).status_code, 403)
    def test_first_manager_is_created_and_logged_in_once(self):
        response = self.client.post("/setup/", {"setup_token": self.token, "username": "factory-owner",
            "password1": "Factory-owner-strong-730!", "password2": "Factory-owner-strong-730!"})
        self.assertEqual(response.status_code, 302)
        user = get_user_model().objects.get()
        self.assertTrue(user.is_superuser and user.is_staff)
        self.assertTrue(user.check_password("Factory-owner-strong-730!"))
        self.assertEqual(int(self.client.session["_auth_user_id"]), user.pk)
        self.assertEqual(self.client.get("/setup/", {"token": self.token}).status_code, 302)
        self.client.post("/setup/", {"setup_token": self.token, "username": "other",
            "password1": "Another-strong-password-123", "password2": "Another-strong-password-123"})
        self.assertEqual(get_user_model().objects.count(), 1)
    def test_weak_password_does_not_create_an_account(self):
        response = self.client.post("/setup/", {"setup_token": self.token, "username": "owner", "password1": "123", "password2": "123"})
        self.assertEqual(response.status_code, 200)
        self.assertFalse(get_user_model().objects.exists())
    def test_setup_has_csrf_protection_even_with_valid_launcher_token(self):
        client = Client(enforce_csrf_checks=True)
        response = client.post("/setup/", {"setup_token": self.token, "username": "owner", "password1": "Test-strong-123", "password2": "Test-strong-123"})
        self.assertEqual(response.status_code, 403)
        self.assertFalse(get_user_model().objects.exists())
