from django.urls import path
from . import views
from .desktop_setup import first_run

urlpatterns = [
    path("setup/", first_run, name="first_run"),
    path("", views.dashboard, name="dashboard"),
    path("contracts/", views.contracts, name="contracts"),
    path("contracts/new/", views.contract_new, name="contract_new"),
    path("contracts/<int:pk>/", views.contract_detail, name="contract_detail"),
    path("contracts/<int:pk>/action/<str:action>/", views.contract_action, name="contract_action"),
    path("contracts/<int:pk>/receive/", views.receipt_new, name="receipt_new"),
    path("inventory/", views.inventory, name="inventory"),
    path("inventory/move/", views.stock_new, name="stock_new"),
    path("finance/", views.finance, name="finance"),
    path("finance/allocate/", views.allocation_new, name="allocation_new"),
    path("finance/deposit/", views.deposit_new, name="deposit_new"),
    path("finance/pay/", views.payment_new, name="payment_new"),
    path("directory/", views.directory, name="directory"),
    path("directory/new/<str:kind>/", views.directory_new, name="directory_new"),
    path("audit/", views.audit_log, name="audit_log"),
    path("exchange/", views.exchange, name="exchange"),
    path("exchange/identity/", views.identity_export, name="identity_export"),
    path("exchange/export/", views.report_export, name="report_export"),
    path("exchange/trust/", views.source_new, name="source_new"),
    path("exchange/import/", views.report_import, name="report_import"),
    path("exchange/source/<int:pk>/", views.remote_detail, name="remote_detail"),
]
