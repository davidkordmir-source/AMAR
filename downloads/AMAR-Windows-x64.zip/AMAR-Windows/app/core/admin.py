from django.contrib import admin
from .models import (Account, Allocation, AuditEvent, Branch, Contract, ContractLine, ImportedSnapshot, Item, MoneyEntry, Organization, Receipt, StockMovement, TrustedSource, Warehouse)

# Business records are read-only here. Every write must use an atomic service.
class LedgerAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False

for model in (Account, Allocation, AuditEvent, Branch, Contract, ContractLine, ImportedSnapshot, Item, MoneyEntry, Organization, Receipt, StockMovement, TrustedSource, Warehouse):
    admin.site.register(model, LedgerAdmin)
