from .access import profile
from .models import SystemConfiguration

def workspace(request):
    configuration=SystemConfiguration.objects.filter(pk=1).first() or SystemConfiguration()
    p=profile(request.user) if request.user.is_authenticated else None
    return {'workspace_config':configuration,'workspace_profile':p,
        'workspace_name':p.display_name if p and p.display_name else (request.user.get_full_name() or request.user.get_username()) if request.user.is_authenticated else '',
        'workspace_title':p.position_title if p and p.position_title else configuration.owner_title if request.user.is_superuser else p.role.name if p and p.role else ''}
