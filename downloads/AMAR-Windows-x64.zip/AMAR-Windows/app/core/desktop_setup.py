"""One-time local account setup. Disabled unless a launcher token is present."""
import os
import secrets
from django.contrib.auth import get_user_model, login
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from django.http import HttpResponseForbidden
from django.shortcuts import redirect, render
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods

from .models import SyncState
from .services import audit

@never_cache
@require_http_methods(["GET", "POST"])
def first_run(request):
    User = get_user_model()
    if User.objects.exists():
        return redirect("login")
    expected = os.environ.get("AMAR_DESKTOP_SETUP_TOKEN", "")
    supplied = request.POST.get("setup_token", "") if request.method == "POST" else request.GET.get("token", "")
    if len(expected) < 32 or not secrets.compare_digest(expected.encode(), supplied.encode()):
        return HttpResponseForbidden("برای راه‌اندازی اولیه، برنامه را از AMAR.exe باز کنید.", content_type="text/plain; charset=utf-8")
    form = UserCreationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            state, _ = SyncState.objects.get_or_create(pk=1)
            SyncState.objects.select_for_update().get(pk=state.pk)
            if User.objects.exists():
                return redirect("login")
            user = form.save(commit=False)
            user.is_staff = True
            user.is_superuser = True
            user.save()
            audit("راه‌اندازی حساب مدیر", user.username, user)
        login(request, user)
        os.environ.pop("AMAR_DESKTOP_SETUP_TOKEN", None)
        return redirect("dashboard")
    return render(request, "registration/first_run.html", {"form": form, "setup_token": supplied, "page_title": "راه‌اندازی اولیه"})
