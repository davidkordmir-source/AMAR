from decimal import Decimal
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.contrib.auth.models import Permission
from django.core.exceptions import ValidationError
from django.forms import modelform_factory,formset_factory
from . import models as m
from .forms import OperationForm
from .access import factory_ids,scope_form,root,contracts_for,profile

SystemForm=modelform_factory(m.SystemConfiguration,fields=['brand_name','central_label','city_label','factory_label','owner_title','person_label','large_contract_amount','abnormal_quantity','overdue_days','backup_hours'])
LocationForm=modelform_factory(m.StorageLocation,fields=['warehouse','code','aisle','rack','shelf','bin'])
TraceForm=modelform_factory(m.TraceUnit,fields=['item','code'])
CustodianForm=modelform_factory(m.Custodian,fields=['branch','code','name','title','active'])
WorkOrderForm=modelform_factory(m.WorkOrder,fields=['branch','number','title','asset','active'])
RouteForm=modelform_factory(m.TransferRoute,fields=['source','destination'])
GeoForm=modelform_factory(m.GeoPlace,fields=['code','name','level','parent'],widgets={'parent':forms.HiddenInput()})

class RoleForm(forms.ModelForm):
    class Meta:
        model=m.AccessRole;fields=['name','permissions','active']
        widgets={'permissions':forms.CheckboxSelectMultiple()}
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        supported=['view_organization','view_branch','view_warehouse','view_item','view_contract','view_contractline','view_stockmovement','view_receipt','add_stockmovement','view_materialrequest','add_materialrequest','view_custodyevent','add_custodyevent','view_stocktransfer','add_stocktransfer','view_stockcount','add_stockcount','view_stockcorrection','add_stockcorrection','view_account','view_allocation','view_moneyentry','add_account','add_allocation','add_moneyentry','add_organization','add_branch','add_warehouse','add_item','view_importedsnapshot','add_importedsnapshot','view_trustedsource','add_trustedsource','export_branch_data','add_contract','approve_contract','view_auditevent','approve_operations','grant_contract']
        self.fields['permissions'].queryset=Permission.objects.filter(content_type__app_label='core',codename__in=supported).select_related('content_type')
        self.fields['permissions'].label='قابلیت‌های مجاز؛ عنوان نقش به‌تنهایی مجوز ایجاد نمی‌کند'
        labels={'view':'مشاهده','add':'ثبت','approve':'تأیید','manage':'مدیریت','grant':'تعیین دسترسی','export':'صدور'}
        self.fields['permissions'].label_from_instance=lambda p: labels.get(p.codename.split('_')[0],p.codename.split('_')[0])+' / '+p.content_type.name if p.codename.startswith(('view_','add_')) else p.name

    def save(self,commit=True):
        if not self.instance.code:
            import uuid
            self.instance.code='role-'+uuid.uuid4().hex[:20]
        return super().save(commit)

class UserForm(forms.Form):
    username=forms.CharField(label='نام کاربری ورود',max_length=150)
    display_name=forms.CharField(label='نام دلخواه برای نمایش',max_length=120)
    position_title=forms.CharField(label='عنوان دلخواه سمت',max_length=120,required=False)
    branch=forms.ModelChoiceField(label='واحد مجاز',queryset=m.Branch.objects.all(),required=False)
    include_descendants=forms.BooleanField(label='دسترسی به واحدهای زیرمجموعه همین واحد',required=False)
    role=forms.ModelChoiceField(label='نقش دسترسی (نام قابل تغییر)',queryset=m.AccessRole.objects.all(),required=False)
    enabled=forms.BooleanField(label='حساب فعال',required=False,initial=True)
    password=forms.CharField(label='رمز جدید (در ویرایش خالی بگذارید تا حفظ شود)',widget=forms.PasswordInput,required=False)
    def __init__(self,*args,user=None,**kwargs):
        self.instance=user
        initial=kwargs.pop('initial',{})
        if user:
            p=m.UserProfile.objects.filter(user=user).first()
            initial.update(username=user.username,enabled=user.is_active)
            if p:
                for name in ['display_name','position_title','branch','include_descendants','role']:
                    initial[name]=getattr(p,name)
        super().__init__(*args,initial=initial,**kwargs)
    def clean(self):
        data=super().clean()
        User=get_user_model()
        if User.objects.filter(username=data.get('username')).exclude(pk=self.instance.pk if self.instance else None).exists():self.add_error('username','نام کاربری تکراری است.')
        if not self.instance and not data.get('password'):self.add_error('password','برای حساب جدید رمز لازم است.')
        if data.get('password'):
            candidate=self.instance or User(username=data.get('username',''))
            try:validate_password(data['password'],candidate)
            except ValidationError as e:self.add_error('password',e)
        if not(self.instance and self.instance.is_superuser) and (not data.get('branch') or not data.get('role')):raise ValidationError('هر حساب زیرمجموعه به واحد و نقش مشخص نیاز دارد.')
        if self.instance and self.instance.is_superuser and not data.get('enabled') and User.objects.filter(is_superuser=True,is_active=True).count()<=1:raise ValidationError('آخرین حساب ارشد فعال را نمی‌توان غیرفعال کرد.')
        return data

class StructureForm(forms.Form):
    organization=forms.ModelChoiceField(label='مجموعه مصرف‌کننده',queryset=m.Organization.objects.exclude(role='producer'))
    root_name=forms.CharField(label='نام مجموعه مرکزی',max_length=100)
    centers=forms.IntegerField(label='تعداد مراکز شهری پیشنهادی',initial=10,min_value=1,max_value=200)
    factories_per_center=forms.IntegerField(label='تعداد اولیه کارخانه زیر هر مرکز',initial=3,min_value=1,max_value=100)

class GrantForm(forms.Form):
    user=forms.ModelChoiceField(label='کاربر',queryset=get_user_model().objects.filter(is_active=True,is_superuser=False),required=False)
    branch=forms.ModelChoiceField(label='یا واحد سازمانی',queryset=m.Branch.objects.all(),required=False)
    include_descendants=forms.BooleanField(label='اعطای صریح به زیرمجموعه‌های واحد انتخابی',required=False)
    can_operate=forms.BooleanField(label='عملیات قرارداد علاوه بر مشاهده (با رعایت نقش)',required=False)
    def clean(self):
        d=super().clean()
        if bool(d.get('user'))==bool(d.get('branch')):raise ValidationError('دقیقاً یک کاربر یا یک واحد انتخاب کنید.')
        return d

class MaterialForm(OperationForm):
    warehouse=forms.ModelChoiceField(label='انبار',queryset=m.Warehouse.objects.all())
    item=forms.ModelChoiceField(label='کالا',queryset=m.Item.objects.all())
    location=forms.ModelChoiceField(label='محل دقیق',queryset=m.StorageLocation.objects.all())
    trace=forms.ModelChoiceField(label='بچ / سریال',queryset=m.TraceUnit.objects.all(),required=False)
    quantity=forms.DecimalField(label='مقدار',max_digits=16,decimal_places=3,min_value=Decimal("0.001"))
    recipient=forms.ModelChoiceField(label='شخص تحویل‌گیرنده',queryset=m.Custodian.objects.filter(active=True))
    work_order=forms.ModelChoiceField(label='دستور کار / دستگاه',queryset=m.WorkOrder.objects.filter(active=True))
    purpose=forms.CharField(label='شرح نیاز',max_length=240)

class TransferForm(OperationForm):
    source=forms.ModelChoiceField(label='انبار مبدأ',queryset=m.Warehouse.objects.all())
    destination=forms.ModelChoiceField(label='انبار مقصد',queryset=m.Warehouse.objects.all())
    item=forms.ModelChoiceField(label='کالا',queryset=m.Item.objects.all())
    location=forms.ModelChoiceField(label='محل مبدأ',queryset=m.StorageLocation.objects.all())
    trace=forms.ModelChoiceField(label='بچ / سریال',queryset=m.TraceUnit.objects.all(),required=False)
    quantity=forms.DecimalField(label='مقدار',max_digits=16,decimal_places=3,min_value=Decimal("0.001"))
    reference=forms.CharField(label='شماره انتقال',max_length=80)
    def restrict(self,user):
        destinations=self.fields['destination'].queryset
        scope_form(self,user)
        if not root(user):
            ids=m.TransferRoute.objects.filter(source_id__in=factory_ids(user)).values('destination_id')
            self.fields['destination'].queryset=destinations.filter(branch_id__in=ids)
        return self

class CorrectionForm(OperationForm):
    warehouse=forms.ModelChoiceField(label='انبار',queryset=m.Warehouse.objects.all())
    item=forms.ModelChoiceField(label='کالا',queryset=m.Item.objects.all())
    location=forms.ModelChoiceField(label='محل دقیق',queryset=m.StorageLocation.objects.all())
    trace=forms.ModelChoiceField(label='بچ / سریال',queryset=m.TraceUnit.objects.all(),required=False)
    quantity=forms.DecimalField(label='تغییر مقدار؛ مثبت برای ورود و منفی برای خروج',max_digits=16,decimal_places=3)
    reason=forms.CharField(label='علت و مستند اصلاح',min_length=10,widget=forms.Textarea)

class SettlementForm(OperationForm):
    kind=forms.ChoiceField(label='تعیین تکلیف',choices=[('consume','مصرف در دستور کار'),('return','برگشت به همان محل انبار')])
    quantity=forms.DecimalField(label='مقدار',max_digits=16,decimal_places=3,min_value=Decimal("0.001"))
    reference=forms.CharField(label='شماره سند',max_length=80)

class TransferReceiveForm(forms.Form):
    location=forms.ModelChoiceField(label='محل دقیق در انبار مقصد',queryset=m.StorageLocation.objects.all())

class CountForm(OperationForm):
    warehouse=forms.ModelChoiceField(label='انبار مورد شمارش',queryset=m.Warehouse.objects.all())
    reference=forms.CharField(label='شماره انبارگردانی',max_length=80)
    csv_file=forms.FileField(label='CSV اختیاری برای شمارش گسترده',required=False)

class CountLineForm(forms.Form):
    item=forms.ModelChoiceField(label='کالا',queryset=m.Item.objects.all())
    location=forms.ModelChoiceField(label='محل',queryset=m.StorageLocation.objects.all(),required=False)
    trace=forms.ModelChoiceField(label='بچ / سریال',queryset=m.TraceUnit.objects.all(),required=False)
    counted=forms.DecimalField(label='شمارش واقعی',max_digits=16,decimal_places=3,min_value=0)

CountFormSet=formset_factory(CountLineForm,extra=1,min_num=1,validate_min=True,max_num=5000,validate_max=True,can_delete=True)
