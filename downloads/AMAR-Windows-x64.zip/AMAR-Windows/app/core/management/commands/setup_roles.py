from django.contrib.auth.models import Group, Permission
from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "Create the four operational roles; safe to run repeatedly."
    def handle(self, *args, **options):
        basic = ["view_organization", "view_branch", "view_warehouse", "view_item", "view_contract", "view_contractline"]
        stock = ["view_stockmovement", "view_receipt", "add_stockmovement"]
        finance = ["view_account", "view_allocation", "view_moneyentry", "add_account", "add_allocation", "add_moneyentry"]
        directories = ["add_organization", "add_branch", "add_warehouse", "add_item"]
        exchange = ["view_importedsnapshot", "add_importedsnapshot", "view_trustedsource", "add_trustedsource", "export_branch_data"]
        roles = {
            "مدیرعامل / مدیر عملیات": basic + stock + finance + directories + exchange + ["add_contract", "approve_contract", "view_auditevent"],
            "مسئول قراردادها": basic + ["add_contract", "approve_contract"],
            "انباردار": basic + stock,
            "مسئول مالی": basic + finance,
            "ناظر": [p.codename for p in Permission.objects.filter(content_type__app_label="core", codename__startswith="view_")],
        }
        for name, codenames in roles.items():
            group, _ = Group.objects.get_or_create(name=name)
            group.permissions.set(Permission.objects.filter(content_type__app_label="core", codename__in=codenames))
        self.stdout.write(self.style.SUCCESS("نقش‌های مدیر عملیات، قراردادها، انبار، مالی و ناظر آماده‌اند."))
