from decimal import Decimal, InvalidOperation
from django import template

register = template.Library()
TRANSLATION = str.maketrans("0123456789,", "۰۱۲۳۴۵۶۷۸۹٬")

@register.filter
def fa(value):
    return str(value).translate(TRANSLATION)

@register.filter
def number(value):
    try:
        value = Decimal(str(value))
        if not value.is_finite():
            return "—"
        text = f"{value:,.3f}".rstrip("0").rstrip(".")
        return text.translate(TRANSLATION)
    except (InvalidOperation, ValueError, TypeError):
        return "—"

@register.simple_tag(takes_context=True)
def query_string(context, **kwargs):
    query = context["request"].GET.copy()
    for k, v in kwargs.items():
        query[k] = str(v)
    return query.urlencode()
