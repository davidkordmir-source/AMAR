"""All stock and cash writes pass through atomic, serialized operations.

Lock order: contract -> account OR warehouse. Ledger rows are append-only in the UI.
SQLite serializes writes via IMMEDIATE transactions; PostgreSQL uses row locks.
"""
from decimal import Decimal, InvalidOperation

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .models import (
    Account, Allocation, AuditEvent, Contract, Item, MoneyEntry, Organization,
    Receipt, StockMovement, Warehouse, summed,
)

def audit(action, target, actor=None, detail=""):
    return AuditEvent.objects.create(action=action, target=str(target), actor=actor, detail=detail)

def positive(value, money=False):
    try:
        value = Decimal(str(value))
        step = Decimal("1") if money else Decimal("0.001")
        limit = Decimal("999999999999999999") if money else Decimal("9999999999999.999")
        if not value.is_finite() or value <= 0 or value > limit or value != value.quantize(step):
            raise ValidationError("مقدار باید مثبت و در محدوده مجاز باشد؛ مبلغ به ریال صحیح و مقدار با حداکثر سه رقم اعشار است.")
    except (InvalidOperation, ValueError, TypeError):
        raise ValidationError("مقدار عددی معتبر وارد کنید.")
    return value

def item_quantity(item, value):
    value = positive(value)
    if item.unit == Item.Unit.PIECE and value != value.to_integral_value():
        raise ValidationError("مقدار کالای شمارشی باید عدد صحیح باشد.")
    return value

def stock(warehouse, item):
    return summed(StockMovement.objects.filter(warehouse=warehouse, item=item), "quantity")

def replay(model, key, **expected):
    previous = model.objects.filter(operation_key=key).first()
    if previous and any(getattr(previous, field) != value for field, value in expected.items()):
        raise ValidationError("شناسه عملیات قبلاً برای اطلاعات متفاوت استفاده شده است. فرم را دوباره باز کنید.")
    return previous

@transaction.atomic
def approve_contract(contract_id, actor=None):
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    if contract.status != Contract.Status.DRAFT:
        raise ValidationError("فقط قرارداد پیش‌نویس قابل تأیید است.")
    if not contract.lines.exists():
        raise ValidationError("قرارداد باید حداقل یک ردیف کالا داشته باشد.")
    if contract.supplier.role not in (Organization.Role.PRODUCER, Organization.Role.BOTH):
        raise ValidationError("طرف فروشنده باید تولیدکننده باشد.")
    if contract.warehouse.branch.organization.role not in (Organization.Role.CONSUMER, Organization.Role.BOTH):
        raise ValidationError("شعبه مقصد باید متعلق به مصرف‌کننده باشد.")
    for line in contract.lines.select_related("item"):
        item_quantity(line.item, line.quantity)
        positive(line.unit_price, money=True)
    positive(contract.total, money=True)
    contract.status = Contract.Status.APPROVED
    contract.approved_at = timezone.now()
    contract.approved_by = actor
    contract.save(update_fields=["status", "approved_at", "approved_by"])
    audit("تأیید قرارداد و ایجاد تعهد", contract.number, actor, f"{contract.total} ریال؛ بدون تغییر موجودی واقعی")
    return contract

@transaction.atomic
def advance_contract(contract_id, target, actor=None):
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    allowed = {
        Contract.Status.APPROVED: Contract.Status.BUILDING,
        Contract.Status.BUILDING: Contract.Status.READY,
    }
    if allowed.get(contract.status) != target:
        raise ValidationError("این تغییر وضعیت برای مرحله فعلی مجاز نیست.")
    contract.status = target
    contract.save(update_fields=["status"])
    audit("تغییر مرحله قرارداد", contract.number, actor, contract.get_status_display())
    return contract

@transaction.atomic
def cancel_contract(contract_id, actor=None):
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    if contract.status in (Contract.Status.CANCELLED, Contract.Status.RECEIVED) or contract.receipts.exists() or contract.paid:
        raise ValidationError("قرارداد دارای تحویل یا پرداخت قابل لغو نیست؛ برگشت آن نیاز به سند اصلاحی دارد.")
    account_ids = list(contract.allocations.filter(active=True).values_list("account_id", flat=True))
    list(Account.objects.select_for_update().filter(pk__in=account_ids).order_by("pk"))
    contract.allocations.update(active=False)
    contract.status = Contract.Status.CANCELLED
    contract.save(update_fields=["status"])
    audit("لغو قرارداد و آزادسازی تخصیص‌ها", contract.number, actor)
    return contract

@transaction.atomic
def allocate(contract_id, account_id, amount, key, actor=None):
    amount = positive(amount, money=True)
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    account = Account.objects.select_for_update().get(pk=account_id)
    previous = replay(Allocation, key, contract_id=contract_id, account_id=account_id, amount=amount)
    if previous:
        return previous
    if contract.status in (Contract.Status.DRAFT, Contract.Status.CANCELLED):
        raise ValidationError("تخصیص فقط برای قرارداد تأییدشده مجاز است.")
    if contract.warehouse.branch_id != account.branch_id:
        raise ValidationError("حساب و قرارداد باید متعلق به یک شعبه باشند.")
    if amount > contract.total - contract.allocated:
        raise ValidationError("تخصیص از مبلغ باقیمانده قرارداد بیشتر است.")
    if amount > account.available:
        raise ValidationError("موجودی آزاد و اعتبار حساب برای این تخصیص کافی نیست.")
    allocation = Allocation.objects.create(contract=contract, account=account, amount=amount, operation_key=key)
    audit("تخصیص وجه", contract.number, actor, f"تخصیص #{allocation.pk}؛ {amount} ریال؛ {account}")
    return allocation

@transaction.atomic
def deposit(account_id, amount, reference, key, actor=None, description=""):
    amount = positive(amount, money=True)
    account = Account.objects.select_for_update().get(pk=account_id)
    previous = replay(MoneyEntry, key, account_id=account_id, amount=amount, kind=MoneyEntry.Kind.DEPOSIT, reference=reference, description=description)
    if previous:
        return previous
    if not reference.strip() or account.entries.filter(reference=reference).exists():
        raise ValidationError("شماره سند مالی الزامی و در هر حساب یکتا است.")
    positive(account.balance + amount + account.credit_limit, money=True)
    entry = MoneyEntry.objects.create(account=account, amount=amount, kind=MoneyEntry.Kind.DEPOSIT, reference=reference, operation_key=key, created_by=actor, description=description)
    audit("دریافت وجه", account, actor, f"{amount} ریال؛ سند {reference}")
    return entry

@transaction.atomic
def pay(allocation_id, amount, reference, key, actor=None, description=""):
    amount = positive(amount, money=True)
    info = Allocation.objects.get(pk=allocation_id)
    Contract.objects.select_for_update().get(pk=info.contract_id)
    account = Account.objects.select_for_update().get(pk=info.account_id)
    allocation = Allocation.objects.select_for_update().get(pk=allocation_id)
    previous = replay(MoneyEntry, key, allocation_id=allocation_id, amount=amount, kind=MoneyEntry.Kind.PAYMENT, reference=reference, description=description)
    if previous:
        return previous
    if not allocation.active or allocation.contract.status in (Contract.Status.DRAFT, Contract.Status.CANCELLED):
        raise ValidationError("این تخصیص فعال نیست.")
    if amount > allocation.remaining:
        raise ValidationError("مبلغ پرداخت از مانده تخصیص بیشتر است.")
    if amount > account.balance + account.credit_limit:
        raise ValidationError("موجودی و اعتبار قابل پرداخت کافی نیست.")
    if not reference.strip() or account.entries.filter(reference=reference).exists():
        raise ValidationError("شماره سند مالی الزامی و در هر حساب یکتا است.")
    entry = MoneyEntry.objects.create(account=account, allocation=allocation, amount=amount, kind=MoneyEntry.Kind.PAYMENT, reference=reference, description=description, operation_key=key, created_by=actor)
    audit("پرداخت به تولیدکننده", allocation.contract.number, actor, f"{amount} ریال؛ سند {reference}")
    return entry

@transaction.atomic
def receive(contract_id, quantities, reference, key, actor=None):
    contract = Contract.objects.select_for_update().get(pk=contract_id)
    warehouse = Warehouse.objects.select_for_update().get(pk=contract.warehouse_id)
    lines = {line.pk: line for line in contract.lines.select_related("item")}
    if set(quantities) - set(lines):
        raise ValidationError("ردیف تحویل متعلق به این قرارداد نیست.")
    quantities = {pk: item_quantity(lines[pk].item, qty) for pk, qty in quantities.items()}
    previous = replay(Receipt, key, contract_id=contract_id, reference=reference)
    if previous:
        if dict(previous.movements.values_list("contract_line_id", "quantity")) != quantities:
            raise ValidationError("اطلاعات این رسید با درخواست قبلی متفاوت است.")
        return previous
    if not contract.is_open:
        raise ValidationError("قرارداد در مرحله قابل تحویل نیست.")
    if not quantities:
        raise ValidationError("حداقل یک مقدار مثبت برای تحویل وارد کنید.")
    if not reference.strip() or contract.receipts.filter(reference=reference).exists():
        raise ValidationError("شماره رسید تحویل الزامی و در این قرارداد یکتا است.")
    for pk, quantity in quantities.items():
        if quantity > lines[pk].quantity - lines[pk].received:
            raise ValidationError(f"مقدار تحویل {lines[pk].item.name} از باقیمانده سفارش بیشتر است.")
        positive(stock(warehouse, lines[pk].item) + quantity)
    receipt = Receipt.objects.create(contract=contract, reference=reference, operation_key=key, created_by=actor)
    for pk, quantity in quantities.items():
        StockMovement.objects.create(warehouse=warehouse, item=lines[pk].item, quantity=quantity, kind=StockMovement.Kind.RECEIPT, contract_line=lines[pk], receipt=receipt, reference=reference, created_by=actor)
    contract.status = Contract.Status.RECEIVED if all(line.received == line.quantity for line in lines.values()) else Contract.Status.PARTIAL
    contract.save(update_fields=["status"])
    audit("ثبت تحویل و افزایش موجودی", contract.number, actor, f"رسید {reference}؛ {contract.get_status_display()}")
    return receipt

@transaction.atomic
def adjust_stock(warehouse_id, item_id, kind, quantity, reference, key, actor=None, note=""):
    warehouse = Warehouse.objects.select_for_update().get(pk=warehouse_id)
    item = Item.objects.get(pk=item_id)
    quantity = item_quantity(item, quantity)
    if kind not in (StockMovement.Kind.IN, StockMovement.Kind.OUT):
        raise ValidationError("نوع حرکت دستی معتبر نیست.")
    signed = -quantity if kind == StockMovement.Kind.OUT else quantity
    previous = replay(StockMovement, key, warehouse_id=warehouse_id, item_id=item_id, quantity=signed, kind=kind, reference=reference, note=note)
    if previous:
        return previous
    balance = stock(warehouse, item) + signed
    if balance < 0:
        raise ValidationError("خروج از موجودی واقعی انبار بیشتر است.")
    if balance:
        positive(balance)
    if not reference.strip():
        raise ValidationError("شماره سند الزامی است.")
    movement = StockMovement.objects.create(warehouse=warehouse, item=item, kind=kind, quantity=signed, reference=reference, operation_key=key, created_by=actor, note=note)
    audit(movement.get_kind_display(), f"{warehouse} / {item.sku}", actor, f"{signed} {item.get_unit_display()}؛ سند {reference}")
    return movement
