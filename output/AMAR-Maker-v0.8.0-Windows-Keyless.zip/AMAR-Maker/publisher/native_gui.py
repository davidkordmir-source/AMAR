"""Native Windows maker GUI; standard controls support keyboard paste and RTL.

The GUI delegates private operations through JSON stdin, keeping passwords out
of process arguments and logs. Only the matching pre-existing key is accepted.
"""
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import traceback

ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT),str(ROOT/'publisher/payload/AMAR-Windows/app')]
from publisher.sign_access import file_dialog_type

CLASS='AMARMakerWorkshop080'
WM_RESULT=0x8001
ID_KEY,ID_PASSWORD,ID_CHALLENGE,ID_BRANDING,ID_STATUS=101,102,103,104,105
CHOOSE_KEY,SHOW,IMPORT,CHOOSE_CHALLENGE,SIGN,CHOOSE_BRANDING,BUILD,OPEN,CLOSE=range(201,210)


def main():
    user=ctypes.WinDLL('user32',use_last_error=True)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    gdi=ctypes.WinDLL('gdi32',use_last_error=True)
    shell=ctypes.WinDLL('shell32',use_last_error=True)
    comdlg=ctypes.WinDLL('comdlg32',use_last_error=True)
    callback=ctypes.WINFUNCTYPE(w.LPARAM,w.HWND,w.UINT,w.WPARAM,w.LPARAM)
    class WNDCLASS(ctypes.Structure):
        _fields_=[('style',w.UINT),('proc',callback),('cls_extra',ctypes.c_int),('wnd_extra',ctypes.c_int),('instance',w.HINSTANCE),('icon',w.HICON),('cursor',w.HANDLE),('background',w.HBRUSH),('menu',w.LPCWSTR),('name',w.LPCWSTR)]
    user.CreateWindowExW.argtypes=[w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,w.HWND,w.HMENU,w.HINSTANCE,ctypes.c_void_p];user.CreateWindowExW.restype=w.HWND
    user.DefWindowProcW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];user.DefWindowProcW.restype=w.LPARAM
    user.SendMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];user.SendMessageW.restype=w.LPARAM
    user.PostMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM]
    user.SetWindowTextW.argtypes=[w.HWND,w.LPCWSTR]
    user.GetWindowTextLengthW.argtypes=[w.HWND];user.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,ctypes.c_int]
    user.EnableWindow.argtypes=[w.HWND,w.BOOL];user.IsWindow.argtypes=[w.HWND]
    user.DestroyWindow.argtypes=[w.HWND];user.ShowWindow.argtypes=[w.HWND,ctypes.c_int]
    user.MessageBoxW.argtypes=[w.HWND,w.LPCWSTR,w.LPCWSTR,w.UINT]
    user.LoadCursorW.argtypes=[w.HINSTANCE,ctypes.c_void_p];user.LoadCursorW.restype=w.HANDLE
    user.GetMessageW.argtypes=[ctypes.POINTER(w.MSG),w.HWND,w.UINT,w.UINT]
    user.IsDialogMessageW.argtypes=[w.HWND,ctypes.POINTER(w.MSG)]
    user.TranslateMessage.argtypes=[ctypes.POINTER(w.MSG)];user.TranslateMessage.restype=w.BOOL
    user.DispatchMessageW.argtypes=[ctypes.POINTER(w.MSG)];user.DispatchMessageW.restype=w.LPARAM
    kernel.GetModuleHandleW.argtypes=[w.LPCWSTR];kernel.GetModuleHandleW.restype=w.HINSTANCE
    kernel.CreateMutexW.argtypes=[ctypes.c_void_p,w.BOOL,w.LPCWSTR];kernel.CreateMutexW.restype=w.HANDLE
    kernel.CloseHandle.argtypes=[w.HANDLE]
    gdi.AddFontResourceExW.argtypes=[w.LPCWSTR,w.DWORD,ctypes.c_void_p]
    gdi.CreateFontW.argtypes=[ctypes.c_int]*5+[w.DWORD]*8+[w.LPCWSTR];gdi.CreateFontW.restype=w.HANDLE
    shell.ShellExecuteW.argtypes=[w.HWND,w.LPCWSTR,w.LPCWSTR,w.LPCWSTR,w.LPCWSTR,ctypes.c_int];shell.ShellExecuteW.restype=w.HINSTANCE
    user.SetProcessDPIAware()
    mutex=kernel.CreateMutexW(None,False,'Local\\AMAR-Maker-'+hashlib.sha256(str(ROOT).casefold().encode()).hexdigest()[:24])
    if ctypes.get_last_error()==183:
        user.MessageBoxW(None,'کارگاه این پوشه از قبل باز است؛ همان پنجره را استفاده کنید.','کارگاه سازنده',0x40)
        kernel.CloseHandle(mutex);return
    font_path=ROOT/'publisher/fonts/NotoSansArabic-Regular.ttf'
    family='Noto Sans Arabic' if font_path.is_file() and gdi.AddFontResourceExW(str(font_path),0x10,None) else 'Segoe UI'
    font=gdi.CreateFontW(-14,0,0,0,400,0,0,0,1,0,0,5,0,family)
    instance=kernel.GetModuleHandleW(None)
    controls={};buttons=[];responses=queue.Queue();state={'busy':False,'folder':None,'window':None}
    def text(handle):
        size=user.GetWindowTextLengthW(handle)
        if size>32768:return ''
        buf=ctypes.create_unicode_buffer(size+1)
        user.SendMessageW(handle,0xD,len(buf),ctypes.addressof(buf))
        return buf.value
    def control(classname,label,style,x,y,width,height,id=0,ex=0x2000):
        handle=user.CreateWindowExW(ex,classname,label,style|0x50000000,x,y,width,height,state['window'],w.HMENU(id),instance,None)
        if not handle:raise ctypes.WinError(ctypes.get_last_error())
        user.SendMessageW(handle,48,font,1)
        if id:controls[id]=handle
        return handle
    def label(value,y):return control('STATIC',value,2,26,y,826,30)
    def edit(id,y):return control('EDIT','',0x00810080,26,y,675,28,id,0x200)
    def button(value,id,x,y,width):
        h=control('BUTTON',value,0x10000,x,y,width,32,id);buttons.append(h);return h
    def start(request):
        if state['busy']:return
        state['busy']=True
        for handle in [*buttons,*[controls[id] for id in [ID_KEY,ID_PASSWORD,ID_CHALLENGE,ID_BRANDING]]]:user.EnableWindow(handle,False)
        user.SetWindowTextW(controls[ID_STATUS],'در حال ساخت نسخهٔ نصبی… چند دقیقه صبر کنید و پنجره را باز نگه دارید.' if request['action']=='build' else 'در حال بررسی؛ لطفاً صبر کنید…')
        def worker():
            try:
                data=json.dumps(request,ensure_ascii=False).encode();request['password']=''
                python=ROOT/'publisher/payload/AMAR-Windows/runtime/python.exe'
                process=subprocess.run([str(python),'-B','-I','-X','utf8',str(ROOT/'publisher/gui_backend.py')],input=data,
                    stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW,cwd=ROOT,timeout=1000)
                data=b''
                result=json.loads(process.stdout)
                if process.returncode or not isinstance(result,dict):raise ValueError()
            except Exception:result={'ok':False,'message':'کارگاه اجرا نشد؛ بسته را کامل با Extract All استخراج کنید.'}
            responses.put(result);user.PostMessageW(state['window'],WM_RESULT,0,0)
        threading.Thread(target=worker,daemon=True).start()
    def choose(title,filter):
        buf=ctypes.create_unicode_buffer(32768);dialog=file_dialog_type()()
        dialog.lStructSize=ctypes.sizeof(dialog);dialog.hwndOwner=state['window'];dialog.lpstrFilter=filter
        dialog.lpstrFile=ctypes.cast(buf,w.LPWSTR);dialog.nMaxFile=len(buf);dialog.lpstrTitle=title;dialog.Flags=0x1000|0x800|0x80000|8
        comdlg.GetOpenFileNameW.argtypes=[ctypes.POINTER(type(dialog))];comdlg.GetOpenFileNameW.restype=w.BOOL
        if comdlg.GetOpenFileNameW(ctypes.byref(dialog)):return buf.value
        code=comdlg.CommDlgExtendedError()
        if code:user.SetWindowTextW(controls[ID_STATUS],f'پنجرهٔ انتخاب فایل باز نشد؛ کد ویندوز: {code:X}')
        return None
    def command(id):
        if state['busy']:return
        choices={CHOOSE_KEY:(ID_KEY,'کلید یا پشتیبان رمزگذاری‌شدهٔ کارگاه قبلی','کلید کارگاه\0*.pem;*.json\0همهٔ فایل‌ها\0*.*\0\0'),CHOOSE_CHALLENGE:(ID_CHALLENGE,'فایل AMAR-Developer-Challenge.json تازه','درخواست ورود\0*.json\0همهٔ فایل‌ها\0*.*\0\0'),CHOOSE_BRANDING:(ID_BRANDING,'فایل AMAR-Branding.zip استودیو','هویت نرم‌افزار\0*.zip\0\0')}
        if id in choices:
            field,title,filter=choices[id];value=choose(title,filter)
            if value:user.SetWindowTextW(controls[field],value)
        elif id==SHOW:
            user.SendMessageW(controls[ID_PASSWORD],0xCC,0 if user.SendMessageW(controls[SHOW],0xF0,0,0) else ord('*'),0)
        elif id==IMPORT:
            password=text(controls[ID_PASSWORD])
            # Replace the password control after reading it. This also drops
            # the edit's undo buffer and resets a temporarily revealed value.
            user.SendMessageW(controls[SHOW],0xF1,0,0)
            user.DestroyWindow(controls[ID_PASSWORD])
            control('EDIT','',0x008100A0,272,123,370,28,ID_PASSWORD,0x200)
            start({'action':'import','key_path':text(controls[ID_KEY]),'password':password})
        elif id==SIGN:start({'action':'sign','challenge':text(controls[ID_CHALLENGE])})
        elif id==BUILD:start({'action':'build','branding':text(controls[ID_BRANDING])})
        elif id==OPEN:
            folder=state['folder'] or str(ROOT/'output');Path(folder).mkdir(parents=True,exist_ok=True);shell.ShellExecuteW(state['window'],'open',folder,None,None,1)
        elif id==CLOSE:user.PostMessageW(state['window'],16,0,0)
    @callback
    def proc(hwnd,msg,wp,lp):
        try:
            if msg==273:command(wp&0xffff);return 0
            if msg==WM_RESULT:
                result=responses.get_nowait();state['busy']=False
                for handle in [*buttons,*[controls[id] for id in [ID_KEY,ID_PASSWORD,ID_CHALLENGE,ID_BRANDING]]]:user.EnableWindow(handle,True)
                if result.get('candidates') and not text(controls[ID_KEY]):user.SetWindowTextW(controls[ID_KEY],result['candidates'][0])
                if result.get('folder'):state['folder']=result['folder']
                message=result.get('message','عملیات کامل نشد.')
                if result.get('file'):message+='\r\n'+result['file']
                if not result.get('ok'):message='عملیات کامل نشد: '+message
                user.SetWindowTextW(controls[ID_STATUS],message);return 0
            if msg==16:
                if state['busy']:user.MessageBoxW(hwnd,'عملیات در حال انجام است؛ پس از پایان، کارگاه را ببندید.','کارگاه سازنده',0x40)
                else:user.DestroyWindow(hwnd)
                return 0
            if msg==2:user.PostQuitMessage(0);return 0
        except Exception as error:
            # Diagnostic codes and line numbers only: never input values,
            # exception arguments, passwords, file content or signing keys.
            try:
                folder=ROOT/'publisher/private';folder.mkdir(parents=True,exist_ok=True)
                (folder/'last-gui-error.json').write_text(json.dumps({'type':type(error).__name__,'frames':[{'file':Path(frame.filename).name,'line':frame.lineno,'function':frame.name} for frame in traceback.extract_tb(error.__traceback__)]}),encoding='utf-8')
            except OSError:pass
            if controls.get(ID_STATUS):user.SetWindowTextW(controls[ID_STATUS],'عملیات کامل نشد؛ فایل انتخابی و کامل بودن کارگاه را بررسی کنید.')
            return 0
        return user.DefWindowProcW(hwnd,msg,wp,lp)
    cls=WNDCLASS(0,proc,0,0,instance,None,user.LoadCursorW(None,ctypes.c_void_p(32512)),w.HBRUSH(16),None,CLASS)
    user.RegisterClassW.argtypes=[ctypes.POINTER(WNDCLASS)]
    if not user.RegisterClassW(ctypes.byref(cls)):raise ctypes.WinError(ctypes.get_last_error())
    hwnd=user.CreateWindowExW(0,CLASS,'AMAR Maker Workshop 0.8.0 — کارگاه سازنده',0x00CA0000,120,40,900,690,None,None,instance,None);state['window']=hwnd
    label('کارگاه سازندهٔ آمار — ورود مستقل، ظاهر اختصاصی، ساخت نسخهٔ نصبی',18)
    label('۱. کلید کارگاه قبلی را انتخاب کنید؛ این کار فقط یک بار لازم است',55)
    edit(ID_KEY,86);button('انتخاب کلید',CHOOSE_KEY,716,84,136)
    control('STATIC','رمز پشتیبان قدیمی',2,660,127,192,25)
    control('EDIT','',0x008100A0,272,123,370,28,ID_PASSWORD,0x200)
    control('BUTTON','نمایش رمز',0x10003,130,121,126,30,SHOW)
    button('وارد کردن کلید قبلی',IMPORT,554,161,298)
    label('۲. در برنامهٔ شرکت «ورود سازنده» را باز و فایل درخواست تازه را دریافت کنید',207)
    edit(ID_CHALLENGE,238);button('انتخاب درخواست',CHOOSE_CHALLENGE,716,236,136);button('ساخت مجوز ورود سازنده',SIGN,554,274,298)
    label('۳. فایل AMAR-Branding.zip استودیو را برای ساخت نسخه انتخاب کنید',320)
    edit(ID_BRANDING,351);button('انتخاب ظاهر',CHOOSE_BRANDING,716,349,136);button('ساخت نسخهٔ نصبی در output',BUILD,554,387,298)
    control('EDIT','',0x00800844,26,436,826,98,ID_STATUS,0x200)
    button('باز کردن پوشهٔ نتیجه',OPEN,554,546,298);button('بستن کارگاه',CLOSE,26,546,150)
    label('کلید و مجوز خصوصی‌اند. برای شرکت‌ها فقط نسخهٔ نصبی و راهنما را منتشر کنید.',597)
    user.ShowWindow(hwnd,1);start({'action':'status'})
    msg=w.MSG()
    while user.GetMessageW(ctypes.byref(msg),None,0,0)>0:
        if not user.IsDialogMessageW(hwnd,ctypes.byref(msg)):user.TranslateMessage(ctypes.byref(msg));user.DispatchMessageW(ctypes.byref(msg))
    kernel.CloseHandle(mutex)


if __name__=='__main__':
    try:main()
    except Exception:
        ctypes.windll.user32.MessageBoxW(None,'کارگاه اجرا نشد؛ بستهٔ کامل را با Extract All استخراج کنید.','کارگاه سازنده',0x10)
        raise SystemExit(1)
