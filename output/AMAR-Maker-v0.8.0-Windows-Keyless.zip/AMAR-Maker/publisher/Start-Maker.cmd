@echo off
if exist "%~dp0..\AMAR-Maker.exe" (
  start "" "%~dp0..\AMAR-Maker.exe"
  exit /b
)
call "%~dp0Sign-Developer-Access.cmd"
