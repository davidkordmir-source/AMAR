"""JSON stdin bridge for the native, offline Windows maker workshop.

Passwords never enter process arguments or diagnostic files. Public kits are
keyless; an existing matching local key is required, never generated here.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import uuid

ROOT=Path(__file__).resolve().parent.parent
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT),str(ROOT/'publisher/payload/AMAR-Windows/app')]

from publisher.workshop_key import read_key, _public, _validate_key, WorkshopKeyError
from publisher.sign_access import prepare_workshop_password
from desktop.maker_protocol import sign_challenge, MakerError
from desktop.brand_profile import MAX_BUNDLE, read_bundle


def candidates(root):
    """Inspect only known workshop locations; never search company data drives."""
    folders=[root]
    downloads=Path.home()/'Downloads'
    for parent in [downloads,downloads/'Compressed',root.parent]:
        if not parent.is_dir():continue
        for name in ['AMAR-Maker-Fix1','AMAR-Publisher','AMAR-Developer-Workshop-v0.7.0-Fix1-Windows','AMAR-Developer-Workshop-v0.7.0-Windows']:
            folder=parent/name
            folders.extend([folder,folder/'AMAR-Maker-Fix1',folder/'AMAR-Publisher'])
    result=[]
    for folder in folders:
        for filename in ['developer-key.pem','developer-key.encrypted.json']:
            file=folder/'publisher/private'/filename
            if file.is_file() and str(file) not in result:result.append(str(file))
    return result[:20]


def import_key(root,source,password):
    target=root/'publisher/private/developer-key.pem'
    public,_=_public(root)
    if target.is_file():
        _validate_key(target.read_bytes(),public)
        return target
    source=Path(source).resolve()
    if not source.is_file() or source.stat().st_size>8192:raise ValueError('فایل کلید خصوصی یا پشتیبان رمزگذاری‌شدهٔ کارگاه قبلی را انتخاب کنید.')
    content=source.read_bytes()
    if content.startswith(b'-----BEGIN PRIVATE KEY-----'):
        key=_validate_key(content,public)
    else:
        # Unlock in a temporary private folder; the old workshop stays intact.
        with tempfile.TemporaryDirectory(prefix='amar-maker-import-') as work:
            temporary=Path(work)
            pin=temporary/'publisher/payload/AMAR-Windows/app/data/developer-public.json'
            pin.parent.mkdir(parents=True)
            shutil.copyfile(root/'publisher/payload/AMAR-Windows/app/data/developer-public.json',pin)
            private=temporary/'publisher/private';private.mkdir(mode=0o700,parents=True)
            (private/'developer-key.encrypted.json').write_bytes(content)
            key=read_key(temporary,lambda:prepare_workshop_password(password))
            content=(private/'developer-key.pem').read_bytes()
    _validate_key(content,public)
    target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    try:
        fd=os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'wb') as stream:stream.write(content)
    except FileExistsError:_validate_key(target.read_bytes(),public)
    return target


def execute(request,root=ROOT):
    root=Path(root).resolve()
    action=request.get('action')
    if action=='status':
        public,fingerprint=_public(root)
        ready=False
        if (root/'publisher/private/developer-key.pem').is_file():
            read_key(root);ready=True
        return {'ok':True,'key_ready':ready,'candidates':candidates(root),'fingerprint':fingerprint,
            'message':'کلید کارگاه آماده است.' if ready else 'کلید کارگاه قبلی را وارد کنید. این بستهٔ عمومی کلید خصوصی ندارد.'}
    if action=='import':
        import_key(root,request.get('key_path',''),request.get('password',''))
        return {'ok':True,'key_ready':True,'message':'کلید قبلی با هویت نرم‌افزار تطبیق دارد؛ کارگاه آماده است.'}
    if action=='sign':
        key=read_key(root)
        challenge=Path(request.get('challenge',''))
        if not challenge.is_file() or challenge.stat().st_size>32768:raise ValueError('فایل AMAR-Developer-Challenge.json تازه را از برنامهٔ شرکت انتخاب کنید.')
        grant=sign_challenge(challenge.read_bytes(),key)
        folder=root/'publisher/private/authorizations';folder.mkdir(mode=0o700,parents=True,exist_ok=True)
        target=folder/('AMAR-Developer-Access-'+uuid.uuid4().hex[:12]+'.json')
        target.write_bytes(grant)
        return {'ok':True,'message':'مجوز ساخته شد. این فایل را در صفحهٔ ورود سازندهٔ برنامهٔ شرکت وارد کنید.','file':str(target),'folder':str(folder)}
    if action=='build':
        read_key(root)
        branding=Path(request.get('branding',''))
        if not branding.is_file() or branding.stat().st_size>MAX_BUNDLE:raise ValueError('فایل AMAR-Branding.zip خروجی استودیوی سازنده را انتخاب کنید.')
        content=branding.read_bytes();profile,assets=read_bundle(content)
        folder=root/'branding';folder.mkdir(exist_ok=True)
        target=folder/'AMAR-Branding.zip'
        if branding.resolve()!=target.resolve():
            temporary=folder/('branding-'+uuid.uuid4().hex+'.tmp')
            try:temporary.write_bytes(content);temporary.replace(target)
            finally:temporary.unlink(missing_ok=True)
        compiler=root/'publisher/tools/inno/ISCC.exe'
        if not compiler.is_file():raise ValueError('ابزار ساخت نسخه در کارگاه موجود نیست؛ بستهٔ کامل کارگاه را استخراج کنید.')
        process=subprocess.run([sys.executable,'-B','-I','-X','utf8',str(root/'publisher/build_release.py'),'--workspace',str(root)],
            cwd=root,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=900,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if process.returncode:raise ValueError('ساخت نسخه کامل نشد؛ سالم بودن بستهٔ کارگاه و فضای آزاد دیسک را بررسی کنید. اطلاعات شرکت تغییر نکرده است.')
        version=json.loads((root/'publisher/payload/AMAR-Windows/package-manifest.json').read_bytes())['version']
        output=root/'output';installer=output/(profile['product_code']+'-Setup-v'+version+'-x64.exe')
        if not installer.is_file():raise ValueError('فایل نصب در پوشهٔ output پیدا نشد.')
        return {'ok':True,'message':'نسخهٔ نصبی با نام و ظاهر انتخابی در پوشهٔ output آماده است.','file':str(installer),'folder':str(output)}
    raise ValueError('عملیات کارگاه معتبر نیست.')


def main():
    try:
        content=sys.stdin.buffer.read(65537)
        if len(content)>65536:raise ValueError('درخواست بیش از حد بزرگ است.')
        request=json.loads(content)
        if not isinstance(request,dict):raise ValueError('درخواست کارگاه معتبر نیست.')
        result=execute(request)
    except (ValueError,MakerError,WorkshopKeyError,OSError,subprocess.SubprocessError) as error:
        result={'ok':False,'message':str(error) or 'عملیات کامل نشد.'}
    except Exception:
        # A traceback must never echo a password, grant or key into the UI/log.
        result={'ok':False,'message':'کارگاه کامل نیست؛ بسته را با Extract All در پوشه‌ای قابل‌نوشتن استخراج کنید.'}
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
