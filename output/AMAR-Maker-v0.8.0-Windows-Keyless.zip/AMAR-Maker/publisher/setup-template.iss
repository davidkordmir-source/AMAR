[Setup]
AppId=@APP_ID@
AppName=@PRODUCT@
AppVersion=@VERSION@
AppPublisher=@PUBLISHER@
AppVerName=@PRODUCT@ @VERSION@
DefaultDirName={localappdata}\Programs\@PRODUCT_CODE@
DefaultGroupName=@PRODUCT_CODE@
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64os
ArchitecturesInstallIn64BitMode=x64os
MinVersion=10.0
UsePreviousAppDir=yes
UsePreviousTasks=yes
OutputDir=@OUTPUT@
OutputBaseFilename=@BASENAME@
SetupIconFile=@ICON@
UninstallDisplayIcon={app}\versions\@VERSION@\app\data\brand-defaults\app.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=no
RestartApplications=no
UninstallDisplayName=@PRODUCT@
SetupLogging=yes
DisableReadyPage=no

[Languages]
Name: "persian"; MessagesFile: "compiler:Languages\Farsi.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "ساخت میان‌بر روی دسکتاپ"; GroupDescription: "میان‌برها:"

[InstallDelete]
Type: files; Name: "{app}\versions\@VERSION@\app\data\brand-defaults\logo.png"
Type: files; Name: "{app}\versions\@VERSION@\app\data\brand-defaults\desktop-icon.png"
Type: files; Name: "{app}\versions\@VERSION@\app\data\brand-defaults\background.png"

[Files]
Source: "@PAYLOAD@\*"; DestDir: "{app}\versions\@VERSION@"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{userprograms}\@PRODUCT_CODE@\@SHORTCUT@"; Filename: "{app}\versions\@VERSION@\@EXECUTABLE@"; WorkingDir: "{app}\versions\@VERSION@"; IconFilename: "{app}\versions\@VERSION@\app\data\brand-defaults\app.ico"
Name: "{userdesktop}\@SHORTCUT@"; Filename: "{app}\versions\@VERSION@\@EXECUTABLE@"; WorkingDir: "{app}\versions\@VERSION@"; IconFilename: "{app}\versions\@VERSION@\app\data\brand-defaults\app.ico"; Tasks: desktopicon
Name: "{userprograms}\@PRODUCT_CODE@\حذف برنامه"; Filename: "{uninstallexe}"

[Registry]
Root: HKCU; Subkey: "Software\AMAR\Install"; ValueType: string; ValueName: "InstallDir"; ValueData: "{app}"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\AMAR\Install"; ValueType: string; ValueName: "StartGroupName"; ValueData: "@PRODUCT_CODE@"
Root: HKCU; Subkey: "Software\AMAR\Install"; ValueType: string; ValueName: "ExecutableName"; ValueData: "@EXECUTABLE@"
Root: HKCU; Subkey: "Software\AMAR\Install"; ValueType: string; ValueName: "Version"; ValueData: "@VERSION@"
Root: HKCU; Subkey: "Software\AMAR\Install"; ValueType: string; ValueName: "ShortcutName"; ValueData: "@SHORTCUT@"

[Run]
Filename: "{app}\versions\@VERSION@\@EXECUTABLE@"; Description: "اجرای @PRODUCT_QUOTED@"; Flags: nowait postinstall skipifsilent

[Code]
function ApplicationIsOpen: Boolean;
begin
  Result := FindWindowByClassName('AMARControlWindow') <> 0;
end;

function InitializeSetup: Boolean;
begin
  Result := not ApplicationIsOpen;
  if not Result and not WizardSilent then
    MsgBox('برنامهٔ آمار هنوز باز است. آن را از پنجرهٔ کنترل با × ببندید و نصب را دوباره اجرا کنید. بستن مرورگر کافی نیست.', mbError, MB_OK);
end;

function InitializeUninstall: Boolean;
begin
  Result := not ApplicationIsOpen;
  if not Result and not UninstallSilent then
    MsgBox('ابتدا برنامه را کامل ببندید و سپس حذف برنامه را دوباره اجرا کنید. اطلاعات کارخانه با حذف برنامه پاک نمی‌شود.', mbError, MB_OK);
end;

function SafeShortcutName(const Name: String): Boolean;
var I: Integer;
begin
  Result := (Length(Name) > 0) and (Length(Name) <= 100) and (Name <> '.') and (Name <> '..');
  for I := 1 to Length(Name) do
    if Pos(Name[I], '\/:*?"<>|') > 0 then Result := False;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var Previous, PreviousGroup, PreviousExecutable: String;
begin
  if CurStep = ssInstall then begin
    PreviousExecutable := 'AMAR.exe';
    RegQueryStringValue(HKCU, 'Software\AMAR\Install', 'ExecutableName', PreviousExecutable);
    if SafeShortcutName(PreviousExecutable) and (Length(PreviousExecutable) <= 44) and (LowerCase(ExtractFileExt(PreviousExecutable)) = '.exe') and (PreviousExecutable <> '@EXECUTABLE@') then
      DeleteFile(ExpandConstant('{app}\versions\@VERSION@\') + PreviousExecutable);
    PreviousGroup := 'AMAR';
    RegQueryStringValue(HKCU, 'Software\AMAR\Install', 'StartGroupName', PreviousGroup);
    if RegQueryStringValue(HKCU, 'Software\AMAR\Install', 'ShortcutName', Previous) and SafeShortcutName(Previous) and SafeShortcutName(PreviousGroup) then begin
      if (Previous <> '@SHORTCUT_PASCAL@') or (PreviousGroup <> '@PRODUCT_CODE@') then begin
        if Previous <> '@SHORTCUT_PASCAL@' then DeleteFile(ExpandConstant('{userdesktop}\') + Previous + '.lnk');
        DeleteFile(ExpandConstant('{userprograms}\') + PreviousGroup + '\' + Previous + '.lnk');
        DeleteFile(ExpandConstant('{userprograms}\') + PreviousGroup + '\حذف برنامه.lnk');
        RemoveDir(ExpandConstant('{userprograms}\') + PreviousGroup);
      end;
    end;
  end;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var CurrentName, CurrentGroup: String;
begin
  if CurUninstallStep = usUninstall then begin
    CurrentGroup := '@PRODUCT_CODE@';
    RegQueryStringValue(HKCU, 'Software\AMAR\Install', 'StartGroupName', CurrentGroup);
    if RegQueryStringValue(HKCU, 'Software\AMAR\Install', 'ShortcutName', CurrentName) and SafeShortcutName(CurrentName) and SafeShortcutName(CurrentGroup) then begin
      DeleteFile(ExpandConstant('{userdesktop}\') + CurrentName + '.lnk');
      DeleteFile(ExpandConstant('{userprograms}\') + CurrentGroup + '\' + CurrentName + '.lnk');
      RemoveDir(ExpandConstant('{userprograms}\') + CurrentGroup);
    end;
  end;
end;
