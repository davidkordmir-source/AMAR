"""Validated offline presentation profile; no credentials or factory data."""
import io,json,re
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

FORMAT='AMAR-Branding'
MAX_LOGO=2*1024*1024
MAX_BACKGROUND=6*1024*1024
MAX_BUNDLE=MAX_BACKGROUND+2*MAX_LOGO+256*1024
NAVIGATION={'dashboard':'نمای کلی','contracts':'قراردادها','inventory':'انبار و قطعات','finance':'امور مالی','directory':'اطلاعات پایه','structure':'موقعیت','geography':'استان تا آبادی','control':'کنترل گردش و تأییدها','alerts':'هشدارها و پیگیری','documents':'اسکن و مدارک','exchange':'تبادلات اطلاعات','audit':'رویدادهای سامانه'}
NAVIGATION['work']='کارهای روزانه'
CHOICES={
 'mode':(['light','dark'],'روشنایی رابط'),'font':(['segoe','tahoma','arial','calibri','verdana'],'قلم رابط'),
 'size':(['standard','large'],'اندازهٔ قدیمی متن'),'rounding':(['soft','square'],'گوشهٔ قدیمی کارت‌ها'),'sidebar':(['standard','wide'],'عرض قدیمی منو'),
 'density':(['comfortable','compact'],'فاصلهٔ ردیف‌های جدول'),'shadow':(['none','soft','strong'],'سایهٔ کارت‌ها'),
 'background_fit':(['cover','contain','repeat'],'چیدمان تصویر پس‌زمینه'),'background_position':(['center','top','bottom','right','left'],'جای تصویر پس‌زمینه'),
}
COLORS={
 'primary':('#6d5ad6','رنگ اصلی'),'page_color':('#f7f8fc','رنگ زمینهٔ صفحه'),'card_color':('#ffffff','رنگ کارت‌ها'),
 'sidebar_color':('#ffffff','رنگ منوی کناری'),'sidebar_text':('#62667d','متن منوی کناری'),'header_color':('#ffffff','رنگ نوار بالایی'),
 'text_color':('#222538','رنگ متن اصلی'),'muted_color':('#6d7285','رنگ متن توضیحی'),'border_color':('#ececf3','رنگ خط و حاشیه'),
 'success_color':('#2c9a7c','رنگ موفقیت'),'warning_color':('#b57912','رنگ هشدار'),'danger_color':('#b63d53','رنگ خطا'),
}
NUMBERS={
 'font_size':(13,12,20,'اندازهٔ متن'),'heading_size':(27,20,38,'اندازهٔ عنوان صفحه'),'logo_size':(48,32,96,'اندازهٔ لوگو'),
 'sidebar_width':(246,200,360,'عرض منوی کناری'),'radius':(16,0,28,'گردی کارت‌ها'),'button_radius':(8,0,24,'گردی دکمه‌ها'),
 'background_opacity':(18,0,100,'وضوح تصویر پس‌زمینه؛ درصد'),'background_blur':(0,0,16,'تاری تصویر پس‌زمینه'),'card_opacity':(100,85,100,'وضوح کارت‌ها؛ درصد'),
}
FLAGS={'custom_colors':(False,'استفاده از رنگ‌های جزئی سفارشی'),'show_tagline':(True,'نمایش زیرعنوان کنار لوگو'),'show_footer':(True,'نمایش متن پایین صفحه')}
COPY={
 'login_heading':('همهٔ کارخانه، در یک تصویر روشن.',140,'عنوان صفحهٔ ورود'),
 'login_message':('قرارداد، انبار و امور مالی؛ متصل به هم، در اختیار شما و مستقل از اینترنت.',320,'توضیح صفحهٔ ورود'),
 'login_caption':('خوش آمدید',80,'پیام خوشامد'),'footer_text':('تمام مبالغ به ریال · تاریخ‌ها میلادی',220,'متن پایین صفحه'),
}
DEFAULT={'format':FORMAT,'version':2,'product_name':'آمار','product_code':'AMAR','tagline':'سامانه یکپارچه کارخانه','publisher':'AMAR',
 'theme':{'mode':'light','font':'segoe','size':'standard','rounding':'soft','sidebar':'standard','density':'comfortable','shadow':'soft','background_fit':'cover','background_position':'center',
 **{k:v[0] for k,v in COLORS.items()},**{k:v[0] for k,v in NUMBERS.items()},**{k:v[0] for k,v in FLAGS.items()}},
 'copy':{k:v[0] for k,v in COPY.items()},'navigation':{}}

class BrandError(ValueError):pass

def text(value,label,maximum,required=True):
 if not isinstance(value,str) or len(value.strip())>maximum or any(ord(c)<32 for c in value):raise BrandError('مقدار '+label+' معتبر نیست.')
 value=value.strip()
 if required and not value:raise BrandError(label+' الزامی است.')
 return value

def validate(value):
 if not isinstance(value,dict) or value.get('format')!=FORMAT or type(value.get('version')) is not int or value['version'] not in [1,2]:raise BrandError('قالب فایل هویت نرم‌افزار معتبر نیست.')
 if set(value)-set(DEFAULT):raise BrandError('گزینهٔ ناشناخته در فایل هویت وجود دارد.')
 result={**DEFAULT,'product_name':text(value.get('product_name'),'نام نرم‌افزار',100),'product_code':text(value.get('product_code','AMAR'),'شناسهٔ فایل اجرایی',40),
  'tagline':text(value.get('tagline',DEFAULT['tagline']),'زیرعنوان',140,False),'publisher':text(value.get('publisher','AMAR'),'ناشر',80)}
 reserved={'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}
 if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,39}',result['product_code']) or result['product_code'].upper() in reserved:raise BrandError('شناسهٔ فایل اجرایی با حرف انگلیسی شروع شود و فقط حرف، عدد، خط تیره یا زیرخط داشته باشد.')
 theme=value.get('theme',{});navigation=value.get('navigation',{});copy=value.get('copy',{})
 if not isinstance(theme,dict) or set(theme)-set(DEFAULT['theme']):raise BrandError('تنظیمات ظاهر معتبر نیست.')
 result['theme']={**DEFAULT['theme'],**theme}
 if value['version']==1:
  if 'font_size' not in theme and theme.get('size')=='large':result['theme']['font_size']=15
  if 'radius' not in theme and theme.get('rounding')=='square':result['theme']['radius']=4
  if 'sidebar_width' not in theme and theme.get('sidebar')=='wide':result['theme']['sidebar_width']=280
 for key in COLORS:
  color=result['theme'][key]
  if not isinstance(color,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',color):raise BrandError('رنگ باید کد شش‌رقمی باشد: '+COLORS[key][1])
  result['theme'][key]=color.lower()
 for key,(allowed,label) in CHOICES.items():
  if not isinstance(result['theme'][key],str) or result['theme'][key] not in allowed:raise BrandError('گزینهٔ ظاهر معتبر نیست: '+label)
 for key,(_,minimum,maximum,label) in NUMBERS.items():
  number=result['theme'][key]
  if type(number) is not int or not minimum<=number<=maximum:raise BrandError('مقدار '+label+' خارج از محدوده است.')
 for key,(_,label) in FLAGS.items():
  if type(result['theme'][key]) is not bool:raise BrandError('گزینهٔ '+label+' معتبر نیست.')
 if not isinstance(navigation,dict) or set(navigation)-set(NAVIGATION):raise BrandError('عنوان‌های منو معتبر نیستند.')
 result['navigation']={key:text(label,'عنوان منو',48) for key,label in navigation.items()}
 if not isinstance(copy,dict) or set(copy)-set(COPY):raise BrandError('متن‌های رابط معتبر نیستند.')
 result['copy']={key:text(copy.get(key,default),label,maximum,False) for key,(default,maximum,label) in COPY.items()}
 return result

def normalize_asset(data,kind='logo'):
 limit=MAX_BACKGROUND if kind=='background' else MAX_LOGO
 if len(data)>limit:raise BrandError('حجم تصویر از '+('۶' if kind=='background' else '۲')+' مگابایت بیشتر است.')
 from PIL import Image,ImageOps
 try:
  with Image.open(io.BytesIO(data)) as original:
   if original.format not in ['PNG','JPEG'] or original.width*original.height>(16000000 if kind=='background' else 8000000):raise BrandError('تصویر باید PNG یا JPEG و در محدودهٔ اندازهٔ مجاز باشد.')
   original.load();image=ImageOps.exif_transpose(original).convert('RGBA');side=2560 if kind=='background' else 1200;image.thumbnail((side,side))
   target=io.BytesIO();image.save(target,format='PNG',optimize=True)
   while target.tell()>limit:
    image.thumbnail((max(1,int(image.width*.85)),max(1,int(image.height*.85))));target=io.BytesIO();image.save(target,format='PNG',optimize=True)
   return target.getvalue(),image.width,image.height
 except BrandError:raise
 except Exception as error:raise BrandError('تصویر خوانا و معتبر نیست.') from error

def normalize_logo(data):return normalize_asset(data)

def icon_bytes(logo=None,primary='#6d5ad6'):
 from PIL import Image,ImageDraw,ImageFont
 canvas=Image.new('RGBA',(256,256),(0,0,0,0))
 if logo:
  with Image.open(io.BytesIO(logo)) as source:
   source=source.convert('RGBA');source.thumbnail((224,224));canvas.alpha_composite(source,((256-source.width)//2,(256-source.height)//2))
 else:
  draw=ImageDraw.Draw(canvas);draw.rounded_rectangle((8,8,248,248),radius=52,fill=primary);draw.text((128,132),'A',anchor='mm',font=ImageFont.load_default(size=155),fill='white')
 output=io.BytesIO();canvas.save(output,format='ICO',sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)]);return output.getvalue()

ASSETS={'logo':'logo.png','desktop_icon':'desktop-icon.png','background':'background.png'}

def read_bundle(data):
 if len(data)>MAX_BUNDLE:raise BrandError('فایل هویت بیش از حد بزرگ است.')
 try:
  with ZipFile(io.BytesIO(data)) as archive:
   names=archive.namelist()
   if len(names)!=len(set(names)) or set(names)-{'branding.json','README-fa.txt',*ASSETS.values()} or 'branding.json' not in names:raise BrandError('فایل هویت فقط باید شامل تنظیمات و تصاویر هویت باشد.')
   if archive.getinfo('branding.json').file_size>65536:raise BrandError('تنظیمات هویت بیش از حد بزرگ است.')
   value=validate(json.loads(archive.read('branding.json')));assets={}
   for kind,name in ASSETS.items():
    if name in names:
     if archive.getinfo(name).file_size>(MAX_BACKGROUND if kind=='background' else MAX_LOGO):raise BrandError('تصویر بیش از حد بزرگ است.')
     assets[kind]=normalize_asset(archive.read(name),kind)[0]
   return value,assets
 except BrandError:raise
 except Exception as error:raise BrandError('فایل هویت نرم‌افزار خوانا نیست.') from error

def asset_map(assets=None):return {'logo':assets} if isinstance(assets,bytes) else dict(assets or {})

def write_bundle(value,assets=None):
 value=validate(value);stream=io.BytesIO();assets=asset_map(assets)
 with ZipFile(stream,'w',ZIP_DEFLATED) as archive:
  archive.writestr('branding.json',json.dumps(value,ensure_ascii=False,indent=2))
  for kind,data in assets.items():archive.writestr(ASSETS[kind],normalize_asset(data,kind)[0])
  archive.writestr('README-fa.txt','این بسته فقط هویت ظاهری نرم‌افزار است؛ اطلاعات کارخانه و کلید ورود سازنده در آن نیست.\nفایل را در branding کارگاه خصوصی سازنده بگذارید و Build-Release.cmd را اجرا کنید.\n')
 return stream.getvalue()

def from_folder(folder):
 folder=Path(folder)
 if (folder/'AMAR-Branding.zip').is_file():return read_bundle((folder/'AMAR-Branding.zip').read_bytes())
 path=folder/'branding.json';value=validate(json.loads(path.read_text(encoding='utf-8-sig'))) if path.is_file() else validate(DEFAULT);assets={}
 for kind,name in ASSETS.items():
  for candidate in [name,name.replace('.png','.jpg'),name.replace('.png','.jpeg')]:
   if (folder/candidate).is_file():assets[kind]=normalize_asset((folder/candidate).read_bytes(),kind)[0];break
 return value,assets

def install_defaults(folder,value,assets=None):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);value=validate(value);assets=asset_map(assets)
 (folder/'branding.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
 for kind,name in ASSETS.items():
  if assets.get(kind):(folder/name).write_bytes(normalize_asset(assets[kind],kind)[0])
  else:(folder/name).unlink(missing_ok=True)
 (folder/'app.ico').write_bytes(icon_bytes(assets.get('desktop_icon') or assets.get('logo'),value['theme']['primary']))
 return value
