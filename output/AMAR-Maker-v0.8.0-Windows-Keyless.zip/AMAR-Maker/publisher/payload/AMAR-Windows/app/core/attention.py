"""Live exceptions plus assigned follow-up; resolving a case never rewrites stock or cash."""
import hashlib
import json
from datetime import timedelta
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Q, F, Sum, Value
from django.db.models.functions import Coalesce
from django.urls import reverse
from django.utils import timezone
from . import models as m, services
from .access import factory_ids, contracts_for, root, require_permission, require_factory
from .fields import QuantityField
from .pro_services import canonical, record_change, snapshot

KINDS={
    'stock':('کمبود موجودی','view_stockmovement'),
    'contract':('تأخیر تحویل قرارداد','view_contract'),
    'payment':('پرداخت منتظر تأیید','view_moneyentry'),
    'custody':('قطعهٔ تعیین‌تکلیف‌نشده','view_materialrequest'),
    'transfer':('انتقال در مسیر','view_stocktransfer'),
    'service':('موعد سرویس دستگاه','view_maintenanceplan'),
    'maintenance':('تأخیر تعمیر','view_maintenancejob'),
    'count':('موعد انبارگردانی','view_countschedule'),
    'quality':('بازرسی منتظر بررسی','view_deliveryinspection'),
    'exchange':('اطلاعات دریافت‌نشده یا قدیمی','view_importedsnapshot'),
}


def issues(actor,kind,pk=None,limit=40):
    if kind not in KINDS or not actor.has_perm('core.'+KINDS[kind][1]):return []
    ids=factory_ids(actor);today=timezone.localdate()
    days=m.SystemConfiguration.objects.values_list('overdue_days',flat=True).first() or 7
    cutoff=timezone.now()-timedelta(days=days)
    visible=contracts_for(actor)
    if kind=='stock':
        from .scalable_reports import AtMinimum
        query=m.StockSummary.objects.filter(warehouse__branch_id__in=ids).annotate(low=AtMinimum(F('milliunits'),F('item__minimum_stock'))).filter(low=True).select_related('warehouse__branch','item')
    elif kind=='contract':query=visible.filter(due_date__lt=today).exclude(status__in=['draft','cancelled','received']).select_related('warehouse__branch')
    elif kind=='payment':
        if not actor.has_perm('core.view_account'):return []
        query=m.PaymentRequest.objects.filter(allocation__account__branch_id__in=ids,allocation__contract__in=visible,status='pending',archived_at__isnull=True,created_at__lt=cutoff).select_related('allocation__account__branch','allocation__contract')
    elif kind=='custody':query=m.MaterialRequest.objects.filter(warehouse__branch_id__in=ids,status__in=['issued','closed'],created_at__lt=cutoff).annotate(settled=Coalesce(Sum('custody_events__quantity'),Value(0,output_field=QuantityField()))).annotate(held=F('quantity')-F('settled')).filter(held__gt=0).select_related('warehouse__branch','item','recipient')
    elif kind=='transfer':query=m.StockTransfer.objects.filter(Q(source__branch_id__in=ids)|Q(destination__branch_id__in=ids),status='transit',archived_at__isnull=True).select_related('source__branch','destination__branch','item')
    elif kind=='service':query=m.MaintenancePlan.objects.filter(equipment__branch_id__in=ids,equipment__archived_at__isnull=True,active=True,next_due__lte=today).select_related('equipment__branch')
    elif kind=='maintenance':query=m.MaintenanceJob.objects.filter(branch_id__in=ids,archived_at__isnull=True,due_on__lt=today).exclude(status__in=['closed','cancelled']).select_related('equipment','branch')
    elif kind=='count':query=m.CountSchedule.objects.filter(warehouse__branch_id__in=ids,active=True,next_due__lte=today).select_related('warehouse__branch')
    elif kind=='quality':query=m.DeliveryInspection.objects.filter(contract__in=visible,status='pending',archived_at__isnull=True).select_related('contract__warehouse__branch')
    else:query=m.ExchangePeer.objects.filter(Q(last_received_at__lt=cutoff)|Q(last_received_at__isnull=True,source__created_at__lt=cutoff),source__branch_id__in=ids).select_related('source__branch')
    if pk is not None:query=query.filter(pk=pk)
    rows=[]
    for obj in query.order_by('pk')[:limit]:
        contract=None;severity='warning'
        if kind=='stock':branch=obj.warehouse.branch;title=f'{obj.item.name} · {obj.warehouse.name}';data=[str(obj.quantity),str(obj.item.minimum_stock)];url=reverse('item_passport',args=[obj.item_id])
        elif kind=='contract':branch=obj.warehouse.branch;contract=obj;title=f'تحویل {obj.number}';data=[obj.status,str(obj.due_date),obj.revision_number];url=reverse('contract_detail',args=[obj.pk]);severity='danger'
        elif kind=='payment':branch=obj.allocation.account.branch;contract=obj.allocation.contract;title=f'سند {obj.reference}';data=[obj.status,obj.amount,obj.reference];url=reverse('operation_detail',args=['payment',obj.pk])
        elif kind=='custody':branch=obj.warehouse.branch;title=f'{obj.item.name} نزد {obj.recipient.name}';data=[str(obj.held),obj.status];url=reverse('operation_detail',args=['material',obj.pk])
        elif kind=='transfer':branch=obj.source.branch if obj.source.branch_id in ids else obj.destination.branch;title=f'{obj.item.name} · انتقال {obj.reference}';data=[obj.status,str(obj.quantity)];url=reverse('operation_detail',args=['transfer',obj.pk])
        elif kind=='service':branch=obj.equipment.branch;title=f'{obj.equipment.code} · {obj.title}';data=[str(obj.next_due),obj.version];url=reverse('maintenance_new')+'?plan='+str(obj.pk);severity='danger' if obj.equipment.critical else 'warning'
        elif kind=='maintenance':branch=obj.branch;title=f'{obj.number} · {obj.title}';data=[obj.status,obj.version];url=reverse('work_detail',args=['maintenance',obj.pk])
        elif kind=='count':branch=obj.warehouse.branch;title=f'{obj.warehouse.name} · {obj.title}';data=[str(obj.next_due),obj.version];url=reverse('count_new')+'?schedule='+str(obj.pk)
        elif kind=='quality':branch=obj.contract.warehouse.branch;contract=obj.contract;title=f'{obj.reference} · {obj.contract.number}';data=[obj.status,obj.version];url=reverse('work_detail',args=['inspection',obj.pk])
        else:branch=obj.source.branch;title=obj.source.label;data=[str(obj.last_received_at),obj.last_received_sequence];url=reverse('secure_exchange')
        rows.append({'key':kind+':'+str(obj.pk),'kind':kind,'pk':obj.pk,'branch':branch,'contract':contract,'title':title,'url':url,
            'fingerprint':hashlib.sha256(canonical(data)).hexdigest(),'severity':severity})
    return rows


def issue_for(actor,key):
    try:
        kind,value=key.split(':',1);pk=int(value)
        if pk<=0:raise ValueError()
    except (ValueError,TypeError):raise ValidationError('شناسهٔ هشدار معتبر نیست.')
    rows=issues(actor,kind,pk,1)
    if not rows:raise PermissionDenied('این هشدار در محدودهٔ فعلی شما نیست یا شرط آن برطرف شده است.')
    return rows[0]


def followups_for(actor):
    require_permission(actor,'view_followup')
    kinds=[kind for kind,(_,perm) in KINDS.items() if actor.has_perm('core.'+perm) and (kind!='payment' or actor.has_perm('core.view_account'))]
    query=m.FollowUp.objects.filter(branch_id__in=factory_ids(actor),key__regex=r'^('+ '|'.join(kinds) +r'):') if kinds else m.FollowUp.objects.none()
    return query.filter(Q(contract__isnull=True)|Q(contract__in=contracts_for(actor)))


@transaction.atomic
def follow_up(actor,key,data,version):
    require_permission(actor,'change_followup')
    existing=m.FollowUp.objects.select_for_update().filter(key=key).first()
    if existing:
        if not followups_for(actor).filter(pk=existing.pk).exists():raise PermissionDenied
        if existing.version!=version:raise ValidationError('پیگیری هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
        try:issue=issue_for(actor,key)
        except PermissionDenied:issue={'branch':existing.branch,'contract':existing.contract,'title':existing.title,'fingerprint':existing.fingerprint}
        before=snapshot(existing);obj=existing;obj.version+=1
    else:
        issue=issue_for(actor,key);before={};obj=m.FollowUp(key=key,branch=issue['branch'],contract=issue['contract'],title=issue['title'])
    assigned=data.get('assigned_to')
    if assigned and (not assigned.is_active or issue['branch'].pk not in factory_ids(assigned) or not assigned.has_perm('core.view_followup')):
        raise ValidationError('مسئول انتخاب‌شده باید به همین موقعیت و پیگیری‌ها دسترسی داشته باشد.')
    if assigned:
        kind=key.split(':',1)[0]
        if kind not in KINDS or not assigned.has_perm('core.'+KINDS[kind][1]) or kind=='payment' and not assigned.has_perm('core.view_account'):
            raise ValidationError('مسئول انتخاب‌شده باید مجوز دیدن بخش مربوط به این هشدار را داشته باشد.')
    if assigned and issue['contract'] and not contracts_for(assigned).filter(pk=issue['contract'].pk).exists():raise ValidationError('مسئول انتخاب‌شده به این قرارداد دسترسی ندارد.')
    obj.fingerprint=issue['fingerprint'];obj.updated_by=actor
    for name in ['assigned_to','due_on','status','note']:setattr(obj,name,data.get(name))
    obj.note=(obj.note or '').strip()
    if len(obj.note)>20000:raise ValidationError('شرح اقدام بیش از حد طولانی است.')
    if obj.status=='resolved' and len(obj.note)<10:raise ValidationError('برای پایان پیگیری، نتیجه را با دست‌کم ۱۰ حرف ثبت کنید.')
    obj.full_clean();obj.save();record_change(obj,actor,obj.branch,before,'ثبت اقدام و مسئول پیگیری',obj.contract)
    return obj
