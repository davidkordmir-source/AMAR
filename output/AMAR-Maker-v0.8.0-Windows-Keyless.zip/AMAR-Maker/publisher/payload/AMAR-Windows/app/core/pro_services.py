"""Scoped workflows, independent approvals and append-only corrections."""
import hashlib
import json
import uuid
from datetime import timedelta
from decimal import Decimal
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from . import models as m, services
from .access import ancestors, contracts_for, factory_ids, profile, require_contract, require_factory, require_permission, root
from .lifecycle import reason_text


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), cls=DjangoJSONEncoder).encode()


def snapshot(obj):
    values={field.attname:getattr(obj,field.attname) for field in obj._meta.concrete_fields}
    labels={}
    for field in obj._meta.concrete_fields:
        if field.is_relation and getattr(obj,field.attname):labels[field.attname]=str(getattr(obj,field.name))
        elif field.choices:labels[field.attname]=str(dict(field.flatchoices).get(getattr(obj,field.attname),getattr(obj,field.attname)))
    values['_labels']=labels
    if isinstance(obj,m.ApprovalPolicy) and obj.pk:
        values['roles']=list(obj.roles.order_by('pk').values_list('name',flat=True))
    return json.loads(canonical(values).decode())


def record_change(obj, actor, branch, before, reason, contract=None):
    after = snapshot(obj)
    detail = {'reason':reason, 'changes_sha256':hashlib.sha256(canonical({'before':before,'after':after})).hexdigest()}
    event = services.audit('ثبت تغییر با حفظ سابقه', str(obj)[:180], actor, canonical(detail).decode(), branch=branch, contract=contract)
    return m.ChangeRecord.objects.create(kind=obj._meta.model_name, object_id=obj.pk, branch=branch, contract=contract,
        title=str(obj)[:200], before=before, after=after, reason=reason, actor=actor, audit=event)


def writable_period(branch_id, at=None):
    day = timezone.localdate(at) if at else timezone.localdate()
    if m.FinancialPeriod.objects.filter(active=True,locked=True, starts_on__lte=day, ends_on__gte=day).filter(Q(branch__isnull=True)|Q(branch_id__in=ancestors(branch_id))).exists():
        raise ValidationError('دورهٔ مالی این تاریخ بسته است؛ ثبت یا بازنویسی سند در آن مجاز نیست.')


def approval_subject(kind, pk):
    if kind == 'contract':
        obj = m.Contract.objects.select_for_update().select_related('warehouse__branch').get(pk=pk)
        branch, contract, creator, amount = obj.warehouse.branch, obj, obj.created_by_id, int(obj.total)
        data = {'number':obj.number,'revision':obj.revision_number,'title':obj.title,'warehouse':obj.warehouse_id,'supplier':obj.supplier_id,
            'lines':list(obj.lines.order_by('pk').values('pk','item_id','quantity','unit_price'))}
    elif kind == 'payment':
        obj = m.PaymentRequest.objects.select_for_update().select_related('allocation__contract','allocation__account__branch').get(pk=pk)
        branch, contract, creator, amount = obj.allocation.account.branch, obj.allocation.contract, obj.requested_by_id, obj.amount
        data = {'allocation':obj.allocation_id,'amount':amount,'reference':obj.reference,'description':obj.description,'archived':obj.archived_at}
    elif kind == 'refund':
        obj = m.RefundRequest.objects.select_for_update().select_related('original__account__branch','original__allocation__contract').get(pk=pk)
        branch, contract, creator, amount = obj.original.account.branch, obj.original.allocation.contract, obj.requested_by_id, obj.original.amount
        data = {'original':obj.original_id,'reference':obj.reference,'reason':obj.reason,'archived':obj.archived_at,'version':obj.version}
    else:
        raise ValidationError('نوع سند تأیید معتبر نیست.')
    return obj, branch, contract, creator, amount, hashlib.sha256(canonical(data)).hexdigest()


@transaction.atomic
def approval_vote(kind, pk, actor, reject=False, note=''):
    if actor is None: return True
    require_permission(actor, 'approve_contract' if kind=='contract' else 'approve_operations')
    obj, branch, contract, creator, amount, digest = approval_subject(kind,pk)
    require_factory(actor,branch.pk)
    require_contract(actor,contract.pk,True)
    if kind=='contract' and obj.status!='draft':raise ValidationError('فقط نسخهٔ پیش‌نویس قرارداد منتظر تأیید است.')
    if creator == actor.pk or kind=='contract' and obj.revised_by_id == actor.pk:
        raise ValidationError('ثبت‌کننده یا ویرایش‌کننده نمی‌تواند سند خودش را تأیید کند.')
    case=m.ApprovalCase.objects.filter(kind=kind,object_id=pk,revision_digest=digest).first()
    if case is None:
        policies=list(m.ApprovalPolicy.objects.filter(kind=kind,active=True,minimum_amount__lte=amount).filter(
            Q(branch__isnull=True)|Q(branch_id=branch.pk)|Q(branch_id__in=ancestors(branch.pk),include_descendants=True)).prefetch_related('roles'))
        restrictions=[{r.pk for r in p.roles.all()} for p in policies if p.roles.all()]
        allowed=set.intersection(*restrictions) if restrictions else set()
        if restrictions and not allowed:
            raise ValidationError('نقش‌های قواعد تأیید با هم سازگار نیستند؛ مسئول سامانه قواعد را بررسی کند.')
        case=m.ApprovalCase.objects.create(kind=kind,object_id=pk,revision_digest=digest,branch=branch,contract=contract,
            document_version=obj.revision_number if kind=='contract' else getattr(obj,'version',0),
            title=contract.number if kind=='contract' else obj.reference,amount=amount,requested_by_id=creator,
            required_votes=max([p.required_votes for p in policies] or [1]),allowed_roles=sorted(allowed),
            policy_snapshot=[{'id':p.pk,'name':p.name,'votes':p.required_votes,'minimum':p.minimum_amount} for p in policies])
    case=m.ApprovalCase.objects.select_for_update().get(pk=case.pk)
    if case.allowed_roles and not root(actor) and (not profile(actor) or profile(actor).role_id not in case.allowed_roles):
        raise PermissionDenied('نقش شما در قاعدهٔ تأیید این سند انتخاب نشده است.')
    if case.status=='rejected': raise ValidationError('این نسخه رد شده است؛ ثبت‌کننده باید سند را ویرایش و دوباره ارسال کند.')
    if case.status=='approved': return True
    decision='reject' if reject else 'approve'
    previous=m.ApprovalVote.objects.filter(case=case,actor=actor).first()
    if previous:
        if previous.decision!=decision: raise ValidationError('رأی ثبت‌شده قابل بازنویسی نیست.')
        return case.status=='approved'
    m.ApprovalVote.objects.create(case=case,actor=actor,decision=decision,note=note[:240])
    if reject: case.status='rejected'
    elif case.votes.filter(decision='approve').count()>=case.required_votes: case.status='approved'
    case.save(update_fields=['status'])
    if case.status!='approved':
        services.audit('رد مستقل سند' if reject else 'ثبت رأی مستقل',case.title,actor,
            f'{case.votes.filter(decision="approve").count()} از {case.required_votes} تأیید',branch=branch,contract=contract)
    return case.status=='approved'


@transaction.atomic
def request_refund(actor, original, reference, reason, key):
    require_permission(actor,'add_refundrequest');require_factory(actor,original.account.branch_id)
    if original.kind!='payment' or not original.allocation_id:
        raise ValidationError('فقط پرداخت قطعی به تولیدکننده قابل برگشت است.')
    require_contract(actor,original.allocation.contract_id,True)
    m.Contract.all_objects.select_for_update().get(pk=original.allocation.contract_id)
    m.Account.objects.select_for_update().get(pk=original.account_id)
    m.MoneyEntry.objects.select_for_update().get(pk=original.pk)
    previous=services.replay(m.RefundRequest,key,original_id=original.pk,reference=reference,requested_by_id=actor.pk)
    if previous:return previous
    if m.MoneyEntry.objects.filter(reverses=original).exists() or m.RefundRequest.objects.filter(original=original,status='pending',archived_at__isnull=True).exists():
        raise ValidationError('برای این پرداخت، برگشت ثبت‌شده یا درخواست باز وجود دارد.')
    reason=reason_text(reason)
    obj=m.RefundRequest.objects.create(original=original,reference=reference.strip(),reason=reason,requested_by=actor,operation_key=key)
    obj.full_clean()
    record_change(obj,actor,original.account.branch,{},reason,original.allocation.contract)
    return obj


@transaction.atomic
def approve_refund(actor, pk, reject=False):
    info=m.RefundRequest.objects.values('original__allocation__contract_id','original__account_id').get(pk=pk)
    m.Contract.all_objects.select_for_update().get(pk=info['original__allocation__contract_id'])
    m.Account.objects.select_for_update().get(pk=info['original__account_id'])
    obj=m.RefundRequest.objects.select_for_update().select_related('original__account__branch','original__allocation__contract').get(pk=pk)
    require_permission(actor,'approve_operations');require_factory(actor,obj.original.account.branch_id);require_contract(actor,obj.original.allocation.contract_id,True)
    if obj.status in ('approved','rejected'):return obj
    if obj.status!='pending' or obj.archived_at:raise ValidationError('درخواست برگشت فعال نیست.')
    completed=approval_vote('refund',pk,actor,reject, obj.reason)
    if not reject and not completed:return obj
    before=snapshot(obj)
    if reject:obj.status='rejected'
    else:
        writable_period(obj.original.account.branch_id)
        original=m.MoneyEntry.objects.select_for_update().get(pk=obj.original_id)
        if m.MoneyEntry.objects.filter(reverses=original).exists():raise ValidationError('این پرداخت قبلاً برگشت خورده است.')
        services.positive(original.account.balance+original.amount+original.account.credit_limit,money=True)
        obj.entry=m.MoneyEntry.objects.create(kind='refund',account=original.account,allocation=original.allocation,
            amount=original.amount,reference=obj.reference,description=obj.reason,reverses=original,created_by=actor,operation_key=obj.operation_key)
        obj.status='approved'
    obj.approved_by=actor;obj.save()
    record_change(obj,actor,obj.original.account.branch,before,obj.reason,obj.original.allocation.contract)
    return obj


def _inspection_payload(contract, quantities, locations, traces):
    lines={line.pk:line for line in contract.lines.select_related('item')}
    result={}
    if not quantities or set(quantities)-set(lines):raise ValidationError('ردیف‌های تحویل متعلق به قرارداد نیستند.')
    for pk, value in quantities.items():
        quantity=services.item_quantity(lines[pk].item,value)
        location=locations.get(pk);trace=traces.get(pk)
        from .operations import validate_bucket
        validate_bucket(contract.warehouse,lines[pk].item,location,trace,quantity,require_location=True)
        if quantity>lines[pk].quantity-lines[pk].received:raise ValidationError('مقدار از ماندهٔ تحویل قرارداد بیشتر است.')
        result[str(pk)]={'quantity':str(quantity),'location':location.pk,'trace':trace.pk if trace else None,
            'label':str(lines[pk].item),'location_label':str(location),'trace_label':trace.code if trace else ''}
    return result


@transaction.atomic
def request_inspection(actor, contract, quantities, locations, traces, reference, notes, key, document=None, existing=None, version=None, reason='ثبت بازرسی تحویل'):
    require_permission(actor,'add_deliveryinspection' if existing is None else 'change_deliveryinspection')
    require_contract(actor,contract.pk,True)
    contract=m.Contract.objects.select_for_update().get(pk=contract.pk)
    require_factory(actor,contract.warehouse.branch_id)
    if not contract.is_open:raise ValidationError('بازرسی فقط برای قرارداد فعال و تأییدشده ثبت می‌شود.')
    if document and (document.branch_id!=contract.warehouse.branch_id or document.contract_id not in (None,contract.pk)):
        raise ValidationError('سند پیوست باید متعلق به همین موقعیت و قرارداد باشد.')
    if document:
        from .documents import visible_documents
        if not visible_documents(actor).filter(pk=document.pk).exists():raise PermissionDenied('به سند بازرسی دسترسی ندارید.')
    payload=_inspection_payload(contract,quantities,locations,traces)
    if existing is not None:
        obj=m.DeliveryInspection.objects.select_for_update().get(pk=existing.pk)
        require_contract(actor,obj.contract_id,True)
        if obj.status!='pending' or obj.receipt_id or obj.archived_at:raise ValidationError('بازرسی تعیین‌تکلیف‌شده بازنویسی نمی‌شود.')
        if obj.version!=version:raise ValidationError('اطلاعات هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
        before=snapshot(obj);reason=reason_text(reason);obj.version+=1;obj.requested_by=actor
    else:
        previous=services.replay(m.DeliveryInspection,key,contract_id=contract.pk,reference=reference,requested_by_id=actor.pk,payload=payload)
        if previous:return previous
        obj=m.DeliveryInspection(contract=contract,requested_by=actor,operation_key=key);before={}
    obj.reference=reference.strip();obj.payload=payload;obj.notes=notes;obj.document=document;obj.contract_revision=contract.revision_number
    obj.full_clean();obj.save()
    record_change(obj,actor,contract.warehouse.branch,before,reason,contract)
    return obj


@transaction.atomic
def review_inspection(actor,pk,accepted,note):
    obj=m.DeliveryInspection.objects.select_for_update().select_related('contract__warehouse__branch').get(pk=pk)
    require_permission(actor,'review_deliveryinspection');require_contract(actor,obj.contract_id,True)
    require_factory(actor,obj.contract.warehouse.branch_id)
    if obj.requested_by_id==actor.pk:raise ValidationError('بازرس تأییدکننده باید از ثبت‌کننده مستقل باشد.')
    if obj.status!='pending' or obj.archived_at:raise ValidationError('این بازرسی قبلاً تعیین تکلیف شده است.')
    note=reason_text(note);before=snapshot(obj)
    if accepted and obj.contract_revision!=obj.contract.revision_number:raise ValidationError('قرارداد پس از ثبت بازرسی ویرایش شده است؛ ابتدا بازرسی را با ردیف‌های جدید ویرایش کنید.')
    obj.status='accepted' if accepted else 'rejected';obj.reviewed_by=actor;obj.reviewed_at=timezone.now();obj.decision_note=note
    obj.save()
    if accepted:
        quantities={int(pk):Decimal(row['quantity']) for pk,row in obj.payload.items()}
        locations={int(pk):m.StorageLocation.objects.get(pk=row['location']) for pk,row in obj.payload.items()}
        traces={int(pk):(m.TraceUnit.objects.get(pk=row['trace']) if row['trace'] else None) for pk,row in obj.payload.items()}
        obj.receipt=services.receive(obj.contract_id,quantities,obj.reference,obj.operation_key,actor,locations,traces,inspection=obj)
        obj.save(update_fields=['receipt'])
    record_change(obj,actor,obj.contract.warehouse.branch,before,note,obj.contract)
    return obj


def validate_equipment(obj):
    if obj.custodian and (obj.custodian.branch_id!=obj.branch_id or not obj.custodian.active):raise ValidationError('مسئول نگهداری باید فعال و متعلق به همین موقعیت باشد.')
    if obj.location and obj.location.warehouse.branch_id!=obj.branch_id:raise ValidationError('محل نگهداری متعلق به موقعیت دیگری است.')
    if obj.trace and (not obj.item_id or obj.trace.item_id!=obj.item_id or obj.item.tracking!='serial'):
        raise ValidationError('سریال باید متعلق به همان کالای دارای ردیابی سریالی باشد.')
    if obj.trace_id:
        if m.StockBalance.objects.filter(trace_id=obj.trace_id,quantity__gt=0).exclude(warehouse__branch_id=obj.branch_id).exists():
            raise ValidationError('این سریال در موجودی موقعیت دیگری است.')
        if m.StockTransfer.objects.filter(trace_id=obj.trace_id,status='transit').exists():
            raise ValidationError('سریال در حال انتقال است؛ پس از دریافت مقصد شناسنامه را ویرایش کنید.')
    if obj.warranty_until and obj.installed_on and obj.warranty_until<obj.installed_on:raise ValidationError('پایان ضمانت پیش از تاریخ نصب است.')


@transaction.atomic
def save_equipment(actor,data,pk=None,version=None,reason='ثبت شناسنامهٔ دستگاه'):
    require_permission(actor,'change_equipment' if pk else 'add_equipment')
    obj=m.Equipment.objects.select_for_update().get(pk=pk) if pk else m.Equipment(created_by=actor)
    if pk:
        require_factory(actor,obj.branch_id)
        if obj.archived_at:raise ValidationError('دارایی حذف‌شده قابل ویرایش نیست.')
        if obj.version!=version:raise ValidationError('اطلاعات هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
        if obj.branch_id!=data['branch'].pk:raise ValidationError('جابه‌جایی موقعیت دارایی از مسیر انتقال کنترل‌شده انجام می‌شود.')
        reason=reason_text(reason)
    before=snapshot(obj) if pk else {}
    for name,value in data.items():setattr(obj,name,value)
    require_factory(actor,obj.branch_id);validate_equipment(obj)
    if pk:obj.version+=1
    obj.full_clean();obj.save();record_change(obj,actor,obj.branch,before,reason)
    return obj


@transaction.atomic
def save_maintenance_plan(actor,data,pk=None,version=None,reason='ثبت برنامهٔ سرویس'):
    require_permission(actor,'change_maintenanceplan' if pk else 'add_maintenanceplan')
    obj=m.MaintenancePlan.objects.select_for_update().get(pk=pk) if pk else m.MaintenancePlan()
    if pk:
        require_factory(actor,obj.equipment.branch_id)
        if obj.version!=version:raise ValidationError('برنامه هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
        if data['equipment'].pk!=obj.equipment_id and obj.maintenancejob_set.exists():raise ValidationError('دستگاه برنامه‌ای که کار ثبت‌شده دارد قابل تعویض نیست؛ برنامهٔ تازه بسازید.')
        reason=reason_text(reason)
    before=snapshot(obj) if pk else {}
    for name,value in data.items():setattr(obj,name,value)
    require_factory(actor,obj.equipment.branch_id)
    if obj.equipment.archived_at:raise ValidationError('دستگاه حذف‌شده است.')
    if pk:obj.version+=1
    obj.full_clean();obj.save();record_change(obj,actor,obj.equipment.branch,before,reason)
    return obj


@transaction.atomic
def request_maintenance(actor,data,key,pk=None,version=None,reason='ثبت درخواست تعمیر یا سرویس'):
    require_permission(actor,'change_maintenancejob' if pk else 'add_maintenancejob')
    equipment=m.Equipment.objects.select_for_update().get(pk=data['equipment'].pk)
    require_factory(actor,equipment.branch_id)
    if equipment.archived_at or equipment.status=='retired':raise ValidationError('دستگاه فعال نیست.')
    if pk:
        obj=m.MaintenanceJob.objects.select_for_update().get(pk=pk)
        require_factory(actor,obj.branch_id)
        if obj.status not in ('open','working') or obj.archived_at:raise ValidationError('کار تعیین‌تکلیف‌شده بازنویسی نمی‌شود.')
        if obj.version!=version:raise ValidationError('اطلاعات هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
        if obj.equipment_id!=equipment.pk:raise ValidationError('دستگاه کار ثبت‌شده قابل تعویض نیست.')
        before=snapshot(obj);reason=reason_text(reason);obj.version+=1
    else:
        previous=services.replay(m.MaintenanceJob,key,equipment_id=equipment.pk,title=data['title'],requested_by_id=actor.pk)
        if previous:return previous
        work=m.WorkOrder.objects.create(branch=equipment.branch,number='MT-'+key.hex[:20].upper(),title=data['title'],asset=equipment.code)
        obj=m.MaintenanceJob(equipment=equipment,branch=equipment.branch,work_order=work,requested_by=actor,operation_key=key);before={}
    for name,value in data.items():setattr(obj,name,value)
    if obj.plan_id and (obj.plan.equipment_id!=equipment.pk or not obj.plan.active):raise ValidationError('برنامهٔ سرویس متعلق به این دستگاه نیست یا غیرفعال است.')
    if obj.technician_id and (obj.technician.branch_id!=equipment.branch_id or not obj.technician.active):raise ValidationError('مسئول انجام متعلق به موقعیت دیگری است یا فعال نیست.')
    obj.full_clean();obj.save();record_change(obj,actor,equipment.branch,before,reason)
    return obj


@transaction.atomic
def maintenance_result(actor,pk,result,cost,downtime,payment=None,document=None,version=None):
    require_permission(actor,'change_maintenancejob')
    obj=m.MaintenanceJob.objects.select_for_update().select_related('equipment__branch').get(pk=pk)
    require_factory(actor,obj.branch_id)
    if obj.status not in ('open','working') or obj.archived_at:raise ValidationError('کار قابل ثبت نتیجه نیست.')
    if obj.version!=version:raise ValidationError('کار هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
    result=(result or '').strip()
    if not 10<=len(result)<=20000:raise ValidationError('گزارش نتیجه باید بین ۱۰ تا ۲۰۰۰۰ حرف باشد.')
    preserve_payment=bool(obj.payment_id and not (actor.has_perm('core.view_moneyentry') and actor.has_perm('core.view_account')))
    if obj.payment_id:
        if preserve_payment:
            payment=obj.payment
        elif payment is None or payment.pk!=obj.payment_id:
            raise ValidationError('پیوند پرداخت قطعی این کار قابل حذف یا جایگزینی نیست؛ اصلاح مالی از مسیر برگشت پرداخت انجام می‌شود.')
    if payment and not preserve_payment:
        require_permission(actor,'view_moneyentry');require_permission(actor,'view_account')
        if payment.kind!='payment' or payment.account.branch_id!=obj.branch_id:raise ValidationError('سند پرداخت متعلق به این موقعیت نیست.')
        require_contract(actor,payment.allocation.contract_id)
    preserve_document=bool(obj.document_id and not actor.has_perm('core.view_document'))
    if preserve_document:document=obj.document
    if document and not preserve_document:
        from .documents import visible_documents
        if not visible_documents(actor).filter(pk=document.pk,branch_id=obj.branch_id).exists():raise PermissionDenied('به سند مرتبط دسترسی ندارید.')
    before=snapshot(obj);obj.result=result;obj.reported_cost=cost;obj.downtime_minutes=downtime;obj.payment=payment;obj.document=document
    obj.status='review';obj.version+=1;obj.result_by=actor;obj.full_clean();obj.save()
    record_change(obj,actor,obj.branch,before,'ثبت نتیجه برای تأیید مستقل')
    return obj


@transaction.atomic
def review_maintenance(actor,pk,accept,note):
    require_permission(actor,'review_maintenancejob')
    obj=m.MaintenanceJob.objects.select_for_update().select_related('equipment__branch','plan').get(pk=pk)
    require_factory(actor,obj.branch_id)
    if actor.pk in (obj.requested_by_id,obj.result_by_id):raise ValidationError('تأییدکنندهٔ پایان کار باید از ثبت‌کننده و انجام‌دهنده مستقل باشد.')
    if obj.status!='review' or obj.archived_at:raise ValidationError('این کار منتظر تأیید نتیجه نیست.')
    before=snapshot(obj);note=reason_text(note)
    if accept:
        if m.MaterialRequest.objects.filter(work_order=obj.work_order,status__in=['pending','approved'],archived_at__isnull=True).exists():
            raise ValidationError('ابتدا درخواست‌های باز قطعهٔ این کار را تعیین تکلیف کنید.')
        for request in m.MaterialRequest.objects.filter(work_order=obj.work_order,status__in=['issued','closed']):
            if request.remaining:raise ValidationError('ابتدا مصرف یا برگشت تمام قطعات تحویلی این کار را ثبت کنید.')
        obj.status='closed';obj.completed_at=timezone.now();obj.reviewed_by=actor
        obj.work_order.active=False;obj.work_order.save(update_fields=['active'])
        if obj.plan_id:
            plan=m.MaintenancePlan.objects.select_for_update().get(pk=obj.plan_id)
            plan.last_completed=timezone.localdate();plan.next_due=plan.last_completed+timedelta(days=plan.interval_days);plan.version+=1;plan.save()
    else:obj.status='working'
    obj.version+=1;obj.save();record_change(obj,actor,obj.branch,before,note)
    return obj


@transaction.atomic
def save_count_schedule(actor,data,pk=None,version=None,reason='ثبت برنامهٔ انبارگردانی'):
    require_permission(actor,'change_countschedule' if pk else 'add_countschedule')
    obj=m.CountSchedule.objects.select_for_update().get(pk=pk) if pk else m.CountSchedule()
    if pk:
        require_factory(actor,obj.warehouse.branch_id)
        if obj.version!=version:raise ValidationError('برنامه هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
        if data['warehouse'].pk!=obj.warehouse_id and obj.runs.exists():raise ValidationError('انبار برنامه‌ای که شمارش ثبت‌شده دارد قابل تعویض نیست؛ برنامهٔ تازه بسازید.')
        reason=reason_text(reason)
    before=snapshot(obj) if pk else {}
    for name,value in data.items():setattr(obj,name,value)
    require_factory(actor,obj.warehouse.branch_id)
    if pk:obj.version+=1
    obj.full_clean();obj.save();record_change(obj,actor,obj.warehouse.branch,before,reason)
    return obj


def count_completed(count):
    run=m.CountScheduleRun.objects.select_related('schedule').filter(count=count).first()
    if run:
        schedule=m.CountSchedule.objects.select_for_update().get(pk=run.schedule_id)
        schedule.last_count=count;schedule.next_due=timezone.localdate()+timedelta(days=schedule.interval_days);schedule.version+=1;schedule.save()


@transaction.atomic
def archive_record(actor,kind,pk,reason):
    models={'equipment':m.Equipment,'inspection':m.DeliveryInspection,'maintenance':m.MaintenanceJob,'refund':m.RefundRequest}
    if kind not in models:raise ValidationError('نوع رکورد معتبر نیست.')
    model=models[kind];require_permission(actor,'delete_'+model._meta.model_name)
    obj=model.objects.select_for_update().get(pk=pk);reason=reason_text(reason)
    branch=obj.branch if kind in ('equipment','maintenance') else obj.contract.warehouse.branch if kind=='inspection' else obj.original.account.branch
    require_factory(actor,branch.pk)
    contract=obj.contract if kind=='inspection' else obj.original.allocation.contract if kind=='refund' else None
    if contract:require_contract(actor,contract.pk,True)
    if kind=='equipment' and (obj.jobs.filter(payment__isnull=False).exists() or obj.jobs.exclude(status__in=['closed','cancelled']).filter(archived_at__isnull=True).exists()):raise ValidationError('دارایی دارای پرداخت یا کار باز قابل حذف نیست.')
    if kind=='inspection' and (obj.receipt_id or obj.contract.allocations.filter(payments__kind='payment').exists()):raise ValidationError('بازرسی دارای تحویل یا پرداخت قابل حذف نیست.')
    if kind=='maintenance' and (obj.payment_id or obj.status=='closed' or m.MaterialRequest.objects.filter(work_order=obj.work_order,status__in=['approved','issued','closed']).exists()):raise ValidationError('کار دارای پرداخت، قطعه یا تأیید نهایی قابل حذف نیست.')
    if kind=='refund' and obj.entry_id:raise ValidationError('برگشت قطعی حذف نمی‌شود.')
    before=snapshot(obj);obj.archived_at=timezone.now();obj.archived_by=actor;obj.archive_reason=reason
    if kind in ('maintenance','refund'):obj.status='cancelled'
    if kind=='maintenance':
        obj.work_order.active=False;obj.work_order.save(update_fields=['active'])
        m.MaterialRequest.objects.filter(work_order=obj.work_order,status='pending').update(status='cancelled')
    obj.save();record_change(obj,actor,branch,before,reason,contract)
    return obj


@transaction.atomic
def revise_refund(actor,pk,reference,reason,version):
    require_permission(actor,'change_refundrequest')
    obj=m.RefundRequest.objects.select_for_update().select_related('original__account__branch','original__allocation__contract').get(pk=pk)
    require_factory(actor,obj.original.account.branch_id);require_contract(actor,obj.original.allocation.contract_id,True)
    if obj.status!='pending' or obj.archived_at or obj.entry_id:raise ValidationError('فقط درخواست برگشتِ تعیین‌تکلیف‌نشده قابل ویرایش است.')
    if obj.version!=version:raise ValidationError('درخواست هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
    before=snapshot(obj);obj.reference=reference.strip();obj.reason=reason_text(reason);obj.requested_by=actor;obj.version+=1
    obj.full_clean();obj.save();record_change(obj,actor,obj.original.account.branch,before,obj.reason,obj.original.allocation.contract)
    return obj


@transaction.atomic
def save_rule(actor,kind,data,pk=None,version=None,reason='ثبت قاعدهٔ سازمانی'):
    mapping={'policy':m.ApprovalPolicy,'period':m.FinancialPeriod,'quality':m.QualityPolicy}
    if kind not in mapping:raise ValidationError('نوع قاعده معتبر نیست.')
    model=mapping[kind];require_permission(actor,('change_' if pk else 'add_')+model._meta.model_name)
    obj=model.objects.select_for_update().get(pk=pk) if pk else model()
    if pk:
        if obj.branch_id:require_factory(actor,obj.branch_id)
        elif not root(actor):raise PermissionDenied
        if obj.version!=version:raise ValidationError('قاعده هم‌زمان تغییر کرده؛ صفحه را تازه کنید.')
        reason=reason_text(reason)
    before=snapshot(obj) if pk else {}
    roles=data.pop('roles',None)
    for name,value in data.items():setattr(obj,name,value)
    if obj.branch_id:require_factory(actor,obj.branch_id)
    elif not root(actor):raise PermissionDenied('قاعدهٔ کل مجموعه فقط با حساب ارشد تنظیم می‌شود.')
    if kind=='period':
        # Money writes lock their account first. Closing a period follows the
        # same order so an in-flight posting cannot pass a newly closed period.
        ids=__import__('core.access',fromlist=['descendants']).descendants(obj.branch_id) if obj.branch_id else factory_ids(actor)
        list(m.Account.objects.select_for_update().filter(branch_id__in=ids).order_by('pk'))
        obj.changed_by=actor
    if pk:obj.version+=1
    obj.full_clean();obj.save()
    if roles is not None:obj.roles.set(roles)
    if obj.branch_id:record_change(obj,actor,obj.branch,before,reason)
    else:services.audit('تغییر قاعدهٔ کل مجموعه',str(obj._meta.verbose_name),actor,canonical({'reason':reason,'before':before,'after':snapshot(obj)}).decode())
    return obj


@transaction.atomic
def deactivate_rule(actor,kind,pk,reason):
    mapping={'policy':m.ApprovalPolicy,'period':m.FinancialPeriod,'quality':m.QualityPolicy,'plan':m.MaintenancePlan,'count':m.CountSchedule}
    if kind not in mapping:raise ValidationError('نوع قاعده معتبر نیست.')
    model=mapping[kind];require_permission(actor,'delete_'+model._meta.model_name)
    obj=model.objects.select_for_update().get(pk=pk);reason=reason_text(reason)
    branch=obj.equipment.branch if kind=='plan' else obj.warehouse.branch if kind=='count' else obj.branch
    if branch:require_factory(actor,branch.pk)
    elif not root(actor):raise PermissionDenied
    if kind=='plan' and obj.maintenancejob_set.filter(payment__isnull=False).exists():raise ValidationError('برنامهٔ دارای پرداخت حذف نمی‌شود؛ آن را از مسیر ویرایش غیرفعال کنید.')
    if kind in ('policy','period','quality'):
        payments=m.MoneyEntry.objects.filter(kind='payment')
        if branch:payments=payments.filter(account__branch_id__in=__import__('core.access',fromlist=['descendants']).descendants(branch.pk))
        if kind=='period':payments=payments.filter(created_at__date__gte=obj.starts_on,created_at__date__lte=obj.ends_on)
        if payments.exists():raise ValidationError('پرداخت مالی مرتبط وجود دارد؛ حذف قاعده مجاز نیست. ویرایش با ثبت علت انجام می‌شود.')
    before=snapshot(obj)
    if kind=='quality':obj.required=False
    else:obj.active=False
    obj.version+=1;obj.save()
    if branch:record_change(obj,actor,branch,before,reason)
    else:services.audit('حذف از فهرست قواعد فعال',obj._meta.verbose_name,actor,reason)
    return obj
