"""Bounded read models for installations with many units and inventory rows."""
from collections import defaultdict
from decimal import Decimal,localcontext
from django.db.models import F,Q,Sum,OuterRef,Subquery,Value,Func,BooleanField
from django.db.models.functions import Coalesce
from . import models as m
from .fields import QuantityField
from .access import factory_ids,contracts_for

def contract_values(objects):
    objects=list(objects)
    for contract in objects:
        contract._report_values={'total':Decimal(contract.total_cached),'paid':int(contract.paid_cached)}
    return objects

def allocation_values(objects):
    objects=list(objects);paid=defaultdict(int)
    for allocation,amount,kind in m.MoneyEntry.objects.filter(kind__in=['payment','refund'],allocation_id__in=[row.pk for row in objects]).values_list('allocation_id','amount','kind'):
        paid[allocation]+=amount if kind=='payment' else -amount
    for row in objects:row._report_paid=paid[row.pk]
    return objects

def inventory_iterator(user,branch=None,search='',ids=None,contract_ids=None):
    from itertools import islice
    ids=factory_ids(user) if ids is None else ids
    iterator=inventory_keys(user,branch,search,ids,contract_ids).iterator(chunk_size=500)
    while batch:=list(islice(iterator,100)):
        yield from inventory_page_rows(batch,user,ids,contract_ids)

class AtMinimum(Func):
    output_field=BooleanField()
    def as_sql(self,compiler,connection,**kwargs):
        left,lp=compiler.compile(self.source_expressions[0]);right,rp=compiler.compile(self.source_expressions[1])
        # Minimum stock fits int64. SQLite's positive saturation cannot turn a
        # larger nonnegative total into a false shortage; PostgreSQL uses NUMERIC.
        cast='INTEGER' if connection.vendor=='sqlite' else 'NUMERIC(80,0)'
        return f'(CAST({left} AS {cast}) <= {right})',lp+rp

def pending_lines(user,ids=None,contract_ids=None):
    ids=factory_ids(user) if ids is None else ids
    contracts=contracts_for(user) if contract_ids is None else m.Contract.objects.filter(pk__in=contract_ids)
    received=m.StockMovement.objects.filter(contract_line_id=OuterRef('pk')).order_by().values('contract_line_id').annotate(total=Sum('quantity')).values('total')
    return m.ContractLine.objects.filter(contract__in=contracts,contract__warehouse__branch_id__in=ids).exclude(contract__status__in=['draft','cancelled','received']).annotate(
        received_quantity=Coalesce(Subquery(received,output_field=QuantityField()),Value(0,output_field=QuantityField()))).filter(quantity__gt=F('received_quantity'))

def _search(prefix,query):
    return Q(**{prefix+'item__name__icontains':query})|Q(**{prefix+'item__sku__icontains':query})|Q(**{prefix+'item__barcode__icontains':query})

def inventory_keys(user,branch=None,search='',ids=None,contract_ids=None):
    ids=factory_ids(user) if ids is None else ids
    summaries=m.StockSummary.objects.filter(warehouse__branch_id__in=ids)
    lines=pending_lines(user,ids,contract_ids)
    if branch:summaries=summaries.filter(warehouse__branch_id=branch);lines=lines.filter(contract__warehouse__branch_id=branch)
    if search:
        summaries=summaries.filter(_search('',search)|Q(warehouse__name__icontains=search)|Q(warehouse__branch__name__icontains=search)|Q(warehouse__branch__city__icontains=search)|Q(warehouse__parent__name__icontains=search))
        lines=lines.filter(_search('',search)|Q(contract__warehouse__name__icontains=search)|Q(contract__warehouse__branch__name__icontains=search)|Q(contract__warehouse__branch__city__icontains=search))
    return summaries.order_by().values('warehouse_id','item_id').union(lines.order_by().annotate(warehouse_id=F('contract__warehouse_id')).values('warehouse_id','item_id')).order_by('warehouse_id','item_id')

def inventory_page_rows(keys,user,ids=None,contract_ids=None):
    keys=[(row['warehouse_id'],row['item_id']) for row in keys]
    if not keys:return []
    ids=factory_ids(user) if ids is None else ids
    selected=set(keys);where=Q(pk__in=[])
    for warehouse,item in keys:where|=Q(warehouse_id=warehouse,item_id=item)
    balances={(b.warehouse_id,b.item_id):b.quantity for b in m.StockSummary.objects.filter(where)}
    pending=defaultdict(lambda:Decimal(0))
    line_filter=Q(pk__in=[])
    for warehouse,item in keys:line_filter|=Q(contract__warehouse_id=warehouse,item_id=item)
    for line in pending_lines(user,ids,contract_ids).filter(line_filter).select_related('contract'):
        pending[(line.contract.warehouse_id,line.item_id)]+=line.quantity-line.received_quantity
    reserved=defaultdict(lambda:Decimal(0));held=defaultdict(lambda:Decimal(0))
    requests=m.MaterialRequest.objects.filter(where,status__in=['approved','issued']).values('pk','warehouse_id','item_id','quantity','status')
    requests=list(requests)
    settled=defaultdict(lambda:Decimal(0))
    for event in m.CustodyEvent.objects.filter(request_id__in=m.MaterialRequest.objects.filter(where,status='issued').values('pk')).values('request_id','quantity'):
        settled[event['request_id']]+=event['quantity']
    for request in requests:
        pair=(request['warehouse_id'],request['item_id'])
        if request['status']=='approved':reserved[pair]+=request['quantity']
        else:held[pair]+=request['quantity']-settled[request['pk']]
    transfers=Q(pk__in=[])
    for warehouse,item in keys:transfers|=Q(source_id=warehouse,item_id=item)
    for row in m.StockTransfer.objects.filter(transfers,status='approved').values('source_id','item_id','quantity'):reserved[(row['source_id'],row['item_id'])]+=row['quantity']
    warehouses=m.Warehouse.objects.filter(pk__in={w for w,i in keys}).select_related('branch__locality__parent__parent__parent__parent__parent','parent__parent__parent__parent').in_bulk()
    items=m.Item.objects.in_bulk({i for w,i in keys})
    return [{'warehouse':warehouses[w],'item':items[i],'on_hand':balances.get((w,i),Decimal(0)),'pending':pending[(w,i)],'reserved':reserved[(w,i)],'available':balances.get((w,i),Decimal(0))-reserved[(w,i)],'held':held[(w,i)],'low':balances.get((w,i),Decimal(0))<=items[i].minimum_stock} for w,i in keys]

def account_rows(accounts):
    accounts=list(accounts);ids=[a.pk for a in accounts]
    branches=m.Branch.objects.in_bulk({a.branch_id for a in accounts})
    reserved=defaultdict(int)
    for row in m.Allocation.objects.filter(account_id__in=ids,active=True).values('account_id','amount'):reserved[row['account_id']]+=row['amount']
    for row in m.MoneyEntry.objects.filter(account_id__in=ids,kind__in=['payment','refund'],allocation__active=True).values('account_id','amount','kind'):reserved[row['account_id']]+=row['amount'] if row['kind']=='refund' else -row['amount']
    return [{'pk':a.pk,'name':a.name,'branch':branches[a.branch_id],'balance':a.current_balance,'credit_limit':a.credit_limit,'reserved':reserved[a.pk],'available':a.current_balance+a.credit_limit-reserved[a.pk]} for a in accounts]

def totals_from_accounts(rows):
    return {field:sum((row[field] for row in rows),0) for field in ['balance','credit_limit','reserved','available']}

def dashboard_inventory(user,branch=None):
    ids=factory_ids(user)
    summaries=m.StockSummary.objects.filter(warehouse__branch_id__in=ids).annotate(low=AtMinimum(F('milliunits'),F('item__minimum_stock'))).filter(low=True)
    pending=pending_lines(user,ids)
    if branch:summaries=summaries.filter(warehouse__branch_id=branch);pending=pending.filter(contract__warehouse__branch_id=branch)
    keys=list(summaries.order_by('warehouse_id','item_id').values('warehouse_id','item_id')[:5])
    return inventory_page_rows(keys,user),pending.order_by().values('contract__warehouse_id','item_id').distinct().count()
