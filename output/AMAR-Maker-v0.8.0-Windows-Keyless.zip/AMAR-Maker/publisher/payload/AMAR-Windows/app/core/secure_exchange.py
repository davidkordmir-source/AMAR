"""Recipient-bound encrypted deltas and receipts; imported data remains source-owned."""
import base64
import hashlib
import json
import uuid
from datetime import datetime
from decimal import Decimal, InvalidOperation
from django.conf import settings
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from amar.localfiles import private_file
from . import models as m, sync, services
from .access import ancestors, descendants, factory_ids, contracts_for, require_factory, require_permission, root

MAX_PLAIN=10*1024*1024
MAX_FILE=16*1024*1024
BASE_COLUMNS={
    'branches':('code','name','city','consumer'),
    'accounts':('branch','name','balance','reserved','credit','available'),
    'contracts':('branch','number','title','supplier','status','total','paid'),
    'inventory':('branch','warehouse','sku','item','unit','on_hand','pending'),
    'buckets':('branch','warehouse','sku','item','location','trace','quantity','unit'),
    'equipment':('branch','code','uid','name','serial','status','custodian'),
    'maintenance':('branch','number','equipment','title','status','due_on'),
    'quality':('branch','number','reference','status','reviewed_at'),
}
SECTIONS={'accounts':'view_account','contracts':'view_contract','inventory':'view_stockmovement',
    'equipment':'view_equipment','maintenance':'view_maintenancejob','quality':'view_deliveryinspection'}


def canonical(value):return sync.canonical(value)
def hashed(value):return hashlib.sha256(canonical(value)).hexdigest()
def b64(value):return base64.b64encode(value).decode('ascii')
def unb64(value):return base64.b64decode(value,validate=True)


def encryption_identity():
    raw=private_file(settings.DATA_DIR/'exchange-encryption.key',lambda:X25519PrivateKey.generate().private_bytes(
        serialization.Encoding.Raw,serialization.PrivateFormat.Raw,serialization.NoEncryption()))
    return X25519PrivateKey.from_private_bytes(raw)


def public_identity():
    source,key=sync.identity()
    payload={'source_id':source,'public_key':sync.public_identity()['public_key'],
        'encryption_key':b64(encryption_identity().public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw))}
    return {'format':'amar-secure-identity','version':1,'payload':payload,'signature':b64(key.sign(canonical(payload)))}


@transaction.atomic
def trust_identity(content,label,actor):
    require_permission(actor,'add_trustedsource')
    data=sync.load_json(content)
    try:
        if set(data)!={'format','version','payload','signature'} or data['format']!='amar-secure-identity' or type(data['version']) is not int or data['version']!=1:raise ValueError()
        p=data['payload']
        if set(p)!={'source_id','public_key','encryption_key'}:raise ValueError()
        source_id=uuid.UUID(p['source_id'])
        Ed25519PublicKey.from_public_bytes(unb64(p['public_key'])).verify(unb64(data['signature']),canonical(p))
        X25519PublicKey.from_public_bytes(unb64(p['encryption_key']))
        if str(source_id)==sync.identity()[0]:raise ValidationError('این هویت متعلق به همین نصب است.')
    except (ValueError,TypeError,KeyError,InvalidSignature):raise ValidationError('هویت رمزگذاری‌شده معتبر نیست یا امضای آن تطبیق ندارد.')
    source,created=m.TrustedSource.objects.get_or_create(source_id=source_id,defaults={'label':label,'public_key':p['public_key']})
    if source.public_key!=p['public_key']:raise ValidationError('کلید امضای مبدأ با هویت ثبت‌شده متفاوت است.')
    peer,new=m.ExchangePeer.objects.get_or_create(source=source,defaults={'encryption_key':p['encryption_key']})
    if peer.encryption_key!=p['encryption_key']:raise ValidationError('کلید رمزگذاری این مبدأ تغییر کرده؛ جایگزینی خودکار مجاز نیست.')
    if new:services.audit('ثبت هویت تبادل رمزگذاری‌شده',label,actor,str(source_id))
    return source


def peer_access(actor,peer,permission):
    require_permission(actor,permission)
    if peer.source.branch_id:require_factory(actor,peer.source.branch_id)
    elif not root(actor):raise PermissionDenied


def _derive(private,public,sender,recipient):
    return HKDF(algorithm=hashes.SHA256(),length=32,salt=None,
        info=('AMAR-Exchange-v1:'+sender+':'+recipient).encode()).derive(private.exchange(public))


def seal(peer,kind,payload,sequence=0,previous='',uid=None):
    source,key=sync.identity();recipient=str(peer.source.source_id)
    ephemeral=X25519PrivateKey.generate()
    header={'kind':kind,'sender':source,'recipient':recipient,'uid':str(uid or uuid.uuid4()),
        'sequence':sequence,'previous':previous,'created_at':timezone.now().isoformat(),
        'ephemeral':b64(ephemeral.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw))}
    plaintext=canonical(payload)
    if len(plaintext)>MAX_PLAIN:raise ValidationError('حجم تغییرات از ۱۰ مگابایت بیشتر است؛ موقعیت یا بخش کوچک‌تری انتخاب کنید.')
    import secrets
    nonce=secrets.token_bytes(12)
    derived=_derive(ephemeral,X25519PublicKey.from_public_bytes(unb64(peer.encryption_key)),source,recipient)
    unsigned={'format':'amar-encrypted-exchange','version':1,'header':header,'nonce':b64(nonce),
        'ciphertext':b64(AESGCM(derived).encrypt(nonce,plaintext,canonical(header)))}
    return canonical({**unsigned,'signature':b64(key.sign(canonical(unsigned)))})


def open_envelope(content,actor):
    if len(content)>MAX_FILE:raise ValidationError('فایل تبادل بیش از حد بزرگ است.')
    try:
        def unique(pairs):
            result={}
            for name,value in pairs:
                if name in result:raise ValueError('duplicate JSON key')
                result[name]=value
            return result
        value=json.loads(content,object_pairs_hook=unique)
        if set(value)!={'format','version','header','nonce','ciphertext','signature'} or value['format']!='amar-encrypted-exchange' or type(value['version']) is not int or value['version']!=1:raise ValueError()
        h=value['header']
        if set(h)!={'kind','sender','recipient','uid','sequence','previous','created_at','ephemeral'} or h['kind'] not in ['data','receipt']:raise ValueError()
        if h['recipient']!=sync.identity()[0]:raise ValidationError('این فایل مخصوص نصب دیگری است؛ در این نصب پذیرفته نمی‌شود.')
        uuid.UUID(h['uid']);uuid.UUID(h['sender'])
        if type(h['sequence']) is not int or not 0<=h['sequence']<2**63 or not isinstance(h['previous'],str) or len(h['previous']) not in (0,64):raise ValueError()
        at=datetime.fromisoformat(h['created_at'])
        if timezone.is_naive(at):raise ValueError()
        peer=m.ExchangePeer.objects.select_related('source').filter(source__source_id=h['sender']).first()
        if not peer:raise ValidationError('هویت رمزگذاری‌شدهٔ فرستنده ثبت نشده است.')
        if h['kind']=='data':peer_access(actor,peer,'add_importedsnapshot')
        else:require_permission(actor,'add_importedsnapshot')
        unsigned={k:v for k,v in value.items() if k!='signature'}
        Ed25519PublicKey.from_public_bytes(unb64(peer.source.public_key)).verify(unb64(value['signature']),canonical(unsigned))
        derived=_derive(encryption_identity(),X25519PublicKey.from_public_bytes(unb64(h['ephemeral'])),h['sender'],h['recipient'])
        plain=AESGCM(derived).decrypt(unb64(value['nonce']),unb64(value['ciphertext']),canonical(h))
        if len(plain)>MAX_PLAIN:raise ValueError()
        payload=json.loads(plain,object_pairs_hook=unique)
        return peer,h,payload,hashlib.sha256(content).hexdigest()
    except (ValueError,TypeError,KeyError,InvalidSignature,InvalidTag,OverflowError,RecursionError):
        raise ValidationError('امضا، رمزگذاری یا ساختار فایل تبادل معتبر نیست؛ اطلاعات فعلی حفظ شد.')


def _contract_scope(actor,ids):
    inherited=set()
    for pk in ids:inherited.update(ancestors(pk))
    grants=m.ContractGrant.objects.filter(Q(branch_id__in=ids)|Q(branch_id__in=inherited,include_descendants=True))
    return contracts_for(actor).filter(warehouse__branch_id__in=ids,pk__in=grants.values('contract_id'))


def projection(actor,peer,scope,sections,include_descendants):
    require_permission(actor,'export_branch_data');require_factory(actor,scope.pk)
    if not peer.source.branch_id:raise ValidationError('ابتدا موقعیت مجاز گیرنده را در اطلاعات مبدأ تعیین کنید.')
    if scope.pk not in descendants(peer.source.branch_id):raise ValidationError('موقعیت انتخابی خارج از محدودهٔ گیرنده است.')
    sections=set(sections)
    if not sections or sections-set(SECTIONS):raise ValidationError('بخش‌های تبادل معتبر نیستند.')
    for section in sections:require_permission(actor,SECTIONS[section])
    ids=factory_ids(actor)&(descendants(scope.pk) if include_descendants else {scope.pk})
    visible=_contract_scope(actor,ids)
    source_id=sync.identity()[0];namespace=uuid.UUID(source_id);rows={}
    def add(kind,pk,data):
        key=kind+':'+uuid.uuid5(namespace,str(pk)).hex
        rows[key]={'kind':kind,'data':{k:str(v) for k,v in data.items()}}
    for b in m.Branch.objects.filter(pk__in=ids).select_related('organization'):
        add('branches',b.pk,{'code':b.code,'name':b.name,'city':b.city,'consumer':b.organization.name})
    if 'accounts' in sections:
        from .scalable_reports import account_rows
        for row in account_rows(m.Account.objects.filter(branch_id__in=ids)):
            add('accounts',row['pk'],{'branch':row['branch'].code,'name':row['name'],'balance':row['balance'],
                'reserved':row['reserved'],'credit':row['credit_limit'],'available':row['available']})
    if 'contracts' in sections:
        for c in visible.select_related('supplier','warehouse__branch'):
            add('contracts',c.pk,{'branch':c.warehouse.branch.code,'number':c.number,'title':c.title,'supplier':c.supplier.name,
                'status':c.get_status_display(),'total':c.total_cached,'paid':c.paid_cached})
    if 'inventory' in sections:
        from .scalable_reports import inventory_iterator
        for row in inventory_iterator(actor,ids=ids,contract_ids=visible.values_list('pk',flat=True) if 'contracts' in sections else []):
            w,i=row['warehouse'],row['item']
            add('inventory',f'{w.pk}:{i.pk}',{'branch':w.branch.code,'warehouse':str(w),'sku':i.sku,'item':i.name,'unit':i.get_unit_display(),'on_hand':row['on_hand'],'pending':row['pending']})
        for b in m.StockBalance.objects.filter(warehouse__branch_id__in=ids,quantity__gt=0).select_related('warehouse__branch','warehouse__parent','item','trace','location'):
            add('buckets',b.pk,{'branch':b.warehouse.branch.code,'warehouse':str(b.warehouse),'sku':b.item.sku,'item':b.item.name,
                'location':b.location.code if b.location else '', 'trace':b.trace.code if b.trace else '', 'quantity':b.quantity,'unit':b.item.get_unit_display()})
    if 'equipment' in sections:
        for e in m.Equipment.objects.filter(branch_id__in=ids,archived_at__isnull=True).select_related('branch','custodian'):
            add('equipment',e.pk,{'branch':e.branch.code,'code':e.code,'uid':e.uid,'name':e.name,'serial':e.serial,'status':e.get_status_display(),'custodian':e.custodian.name if e.custodian else ''})
    if 'maintenance' in sections:
        for j in m.MaintenanceJob.objects.filter(branch_id__in=ids,archived_at__isnull=True).select_related('branch','equipment'):
            add('maintenance',j.pk,{'branch':j.branch.code,'number':j.number,'equipment':j.equipment.code,'title':j.title,'status':j.get_status_display(),'due_on':j.due_on.isoformat()})
    if 'quality' in sections:
        for q in m.DeliveryInspection.objects.filter(contract__in=visible,archived_at__isnull=True).select_related('contract__warehouse__branch'):
            add('quality',q.pk,{'branch':q.contract.warehouse.branch.code,'number':q.contract.number,'reference':q.reference,
                'status':q.get_status_display(),'reviewed_at':q.reviewed_at.isoformat() if q.reviewed_at else ''})
    validate_rows(rows)
    return rows,{'branches':sorted(m.Branch.objects.filter(pk__in=ids).values_list('code',flat=True)),
        'sections':sorted(sections),'contracts':list(visible.values_list('number',flat=True)) if 'contracts' in sections or 'quality' in sections else []}


def validate_rows(rows):
    if not isinstance(rows,dict) or len(rows)>140000:raise ValueError('too many records')
    counts={kind:0 for kind in BASE_COLUMNS}
    for key,row in rows.items():
        if not isinstance(key,str) or len(key)>120 or not isinstance(row,dict) or set(row)!={'kind','data'} or row['kind'] not in BASE_COLUMNS:raise ValueError('record structure')
        kind=row['kind'];data=row['data'];counts[kind]+=1
        if not key.startswith(kind+':') or not isinstance(data,dict) or set(data)!=set(BASE_COLUMNS[kind]):raise ValueError('record columns')
        for name,value in data.items():
            if not isinstance(value,str) or len(value)>500:raise ValueError('record cell')
            if name in {'balance','reserved','credit','available','total','paid','on_hand','pending','quantity'}:
                amount=Decimal(value)
                if not amount.is_finite() or abs(amount)>Decimal('1e25'):raise ValueError('record amount')
    if any(n>20000 for n in counts.values()):raise ValidationError('هر بخش حداکثر ۲۰هزار ردیف دارد؛ محدودهٔ کوچک‌تری انتخاب کنید.')
    branches=[row['data']['code'] for row in rows.values() if row['kind']=='branches']
    if len(branches)!=len(set(branches)):raise ValueError('duplicate branch code')
    if any(row['data']['branch'] not in branches for row in rows.values() if row['kind']!='branches'):raise ValueError('unknown branch')
    if len(canonical(rows))>MAX_PLAIN:raise ValidationError('اطلاعات این محدوده از سقف بسته بیشتر است؛ موقعیت کوچک‌تری انتخاب کنید.')


@transaction.atomic
def prepare(actor,peer_id,scope,sections,include_descendants=False,baseline=False):
    peer=m.ExchangePeer.objects.select_for_update().select_related('source').get(pk=peer_id)
    require_permission(actor,'export_branch_data')
    pending=peer.outbox.filter(ack__isnull=True).first()
    if pending:raise ValidationError('برای این گیرنده بستهٔ منتظر رسید وجود دارد؛ همان بسته را دوباره دریافت کنید یا رسیدش را وارد کنید.')
    rows,access=projection(actor,peer,scope,sections,include_descendants)
    manifest={key:hashed(row) for key,row in rows.items()}
    old=peer.acked_manifest
    baseline=bool(baseline or not peer.last_sent_hash)
    body={'baseline':baseline,'upserts':[{'key':key,**row,'base':None if baseline else old.get(key)} for key,row in sorted(rows.items()) if baseline or old.get(key)!=manifest[key]],
        'deletes':[] if baseline else [{'key':key,'base':value} for key,value in sorted(old.items()) if key not in rows],
        'manifest_digest':hashed(manifest),'scope':access}
    state,_=m.SyncState.objects.get_or_create(pk=1);state=m.SyncState.objects.select_for_update().get(pk=state.pk)
    state.sequence+=1;state.save(update_fields=['sequence'])
    uid=uuid.uuid4();content=seal(peer,'data',body,state.sequence,peer.last_sent_hash,uid)
    out=m.ExchangeOutbox.objects.create(uid=uid,peer=peer,sequence=state.sequence,digest=hashlib.sha256(content).hexdigest(),
        envelope=content,manifest={'rows':manifest,**access},created_by=actor)
    services.audit('تهیهٔ تغییرات رمزگذاری‌شده',peer.source.label,actor,f'{len(body["upserts"])} تغییر؛ نسخهٔ {state.sequence}')
    return out


def outbox_access(actor,out):
    require_permission(actor,'export_branch_data')
    if root(actor):return
    if out.created_by_id!=actor.pk:raise PermissionDenied
    codes=set(m.Branch.objects.filter(pk__in=factory_ids(actor)).values_list('code',flat=True))
    if not set(out.manifest['branches'])<=codes:raise PermissionDenied
    for section in out.manifest['sections']:require_permission(actor,SECTIONS[section])
    allowed=set(contracts_for(actor).values_list('number',flat=True))
    if not set(out.manifest['contracts'])<=allowed:raise PermissionDenied


def _candidate(peer,body):
    if not isinstance(body,dict) or set(body)!={'baseline','upserts','deletes','manifest_digest','scope'} or type(body['baseline']) is not bool:raise ValueError('body')
    if not isinstance(body['upserts'],list) or not isinstance(body['deletes'],list) or len(body['upserts'])+len(body['deletes'])>140000:raise ValueError('rows')
    if not isinstance(body['scope'],dict) or set(body['scope'])!={'branches','sections','contracts'}:raise ValueError('scope')
    if any(not isinstance(body['scope'][key],list) or any(not isinstance(v,str) or len(v)>500 for v in body['scope'][key]) for key in body['scope']):raise ValueError('scope')
    if set(body['scope']['sections'])-set(SECTIONS):raise ValueError('sections')
    rows={} if body['baseline'] else {r.entity_key:{'kind':r.kind,'data':r.data} for r in m.ExchangeReplica.objects.filter(peer=peer)}
    conflict=False;seen=set()
    for up in body['upserts']:
        if set(up)!={'key','kind','data','base'} or up['key'] in seen:raise ValueError('upsert')
        seen.add(up['key']);current=rows.get(up['key'])
        if not body['baseline'] and (hashed(current) if current else None)!=up['base']:conflict=True
        rows[up['key']]={'kind':up['kind'],'data':up['data']}
    for deletion in body['deletes']:
        if set(deletion)!={'key','base'} or deletion['key'] in seen or body['baseline']:raise ValueError('deletion')
        seen.add(deletion['key']);current=rows.get(deletion['key'])
        if not current or hashed(current)!=deletion['base']:conflict=True
        rows.pop(deletion['key'],None)
    validate_rows(rows)
    allowed={'branches',*body['scope']['sections']}
    if 'inventory' in allowed:allowed.add('buckets')
    if any(row['kind'] not in allowed for row in rows.values()):raise ValueError('undeclared section')
    numbers={row['data']['number'] for row in rows.values() if row['kind'] in ('contracts','quality')}
    if not numbers<=set(body['scope']['contracts']):raise ValueError('undeclared contract')
    if set(body['scope']['branches'])!={r['data']['code'] for r in rows.values() if r['kind']=='branches'}:raise ValueError('branch scope')
    if hashed({key:hashed(row) for key,row in rows.items()})!=body['manifest_digest']:conflict=True
    return rows,conflict


def _scope_incoming(peer,rows,actor):
    codes={row['data']['code'] for row in rows.values() if row['kind']=='branches'}
    if peer.source.branch_id:
        allowed=set(m.Branch.objects.filter(pk__in=descendants(peer.source.branch_id)).values_list('code',flat=True))
        if not codes<=allowed:raise ValidationError('بسته شامل موقعیت بیرون از محدودهٔ ثبت‌شدهٔ مبدأ است.')
    elif not root(actor):raise PermissionDenied
    if not root(actor) and not codes<=set(m.Branch.objects.filter(pk__in=factory_ids(actor)).values_list('code',flat=True)):raise PermissionDenied


@transaction.atomic
def import_file(actor,content):
    peer,h,payload,digest=open_envelope(content,actor)
    peer=m.ExchangePeer.objects.select_for_update().select_related('source').get(pk=peer.pk)
    if h['kind']=='receipt':return _import_ack(actor,peer,payload,digest)
    previous=m.ExchangeInbox.objects.filter(uid=h['uid']).first()
    if previous:
        if previous.digest!=digest or previous.peer_id!=peer.pk:raise ValidationError('شناسهٔ بسته با محتوای دیگری ثبت شده است.')
        inbox_access(actor,previous)
        return previous
    try:
        rows,conflict=_candidate(peer,payload);_scope_incoming(peer,rows,actor)
        if h['sequence']<=0:raise ValueError()
    except (ValueError,KeyError,TypeError,InvalidOperation,OverflowError,RecursionError):raise ValidationError('ساختار تغییرات یا ردیف‌های بسته معتبر نیست.')
    conflict=conflict or h['previous']!=peer.last_received_hash or h['sequence']<=peer.last_received_sequence
    inbox=m.ExchangeInbox.objects.create(uid=h['uid'],peer=peer,sequence=h['sequence'],digest=digest,previous_hash=h['previous'],
        status='conflict' if conflict else 'review',reason='ترتیب یا نسخهٔ پایه با اطلاعات فعلی تطبیق ندارد.' if conflict else '',payload=payload,imported_by=actor,generated_at=datetime.fromisoformat(h['created_at']))
    services.audit('دریافت تغییرات برای بررسی',peer.source.label,actor,f'نسخهٔ {h["sequence"]}؛ {inbox.get_status_display()}')
    return inbox


@transaction.atomic
def review(actor,pk,accept,note='',replace_baseline=False):
    inbox=m.ExchangeInbox.objects.select_for_update().select_related('peer__source').get(pk=pk)
    peer=m.ExchangePeer.objects.select_for_update().select_related('source').get(pk=inbox.peer_id)
    peer_access(actor,peer,'add_importedsnapshot')
    inbox_access(actor,inbox)
    if inbox.status in ('applied','rejected'):return inbox
    if accept:
        rows,conflict=_candidate(peer,inbox.payload);_scope_incoming(peer,rows,actor)
        conflict=conflict or inbox.previous_hash!=peer.last_received_hash or inbox.sequence<=peer.last_received_sequence
        latest=peer.source.latest
        if latest and inbox.sequence<=latest.sequence:conflict=True
        override=replace_baseline and root(actor) and inbox.payload['baseline'] and len(note.strip())>=10
        if conflict and not override:raise ValidationError('بسته متعارض است؛ نسخهٔ کامل تازه بگیرید یا مسئول ارشد نسخهٔ کامل را با علت صریح بررسی کند.')
        if latest and inbox.sequence<=latest.sequence:raise ValidationError('نسخهٔ قدیمی‌تر جای نسخهٔ جدید را نمی‌گیرد؛ از مبدأ نسخهٔ کامل تازه بخواهید.')
        m.ExchangeReplica.objects.filter(peer=peer).delete()
        m.ExchangeReplica.objects.bulk_create([m.ExchangeReplica(peer=peer,entity_key=key,digest=hashed(row),kind=row['kind'],data=row['data'],search_key=(row['data'].get('uid') or row['data'].get('trace') or row['data'].get('sku') or row['data'].get('number') or '')[:120]) for key,row in rows.items()],batch_size=500)
        payload={'source_id':str(peer.source.source_id),'sequence':inbox.sequence,'generated_at':inbox.generated_at.isoformat(),'recipient_id':sync.identity()[0]}
        for kind in ['branches','accounts','contracts','inventory']:payload[kind]=[row['data'] for row in rows.values() if row['kind']==kind]
        sync.validate_payload(payload)
        snapshot=m.ImportedSnapshot.objects.create(source=peer.source,sequence=inbox.sequence,payload=payload,digest=hashed(payload),generated_at=inbox.generated_at,imported_by=actor)
        from .remote_reports import index_snapshot
        index_snapshot(snapshot)
        peer.last_received_hash=inbox.digest;peer.last_received_sequence=inbox.sequence;peer.last_received_at=timezone.now();peer.last_received_scope=inbox.payload['scope'];peer.save()
        peer.source.encrypted_only=True;peer.source.save(update_fields=['encrypted_only'])
        inbox.status='applied';inbox.applied_at=timezone.now()
    else:
        if len(note.strip())<10:raise ValidationError('علت رد بسته را دست‌کم در ۱۰ حرف بنویسید.')
        inbox.status='rejected'
    inbox.reason=note[:240];inbox.reviewed_by=actor
    inbox.receipt=seal(peer,'receipt',{'outbox':str(inbox.uid),'digest':inbox.digest,'result':inbox.status,'sequence':inbox.sequence})
    inbox.save()
    services.audit('ثبت بستهٔ رمزگذاری‌شده' if accept else 'رد بستهٔ رمزگذاری‌شده',peer.source.label,actor,f'نسخهٔ {inbox.sequence}؛ {note[:160]}')
    return inbox


def _import_ack(actor,peer,payload,digest):
    if not isinstance(payload,dict) or set(payload)!={'outbox','digest','result','sequence'} or payload['result'] not in ['applied','rejected']:raise ValidationError('رسید تبادل معتبر نیست.')
    try:
        uuid.UUID(payload['outbox'])
        if type(payload['sequence']) is not int or payload['sequence']<=0 or not isinstance(payload['digest'],str) or len(payload['digest'])!=64:raise ValueError()
    except (TypeError,ValueError,AttributeError):raise ValidationError('شناسهٔ رسید تبادل معتبر نیست.')
    out=m.ExchangeOutbox.objects.filter(uid=payload['outbox'],peer=peer,sequence=payload['sequence'],digest=payload['digest']).first()
    if out is None:raise ValidationError('رسید با بستهٔ ارسالی این گیرنده تطبیق ندارد.')
    outbox_access(actor,out)
    existing=m.ExchangeAck.objects.filter(outbox=out).first()
    if existing:
        if existing.result!=payload['result']:raise ValidationError('برای این بسته رسید متعارض ثبت شده است.')
        return existing
    ack=m.ExchangeAck.objects.create(outbox=out,result=payload['result'],digest=digest,created_by=actor)
    if ack.result=='applied':peer.acked_manifest=out.manifest['rows'];peer.last_sent_hash=out.digest
    peer.last_ack_at=timezone.now();peer.save()
    services.audit('ثبت رسید تبادل',peer.source.label,actor,ack.get_result_display())
    return ack


def inbox_access(actor,inbox):
    peer_access(actor,inbox.peer,'view_importedsnapshot')
    if not root(actor):
        codes=set(m.Branch.objects.filter(pk__in=factory_ids(actor)).values_list('code',flat=True))
        if not set(inbox.payload['scope']['branches'])<=codes:raise PermissionDenied
