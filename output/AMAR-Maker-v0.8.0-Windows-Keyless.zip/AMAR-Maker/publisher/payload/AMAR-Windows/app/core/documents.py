"""Versioned, private scanned documents and explicit human review."""
import hashlib,json,os,uuid
from pathlib import Path,PureWindowsPath
from django.conf import settings
from django.core.exceptions import PermissionDenied,ValidationError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from . import models as m,services
from .access import factory_ids,contracts_for,require_factory,require_permission,require_contract,root
from .lifecycle import entries_for,reason_text

MAX_UPLOAD=20*1024*1024

def visible_documents(actor,archived=False):
    require_permission(actor,'view_document')
    objects=m.Document.all_objects if archived and root(actor) else m.Document.objects
    objects=objects.filter(branch_id__in=factory_ids(actor))
    if root(actor):return objects
    if not actor.has_perm('core.view_contract'):objects=objects.exclude(kind='contract')
    if not actor.has_perm('core.view_moneyentry'):objects=objects.exclude(kind='financial').filter(money_entry__isnull=True,payment_request__isnull=True)
    objects=objects.filter(Q(contract__isnull=True)|Q(contract__in=contracts_for(actor)))
    if actor.has_perm('core.view_account'):objects=objects.filter(Q(account__isnull=True)|Q(account__branch_id__in=factory_ids(actor)))
    else:objects=objects.filter(account__isnull=True)
    return objects.filter(Q(money_entry__isnull=True)|Q(money_entry__in=entries_for(actor)))

def has_payment(document):
    if document.money_entry_id and document.money_entry.kind==m.MoneyEntry.Kind.PAYMENT:return True
    if document.payment_request_id and document.payment_request.entry_id:return True
    if document.contract_id and document.contract.allocations.filter(payments__kind='payment').exists():return True
    if document.account_id and m.MoneyEntry.objects.filter(account_id=document.account_id,kind=m.MoneyEntry.Kind.PAYMENT).exists():return True
    return False

def expected_amount(document):
    if document.money_entry_id:return document.money_entry.amount
    if document.payment_request_id:return document.payment_request.amount
    if document.contract_id:return int(document.contract.total)
    return None

def validate_links(actor,data):
    require_factory(actor,data['branch'].pk)
    if data['kind']=='financial':require_permission(actor,'view_moneyentry')
    if data['kind']=='contract':require_permission(actor,'view_contract')
    contract=data.get('contract');account=data.get('account');entry=data.get('money_entry')
    if contract:
        require_contract(actor,contract.pk,True)
        if data['kind']=='contract' and contract.warehouse.branch_id!=data['branch'].pk:raise ValidationError('قرارداد باید متعلق به موقعیت سند باشد.')
    if account:
        require_permission(actor,'view_account');require_factory(actor,account.branch_id)
        if account.branch_id!=data['branch'].pk:raise ValidationError('حساب باید متعلق به موقعیت سند مالی باشد.')
    if entry:
        require_permission(actor,'view_moneyentry')
        if not entries_for(actor).filter(pk=entry.pk).exists():raise PermissionDenied
        if entry.account.branch_id!=data['branch'].pk:raise ValidationError('موقعیت سند مالی با فایل مرتبط همخوانی ندارد.')
        if account and account.pk!=entry.account_id:raise ValidationError('حساب انتخاب‌شده با سند مالی مرتبط یکسان نیست.')
        if contract and entry.allocation_id and contract.pk!=entry.allocation.contract_id:raise ValidationError('قرارداد انتخاب‌شده با سند مالی مرتبط یکسان نیست.')

def store_upload(upload):
    if not upload or upload.size>MAX_UPLOAD:raise ValidationError('فایل اسکن را انتخاب کنید؛ حداکثر اندازه ۲۰ مگابایت است.')
    folder=settings.DATA_DIR/'documents';folder.mkdir(mode=0o700,parents=True,exist_ok=True)
    temporary=folder/(uuid.uuid4().hex+'.part');digest=hashlib.sha256();size=0;prefix=b''
    try:
        descriptor=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'wb') as out:
            for chunk in upload.chunks():
                size+=len(chunk)
                if size>MAX_UPLOAD:raise ValidationError('اندازه فایل بیشتر از ۲۰ مگابایت است.')
                if len(prefix)<1024:prefix=(prefix+chunk)[:1024]
                digest.update(chunk);out.write(chunk)
        if prefix.startswith(b'%PDF-'):extension,mime='.pdf','application/pdf'
        elif prefix.startswith(b'\x89PNG\r\n\x1a\n'):extension,mime='.png','image/png'
        elif prefix.startswith(b'\xff\xd8\xff'):extension,mime='.jpg','image/jpeg'
        else:raise ValidationError('فقط PDF، PNG یا JPEG واقعی پذیرفته می‌شود.')
        if mime!='application/pdf':
            from PIL import Image
            with Image.open(temporary) as image:
                if image.width*image.height>16000000:raise ValidationError('تصویر بیش از حد بزرگ است؛ تصویر را با وضوح کمتر ذخیره کنید.')
                image.verify()
        filename=uuid.uuid4().hex+extension;destination=folder/filename;temporary.replace(destination)
        name=PureWindowsPath(upload.name.replace('/','\\')).name
        name=''.join(c for c in name if ord(c)>=32)[:200] or 'scan'+extension
        return {'filename':filename,'original_name':name,'content_type':mime,'size':size,'digest':digest.hexdigest()}
    except ValidationError:temporary.unlink(missing_ok=True);raise
    except Exception:temporary.unlink(missing_ok=True);raise ValidationError('فایل اسکن خوانا و معتبر نیست.')

def _queue(version):
    from .ocr import enqueue
    transaction.on_commit(lambda:enqueue(version.pk))

def _lock_related(document,actor):
    require_factory(actor,document.branch_id)
    contract_ids={document.contract_id} if document.contract_id else set()
    account_ids={document.account_id} if document.account_id else set()
    if document.money_entry_id:
        account_ids.add(document.money_entry.account_id)
        if document.money_entry.allocation_id:contract_ids.add(document.money_entry.allocation.contract_id)
    if document.payment_request_id:
        contract_ids.add(document.payment_request.allocation.contract_id);account_ids.add(document.payment_request.allocation.account_id)
    for pk in sorted(contract_ids):
        require_contract(actor,pk,True)
        m.Contract.all_objects.select_for_update().get(pk=pk)
    list(m.Account.objects.select_for_update().filter(pk__in=account_ids).order_by('pk'))

def create_document(actor,data,upload,key):
    require_permission(actor,'add_document');require_permission(actor,'view_document');validate_links(actor,data)
    stored=store_upload(upload)
    try:
        with transaction.atomic():
            previous=m.Document.all_objects.filter(creation_key=key).first()
            if previous:
                if not visible_documents(actor).filter(pk=previous.pk).exists():raise PermissionDenied
                if previous.current_version.digest!=stored['digest'] or previous.title!=data['title'] or previous.branch_id!=data['branch'].pk:raise ValidationError('شناسهٔ ثبت با اطلاعات دیگری استفاده شده است.')
                (settings.DATA_DIR/'documents'/stored['filename']).unlink(missing_ok=True)
                return previous
            document=m.Document.objects.create(created_by=actor,creation_key=key,**data)
            version=m.DocumentVersion.objects.create(document=document,number=1,created_by=actor,**stored)
            document.current_version=version;document.save(update_fields=['current_version'])
            services.audit('ثبت سند اسکن‌شده',document.title,actor,stored['digest'],branch=document.branch,contract=document.contract)
            _queue(version)
            return document
    except Exception:
        (settings.DATA_DIR/'documents'/stored['filename']).unlink(missing_ok=True);raise

def edit_document(actor,pk,data,upload,reason):
    require_permission(actor,'change_document');visible_documents(actor).get(pk=pk)
    validate_links(actor,data);reason=reason_text(reason)
    stored=store_upload(upload) if upload else None
    try:
        with transaction.atomic():
            document=m.Document.objects.select_for_update().get(pk=pk)
            _lock_related(document,actor)
            if has_payment(document) or document.payment_request_id:
                for field in ['kind','branch','contract','account','money_entry']:
                    old=getattr(document,field+'_id') if field not in ['kind'] else document.kind
                    new=data[field].pk if field!='kind' and data.get(field) else data.get(field)
                    if old!=new:raise ValidationError('پس از پرداخت، موقعیت و پیوند مالی سند ثابت است؛ عنوان و توضیحات قابل اصلاح‌اند.')
            before={name:getattr(document,name) for name in ['title','reference','notes','kind','branch_id','contract_id','account_id','money_entry_id']}
            for field,value in data.items():setattr(document,field,value)
            if any(before[key]!=getattr(document,key) for key in ['kind','branch_id','contract_id','account_id','money_entry_id']):
                document.confirmed_at=None;document.confirmed_by=None
            if stored:
                number=(document.versions.order_by('-number').values_list('number',flat=True).first() or 0)+1
                version=m.DocumentVersion.objects.create(document=document,number=number,created_by=actor,**stored)
                document.current_version=version;document.ocr_status='pending';document.confirmed_at=None;document.confirmed_by=None
                _queue(version)
            document.save()
            services.audit('ویرایش سند اسکن‌شده با حفظ نسخه قبلی',document.title,actor,json.dumps({'before':before,'reason':reason},ensure_ascii=False),branch=document.branch,contract=document.contract)
            return document
    except Exception:
        if stored:(settings.DATA_DIR/'documents'/stored['filename']).unlink(missing_ok=True)
        raise

@transaction.atomic
def confirm_document(actor,pk,version_id,values):
    require_permission(actor,'change_document');visible_documents(actor).get(pk=pk)
    document=m.Document.objects.select_for_update().get(pk=pk)
    _lock_related(document,actor)
    if document.current_version_id!=version_id:raise ValidationError('فایل سند تغییر کرده است؛ نسخهٔ تازه را دوباره بررسی کنید.')
    amount=values.get('amount')
    if amount is not None and (amount<0 or amount>999999999999999999):raise ValidationError('مبلغ معتبر به ریال وارد کنید.')
    expected=expected_amount(document)
    if expected is not None and amount!=expected:raise ValidationError('مبلغ تأییدشده باید با سند مرتبط مطابقت داشته باشد؛ مبلغ را در خود سند ویرایش کنید.')
    for field in ['reference','amount','document_date','notes']:setattr(document,field,values[field])
    document.confirmed_at=timezone.now();document.confirmed_by=actor;document.save()
    extraction=document.current_version.extractions.first()
    m.DocumentReview.objects.create(document=document,version=document.current_version,extraction=extraction,values={k:str(v) if v is not None else None for k,v in values.items()},actor=actor)
    services.audit('تأیید انسانی اطلاعات اسکن',document.title,actor,document.current_version.digest,branch=document.branch,contract=document.contract)
    return document

@transaction.atomic
def archive_document(actor,pk,reason):
    require_permission(actor,'delete_document');visible_documents(actor).get(pk=pk)
    document=m.Document.objects.select_for_update().get(pk=pk)
    _lock_related(document,actor)
    if has_payment(document):raise ValidationError('پرداخت مالی مرتبط ثبت شده است؛ حذف این سند مجاز نیست.')
    document.archived_at=timezone.now();document.archived_by=actor;document.archive_reason=reason_text(reason);document.save()
    services.audit('حذف سند اسکن‌شده بدون پرداخت',document.title,actor,document.archive_reason,branch=document.branch,contract=document.contract)
    return document

def file_for(actor,version_id):
    version=m.DocumentVersion.objects.select_related('document').get(pk=version_id)
    if not visible_documents(actor,archived=root(actor)).filter(pk=version.document_id).exists():raise PermissionDenied
    path=settings.DATA_DIR/'documents'/version.filename
    if not path.is_file() or path.stat().st_size!=version.size:raise ValidationError('فایل سند در محل نگهداری موجود یا معتبر نیست.')
    with path.open('rb') as stream:
        if hashlib.file_digest(stream,'sha256').hexdigest()!=version.digest:raise ValidationError('فایل با نسخهٔ ثبت‌شده مطابقت ندارد.')
    return version,path

def scan_form(form,request,target):
    """Carry an authenticated, reviewed scan through the normal entry form."""
    from django import forms
    from django.shortcuts import get_object_or_404
    form.fields['scan_document']=forms.IntegerField(required=False,widget=forms.HiddenInput)
    form.fields['scan_version']=forms.IntegerField(required=False,widget=forms.HiddenInput)
    value=request.POST.get('scan_document','') if request.method=='POST' else request.GET.get('document','')
    if not str(value).isdigit():return form
    require_permission(request.user,'change_document')
    document=get_object_or_404(visible_documents(request.user),pk=int(value));form.scan_source=document
    form.initial.update(scan_document=document.pk,scan_version=document.current_version_id)
    if request.method!='POST':
        initial={'notes':document.notes,'description':document.notes[:240]}
        if target=='contract':initial.update(number=document.reference,title=document.title)
        else:initial.update(reference=document.reference,amount=document.amount,account=document.account_id)
        for key,value in initial.items():
            if key in form.fields:form.initial[key]=value
    return form

@transaction.atomic
def apply_scan(actor,data,target,create):
    pk=data.get('scan_document')
    if not pk:return create()
    require_permission(actor,'change_document')
    visible_documents(actor).get(pk=pk)
    document=m.Document.objects.select_for_update().get(pk=pk);_lock_related(document,actor)
    if not document.confirmed_at:raise ValidationError('ابتدا اطلاعات اسکن را در صفحهٔ بررسی تأیید کنید.')
    if document.current_version_id!=data.get('scan_version'):raise ValidationError('نسخهٔ فایل اسکن تغییر کرده است؛ ابتدا دوباره آن را بررسی کنید.')
    if target=='contract':
        if document.kind!='contract' or document.contract_id:raise ValidationError('این اسکن به قرارداد مرتبط است یا از نوع قرارداد نیست.')
        if data['warehouse'].branch_id!=document.branch_id:raise ValidationError('مقصد قرارداد باید در موقعیت اسکن باشد.')
        reference=data['number']
    else:
        if document.kind!='financial':raise ValidationError('برای این عملیات اسکن سند مالی را انتخاب کنید.')
        if document.money_entry_id or document.payment_request_id:raise ValidationError('این اسکن قبلاً به یک سند مالی متصل شده است.')
        account=data['account'] if target=='deposit' else data['allocation'].account
        if account.branch_id!=document.branch_id:raise ValidationError('موقعیت حساب با اسکن همخوانی ندارد.')
        if document.account_id and document.account_id!=account.pk:raise ValidationError('حساب با پیوند تأییدشدهٔ اسکن همخوانی ندارد.')
        if data['amount']!=document.amount:raise ValidationError('مبلغ را با اطلاعات تأییدشدهٔ اسکن تطبیق دهید؛ اصلاح مبلغ در صفحهٔ بررسی اسکن انجام می‌شود.')
        reference=data['reference']
    if reference!=document.reference:raise ValidationError('شماره با اطلاعات تأییدشدهٔ اسکن همخوانی ندارد؛ ابتدا اسکن را دوباره بررسی کنید.')
    record=create()
    if target=='contract':
        if document.amount is not None and record.total!=document.amount:raise ValidationError('جمع اقلام قرارداد با مبلغ تأییدشدهٔ اسکن یکسان نیست.')
        document.contract=record
    elif target=='deposit':document.money_entry=record;document.account=record.account
    else:document.payment_request=record;document.account=record.allocation.account;document.contract=record.allocation.contract
    document.save()
    services.audit('ثبت از اطلاعات تأییدشدهٔ اسکن',document.title,actor,target,branch=document.branch,contract=document.contract)
    return record
