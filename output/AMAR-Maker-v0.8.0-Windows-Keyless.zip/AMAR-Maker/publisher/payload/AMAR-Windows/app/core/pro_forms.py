import uuid
from django import forms
from django.contrib.auth import get_user_model
from django.db.models import Q
from . import models as m
from .access import factory_ids, contracts_for, scope_form, root
from .forms import OperationForm, ReceiptForm
from .lifecycle import entries_for


class WorkflowForm(forms.ModelForm):
    expected_version=forms.IntegerField(widget=forms.HiddenInput,required=False)
    reason=forms.CharField(label='علت ویرایش',max_length=240,required=False,widget=forms.Textarea(attrs={'rows':2}))
    operation_key=forms.UUIDField(widget=forms.HiddenInput,initial=uuid.uuid4)
    def __init__(self,*args,actor=None,**kwargs):
        super().__init__(*args,**kwargs)
        self.actor=actor
        if self.instance.pk:
            self.fields['expected_version'].initial=getattr(self.instance,'version',1)
            self.fields['reason'].required=True;self.fields['reason'].min_length=10
        else:self.fields.pop('reason')
        if actor:scope_form(self,actor)
        for name,field in self.fields.items():
            if isinstance(field,forms.DateField):field.widget=forms.DateInput(attrs={'type':'date'})
            if isinstance(field.widget,forms.Textarea):field.widget.attrs.setdefault('rows',3)
    def data_fields(self):return {name:self.cleaned_data[name] for name in self._meta.fields if name in self.cleaned_data}


class EquipmentForm(WorkflowForm):
    class Meta:
        model=m.Equipment
        fields=['branch','code','name','item','trace','serial','custodian','location','status','installed_on','warranty_until','critical','notes']
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.instance.pk:self.fields['branch'].disabled=True


class MaintenancePlanForm(WorkflowForm):
    class Meta:
        model=m.MaintenancePlan
        fields=['equipment','title','interval_days','next_due','instructions','active']
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.instance.pk and self.instance.maintenancejob_set.exists():self.fields['equipment'].disabled=True


class MaintenanceJobForm(WorkflowForm):
    class Meta:
        model=m.MaintenanceJob
        fields=['equipment','plan','number','title','description','due_on','technician']
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.instance.pk:self.fields['equipment'].disabled=True


class MaintenanceResultForm(OperationForm):
    expected_version=forms.IntegerField(widget=forms.HiddenInput)
    result=forms.CharField(label='کار انجام‌شده و نتیجه',min_length=10,max_length=20000,widget=forms.Textarea(attrs={'rows':5}))
    reported_cost=forms.IntegerField(label='هزینهٔ اعلام‌شده (ریال؛ ثبت پرداخت جداست)',min_value=0,max_value=999999999999999999,initial=0)
    downtime_minutes=forms.IntegerField(label='توقف دستگاه (دقیقه)',min_value=0,max_value=52560000,initial=0)
    payment=forms.ModelChoiceField(label='سند پرداخت ثبت‌شدهٔ مرتبط',queryset=m.MoneyEntry.objects.none(),required=False)
    document=forms.ModelChoiceField(label='سند یا اسکن مرتبط',queryset=m.Document.objects.none(),required=False)
    def __init__(self,*args,actor,job,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['expected_version'].initial=job.version
        for name in ['result','reported_cost','downtime_minutes','payment','document']:
            self.fields[name].initial=getattr(job,name)
        if actor.has_perm('core.view_moneyentry') and actor.has_perm('core.view_account'):
            self.fields['payment'].queryset=entries_for(actor).filter(kind='payment',account__branch_id=job.branch_id)
        else:self.fields.pop('payment')
        if actor.has_perm('core.view_document'):
            from .documents import visible_documents
            self.fields['document'].queryset=visible_documents(actor).filter(branch_id=job.branch_id)
        else:self.fields.pop('document')
        scope_form(self,actor)


class CountScheduleForm(WorkflowForm):
    class Meta:
        model=m.CountSchedule
        fields=['warehouse','title','interval_days','next_due','active']
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.instance.pk and self.instance.runs.exists():self.fields['warehouse'].disabled=True


class ApprovalPolicyForm(WorkflowForm):
    class Meta:
        model=m.ApprovalPolicy
        fields=['name','kind','branch','include_descendants','minimum_amount','required_votes','roles','active']
        widgets={'roles':forms.CheckboxSelectMultiple()}


class FinancialPeriodForm(WorkflowForm):
    class Meta:
        model=m.FinancialPeriod
        fields=['name','branch','starts_on','ends_on','locked','reason']
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if 'reason' not in self.fields:self.fields['reason']=forms.CharField(label='علت ایجاد یا بستن دوره',min_length=10,max_length=240)


class QualityPolicyForm(WorkflowForm):
    class Meta:
        model=m.QualityPolicy
        fields=['branch','required','instructions']


class InspectionForm(ReceiptForm):
    notes=forms.CharField(label='شرایط و مشاهدات پیش از بازرسی',required=False,max_length=20000,widget=forms.Textarea(attrs={'rows':3}))
    document=forms.ModelChoiceField(label='سند یا اسکن مرتبط',queryset=m.Document.objects.none(),required=False)
    expected_version=forms.IntegerField(widget=forms.HiddenInput,required=False)
    reason=forms.CharField(label='علت ویرایش',required=False,max_length=240)
    def __init__(self,*args,actor,contract,inspection=None,**kwargs):
        super().__init__(*args,contract=contract,**kwargs)
        if actor.has_perm('core.view_document'):
            from .documents import visible_documents
            self.fields['document'].queryset=visible_documents(actor).filter(branch=contract.warehouse.branch).filter(Q(contract__isnull=True)|Q(contract=contract))
        else:self.fields.pop('document')
        if inspection:
            self.fields['expected_version'].initial=inspection.version
            self.fields['reason'].required=True;self.fields['reason'].min_length=10
            for name in ['reference','notes','document']:
                if name in self.fields:self.fields[name].initial=getattr(inspection,name)
            for pk,row in inspection.payload.items():
                for prefix,value in [('line',row['quantity']),('location',row['location']),('trace',row['trace'])]:
                    if prefix+'_'+pk in self.fields:self.fields[prefix+'_'+pk].initial=value
        else:self.fields.pop('reason')
        scope_form(self,actor)


class ContractSelectionForm(forms.Form):
    contract=forms.ModelChoiceField(label='قرارداد تحویل',queryset=m.Contract.objects.none())
    def __init__(self,*args,actor,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['contract'].queryset=contracts_for(actor,True).exclude(status__in=['draft','cancelled','received'])
        scope_form(self,actor)


class RefundForm(WorkflowForm):
    class Meta:
        model=m.RefundRequest
        fields=['original','reference','reason']
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['reason']=forms.CharField(label='علت و مستند برگشت پرداخت',min_length=10,max_length=240,widget=forms.Textarea(attrs={'rows':3}),initial=self.instance.reason if self.instance.pk else '')
        self.fields['original'].queryset=entries_for(self.actor).filter(kind='payment')
        if self.instance.pk:self.fields['original'].disabled=True
        scope_form(self,self.actor)


class ActionForm(forms.Form):
    note=forms.CharField(label='علت و نتیجهٔ بررسی',max_length=240,required=False,widget=forms.Textarea(attrs={'rows':3}))


class ArchiveForm(forms.Form):
    reason=forms.CharField(label='علت حذف از فهرست فعال',min_length=10,max_length=240,widget=forms.Textarea(attrs={'rows':3}))


class FollowUpForm(forms.Form):
    expected_version=forms.IntegerField(widget=forms.HiddenInput,initial=0)
    assigned_to=forms.ModelChoiceField(label='مسئول پیگیری',queryset=get_user_model().objects.none(),required=False)
    due_on=forms.DateField(label='مهلت پیگیری',required=False,widget=forms.DateInput(attrs={'type':'date'}))
    status=forms.ChoiceField(label='وضعیت رسیدگی',choices=m.FollowUp._meta.get_field('status').choices)
    note=forms.CharField(label='شرح اقدام و نتیجه',min_length=10,max_length=10000,widget=forms.Textarea(attrs={'rows':4}))
    def __init__(self,*args,actor,instance=None,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['assigned_to'].queryset=get_user_model().objects.filter(is_active=True).filter(
            Q(is_superuser=True)|Q(factory_profile__branch_id__in=factory_ids(actor))) if root(actor) else get_user_model().objects.filter(is_active=True,factory_profile__branch_id__in=factory_ids(actor))
        if instance:
            self.fields['expected_version'].initial=instance.version
            for name in ['assigned_to','due_on','status','note']:self.fields[name].initial=getattr(instance,name)
        scope_form(self,actor)


class SecureExportForm(OperationForm):
    peer=forms.ModelChoiceField(label='نصب گیرنده',queryset=m.ExchangePeer.objects.none())
    scope=forms.ModelChoiceField(label='موقعیتِ اطلاعات ارسالی',queryset=m.Branch.objects.none())
    sections=forms.MultipleChoiceField(label='بخش‌های مجاز',choices=[],widget=forms.CheckboxSelectMultiple)
    include_descendants=forms.BooleanField(label='شامل اطلاعات زیرموقعیت‌های مجاز',required=False)
    baseline=forms.BooleanField(label='نسخهٔ کامل برای آغاز یا رفع تعارض',required=False)
    def __init__(self,*args,actor,**kwargs):
        super().__init__(*args,**kwargs)
        from .secure_exchange import SECTIONS
        labels={'inventory':'انبار و محل دقیق / بچ / سریال','contracts':'قراردادهای دارای مجوز صریح','accounts':'حساب‌های مالی','equipment':'دستگاه‌ها','maintenance':'تعمیرات و سرویس','quality':'کنترل کیفیت'}
        from .access import ancestors
        allowed=set()
        for pk in factory_ids(actor):allowed.update(ancestors(pk))
        self.fields['peer'].queryset=m.ExchangePeer.objects.select_related('source').filter(source__branch_id__in=allowed)
        self.fields['peer'].label_from_instance=lambda p:p.source.label
        self.fields['scope'].queryset=m.Branch.objects.filter(pk__in=factory_ids(actor))
        self.fields['sections'].choices=[(name,labels[name]) for name,perm in SECTIONS.items() if actor.has_perm('core.'+perm)]
        self.fields['sections'].initial=['inventory'] if actor.has_perm('core.view_stockmovement') else []
        scope_form(self,actor)


class SecureImportForm(forms.Form):
    file=forms.FileField(label='فایل تغییرات یا رسید رمزگذاری‌شده',widget=forms.FileInput(attrs={'accept':'.amar,.json'}))


class SecureReviewForm(ActionForm):
    replace_baseline=forms.BooleanField(label='جایگزینی نسخهٔ کامل پس از بررسی تعارض (فقط حساب ارشد)',required=False)
