"""Business outcomes and scope boundaries for the offline factory workflows."""
import io
import json
import tempfile
import uuid
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.management import call_command
from django.contrib.auth.models import Permission
from django.test import override_settings
from django.urls import reverse
from django.utils import timezone
from core import models as m, services, operations as op, pro_services as pro, secure_exchange as secure, attention, lifecycle
from .helpers import body
from .test_enterprise import EnterpriseBase


class ApprovalAndMoneyTests(EnterpriseBase):
    def payment(self,amount=100):
        c,line=self.contract('PAY',True,True)
        allocation=services.allocate(c.pk,self.account.pk,1000,uuid.uuid4(),self.finance)
        return c,allocation,op.request_payment(self.finance,allocation,amount,'PAY-1','پرداخت نمونه',uuid.uuid4())

    def test_multi_person_payment_posts_only_after_last_distinct_vote(self):
        c,a,request=self.payment()
        m.ApprovalPolicy.objects.create(name='دو امضا',kind='payment',branch=self.city,minimum_amount=100,required_votes=2)
        result=op.approve_payment(self.approver,request.pk)
        self.assertEqual(result.status,'pending')
        self.assertEqual(m.MoneyEntry.objects.count(),0)
        self.assertEqual(self.account.balance,100000)
        op.approve_payment(self.approver,request.pk)
        self.assertEqual(m.ApprovalVote.objects.count(),1)
        self.allow_approval(self.finance)
        with self.assertRaises(ValidationError):op.approve_payment(self.finance,request.pk)
        op.approve_payment(self.owner,request.pk)
        self.assertEqual(m.MoneyEntry.objects.filter(kind='payment').count(),1)
        self.assertEqual(self.account.balance,99900)
        self.assertEqual(c.paid,100)
        op.approve_payment(self.owner,request.pk)
        self.assertEqual(m.MoneyEntry.objects.count(),1)

    def test_started_policy_is_frozen_and_rejected_revision_needs_edit(self):
        c,a,request=self.payment()
        policy=m.ApprovalPolicy.objects.create(name='دو امضا',kind='payment',minimum_amount=1,required_votes=2)
        op.approve_payment(self.approver,request.pk)
        policy.required_votes=5;policy.save()
        op.approve_payment(self.owner,request.pk)
        self.assertEqual(m.ApprovalCase.objects.get().required_votes,2)
        self.assertEqual(m.ApprovalCase.objects.get().status,'approved')

    def test_contract_revision_invalidation_and_creator_independence(self):
        c=m.Contract.objects.create(number='DRAFT',title='قرارداد',supplier=self.supplier,warehouse=self.w,created_by=self.owner)
        m.ContractLine.objects.create(contract=c,item=self.item,quantity=10,unit_price=100)
        m.ContractGrant.objects.create(contract=c,branch=self.leaf,can_operate=True,created_by=self.owner)
        m.ApprovalPolicy.objects.create(name='قرارداد حساس',kind='contract',required_votes=2)
        with self.assertRaises(ValidationError):services.approve_contract(c.pk,self.owner)
        services.approve_contract(c.pk,self.approver)
        c.refresh_from_db();self.assertEqual(c.status,'draft')
        c.revision_number+=1;c.save()
        second=self.person('second','approval',self.city,True)
        services.approve_contract(c.pk,second)
        c.refresh_from_db();self.assertEqual(c.status,'draft')
        services.approve_contract(c.pk,self.approver)
        c.refresh_from_db();self.assertEqual(c.status,'approved')
        self.assertEqual(m.ApprovalCase.objects.count(),2)
        self.assertEqual(int(m.StockSummary.objects.get(warehouse=self.w,item=self.item).milliunits),100000)

    def test_refund_preserves_posting_restores_net_values_and_blocks_deletion(self):
        c,a,r=self.payment()
        op.approve_payment(self.approver,r.pk);r.refresh_from_db()
        original=r.entry
        refund=pro.request_refund(self.finance,original,'RET-1','برگشت به علت مغایرت مستند',uuid.uuid4())
        self.allow_approval(self.finance)
        with self.assertRaises(ValidationError):pro.approve_refund(self.finance,refund.pk)
        pro.approve_refund(self.approver,refund.pk)
        self.assertEqual(self.account.balance,100000)
        self.assertEqual(c.paid,0)
        self.assertEqual(a.paid,0)
        self.assertEqual(self.account.reserved,1000)
        self.assertEqual(m.MoneyEntry.objects.get(pk=original.pk).amount,100)
        self.assertEqual(m.MoneyEntry.objects.get(kind='refund').reverses_id,original.pk)
        with self.assertRaises(ValidationError):pro.request_refund(self.finance,original,'RET-2','درخواست تکراری برگشت',uuid.uuid4())
        with self.assertRaises(ValidationError):lifecycle.archive_contract(self.owner,c.pk,'حذف آزمایشی با علت صریح')
        with self.assertRaises(ValidationError):lifecycle.revise_allocation(self.owner,a.pk,'حذف آزمایشی تخصیص وجه',uuid.uuid4())
        with self.assertRaises(ValidationError):services.cancel_contract(c.pk,self.owner)

    def test_closed_parent_period_blocks_money_and_can_be_reopened_with_history(self):
        c,a,r=self.payment()
        today=timezone.localdate()
        p=pro.save_rule(self.owner,'period',{'name':'دوره بسته','branch':self.city,'starts_on':today,'ends_on':today,'locked':True,'reason':'بستن دوره برای کنترل نهایی'})
        with self.assertRaises(ValidationError):services.deposit(self.account.pk,100,'DEP-1',uuid.uuid4(),self.finance)
        with self.assertRaises(ValidationError):op.approve_payment(self.approver,r.pk)
        with self.assertRaises(ValidationError):services.set_credit(self.account.pk,1000,self.owner)
        with self.assertRaises(ValidationError):lifecycle.revise_allocation(self.owner,a.pk,'اصلاح در دورهٔ مالی بسته',uuid.uuid4(),500)
        self.assertEqual(m.MoneyEntry.objects.count(),0)
        pro.save_rule(self.owner,'period',{'name':p.name,'branch':self.city,'starts_on':today,'ends_on':today,'locked':False,'reason':'بازگشایی با مستند اصلاحی'},p.pk,p.version,'بازگشایی با مستند اصلاحی')
        op.approve_payment(self.approver,r.pk)
        self.assertEqual(m.ChangeRecord.objects.filter(kind='financialperiod').count(),2)


class QualityAssetAndMaintenanceTests(EnterpriseBase):
    def equipment(self,**extra):
        return pro.save_equipment(self.owner,{'branch':self.leaf,'code':'AS-1','name':'دستگاه اصلی','status':'operating',**extra})

    def inspection(self):
        c,line=self.contract('QC',True,True)
        m.QualityPolicy.objects.create(branch=self.leaf,required=True)
        obj=pro.request_inspection(self.requester,c,{line.pk:2},{line.pk:self.location},{},'QC-1','ظاهر سالم',uuid.uuid4())
        return c,line,obj

    def test_quality_gate_no_physical_stock_before_independent_acceptance(self):
        c,line,obj=self.inspection()
        self.assertEqual(line.received,0)
        with self.assertRaises(ValidationError):services.receive(c.pk,{line.pk:2},'BYPASS',uuid.uuid4(),self.owner,{line.pk:self.location})
        self.requester.factory_profile.role.permissions.add(Permission.objects.get(codename='review_deliveryinspection'))
        with self.assertRaises(ValidationError):pro.review_inspection(self.requester,obj.pk,True,'کیفیت کالا تأیید شده است')
        pro.review_inspection(self.approver,obj.pk,True,'کیفیت کالا تأیید شده است')
        self.assertEqual(line.received,2)
        self.assertEqual(int(m.StockSummary.objects.get(item=self.item,warehouse=self.w).milliunits),102000)
        with self.assertRaises(ValidationError):pro.archive_record(self.owner,'inspection',obj.pk,'حذف آزمایشی با علت کامل')

    def test_stale_contract_invalidates_pending_quality_and_edit_is_versioned(self):
        c,line,obj=self.inspection()
        c.revision_number+=1;c.save()
        with self.assertRaises(ValidationError):pro.review_inspection(self.approver,obj.pk,True,'تأیید آزمایشی کیفیت کالا')
        self.assertFalse(m.Receipt.objects.exists())
        with self.assertRaises(ValidationError):pro.request_inspection(self.owner,c,{line.pk:2},{line.pk:self.location},{},'QC-1','اصلاح',uuid.uuid4(),existing=obj,version=0,reason='اصلاح بازرسی قرارداد جدید')

    def test_equipment_edit_version_scope_and_before_after_history(self):
        obj=self.equipment()
        pro.save_equipment(self.owner,{'branch':self.leaf,'code':'AS-1','name':'نام تازه','status':'down'},obj.pk,obj.version,'اصلاح نام و وضعیت دستگاه')
        with self.assertRaises(ValidationError):pro.save_equipment(self.owner,{'branch':self.leaf,'name':'دوباره'},obj.pk,1,'ویرایش از فرم قدیمی باز')
        with self.assertRaises(PermissionDenied):pro.save_equipment(self.receiver,{'branch':self.leaf,'name':'غیرمجاز'},obj.pk,2,'تلاش غیرمجاز از موقعیت دیگر')
        record=m.ChangeRecord.objects.filter(kind='equipment',object_id=obj.pk).first()
        self.assertEqual(record.before['name'],'دستگاه اصلی')
        self.assertEqual(record.after['name'],'نام تازه')

    def test_maintenance_independent_result_and_parts_must_be_settled(self):
        obj=self.equipment();tech=self.person('tech','maintenance',self.leaf)
        plan=pro.save_maintenance_plan(self.owner,{'equipment':obj,'title':'روغن‌کاری','interval_days':30,'next_due':timezone.localdate(),'instructions':'سرویس کامل','active':True})
        job=pro.request_maintenance(tech,{'equipment':obj,'plan':plan,'number':'MT-1','title':'سرویس','description':'بازرسی و تعویض قطعه','due_on':timezone.localdate()},uuid.uuid4())
        request=op.request_material(tech,self.w,self.item,self.location,None,2,self.custodian,job.work_order,'تعویض قطعه',uuid.uuid4())
        op.approve_material(self.approver,request.pk)
        report='گزارش مفصل انجام سرویس دستگاه. '*30
        pro.maintenance_result(tech,job.pk,report,100,20,version=job.version)
        tech.factory_profile.role.permissions.add(Permission.objects.get(codename='review_maintenancejob'))
        with self.assertRaises(ValidationError):pro.review_maintenance(tech,job.pk,True,'تأیید نهایی سرویس دستگاه')
        with self.assertRaises(ValidationError):pro.review_maintenance(self.approver,job.pk,True,'تأیید نهایی سرویس دستگاه')
        op.cancel_reservation(self.approver,'material',request.pk)
        pro.review_maintenance(self.approver,job.pk,True,'تأیید نهایی سرویس دستگاه')
        job.refresh_from_db();plan.refresh_from_db()
        self.assertEqual(job.status,'closed');self.assertEqual(job.result,report.strip())
        self.assertEqual(plan.next_due,timezone.localdate()+timedelta(days=30))
        self.assertFalse(m.WorkOrder.objects.get(pk=job.work_order_id).active)

    def test_scheduled_count_advances_only_after_approval(self):
        schedule=pro.save_count_schedule(self.owner,{'warehouse':self.w,'title':'ماهانه','interval_days':20,'next_due':timezone.localdate(),'active':True})
        count=op.request_count(self.requester,self.w,'CT-1',[{'item':self.item,'location':self.location,'trace':None,'counted':99}],uuid.uuid4(),schedule=schedule)
        schedule.refresh_from_db();self.assertIsNone(schedule.last_count_id)
        with self.assertRaises(ValidationError):op.request_count(self.requester,self.w,'CT-2',[],uuid.uuid4(),schedule=schedule)
        op.approve_count(self.approver,count.pk)
        schedule.refresh_from_db();self.assertEqual(schedule.last_count_id,count.pk)
        self.assertEqual(schedule.next_due,timezone.localdate()+timedelta(days=20))

    def test_controlled_serial_transfer_moves_passport_and_keeps_old_history_scoped(self):
        item=m.Item.objects.create(name='ماشین',sku='SER',tracking='serial')
        trace=m.TraceUnit.objects.create(item=item,code='SER-1')
        m.StockMovement.objects.create(warehouse=self.w,item=item,trace=trace,location=self.location,kind='in',quantity=1,reference='INITIAL')
        obj=self.equipment(item=item,trace=trace,location=self.location,custodian=self.custodian)
        transfer=op.request_transfer(self.owner,self.w,self.dest,item,self.location,trace,1,'MOVE-1',uuid.uuid4())
        op.approve_transfer(self.approver,transfer.pk);op.send_transfer(self.requester,transfer.pk)
        with self.assertRaises(ValidationError):pro.save_equipment(self.owner,{'branch':self.leaf,'name':obj.name},obj.pk,obj.version,'اصلاح در زمان انتقال')
        op.receive_transfer(self.receiver,transfer.pk,self.destination_location)
        obj.refresh_from_db();self.assertEqual(obj.branch_id,self.foreign.pk)
        self.assertEqual(obj.location_id,self.destination_location.pk);self.assertIsNone(obj.custodian_id)


class DeskAndInterfaceTests(EnterpriseBase):
    def test_followup_ownership_deadline_and_recurring_exception(self):
        equipment=pro.save_equipment(self.owner,{'branch':self.leaf,'code':'E-1','name':'دستگاه'})
        plan=pro.save_maintenance_plan(self.owner,{'equipment':equipment,'title':'سرویس','interval_days':30,'next_due':timezone.localdate(),'active':True})
        key='service:'+str(plan.pk)
        data={'assigned_to':self.approver,'due_on':timezone.localdate(),'status':'resolved','note':'سرویس بررسی و اقدام ثبت شد'}
        followup=attention.follow_up(self.owner,key,data,0)
        self.assertEqual(followup.assigned_to_id,self.approver.pk)
        self.assertEqual(followup.fingerprint,attention.issue_for(self.owner,key)['fingerprint'])
        plan.version+=1;plan.save()
        self.assertNotEqual(followup.fingerprint,attention.issue_for(self.owner,key)['fingerprint'])
        with self.assertRaises(PermissionDenied):attention.issue_for(self.receiver,key)
        data['assigned_to']=self.receiver
        with self.assertRaises(ValidationError):attention.follow_up(self.owner,key,data,followup.version)

    def test_new_pages_and_forms_render_and_create_equipment_from_web(self):
        self.client.force_login(self.owner)
        paths=['/work/','/work/approvals/','/work/desk/','/work/scan/','/exchange/secure/']
        for kind in ['equipment','maintenance','plan','count','refund','inspection']:
            paths+=[reverse('work_list',args=[kind])]
            if kind!='inspection':paths+=[reverse('work_new',args=[kind])]
        for kind in ['policy','period','quality']:
            paths += [reverse('work_rules',args=[kind]),reverse('work_rule_new',args=[kind])]
        paths += [reverse('inspection_new'),reverse('secure_export'),reverse('item_passport',args=[self.item.pk])]
        for path in paths:
            response=self.client.get(path);self.assertEqual(response.status_code,200,path)
        response=self.client.post(reverse('work_new',args=['equipment']),{'operation_key':uuid.uuid4(),'branch':self.leaf.pk,'code':'WEB-1','name':'دستگاه وب','status':'operating'})
        self.assertEqual(response.status_code,302,body(response))
        asset=m.Equipment.objects.get(code='WEB-1')
        for path in [reverse('work_detail',args=['equipment',asset.pk]),reverse('equipment_label',args=[asset.pk]),reverse('change_detail',args=[m.ChangeRecord.objects.get(object_id=asset.pk).pk])]:
            self.assertEqual(self.client.get(path).status_code,200,path)
        self.client.force_login(self.receiver)
        self.assertEqual(self.client.get(reverse('work_detail',args=['equipment',asset.pk])).status_code,404)


class EncryptedExchangeTests(EnterpriseBase):
    def setUp(self):
        super().setUp()
        self.a=tempfile.TemporaryDirectory();self.addCleanup(self.a.cleanup)
        self.b=tempfile.TemporaryDirectory();self.addCleanup(self.b.cleanup)
        with override_settings(DATA_DIR=Path(self.a.name)):self.identity_a=secure.public_identity()
        with override_settings(DATA_DIR=Path(self.b.name)):
            self.identity_b=secure.public_identity()
            self.source_a=secure.trust_identity(secure.canonical(self.identity_a),'مبدأ یک',self.owner)
        self.source_a.branch=self.leaf;self.source_a.save()
        self.peer_a=self.source_a.exchange_peer
        with override_settings(DATA_DIR=Path(self.a.name)):
            self.source_b=secure.trust_identity(secure.canonical(self.identity_b),'گیرنده دو',self.owner)
        self.source_b.branch=self.leaf;self.source_b.save();self.peer_b=self.source_b.exchange_peer

    def prepare(self,baseline=False):
        with override_settings(DATA_DIR=Path(self.a.name)):
            return secure.prepare(self.owner,self.peer_b.pk,self.leaf,['contracts','inventory','equipment'],baseline=baseline)

    def deliver(self,out,accept=True):
        with override_settings(DATA_DIR=Path(self.b.name)):
            inbox=secure.import_file(self.owner,bytes(out.envelope))
            return secure.review(self.owner,inbox.pk,accept,'بررسی و تأیید اطلاعات دریافتی')

    def ack(self,inbox):
        with override_settings(DATA_DIR=Path(self.a.name)):return secure.import_file(self.owner,bytes(inbox.receipt))

    def test_full_delta_deletion_ack_and_duplicate_do_not_post_local_ledgers(self):
        c,line=self.contract('VISIBLE-X',True,True)
        hidden,_=self.contract('SECRET-X')
        asset=pro.save_equipment(self.owner,{'branch':self.leaf,'code':'E-X','name':'دستگاه پنهان در رمز'})
        out=self.prepare()
        self.assertNotIn('VISIBLE-X',bytes(out.envelope).decode())
        self.assertNotIn('دستگاه پنهان در رمز',bytes(out.envelope).decode())
        with self.assertRaises(ValidationError):self.prepare()
        original_count=m.StockMovement.objects.count()
        inbox=self.deliver(out)
        self.assertEqual(inbox.status,'applied')
        self.assertEqual(m.StockMovement.objects.count(),original_count)
        self.assertEqual(m.MoneyEntry.objects.count(),0)
        snapshot=self.source_a.latest
        self.assertEqual([x['number'] for x in snapshot.payload['contracts']],['VISIBLE-X'])
        with override_settings(DATA_DIR=Path(self.b.name)):
            self.assertEqual(secure.import_file(self.owner,bytes(out.envelope)).pk,inbox.pk)
        self.ack(inbox);self.ack(inbox)
        asset.archived_at=timezone.now();asset.save()
        c.title='عنوان تازه';c.save()
        second=self.prepare();received=self.deliver(second)
        self.assertFalse(received.payload['baseline'])
        self.assertTrue(received.payload['deletes'])
        self.assertLess(len(received.payload['upserts']),len(inbox.payload['upserts']))
        self.assertFalse(m.ExchangeReplica.objects.filter(peer=self.peer_a,kind='equipment').exists())
        self.assertEqual(self.source_a.latest.payload['contracts'][0]['title'],'عنوان تازه')

    def test_recipient_signature_tamper_and_scope_are_enforced(self):
        out=self.prepare()
        with override_settings(DATA_DIR=Path(self.a.name)):
            with self.assertRaises(ValidationError):secure.import_file(self.owner,bytes(out.envelope))
        value=json.loads(bytes(out.envelope));value['ciphertext']=value['ciphertext'][::-1]
        with override_settings(DATA_DIR=Path(self.b.name)):
            with self.assertRaises(ValidationError):secure.import_file(self.owner,secure.canonical(value))
            with self.assertRaises(PermissionDenied):secure.import_file(self.receiver,bytes(out.envelope))
        self.assertEqual(m.ExchangeInbox.objects.count(),0)

    def test_conflict_is_reviewed_and_older_baseline_cannot_replace_newer(self):
        out=self.prepare();inbox=self.deliver(out);self.ack(inbox)
        second=self.prepare()
        self.peer_a.last_received_hash='f'*64;self.peer_a.save()
        with override_settings(DATA_DIR=Path(self.b.name)):
            conflict=secure.import_file(self.owner,bytes(second.envelope))
            self.assertEqual(conflict.status,'conflict')
            with self.assertRaises(ValidationError):secure.review(self.owner,conflict.pk,True)
            rejected=secure.review(self.owner,conflict.pk,False,'نیاز به نسخهٔ کامل تازه است')
        self.ack(rejected)
        fresh=self.prepare(baseline=True)
        with override_settings(DATA_DIR=Path(self.b.name)):
            item=secure.import_file(self.owner,bytes(fresh.envelope))
            secure.review(self.owner,item.pk,True,'بازسازی نسخهٔ کامل با بررسی مسئول',replace_baseline=True)
        self.assertEqual(self.source_a.latest.sequence,fresh.sequence)

    def test_backup_includes_encryption_identity_and_legacy_downgrade_is_blocked(self):
        out=self.prepare();self.deliver(out)
        self.source_a.refresh_from_db();self.assertTrue(self.source_a.encrypted_only)
        from core import sync
        with override_settings(DATA_DIR=Path(self.a.name)):
            report=sync.export_report(self.owner)
        with override_settings(DATA_DIR=Path(self.b.name)):
            with self.assertRaises(ValidationError):sync.import_report(report,self.owner)
