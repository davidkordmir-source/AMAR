import hashlib
import json
import uuid
from datetime import timedelta
from decimal import Decimal
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import Q, Count
from django.db.models import Exists, OuterRef
from django.db.models.fields.json import KeyTextTransform
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST
from . import models as m, pro_forms as f, pro_services as pro, services, operations, attention, secure_exchange as secure
from .access import contracts_for, factory_ids, require_factory, require_permission, root, scope_form
from .enterprise_views import permitted, owner
from .lifecycle import entries_for

RECORDS={
    'equipment':(m.Equipment,f.EquipmentForm,'دستگاه‌ها و دارایی‌ها'),
    'maintenance':(m.MaintenanceJob,f.MaintenanceJobForm,'تعمیرات و سرویس'),
    'plan':(m.MaintenancePlan,f.MaintenancePlanForm,'برنامهٔ سرویس دوره‌ای'),
    'count':(m.CountSchedule,f.CountScheduleForm,'برنامهٔ انبارگردانی'),
    'refund':(m.RefundRequest,f.RefundForm,'برگشت پرداخت'),
    'inspection':(m.DeliveryInspection,None,'کنترل کیفیت تحویل'),
}
RULES={'policy':(m.ApprovalPolicy,f.ApprovalPolicyForm,'قواعد تأیید چندنفره'),
    'period':(m.FinancialPeriod,f.FinancialPeriodForm,'دوره‌های مالی'),
    'quality':(m.QualityPolicy,f.QualityPolicyForm,'قواعد کنترل کیفیت')}


def pager(request,objects,size=30):
    if not objects.ordered:objects=objects.order_by('pk')
    return Paginator(objects,size).get_page(request.GET.get('page'))


def scoped(actor,kind):
    if kind not in RECORDS:raise Http404
    model=RECORDS[kind][0];require_permission(actor,'view_'+model._meta.model_name)
    ids=factory_ids(actor)
    if kind=='equipment':return model.objects.filter(branch_id__in=ids,archived_at__isnull=True).select_related('branch','custodian','location','item','trace')
    if kind=='maintenance':return model.objects.filter(branch_id__in=ids,archived_at__isnull=True).select_related('equipment','branch','plan','requested_by','reviewed_by')
    if kind=='plan':return model.objects.filter(equipment__branch_id__in=ids).select_related('equipment__branch')
    if kind=='count':return model.objects.filter(warehouse__branch_id__in=ids).select_related('warehouse__branch')
    if kind=='inspection':return model.objects.filter(contract__in=contracts_for(actor),archived_at__isnull=True).select_related('contract__warehouse__branch','requested_by','reviewed_by','receipt')
    require_permission(actor,'view_moneyentry');require_permission(actor,'view_account')
    return model.objects.filter(original__in=entries_for(actor),archived_at__isnull=True).select_related('original__account__branch','original__allocation__contract','requested_by','approved_by','entry')


def context(title,**extra):return {'page_title':title,'active_page':'work',**extra}


def form_page(request,form,title,help_text='',**extra):
    return render(request,'core/work/form.html',context(title,form=form,help_text=help_text,**extra))


def _error(form,error):
    form.add_error(None,'کد یا شماره سند تکراری است؛ چیزی ثبت نشد.' if isinstance(error,IntegrityError) else error)


@permitted('view_branch')
def home(request):
    ids=factory_ids(request.user);today=timezone.localdate();cards=[];tasks=[]
    def card(title,kind,permission):
        if request.user.has_perm('core.'+permission):cards.append({'title':title,'url':reverse('work_list',args=[kind])})
    card('دستگاه و شناسنامهٔ دارایی','equipment','view_equipment')
    card('تعمیر و سرویس','maintenance','view_maintenancejob')
    card('برنامهٔ سرویس دوره‌ای','plan','view_maintenanceplan')
    card('کنترل کیفیت تحویل','inspection','view_deliveryinspection')
    card('انبارگردانی برنامه‌ریزی‌شده','count','view_countschedule')
    card('برگشت پرداخت','refund','view_refundrequest')
    def group(title,objects,kind):
        tasks.append({'title':title,'rows':[{'title':str(obj),'url':reverse('work_detail',args=[kind,obj.pk])} for obj in objects[:8]]})
    if request.user.has_perm('core.view_maintenancejob'):
        group('کارهای تعمیر باز',scoped(request.user,'maintenance').exclude(status__in=['closed','cancelled']),'maintenance')
    if request.user.has_perm('core.view_deliveryinspection'):
        group('تحویل‌های منتظر بازرسی',scoped(request.user,'inspection').filter(status='pending'),'inspection')
    followups=attention.followups_for(request.user).filter(Q(assigned_to=request.user)|Q(updated_by=request.user)).exclude(status='resolved').select_related('branch','assigned_to')[:10] if request.user.has_perm('core.view_followup') else []
    return render(request,'core/work/home.html',context('کارهای روزانه و عملیات کارخانه',cards=cards,tasks=tasks,followups=followups))


@login_required
def record_list(request,kind):
    objects=scoped(request.user,kind)
    query=request.GET.get('q','').strip()[:120]
    searches={'equipment':['code','name','serial'],'maintenance':['number','title','equipment__code'],'plan':['title','equipment__code'],'count':['title','warehouse__name'],'inspection':['reference','contract__number'],'refund':['reference','reason']}
    if query:
        where=Q()
        for name in searches[kind]:where|=Q(**{name+'__icontains':query})
        objects=objects.filter(where)
    if kind in ('plan','count') and request.GET.get('inactive')!='1':objects=objects.filter(active=True)
    selected=request.GET.get('status','')
    if selected and kind not in ('plan','count'):objects=objects.filter(status=selected)
    page=pager(request,objects);rows=[]
    for obj in page:
        unit=obj.branch if kind in ('equipment','maintenance') else obj.equipment.branch if kind=='plan' else obj.warehouse.branch if kind=='count' else obj.contract.warehouse.branch if kind=='inspection' else obj.original.account.branch
        state=obj.get_status_display() if hasattr(obj,'status') else ('فعال' if obj.active else 'غیرفعال')
        rows.append({'title':str(obj),'unit':unit.name,'status':state,'url':reverse('work_detail',args=[kind,obj.pk]),'due':getattr(obj,'next_due',None) or getattr(obj,'due_on',None)})
    model=RECORDS[kind][0]
    new_url=reverse('inspection_new') if kind=='inspection' else reverse('work_new',args=[kind])
    return render(request,'core/work/list.html',context(RECORDS[kind][2],objects=page,rows=rows,search=query,kind=kind,
        new_url=new_url if request.user.has_perm('core.add_'+model._meta.model_name) else '',status_choices=model._meta.get_field('status').choices if hasattr(model,'status') else [],selected_status=selected))


@login_required
def record_form(request,kind,pk=None):
    if kind not in RECORDS or kind=='inspection':raise Http404
    model,form_class,title=RECORDS[kind]
    require_permission(request.user,('change_' if pk else 'add_')+model._meta.model_name)
    obj=get_object_or_404(scoped(request.user,kind),pk=pk) if pk else None
    initial={}
    if not pk and kind=='maintenance':
        if request.GET.get('plan'):
            plan=get_object_or_404(scoped(request.user,'plan'),pk=request.GET['plan'],active=True)
            initial.update(plan=plan.pk,equipment=plan.equipment_id,title=plan.title,description=plan.instructions or plan.title,due_on=plan.next_due)
        elif request.GET.get('equipment'):initial['equipment']=get_object_or_404(scoped(request.user,'equipment'),pk=request.GET['equipment']).pk
        initial.setdefault('due_on',timezone.localdate()+timedelta(days=7))
        initial['number']='MT-'+uuid.uuid4().hex[:12].upper()
    if not pk and kind=='plan' and request.GET.get('equipment'):initial['equipment']=get_object_or_404(scoped(request.user,'equipment'),pk=request.GET['equipment']).pk
    if not pk and kind in ('plan','count'):initial['next_due']=timezone.localdate()+timedelta(days=30)
    if not pk and kind=='refund' and request.GET.get('entry'):initial['original']=get_object_or_404(entries_for(request.user),pk=request.GET['entry'],kind='payment').pk
    form=form_class(request.POST or None,instance=obj,initial=initial,actor=request.user)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data;data=form.data_fields();reason=d.get('reason') or 'ثبت اطلاعات اولیه';version=d.get('expected_version')
        try:
            if kind=='equipment':saved=pro.save_equipment(request.user,data,pk,version,reason)
            elif kind=='plan':saved=pro.save_maintenance_plan(request.user,data,pk,version,reason)
            elif kind=='maintenance':saved=pro.request_maintenance(request.user,data,d['operation_key'],pk,version,reason)
            elif kind=='count':saved=pro.save_count_schedule(request.user,data,pk,version,reason)
            elif pk:saved=pro.revise_refund(request.user,pk,d['reference'],d['reason'],version)
            else:saved=pro.request_refund(request.user,d['original'],d['reference'],d['reason'],d['operation_key'])
            messages.success(request,'اطلاعات با حفظ سابقه ثبت شد.');return redirect('work_detail',kind=kind,pk=saved.pk)
        except (ValidationError,IntegrityError) as error:_error(form,error)
    return form_page(request,form,('ویرایش ' if pk else 'ثبت ')+title,'فیلدهای ستاره‌دار را کامل کنید. پرداخت مالی و مصرف قطعه از مسیر تأیید و اسناد خودشان ثبت می‌شوند.')


@login_required
def record_detail(request,kind,pk):
    obj=get_object_or_404(scoped(request.user,kind),pk=pk);model=RECORDS[kind][0]
    names={'equipment':['branch','code','name','item','trace','serial','custodian','location','status','installed_on','warranty_until','critical','notes'],
        'maintenance':['branch','equipment','plan','number','title','description','due_on','technician','status','result','reported_cost','downtime_minutes'],
        'plan':['equipment','title','interval_days','next_due','last_completed','instructions','active'],
        'count':['warehouse','title','interval_days','next_due','active','last_count'],
        'inspection':['contract','reference','notes','status','decision_note','reviewed_at','receipt'],
        'refund':['original','reference','reason','status','entry']}
    fields=[]
    for name in names[kind]:
        value=getattr(obj,name)
        if hasattr(obj,'get_'+name+'_display'):value=getattr(obj,'get_'+name+'_display')()
        if isinstance(value,bool):value='بله' if value else 'خیر'
        fields.append({'label':model._meta.get_field(name).verbose_name,'value':value,'numeric':name in ['reported_cost','downtime_minutes','interval_days']})
    actions=[]
    def action(code,label,permission):
        if request.user.has_perm('core.'+permission):actions.append({'label':label,'url':reverse('work_action',args=[kind,pk,code]),'code':code})
    if kind=='inspection' and obj.status=='pending' and obj.requested_by_id!=request.user.pk:
        action('accept','پذیرش کیفیت و ثبت تحویل','review_deliveryinspection');action('reject','رد کیفیت','review_deliveryinspection')
    if kind=='maintenance':
        if obj.status=='open':action('start','آغاز انجام کار','change_maintenancejob')
        if obj.status=='review' and request.user.pk not in (obj.requested_by_id,obj.result_by_id):
            action('accept','تأیید پایان کار','review_maintenancejob');action('reject','برگشت برای تکمیل','review_maintenancejob')
    if kind=='refund' and obj.status=='pending' and obj.requested_by_id!=request.user.pk:
        action('accept','تأیید برگشت پرداخت','approve_operations');action('reject','رد درخواست','approve_operations')
    history=m.ChangeRecord.objects.filter(kind=model._meta.model_name,object_id=pk,branch_id__in=factory_ids(request.user)).select_related('actor')[:20] if request.user.has_perm('core.view_changerecord') else []
    extra={}
    if kind=='equipment':
        extra['plans']=scoped(request.user,'plan').filter(equipment=obj)[:20] if request.user.has_perm('core.view_maintenanceplan') else []
        extra['jobs']=scoped(request.user,'maintenance').filter(equipment=obj)[:20] if request.user.has_perm('core.view_maintenancejob') else []
    if kind=='inspection':
        extra['inspection_lines']=[{'item':row.get('label','ردیف '+pk),'quantity':row['quantity'],'location':row.get('location_label',''),'trace':row.get('trace_label','')} for pk,row in obj.payload.items()]
    if kind=='maintenance':
        extra['materials']=m.MaterialRequest.objects.filter(work_order=obj.work_order).select_related('item','recipient')[:30] if request.user.has_perm('core.view_materialrequest') else []
    if kind=='refund':extra['refund_amount']=obj.original.amount
    editable=kind not in ('inspection','maintenance','refund') or obj.status in ('pending','open','working')
    return render(request,'core/work/detail.html',context(str(obj),obj=obj,kind=kind,fields=fields,actions=actions,history=history,
        can_edit=editable and request.user.has_perm('core.change_'+model._meta.model_name),
        can_delete=request.user.has_perm('core.delete_'+model._meta.model_name),**extra))


@login_required
def archive(request,kind,pk):
    obj=get_object_or_404(scoped(request.user,kind),pk=pk);require_permission(request.user,'delete_'+RECORDS[kind][0]._meta.model_name)
    form=f.ArchiveForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        try:
            if kind in ('plan','count'):pro.deactivate_rule(request.user,kind,pk,form.cleaned_data['reason'])
            else:pro.archive_record(request.user,kind,pk,form.cleaned_data['reason'])
            messages.success(request,'از فهرست فعال حذف شد؛ سابقه حفظ شد.');return redirect('work_list',kind=kind)
        except ValidationError as error:form.add_error(None,error)
    return form_page(request,form,'بررسی حذف '+str(obj),'وجود پرداخت یا اجرای قطعی می‌تواند حذف را مسدود کند. علت حذف در سابقه ثبت می‌شود.')


@login_required
def inspection_new(request,pk=None):
    require_permission(request.user,'change_deliveryinspection' if pk else 'add_deliveryinspection')
    obj=get_object_or_404(scoped(request.user,'inspection'),pk=pk) if pk else None
    if not obj and not request.GET.get('contract'):
        selection=f.ContractSelectionForm(request.GET or None,actor=request.user)
        return form_page(request,selection,'انتخاب قرارداد برای کنترل کیفیت','ابتدا قرارداد تحویل را جست‌وجو کنید.',form_method='get',submit_label='ادامه')
    contract=obj.contract if obj else get_object_or_404(contracts_for(request.user,True),pk=request.GET['contract'])
    form=f.InspectionForm(request.POST or None,actor=request.user,contract=contract,inspection=obj)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data
        locations={line.pk:d.get('location_'+str(line.pk)) for line in form.lines}
        traces={line.pk:d.get('trace_'+str(line.pk)) for line in form.lines}
        try:
            saved=pro.request_inspection(request.user,contract,form.quantities,locations,traces,d['reference'],d['notes'],d['operation_key'],d.get('document'),obj,d.get('expected_version'),d.get('reason') or 'ثبت بازرسی تحویل')
            messages.success(request,'بازرسی ثبت شد؛ موجودی پس از پذیرش مستقل کیفیت افزایش می‌یابد.');return redirect('work_detail',kind='inspection',pk=saved.pk)
        except (ValidationError,IntegrityError) as error:_error(form,error)
    return form_page(request,form,'کنترل کیفیت تحویل · '+contract.number,'مقدار و محل دقیق هر ردیف را ثبت کنید؛ بازرسیِ در انتظار، موجودی واقعی نیست.')


@login_required
def maintenance_result(request,pk):
    obj=get_object_or_404(scoped(request.user,'maintenance'),pk=pk);require_permission(request.user,'change_maintenancejob')
    form=f.MaintenanceResultForm(request.POST or None,actor=request.user,job=obj)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data
        try:
            pro.maintenance_result(request.user,pk,d['result'],d['reported_cost'],d['downtime_minutes'],d.get('payment'),d.get('document'),d['expected_version'])
            messages.success(request,'نتیجه برای تأیید مستقل ثبت شد.');return redirect('work_detail',kind='maintenance',pk=pk)
        except (ValidationError,IntegrityError) as error:_error(form,error)
    return form_page(request,form,'ثبت نتیجه · '+obj.number,'مصرف یا برگشت قطعات تحویلی را در دستور کار همین تعمیر تعیین تکلیف کنید. هزینهٔ اعلام‌شده به‌تنهایی پرداخت مالی ایجاد نمی‌کند.')


@login_required
@require_POST
def record_action(request,kind,pk,action):
    obj=get_object_or_404(scoped(request.user,kind),pk=pk)
    if action not in ['accept','reject','start']:raise Http404
    form=f.ActionForm(request.POST)
    if form.is_valid():
        note=form.cleaned_data['note']
        try:
            if kind=='inspection':pro.review_inspection(request.user,pk,action=='accept',note)
            elif kind=='refund':pro.approve_refund(request.user,pk,action=='reject')
            elif kind=='maintenance' and action=='start':
                require_permission(request.user,'change_maintenancejob')
                with transaction.atomic():
                    current=m.MaintenanceJob.objects.select_for_update().get(pk=pk)
                    if current.status!='open':raise ValidationError('کار قبلاً شروع یا تعیین تکلیف شده است.')
                    before=pro.snapshot(current);current.status='working';current.version+=1;current.save();pro.record_change(current,request.user,current.branch,before,'آغاز انجام کار توسط مسئول مجاز')
            elif kind=='maintenance':pro.review_maintenance(request.user,pk,action=='accept',note)
            else:raise Http404
            messages.success(request,'اقدام ثبت شد؛ وضعیت تأیید را در همین صفحه ببینید.')
        except ValidationError as error:messages.error(request,' / '.join(error.messages))
    else:messages.error(request,'توضیح اقدام معتبر نیست.')
    return redirect('work_detail',kind=kind,pk=pk)


@login_required
def approvals(request):
    kind=request.GET.get('kind','payment')
    ids=factory_ids(request.user);visible=contracts_for(request.user,True)
    if kind=='contract':
        require_permission(request.user,'approve_contract')
        objects=visible.filter(status='draft').exclude(Q(created_by=request.user)|Q(revised_by=request.user)).select_related('warehouse__branch')
    elif kind=='payment':
        require_permission(request.user,'approve_operations');require_permission(request.user,'view_moneyentry')
        objects=m.PaymentRequest.objects.filter(allocation__contract__in=visible,allocation__account__branch_id__in=ids,status='pending',archived_at__isnull=True).exclude(requested_by=request.user).select_related('allocation__contract','allocation__account__branch')
    elif kind=='refund':
        require_permission(request.user,'approve_operations');objects=scoped(request.user,'refund').filter(status='pending').exclude(requested_by=request.user)
    else:raise Http404
    page=pager(request,objects)
    cases=list(m.ApprovalCase.objects.filter(kind=kind,object_id__in=[o.pk for o in page]).annotate(vote_count=Count('votes',filter=Q(votes__decision='approve'))).order_by('-pk'))
    rows=[]
    for obj in page:
        version=obj.revision_number if kind=='contract' else getattr(obj,'version',0)
        case=next((c for c in cases if c.object_id==obj.pk and c.document_version==version),None)
        contract=obj if kind=='contract' else obj.allocation.contract if kind=='payment' else obj.original.allocation.contract
        amount=int(obj.total_cached) if kind=='contract' else obj.amount if kind=='payment' else obj.original.amount
        rows.append({'pk':obj.pk,'title':contract.number if kind=='contract' else obj.reference,'contract':contract,'amount':amount,'case':case})
    return render(request,'core/work/approvals.html',context('صف تأییدهای مستقل',kind=kind,rows=rows,objects=page))


@login_required
@require_POST
def approval_action(request,kind,pk,action):
    if action not in ['approve','reject']:raise Http404
    note=request.POST.get('note','').strip()[:240]
    try:
        if kind=='contract':
            if action=='approve':services.approve_contract(pk,request.user)
            else:
                if len(note)<10:raise ValidationError('علت رد را دست‌کم در ۱۰ حرف بنویسید.')
                pro.approval_vote(kind,pk,request.user,True,note)
        elif kind=='payment':operations.approve_payment(request.user,pk,action=='reject')
        elif kind=='refund':pro.approve_refund(request.user,pk,action=='reject')
        else:raise Http404
        messages.success(request,'رأی شما ثبت شد؛ اجرا پس از تکمیل تعداد تأییدهای لازم انجام می‌شود.')
    except ValidationError as error:messages.error(request,' / '.join(error.messages))
    return redirect(reverse('approval_queue')+'?kind='+kind)


@owner
def rules(request,kind='policy'):
    if kind not in RULES:raise Http404
    model,form_class,title=RULES[kind]
    return render(request,'core/work/rules.html',context(title,kind=kind,objects=pager(request,model.objects.all().select_related('branch'))))


@owner
def rule_form(request,kind,pk=None):
    if kind not in RULES:raise Http404
    model,form_class,title=RULES[kind];obj=get_object_or_404(model,pk=pk) if pk else None
    form=form_class(request.POST or None,instance=obj,actor=request.user)
    if request.method=='POST' and form.is_valid():
        try:
            pro.save_rule(request.user,kind,form.data_fields(),pk,form.cleaned_data.get('expected_version'),form.cleaned_data.get('reason') or 'ثبت قاعدهٔ سازمانی')
            messages.success(request,'قاعده ثبت شد؛ تأییدهای شروع‌شده با نسخهٔ قبلی، شرط‌های ثبت‌شدهٔ خود را حفظ می‌کنند.');return redirect('work_rules',kind=kind)
        except (ValidationError,IntegrityError) as error:_error(form,error)
    return form_page(request,form,('ویرایش ' if pk else 'ثبت ')+title,'مبلغ‌ها ریال هستند. عنوان نقش، جای قابلیت‌های واقعی و محدودهٔ موقعیت را نمی‌گیرد.')


@owner
def rule_delete(request,kind,pk):
    if kind not in RULES:raise Http404
    obj=get_object_or_404(RULES[kind][0],pk=pk);form=f.ArchiveForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        try:pro.deactivate_rule(request.user,kind,pk,form.cleaned_data['reason']);return redirect('work_rules',kind=kind)
        except ValidationError as error:form.add_error(None,error)
    return form_page(request,form,'بررسی حذف قاعده','وجود پرداخت مرتبط، حذف را مسدود می‌کند. نسخه و علت تغییر در سابقه می‌مانند.')


@permitted('view_branch')
def desk(request):
    kind=request.GET.get('kind','stock')
    if kind not in attention.KINDS:kind='stock'
    rows=attention.issues(request.user,kind,limit=60)
    cases={obj.key:obj for obj in attention.followups_for(request.user).filter(key__in=[r['key'] for r in rows]).select_related('assigned_to')} if request.user.has_perm('core.view_followup') else {}
    for row in rows:
        case=cases.get(row['key']);row['case']=case
        row['changed']=bool(case and case.fingerprint!=row['fingerprint'])
    kinds=[{'key':key,'label':label} for key,(label,permission) in attention.KINDS.items() if request.user.has_perm('core.'+permission)]
    assigned=attention.followups_for(request.user).filter(assigned_to=request.user).exclude(status='resolved').select_related('branch')[:20] if request.user.has_perm('core.view_followup') else []
    return render(request,'core/work/desk.html',context('میز رسیدگی و هشدارها',rows=rows,kinds=kinds,selected_kind=kind,assigned=assigned))


@permitted('view_followup')
def followup(request,key):
    current=attention.followups_for(request.user).filter(key=key).first()
    issue=None
    try:issue=attention.issue_for(request.user,key)
    except PermissionDenied:
        if current is None:raise
    form=f.FollowUpForm(request.POST or None,actor=request.user,instance=current)
    if request.method=='POST' and form.is_valid():
        try:
            attention.follow_up(request.user,key,form.cleaned_data,form.cleaned_data['expected_version'])
            messages.success(request,'مسئول، مهلت و نتیجهٔ پیگیری ثبت شد.');return redirect('attention_desk')
        except ValidationError as error:form.add_error(None,error)
    return form_page(request,form,'پیگیری · '+(issue['title'] if issue else current.title),'ثبت نتیجهٔ پیگیری، سند مالی یا انبار را تغییر نمی‌دهد. اگر اطلاعات منشأ تغییر کند، هشدار دوباره نیازمند بررسی می‌شود.')


@permitted('view_changerecord')
def changes(request,pk):
    obj=get_object_or_404(m.ChangeRecord.objects.filter(branch_id__in=factory_ids(request.user)).filter(Q(contract__isnull=True)|Q(contract__in=contracts_for(request.user))),pk=pk)
    models={model._meta.model_name:model for model,_,_ in [*RECORDS.values(),*RULES.values()]}
    models['followup']=m.FollowUp
    if obj.kind not in models:raise Http404
    require_permission(request.user,'view_'+obj.kind)
    if obj.kind=='followup':
        if not attention.followups_for(request.user).filter(pk=obj.object_id).exists():raise PermissionDenied
    if obj.kind in ('refundrequest','financialperiod','approvalpolicy'):require_permission(request.user,'view_account')
    model=models.get(obj.kind)
    rows=[]
    for name in sorted(set(obj.before)|set(obj.after)):
        if obj.before.get(name)==obj.after.get(name) or name.startswith('_') or name in {'operation_key','uid','id','version','created_at','updated_at','requested_by_id','created_by_id','reviewed_by_id','approved_by_id','changed_by_id','updated_by_id'}:continue
        if name in {'payment_id','entry_id','original_id'}:
            if not (request.user.has_perm('core.view_moneyentry') and request.user.has_perm('core.view_account')):continue
            references={value for value in [obj.before.get(name),obj.after.get(name)] if value}
            if references-set(entries_for(request.user).filter(pk__in=references).values_list('pk',flat=True)):continue
        if name=='document_id':
            if not request.user.has_perm('core.view_document'):continue
            from .documents import visible_documents
            references={value for value in [obj.before.get(name),obj.after.get(name)] if value}
            if references-set(visible_documents(request.user).filter(pk__in=references).values_list('pk',flat=True)):continue
        label=name
        if model:
            try:label=model._meta.get_field(name[:-3] if name.endswith('_id') else name).verbose_name
            except Exception:pass
        before=obj.before.get('_labels',{}).get(name,obj.before.get(name,'—'));after=obj.after.get('_labels',{}).get(name,obj.after.get(name,'—'))
        if name=='payload':
            label='ردیف‌های تحویل'
            def summary(value):return ' ؛ '.join(f"{r.get('label','ردیف '+pk)}: {r['quantity']} · {r.get('location_label','')} · {r.get('trace_label','')}" for pk,r in (value or {}).items())
            before=summary(obj.before.get(name));after=summary(obj.after.get(name))
        rows.append({'label':label,'before':before,'after':after})
    return render(request,'core/work/changes.html',context('سابقهٔ تغییر · '+obj.title,obj=obj,rows=rows))


@permitted('view_importedsnapshot')
def exchange(request):
    peers=m.ExchangePeer.objects.select_related('source__branch')
    if not root(request.user):peers=peers.filter(source__branch_id__in=factory_ids(request.user))
    out=m.ExchangeOutbox.objects.select_related('peer__source','created_by','ack')
    if not root(request.user):out=out.filter(created_by=request.user)
    incoming=m.ExchangeInbox.objects.filter(peer__in=peers).select_related('peer__source','reviewed_by')
    show=request.GET.get('show','peers')
    if show not in ['peers','outbox','inbox']:show='peers'
    objects=pager(request,{'peers':peers.order_by('source__label'),'outbox':out,'inbox':incoming}[show])
    return render(request,'core/work/exchange.html',context('تبادلات رمزگذاری‌شده و رسیدها',peers=objects if show=='peers' else [],outbox=objects if show=='outbox' else [],inbox=objects if show=='inbox' else [],objects=objects,show=show,import_form=f.SecureImportForm()))


@permitted('export_branch_data')
def secure_identity(request):
    content=secure.canonical(secure.public_identity())
    response=HttpResponse(content,content_type='application/json');response['Content-Disposition']='attachment; filename="AMAR-Exchange-Identity.json"';return response


@permitted('export_branch_data')
def export_changes(request):
    form=f.SecureExportForm(request.POST or None,actor=request.user)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data
        try:
            out=secure.prepare(request.user,d['peer'].pk,d['scope'],d['sections'],d['include_descendants'],d['baseline'])
            return redirect('secure_outbox_file',pk=out.pk)
        except (ValidationError,IntegrityError) as error:_error(form,error)
    return form_page(request,form,'تهیهٔ بستهٔ تغییرات','گیرنده و محدوده را مشخص کنید. پس از اولین نسخه، فقط تغییرات و حذف‌های همان داده‌های مبدأ ارسال می‌شوند. تا رسید بستهٔ باز نرسد، بستهٔ تازه برای همان گیرنده ساخته نمی‌شود.')


@permitted('add_importedsnapshot')
@require_POST
def import_changes(request):
    form=f.SecureImportForm(request.POST,request.FILES)
    if form.is_valid():
        try:
            uploaded=form.cleaned_data['file']
            if uploaded.size>secure.MAX_FILE:raise ValidationError('فایل بیش از حد بزرگ است.')
            result=secure.import_file(request.user,uploaded.read())
            if isinstance(result,m.ExchangeInbox):return redirect('secure_inbox_detail',pk=result.pk)
            messages.success(request,'رسید معتبر ثبت شد؛ بستهٔ بعدی را می‌توانید تهیه کنید.')
        except ValidationError as error:messages.error(request,' / '.join(error.messages))
    else:messages.error(request,'فایل تغییرات یا رسید را انتخاب کنید.')
    return redirect('secure_exchange')


@permitted('export_branch_data')
def outbox_file(request,pk):
    obj=get_object_or_404(m.ExchangeOutbox.objects.select_related('peer__source'),pk=pk);secure.outbox_access(request.user,obj)
    response=HttpResponse(bytes(obj.envelope),content_type='application/octet-stream');response['Content-Disposition']=f'attachment; filename="AMAR-Changes-{obj.sequence}.amar"';return response


@permitted('view_importedsnapshot')
def inbox_detail(request,pk):
    obj=get_object_or_404(m.ExchangeInbox.objects.select_related('peer__source','reviewed_by'),pk=pk);secure.inbox_access(request.user,obj)
    form=f.SecureReviewForm(request.POST or None)
    if not root(request.user) or not obj.payload['baseline']:form.fields.pop('replace_baseline')
    if request.method=='POST' and form.is_valid():
        try:
            if request.POST.get('action') not in ['accept','reject']:raise ValidationError('پذیرش یا رد بسته را انتخاب کنید.')
            secure.review(request.user,pk,request.POST.get('action')=='accept',form.cleaned_data['note'],form.cleaned_data.get('replace_baseline',False))
            messages.success(request,'نتیجه ثبت شد؛ فایل رسید را برای فرستنده برگردانید.');return redirect('secure_inbox_detail',pk=pk)
        except ValidationError as error:form.add_error(None,error)
    return render(request,'core/work/inbox.html',context('بررسی بستهٔ دریافتی',obj=obj,form=form,change_count=len(obj.payload['upserts']),delete_count=len(obj.payload['deletes'])))


@permitted('view_importedsnapshot')
def receipt_file(request,pk):
    obj=get_object_or_404(m.ExchangeInbox.objects.select_related('peer__source'),pk=pk);secure.inbox_access(request.user,obj)
    if obj.receipt is None:raise Http404
    response=HttpResponse(bytes(obj.receipt),content_type='application/octet-stream');response['Content-Disposition']=f'attachment; filename="AMAR-Receipt-{obj.sequence}.amar"';return response


def visible_traces(actor):
    require_permission(actor,'view_item')
    if root(actor):return m.TraceUnit.objects.all()
    return m.TraceUnit.objects.filter(Q(stockmovement__warehouse__branch_id__in=factory_ids(actor))|Q(stockmovement__isnull=True)).distinct()


@permitted('view_item')
def scan(request):
    query=request.GET.get('q','').strip()[:120]
    items=[];traces=[];equipment=[];remote=[]
    if query:
        exact=m.Item.objects.filter(Q(barcode__iexact=query)|Q(sku__iexact=query))
        if exact.count()==1:return redirect('item_passport',pk=exact.first().pk)
        if query.upper().startswith('TRACE-') and query[6:].isdigit():
            trace=visible_traces(request.user).filter(pk=int(query[6:])).first()
            if trace:return redirect('trace_passport',pk=trace.pk)
        if request.user.has_perm('core.view_equipment') and query.upper().startswith('ASSET-'):
            try:
                uid=uuid.UUID(query[6:]);asset=scoped(request.user,'equipment').filter(uid=uid).first()
                if asset:return redirect('work_detail',kind='equipment',pk=asset.pk)
                if request.user.has_perm('core.view_importedsnapshot'):remote=list(replica_rows(request.user,'equipment').filter(search_key=str(uid))[:10])
            except ValueError:pass
        items=list(m.Item.objects.filter(Q(name__icontains=query)|Q(sku__icontains=query)|Q(barcode__icontains=query)).order_by('sku')[:20])
        traces=list(visible_traces(request.user).filter(Q(code__icontains=query)|Q(item__sku__icontains=query)).select_related('item')[:20])
        if request.user.has_perm('core.view_equipment'):equipment=list(scoped(request.user,'equipment').filter(Q(code__icontains=query)|Q(serial__icontains=query)|Q(name__icontains=query))[:15])
    return render(request,'core/work/scan.html',context('اسکن و شناسنامهٔ کالا',query=query,items=items,traces=traces,equipment=equipment,remote=remote))


@permitted('view_item')
def item_passport(request,pk,trace_id=None):
    item=get_object_or_404(m.Item,pk=pk)
    trace=get_object_or_404(visible_traces(request.user),pk=trace_id,item=item) if trace_id else None
    ids=factory_ids(request.user)
    balances=m.StockBalance.objects.filter(item=item,warehouse__branch_id__in=ids).exclude(quantity=0).select_related('warehouse__branch','warehouse__parent','location','trace')
    movements=m.StockMovement.objects.filter(item=item,warehouse__branch_id__in=ids).select_related('warehouse__branch','location','trace','created_by','contract_line__contract')
    custody=m.MaterialRequest.objects.filter(item=item,warehouse__branch_id__in=ids,status__in=['issued','closed']).select_related('recipient','work_order','warehouse__branch')
    if trace:
        balances=balances.filter(trace=trace);movements=movements.filter(trace=trace);custody=custody.filter(trace=trace)
    visible=set(contracts_for(request.user).values_list('pk',flat=True))
    movement_rows=[]
    if request.user.has_perm('core.view_stockmovement'):
        for row in movements[:40]:
            allowed=not row.contract_line_id or row.contract_line.contract_id in visible
            movement_rows.append({'obj':row,'reference':row.reference if allowed else 'رسید مرتبط با قرارداد محدود','contract':row.contract_line.contract if row.contract_line_id and allowed else None})
    else:balances=balances.none()
    held=list(custody[:30]) if request.user.has_perm('core.view_materialrequest') else []
    pending=[]
    if request.user.has_perm('core.view_contract'):
        from .scalable_reports import pending_lines
        pending=list(pending_lines(request.user).filter(item=item).select_related('contract__warehouse__branch')[:30])
    assets=scoped(request.user,'equipment').filter(item=item) if request.user.has_perm('core.view_equipment') else m.Equipment.objects.none()
    if trace:assets=assets.filter(trace=trace)
    return render(request,'core/work/passport.html',context(item.name,item=item,trace=trace,objects=pager(request,balances),movements=movement_rows,custody=held,pending=pending,equipment=assets[:10]))


@permitted('view_item')
def trace_passport(request,pk):
    trace=get_object_or_404(visible_traces(request.user),pk=pk)
    return item_passport(request,trace.item_id,trace.pk)


@permitted('view_equipment')
def equipment_label(request,pk):
    obj=get_object_or_404(scoped(request.user,'equipment'),pk=pk)
    from .barcodes import code39_svg
    code='ASSET-'+obj.uid.hex.upper()
    return render(request,'core/work/asset_label.html',context('برچسب دستگاه',obj=obj,barcode=code,svg=code39_svg(code)))


def replica_rows(actor,kind):
    permissions={'buckets':'view_stockmovement','equipment':'view_equipment','maintenance':'view_maintenancejob','quality':'view_deliveryinspection'}
    if kind not in permissions:raise Http404
    require_permission(actor,permissions[kind]);require_permission(actor,'view_importedsnapshot')
    query=m.ExchangeReplica.objects.filter(kind=kind).select_related('peer__source')
    if not root(actor):
        codes=m.Branch.objects.filter(pk__in=factory_ids(actor)).values_list('code',flat=True)
        query=query.filter(data__branch__in=list(codes))
        if kind=='quality':
            grants=m.RemoteContractGrant.objects.filter(source_id=OuterRef('peer__source_id'),number=OuterRef('contract_number'),user=actor)
            query=query.annotate(contract_number=KeyTextTransform('number','data')).annotate(permitted=Exists(grants)).filter(permitted=True)
    return query.order_by('peer__source__label','pk')


@permitted('view_importedsnapshot')
def received_records(request,kind='buckets'):
    query=replica_rows(request.user,kind)
    q=request.GET.get('q','').strip()[:120]
    if q:query=query.filter(Q(search_key__icontains=q)|Q(peer__source__label__icontains=q))
    labels={'buckets':'محل دقیق و سریال دریافتی','equipment':'دستگاه‌های دریافتی','maintenance':'وضعیت تعمیرات دریافتی','quality':'کنترل کیفیت دریافتی'}
    objects=pager(request,query)
    names=[name for name in secure.BASE_COLUMNS[kind] if name!='uid']
    titles={'branch':'موقعیت','warehouse':'انبار','sku':'کد کالا','item':'نام کالا','location':'محل دقیق','trace':'بچ / سریال','quantity':'مقدار','unit':'واحد','code':'کد دستگاه','name':'نام','serial':'سریال سازنده','status':'وضعیت','custodian':'مسئول نگهداری','number':'شماره','equipment':'دستگاه','title':'موضوع','due_on':'موعد','reference':'شماره بازرسی','reviewed_at':'زمان بررسی'}
    rows=[{'source':row.peer.source.label,'values':[row.data[name] for name in names]} for row in objects]
    return render(request,'core/work/replicas.html',context(labels[kind],kind=kind,objects=objects,rows=rows,columns=[titles[n] for n in names],search=q))
