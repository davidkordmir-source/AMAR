"""Scheduled count revisions retain their schedule; refunds retain payment guards."""
import uuid
from datetime import timedelta
from django.core.exceptions import ValidationError
from django.utils import timezone
from core import models as m, operations as op, operation_lifecycle as life, pro_services as pro, services
from .test_enterprise import EnterpriseBase


class ScheduledCountRevisionTests(EnterpriseBase):
    def scheduled_count(self):
        due=timezone.localdate()-timedelta(days=1)
        schedule=pro.save_count_schedule(self.owner,{'warehouse':self.w,'title':'شمارش ماهانه','interval_days':20,'next_due':due,'active':True})
        count=op.request_count(self.requester,self.w,'COUNT-ORIGINAL',[{'item':self.item,'location':self.location,'trace':None,'counted':100}],uuid.uuid4(),schedule=schedule)
        return schedule,count,due

    def test_revised_count_keeps_both_links_and_advances_schedule_only_on_approval(self):
        schedule,original,due=self.scheduled_count()
        key=uuid.uuid4()
        def create():
            return op.request_count(self.requester,self.w,'COUNT-REVISED',[{'item':self.item,'location':self.location,'trace':None,'counted':99}],key)
        revised=life.revise(self.requester,'count',original.pk,'اصلاح نتیجهٔ شمارش با بازبینی ردیف',key,create)
        original.refresh_from_db();schedule.refresh_from_db()
        self.assertIsNotNone(original.archived_at)
        self.assertEqual(original.status,'rejected')
        self.assertEqual(schedule.next_due,due)
        self.assertIsNone(schedule.last_count_id)
        self.assertEqual(set(schedule.runs.values_list('count_id',flat=True)),{original.pk,revised.pk})
        # Replaying the same submitted revision does not create another run.
        replayed=life.revise(self.requester,'count',original.pk,'اصلاح نتیجهٔ شمارش با بازبینی ردیف',key,lambda:self.fail('Revision was executed twice'))
        self.assertEqual(replayed.pk,revised.pk)
        self.assertEqual(schedule.runs.count(),2)
        op.approve_count(self.approver,revised.pk)
        schedule.refresh_from_db()
        self.assertEqual(schedule.last_count_id,revised.pk)
        self.assertEqual(schedule.next_due,timezone.localdate()+timedelta(days=20))
        self.assertEqual(m.StockBalance.objects.get(warehouse=self.w,item=self.item,location=self.location).quantity,99)

    def test_changing_scheduled_count_warehouse_rolls_back_original_and_replacement(self):
        schedule,original,due=self.scheduled_count()
        key=uuid.uuid4();before_events=m.AuditEvent.objects.count()
        def create():
            return op.request_count(self.owner,self.dest,'WRONG-WAREHOUSE',[{'item':self.item,'location':self.destination_location,'trace':None,'counted':0}],key)
        with self.assertRaises(ValidationError):life.revise(self.owner,'count',original.pk,'تلاش تغییر انبار شمارش برنامه‌ریزی‌شده',key,create)
        original.refresh_from_db();schedule.refresh_from_db()
        self.assertIsNone(original.archived_at)
        self.assertEqual(original.status,'pending')
        self.assertFalse(m.StockCount.objects.filter(operation_key=key).exists())
        self.assertFalse(m.OperationRevision.objects.filter(operation_key=key).exists())
        self.assertEqual(schedule.runs.count(),1)
        self.assertEqual(schedule.next_due,due)
        self.assertEqual(m.AuditEvent.objects.count(),before_events)

    def test_deleting_pending_count_preserves_history_and_does_not_advance_due_date(self):
        schedule,original,due=self.scheduled_count()
        life.revise(self.requester,'count',original.pk,'انصراف از شمارش پیش از تأیید نهایی',uuid.uuid4())
        schedule.refresh_from_db()
        self.assertEqual(schedule.runs.get().count_id,original.pk)
        self.assertEqual(schedule.next_due,due)
        self.assertIsNone(schedule.last_count_id)

    def test_schedule_warehouse_cannot_change_after_a_run_exists(self):
        schedule,original,due=self.scheduled_count()
        with self.assertRaises(ValidationError):
            pro.save_count_schedule(self.owner,{'warehouse':self.dest,'title':schedule.title,'interval_days':20,'next_due':due,'active':True},schedule.pk,schedule.version,'تغییر انبار برنامه پس از شروع شمارش')
        schedule.refresh_from_db()
        self.assertEqual(schedule.warehouse_id,self.w.pk)
        self.assertEqual(schedule.runs.get().count_id,original.pk)


class RefundedPaymentRequestRevisionTests(EnterpriseBase):
    def test_historical_payment_blocks_edit_and_delete_after_full_refund(self):
        contract,_=self.contract('PAID-THEN-REFUNDED',True,True)
        allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4(),self.finance)
        paid=op.request_payment(self.finance,allocation,100,'PAY-ORIGINAL','پرداخت نمونه',uuid.uuid4())
        op.approve_payment(self.approver,paid.pk);paid.refresh_from_db()
        refund=pro.request_refund(self.finance,paid.entry,'REFUND-FULL','برگشت کامل با مستند مستقل',uuid.uuid4())
        pro.approve_refund(self.approver,refund.pk)
        self.assertEqual(contract.paid,0)
        pending=op.request_payment(self.finance,allocation,50,'PAY-PENDING','پرداخت مرحلهٔ بعد',uuid.uuid4())
        self.assertTrue(life.blockers(pending,'payment',editing=True))
        self.assertTrue(life.blockers(pending,'payment'))
        for create in [None,lambda:self.fail('Blocked revision reached posting callback')]:
            with self.assertRaises(ValidationError):life.revise(self.owner,'payment',pending.pk,'اصلاح درخواست پس از برگشت کامل پرداخت',uuid.uuid4(),create)
        pending.refresh_from_db()
        self.assertEqual(pending.status,'pending')
        self.assertIsNone(pending.archived_at)
