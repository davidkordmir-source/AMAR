from functools import wraps
from decimal import Decimal
from datetime import timedelta
import json
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required,permission_required
from django.core.exceptions import PermissionDenied,ValidationError
from django.db import transaction,IntegrityError
from django.db.models import Q,Count
from django.http import JsonResponse,HttpResponse
from django.shortcuts import get_object_or_404,redirect,render
from django.urls import reverse
from django.views.decorators.http import require_POST
from . import enterprise_forms as f,forms,models as m,operations as op,services
from .access import factory_ids,root,scope_form,contracts_for,descendants,ancestors,profile
from .views import page
from .templatetags.persian import person_name


def owner(view):
    @login_required
    @wraps(view)
    def guarded(request,*args,**kwargs):
        if not request.user.is_superuser:raise PermissionDenied
        return view(request,*args,**kwargs)
    return guarded

def permitted(code):
    def wrapper(view):return login_required(permission_required('core.'+code,raise_exception=True)(view))
    return wrapper

def submit(request,form,title,callback,destination='control',hint='',section='control'):
    if request.method=='POST' and form.is_valid():
        try:
            callback(form.cleaned_data)
            messages.success(request,'اطلاعات ثبت شد. عملیات نیازمند تأیید، در صف کنترل قرار گرفت.')
            return redirect(destination)
        except ValidationError as e:form.add_error(None,e)
        except IntegrityError:form.add_error(None,'کد یا شماره سند تکراری است؛ عملیات ثبت نشد.')
    return render(request,'core/form.html',{'form':form,'page_title':title,'help_text':hint,'active_page':section})

@owner
def configuration(request):
    obj,_=m.SystemConfiguration.objects.get_or_create(pk=1)
    form=f.SystemForm(request.POST or None,instance=obj)
    form.fields['brand_name'].disabled=True
    form.fields['brand_name'].help_text='نام و هویت نرم‌افزار فقط از ورود جداگانهٔ سازنده قابل تغییر است.'
    def save(d):
        with transaction.atomic():
            current=m.SystemConfiguration.objects.select_for_update().get(pk=1)
            before=m.SystemConfiguration.objects.filter(pk=1).values().get()
            changed=[name for name,field in form.fields.items() if not field.disabled]
            for name in changed:setattr(current,name,d[name])
            current.save(update_fields=changed);services.audit('تغییر نام‌ها و قواعد کنترل','تنظیمات مجموعه',request.user,json.dumps(before,ensure_ascii=False,default=str))
        from desktop.backend import set_brand_name
        set_brand_name(current.brand_name)
    return submit(request,form,'تنظیمات سازمان و کنترل',save,'configuration','عنوان سمت و نام نمایشی از مجوزهای دسترسی مستقل هستند. هویت نرم‌افزار فقط توسط سازنده تغییر می‌کند.','settings')

@owner
def brand_name(request):
    from .branding import require_owner
    require_owner(request.user)
    obj,_=m.SystemConfiguration.objects.get_or_create(pk=1)
    form=f.BrandForm(request.POST or None,instance=obj)
    def save(data):
        with transaction.atomic():
            before=m.SystemConfiguration.objects.get(pk=1).brand_name
            m.SystemConfiguration.objects.filter(pk=1).update(brand_name=data['brand_name']);services.audit('تغییر نام نرم‌افزار',data['brand_name'],request.user,json.dumps({'before':before},ensure_ascii=False))
        from desktop.backend import set_brand_name
        set_brand_name(obj.brand_name)
    return submit(request,form,'تغییر نام نرم‌افزار',save,'directory','نام دلخواه شما در صفحهٔ ورود، بالای صفحات و پنجرهٔ ویندوز نمایش داده می‌شود.','directory')

@owner
@require_POST
def desktop_close(request):
    from desktop.control import session
    if not session.installed():raise PermissionDenied
    response=render(request,'core/desktop_closing.html',{'page_title':'بستن برنامه'})
    session.request_close()
    return response

@owner
def access_center(request):
    return render(request,'core/access_center.html',{'page_title':'افراد، عنوان‌ها و دسترسی‌ها','active_page':'access',
        'profiles':get_user_model().objects.select_related('factory_profile__branch','factory_profile__role').order_by('username'),
        'roles':m.AccessRole.objects.all(),'remote_grants':m.RemoteContractGrant.objects.select_related('user','source')})

@owner
def user_edit(request,pk=None):
    user=get_object_or_404(get_user_model(),pk=pk) if pk else None
    from . import branding
    if user and user.pk==branding.owner_id() and not branding.is_owner(request.user):
        raise PermissionDenied('مشخصات و رمز حساب مالک اصلی فقط توسط خود او قابل تغییر است.')
    form=f.UserForm(request.POST or None,user=user)
    def save(d):
        with transaction.atomic():
            account=user or get_user_model()()
            account.username=d['username'];account.is_active=d['enabled']
            if d['password']:account.set_password(d['password'])
            account.save()
            m.UserProfile.objects.update_or_create(user=account,defaults={'display_name':d['display_name'],'position_title':d['position_title'],'branch':d['branch'],'include_descendants':d['include_descendants'],'role':d['role'],'enabled':d['enabled']})
            services.audit('تغییر مشخصات و محدوده شخص' if user else 'ایجاد حساب با محدوده مشخص',account.username,request.user,branch=d['branch'])
    return submit(request,form,'ویرایش نام، سمت و دسترسی شخص' if user else 'ایجاد حساب شخص',save,'access_center',section='access')

@owner
def role_edit(request,pk=None):
    instance=get_object_or_404(m.AccessRole,pk=pk) if pk else None
    form=f.RoleForm(request.POST or None,instance=instance)
    def save(d):
        with transaction.atomic():
            role=form.save();services.audit('تعریف یا تغییر نقش دسترسی',role.name,request.user)
    return submit(request,form,'نام دلخواه نقش و قابلیت‌های آن',save,'access_center',section='access')

@permitted('view_branch')
def structure(request):
    ids=factory_ids(request.user)
    units=m.Branch.objects.filter(pk__in=ids).select_related('parent','organization','locality__parent__parent__parent__parent__parent').order_by('organization_id','kind','parent_id','name')
    query=request.GET.get('q','').strip()[:120]
    if query:units=units.filter(Q(name__icontains=query)|Q(code__icontains=query)|Q(city__icontains=query)|Q(parent__name__icontains=query))
    parent=request.GET.get('parent','')
    if parent:
        if not parent.isdigit() or int(parent) not in ids:raise PermissionDenied
        units=units.filter(parent_id=int(parent))
    objects=page(request,units)
    return render(request,'core/structure.html',{'page_title':'ساختار مجموعه و کارخانه‌ها','active_page':'structure','units':objects,'objects':objects,'search':query,'unit_count':len(ids)})

@owner
def structure_template(request):
    form=f.StructureForm(request.POST or None)
    def save(d):
        with transaction.atomic():
            organization=d['organization'];prefix=f'G{organization.pk}'
            central,created=m.Branch.objects.get_or_create(code=prefix+'-ROOT',defaults={'name':d['root_name'],'organization':organization,'city':'مرکز مجموعه','kind':'central'})
            if central.organization_id!=organization.pk:raise ValidationError('کد ساختار با مجموعه دیگر تداخل دارد.')
            for c in range(1,d['centers']+1):
                city,_=m.Branch.objects.get_or_create(code=f'{prefix}-C{c:02d}',defaults={'name':f'مرکز شهری {c:02d}','city':f'شهر {c:02d} ـ قابل تغییر','organization':organization,'parent':central,'kind':'city'})
                if city.parent_id!=central.pk:raise ValidationError('کد مرکز شهری با ساختار قبلی تداخل دارد.')
                for n in range(1,d['factories_per_center']+1):
                    leaf,_=m.Branch.objects.get_or_create(code=f'{prefix}-C{c:02d}-F{n:02d}',defaults={'name':f'کارخانه {c:02d}-{n:02d}','city':city.city,'organization':organization,'parent':city,'kind':'factory'})
                    if leaf.parent_id!=city.pk:raise ValidationError('کد زیرمجموعه با ساختار قبلی تداخل دارد.')
            services.audit('ساخت الگوی کارخانه‌ها',central.name,request.user,f"{d['centers']} مرکز؛ {d['factories_per_center']} زیرمجموعه برای هر مرکز",branch=central)
    return submit(request,form,'ساخت الگوی اولیه؛ بدون سقف تعداد کارخانه',save,'structure','نام‌ها پیشنهادی‌اند و بعداً تغییر می‌کنند. این الگو با فهرست جغرافیایی ۳۱ استان متفاوت است.','structure')

@owner
def master_edit(request,kind,pk=None):
    from .master_data import MASTER_FORMS,validate_reference_edit
    options=MASTER_FORMS
    if kind not in options:raise PermissionDenied
    model,klass=options[kind];obj=get_object_or_404(model,pk=pk) if pk else None
    form=klass(request.POST or None,instance=obj)
    scope_form(form,request.user)
    if obj:form.delete_url=reverse('master_delete',args=[kind,obj.pk])
    def save(d):
        with transaction.atomic():
            previous=model.objects.select_for_update().get(pk=obj.pk) if obj else None
            if kind=='account':
                from .pro_services import writable_period
                writable_period(d['branch'].pk)
            validate_reference_edit(kind,previous,d)
            if kind=='branch' and previous and previous.organization_id!=d['organization'].pk and (previous.warehouses.exists() or previous.children.exists() or m.Account.objects.filter(branch=previous).exists()):raise ValidationError('موقعیت دارای سوابق یا زیرمجموعه را نمی‌توان به مجموعه دیگر منتقل کرد.')
            if kind=='organization' and previous and previous.role!=d['role'] and (previous.branch_set.exists() or previous.supplied_contracts.exclude(status__in=['draft','cancelled']).exists()):raise ValidationError('نقش مجموعه دارای سابقه قابل تغییر نیست؛ نام و اطلاعات تماس قابل اصلاح است.')
            if kind=='warehouse' and previous and previous.branch_id!=d['branch'].pk:
                if any(relation.exists() for relation in [previous.movements,previous.contracts,previous.children]) or m.MaterialRequest.objects.filter(warehouse=previous).exists() or m.StockTransfer.objects.filter(Q(source=previous)|Q(destination=previous)).exists() or m.StockCount.objects.filter(warehouse=previous).exists() or m.StockCorrection.objects.filter(warehouse=previous).exists() or m.StorageLocation.objects.filter(warehouse=previous).exists():raise ValidationError('موقعیت انبار دارای سابقه قابل تغییر نیست؛ انبار جدید و انتقال کنترل‌شده بسازید.')
            if kind=='account' and previous and previous.branch_id!=d['branch'].pk and (previous.entries.exists() or previous.allocations.exists()):raise ValidationError('موقعیت حساب دارای سابقه قابل تغییر نیست.')
            if kind=='account' and previous and previous.entries.exists() and previous.opening_balance!=d['opening_balance']:raise ValidationError('موجودی اولیه حساب دارای سند قابل بازنویسی نیست.')
            if kind=='account' and previous and previous.current_balance+(d['opening_balance']-previous.opening_balance if not previous.entries.exists() else 0)+d['credit_limit']-previous.reserved<0:raise ValidationError('اعتبار جدید برای تعهدها و ماندهٔ فعلی کافی نیست.')
            before=list(model.objects.filter(pk=obj.pk).values()) if obj else []
            value=form.save()
            if kind=='geography':
                current=value.parent;seen={value.pk}
                while current:
                    if current.pk in seen:raise ValidationError('تقسیمات کشوری نباید چرخه داشته باشد.')
                    seen.add(current.pk);current=current.parent
            services.audit('ویرایش اطلاعات پایه' if obj else 'ثبت اطلاعات پایه',value,request.user,json.dumps(before,ensure_ascii=False,default=str))
    return submit(request,form,('ویرایش ' if obj else 'ثبت ')+model._meta.verbose_name,save,'finance' if kind=='account' else 'structure' if kind=='branch' else 'geography' if kind=='geography' else 'control' if kind in ('workorder','custodian','route','trace','location') else 'directory',section='structure' if kind=='branch' else 'directory')

@owner
def master_list(request,kind='organization'):
    from .master_data import MASTER_FORMS
    if kind not in MASTER_FORMS:raise PermissionDenied
    model,_=MASTER_FORMS[kind]
    objects=model.objects.order_by(*(model._meta.ordering or []),'pk')
    query=request.GET.get('q','').strip()[:120]
    searchable=[field.name for field in model._meta.fields if field.get_internal_type() in ('CharField','TextField')]
    if query and searchable:
        predicate=Q()
        for field in searchable:predicate|=Q(**{field+'__icontains':query})
        objects=objects.filter(predicate)
    return render(request,'core/master_list.html',{'page_title':'ویرایش و حذف اطلاعات پایه','active_page':'directory','kind':kind,'search':query,
        'objects':page(request,objects),'record_title':model._meta.verbose_name,'categories':[(key,value[0]._meta.verbose_name) for key,value in MASTER_FORMS.items()]})

@owner
def master_delete(request,kind,pk):
    from .master_data import MASTER_FORMS,deletion_blockers,delete_reference
    if kind not in MASTER_FORMS:raise PermissionDenied
    model,_=MASTER_FORMS[kind]
    obj=get_object_or_404(model,pk=pk)
    reasons=deletion_blockers(obj)
    if request.method=='POST':
        try:
            delete_reference(request.user,kind,pk)
            messages.success(request,'اطلاعات پایه بدون حذف اسناد وابسته حذف شد.')
            return redirect('master_list',kind=kind)
        except ValidationError as error:reasons=error.messages
        except IntegrityError:reasons=['این رکورد هم‌زمان در سند دیگری استفاده شده است؛ حذف انجام نشد.']
        except model.DoesNotExist:return redirect('master_list',kind=kind)
    return render(request,'core/master_delete.html',{'page_title':'بررسی حذف اطلاعات پایه','active_page':'directory','record':obj,'kind':kind,'reasons':reasons})

@permitted('grant_contract')
def contract_access(request,pk):
    contract=get_object_or_404(contracts_for(request.user,True),pk=pk)
    form=f.GrantForm(request.POST or None)
    scope_form(form,request.user)
    if not root(request.user):form.fields['user'].queryset=form.fields['user'].queryset.filter(factory_profile__branch_id__in=factory_ids(request.user))
    def save(d):
        with transaction.atomic():
            if d['user']:
                if contract.warehouse.branch_id not in factory_ids(d['user']):raise ValidationError('کاربر انتخاب‌شده در محدوده واحد این قرارداد نیست.')
            else:
                relevant=descendants(d['branch'].pk) if d['include_descendants'] else {d['branch'].pk}
                if contract.warehouse.branch_id not in relevant:raise ValidationError('قرارداد به واحد انتخاب‌شده یا زیرمجموعه مجاز آن مربوط نیست.')
                if not root(request.user) and not relevant.issubset(factory_ids(request.user)):raise PermissionDenied
            m.ContractGrant.objects.create(contract=contract,user=d['user'],branch=d['branch'],include_descendants=d['include_descendants'],can_operate=d['can_operate'],created_by=request.user)
            services.audit('اعطای دسترسی صریح قرارداد',contract.number,request.user,str(d['user'] or d['branch']),branch=contract.warehouse.branch,contract=contract)
    if request.method=='POST' and form.is_valid():
        try:save(form.cleaned_data);messages.success(request,'دسترسی ثبت شد.');return redirect('contract_access',pk=pk)
        except ValidationError as e:form.add_error(None,e)
    return render(request,'core/contract_access.html',{'form':form,'contract':contract,'grants':contract.access_grants.select_related('user','branch'),'page_title':'تعیین دسترسی قرارداد','active_page':'contracts'})

@permitted('grant_contract')
@require_POST
def revoke_grant(request,pk):
    grant=get_object_or_404(m.ContractGrant,pk=pk,contract__in=contracts_for(request.user,True))
    contract=grant.contract
    with transaction.atomic():
        detail=str(grant.user or grant.branch);grant.delete()
        services.audit('لغو دسترسی قرارداد',contract.number,request.user,detail,branch=contract.warehouse.branch,contract=contract)
    return redirect('contract_access',pk=contract.pk)

@owner
def remote_grant(request):
    class Form(f.forms.Form):
        source=f.forms.ModelChoiceField(label='مبدأ گزارش',queryset=m.TrustedSource.objects.all())
        user=f.forms.ModelChoiceField(label='کاربر مجاز',queryset=get_user_model().objects.filter(is_active=True,is_superuser=False))
        number=f.forms.CharField(label='شماره دقیق قرارداد در آخرین گزارش',max_length=40)
    form=Form(request.POST or None)
    def save(d):
        latest=d['source'].latest
        if not latest or not any(r['number']==d['number'] and r['branch'] in set(m.Branch.objects.filter(pk__in=factory_ids(d['user'])).values_list('code',flat=True)) for r in latest.payload['contracts']):raise ValidationError('این قرارداد در گزارش و محدوده کاربر نیست.')
        m.RemoteContractGrant.objects.get_or_create(source=d['source'],user=d['user'],number=d['number'])
        services.audit('دسترسی قرارداد گزارش موقعیت',d['number'],request.user,str(d['user']))
    return submit(request,form,'دسترسی صریح به قرارداد گزارش دریافتی',save,'access_center',section='access')

@owner
@require_POST
def revoke_remote(request,pk):
    grant=get_object_or_404(m.RemoteContractGrant,pk=pk)
    with transaction.atomic():
        services.audit('لغو دسترسی قرارداد گزارش موقعیت',grant.number,request.user,str(grant.user));grant.delete()
    return redirect('access_center')

@permitted('view_branch')
def geography(request):
    query=request.GET.get('q','').strip()[:120].replace('ي','ی').replace('ك','ک')
    objects=m.GeoPlace.objects.select_related('parent__parent')
    parent=request.GET.get('parent','')
    if parent.isascii() and parent.isdigit():objects=objects.filter(parent_id=parent)
    elif not query:objects=objects.filter(level='province')
    if query:objects=objects.filter(Q(name__icontains=query)|Q(code__icontains=query))
    level=request.GET.get('level','')
    if level in dict(m.GeoPlace._meta.get_field('level').choices):objects=objects.filter(level=level)
    return render(request,'core/geography.html',{'page_title':'فهرست سراسری استان تا آبادی','active_page':'geography','objects':page(request,objects),'search':query,'levels':m.GeoPlace._meta.get_field('level').choices,'counts':m.GeoPlace.objects.values('level').annotate(count=Count('pk')),'load':m.GeographyLoad.objects.filter(pk=1).first()})

@login_required
def geography_search(request):
    if not factory_ids(request.user) and not root(request.user):raise PermissionDenied
    query=request.GET.get('q','').strip()[:100].replace('ي','ی').replace('ك','ک')
    objects=m.GeoPlace.objects.select_related('parent__parent')
    if len(query)<2:return JsonResponse({'results':[]})
    objects=objects.filter(Q(name__icontains=query)|Q(code__icontains=query))[:40]
    return JsonResponse({'results':[{'id':p.pk,'name':p.name,'level':p.get_level_display(),'path':p.path} for p in objects]})

OPERATIONS={'material':(m.MaterialRequest,f.MaterialForm,'add_materialrequest','درخواست قطعه'),
    'transfer':(m.StockTransfer,f.TransferForm,'add_stocktransfer','درخواست انتقال'),
    'correction':(m.StockCorrection,f.CorrectionForm,'add_stockcorrection','درخواست اصلاح / موجودی اولیه')}

@login_required
def operation_new(request,kind):
    if kind not in OPERATIONS:raise PermissionDenied
    model,klass,permission,title=OPERATIONS[kind]
    if not request.user.has_perm('core.'+permission):raise PermissionDenied
    initial={}
    if kind=='material' and request.GET.get('work_order'):
        work=get_object_or_404(m.WorkOrder.objects.filter(branch_id__in=factory_ids(request.user)),pk=request.GET['work_order'],active=True)
        initial['work_order']=work.pk
    form=klass(request.POST or None,initial=initial)
    if kind=='transfer':form.restrict(request.user)
    else:scope_form(form,request.user)
    def save(d):
        if kind=='material':return op.request_material(request.user,d['warehouse'],d['item'],d['location'],d['trace'],d['quantity'],d['recipient'],d['work_order'],d['purpose'],d['operation_key'])
        if kind=='transfer':return op.request_transfer(request.user,d['source'],d['destination'],d['item'],d['location'],d['trace'],d['quantity'],d['reference'],d['operation_key'])
        return op.request_correction(request.user,d['warehouse'],d['item'],d['location'],d['trace'],d['quantity'],d['reason'],d['operation_key'])
    return submit(request,form,title,save,hint='ثبت‌کننده و تأییدکننده مستقل هستند؛ کالا تا ثبت تحویل واقعی از انبار کم نمی‌شود.')

@permitted('add_stockcount')
def count_new(request):
    initial={}
    if request.GET.get('schedule'):
        schedule=get_object_or_404(m.CountSchedule.objects.filter(warehouse__branch_id__in=factory_ids(request.user)),pk=request.GET['schedule'],active=True)
        initial={'schedule':schedule.pk,'warehouse':schedule.warehouse_id}
    form=scope_form(f.CountForm(request.POST or None,request.FILES or None,initial=initial),request.user)
    form.fields['schedule'].queryset=m.CountSchedule.objects.filter(warehouse__branch_id__in=factory_ids(request.user),active=True)
    lines=f.CountFormSet(request.POST or None,prefix='lines')
    for row in lines:scope_form(row,request.user)
    scope_form(lines.empty_form,request.user)
    if request.method=='POST':
        valid=form.is_valid()
        uploaded=request.FILES.get('csv_file')
        valid_lines=True if uploaded else lines.is_valid()
        if valid and valid_lines:
            try:
                d=form.cleaned_data
                rows=parse_count_csv(uploaded,d['warehouse']) if uploaded else [r.cleaned_data for r in lines if r.cleaned_data and not r.cleaned_data.get('DELETE')]
                op.request_count(request.user,d['warehouse'],d['reference'],rows,d['operation_key'],schedule=d.get('schedule'))
                messages.success(request,'شمارش ثبت شد؛ تأیید و ثبت مغایرت با شخص مستقل است.');return redirect('control')
            except ValidationError as e:form.add_error(None,e)
    return render(request,'core/contract_form.html',{'form':form,'formset':lines,'page_title':'ثبت انبارگردانی','active_page':'control','generic_count':True})

def document_for(user,kind,archived=False):
    ids=factory_ids(user)
    if kind=='material':query=m.MaterialRequest.objects.filter(warehouse__branch_id__in=ids).select_related('warehouse__branch','item','requested_by')
    elif kind=='transfer':query=m.StockTransfer.objects.filter(Q(source__branch_id__in=ids)|Q(destination__branch_id__in=ids)).select_related('source__branch','destination__branch','item','requested_by')
    elif kind=='correction':query=m.StockCorrection.objects.filter(warehouse__branch_id__in=ids).select_related('warehouse__branch','item','requested_by')
    elif kind=='count':query=m.StockCount.objects.filter(warehouse__branch_id__in=ids).select_related('warehouse__branch','requested_by')
    elif kind=='payment':query=m.PaymentRequest.objects.filter(allocation__account__branch_id__in=ids,allocation__contract__in=contracts_for(user)).select_related('allocation__contract','allocation__account__branch','requested_by')
    else:raise PermissionDenied
    return query if archived and root(user) else query.filter(archived_at__isnull=True)

def document_permission(user,kind):
    codes={'material':'view_materialrequest','transfer':'view_stocktransfer','correction':'view_stockcorrection','count':'view_stockcount','payment':'view_moneyentry'}
    if not user.has_perm('core.'+codes[kind]):raise PermissionDenied

def actions_for(user,kind,d):
    if d.archived_at:return []
    actions=[];ids=factory_ids(user)
    approval=user.has_perm('core.approve_operations') and d.requested_by_id!=user.pk
    if kind=='payment':approval=approval and contracts_for(user,True).filter(pk=d.allocation.contract_id).exists()
    if kind=='transfer':approval=approval and d.source.branch_id in ids
    if d.status=='pending' and approval:
        for action,label in [('approve','تأیید مستقل'),('reject','رد درخواست')]:actions.append({'url':reverse('operation_action',args=[kind,d.pk,action]),'label':label})
    if kind in ('material','transfer') and d.status=='approved' and approval:
        actions.append({'url':reverse('operation_action',args=[kind,d.pk,'cancel']),'label':'لغو و آزادسازی رزرو'})
    if kind=='material' and d.status=='approved' and user.has_perm('core.add_stockmovement') and user.pk!=d.approved_by_id:
        actions.append({'url':reverse('operation_action',args=[kind,d.pk,'issue']),'label':'ثبت تحویل به شخص'})
    if kind=='transfer' and d.status=='approved' and d.source.branch_id in ids and user.has_perm('core.add_stockmovement') and user.pk!=d.approved_by_id:
        actions.append({'url':reverse('operation_action',args=[kind,d.pk,'send']),'label':'تأیید ارسال'})
    return actions

@permitted('view_branch')
def control(request):
    groups=[];selected_kind=request.GET.get('kind','');selected_page=None
    query=request.GET.get('q','').strip()[:120];status=request.GET.get('status','')
    for kind,title,perm in [('material','درخواست و عهده اشخاص','view_materialrequest'),('transfer','انتقال بین انبارها و کارخانه‌ها','view_stocktransfer'),('correction','اصلاح و موجودی اولیه','view_stockcorrection'),('count','انبارگردانی','view_stockcount'),('payment','درخواست پرداخت','view_moneyentry')]:
        if not request.user.has_perm('core.'+perm):continue
        if selected_kind and selected_kind!=kind:continue
        objects=document_for(request.user,kind,archived=request.GET.get('archive')=='1').order_by('-pk')
        if status in ['pending','approved','rejected','issued','closed','transit','received','cancelled']:objects=objects.filter(status=status)
        if query:
            fields=['requested_by__username']+(['purpose','item__name','item__sku','recipient__name','work_order__number'] if kind=='material' else ['reference','item__name','item__sku'] if kind=='transfer' else ['reason','item__name','item__sku'] if kind=='correction' else ['reference'] if kind=='count' else ['reference','allocation__contract__number'])
            predicate=Q()
            for field in fields:predicate|=Q(**{field+'__icontains':query})
            objects=objects.filter(predicate)
        if selected_kind:selected_page=page(request,objects);objects=selected_page
        else:objects=objects[:20]
        rows=[]
        for d in objects:
            branch=d.source.branch if kind=='transfer' else d.allocation.account.branch if kind=='payment' else d.warehouse.branch
            title_value=(f'{d.item.name} / {d.quantity}' if kind in ('material','transfer','correction') else d.reference)
            rows.append({'pk':d.pk,'title':title_value,'unit':branch.name,'status':d.get_status_display(),'requested_by':d.requested_by,'url':reverse('operation_detail',args=[kind,d.pk]),'actions':actions_for(request.user,kind,d)})
        groups.append({'kind':kind,'title':title,'rows':rows})
    return render(request,'core/control.html',{'page_title':'کنترل گردش قطعات و تأییدها','active_page':'control','groups':groups,
        'locations':m.StorageLocation.objects.filter(warehouse__branch_id__in=factory_ids(request.user)).select_related('warehouse__branch')[:100],
        'custodians':m.Custodian.objects.filter(branch_id__in=factory_ids(request.user))[:100],
        'work_orders':m.WorkOrder.objects.filter(branch_id__in=factory_ids(request.user))[:100], 'objects':selected_page,'search':query,'selected_kind':selected_kind,'selected_status':status})

@login_required
def operation_detail(request,kind,pk):
    document_permission(request.user,kind)
    d=get_object_or_404(document_for(request.user,kind,archived=True),pk=pk)
    fields=[('ثبت‌کننده',person_name(d.requested_by)),('وضعیت',d.get_status_display())]
    if kind=='payment':fields += [('قرارداد',d.allocation.contract.number),('مبلغ ریال',d.amount),('شماره سند',d.reference),('شرح',d.description)]
    elif kind=='count':fields += [('انبار',d.warehouse),('شماره شمارش',d.reference)]
    else:
        fields += [('کالا',d.item),('مقدار',d.quantity),('محل',d.location or 'تعیین نشده'),('بچ / سریال',d.trace or '—')]
        if kind=='material':fields += [('تحویل‌گیرنده',d.recipient),('دستور کار',d.work_order),('هدف',d.purpose),('مصرف‌شده',d.consumed),('برگشت‌شده',d.returned),('مانده عهده',d.remaining)]
        elif kind=='transfer':fields += [('مبدأ',d.source),('مقصد',d.destination),('شماره انتقال',d.reference)]
        else:fields += [('علت اصلاح',d.reason)]
    context={'page_title':str(d._meta.verbose_name)+f' #{d.pk}','active_page':'control','document':d,'kind':kind,'fields':fields,'actions':actions_for(request.user,kind,d),
        'settle':kind=='material' and d.status=='issued' and request.user.has_perm('core.add_custodyevent'),
        'receive':kind=='transfer' and d.status=='transit' and d.destination.branch_id in factory_ids(request.user) and d.sent_by_id!=request.user.pk and request.user.has_perm('core.add_stockmovement'),
        'show_expected':request.user.has_perm('core.approve_operations')}
    from .operation_lifecycle import permission
    context['can_edit']=not d.archived_at and request.user.has_perm('core.'+permission(kind,'change'))
    context['can_delete']=not d.archived_at and request.user.has_perm('core.'+permission(kind,'delete'))
    return render(request,'core/operation_detail.html',context)

@login_required
@require_POST
def operation_action(request,kind,pk,action):
    document_permission(request.user,kind)
    get_object_or_404(document_for(request.user,kind),pk=pk)
    handlers={('material','cancel'):lambda:op.cancel_reservation(request.user,'material',pk),('transfer','cancel'):lambda:op.cancel_reservation(request.user,'transfer',pk),('material','approve'):lambda:op.approve_material(request.user,pk),('material','reject'):lambda:op.approve_material(request.user,pk,True),('material','issue'):lambda:op.issue_material(request.user,pk),
        ('transfer','approve'):lambda:op.approve_transfer(request.user,pk),('transfer','reject'):lambda:op.approve_transfer(request.user,pk,True),('transfer','send'):lambda:op.send_transfer(request.user,pk),
        ('correction','approve'):lambda:op.approve_correction(request.user,pk),('correction','reject'):lambda:op.approve_correction(request.user,pk,True),
        ('count','approve'):lambda:op.approve_count(request.user,pk),('count','reject'):lambda:op.approve_count(request.user,pk,True),
        ('payment','approve'):lambda:op.approve_payment(request.user,pk),('payment','reject'):lambda:op.approve_payment(request.user,pk,True)}
    if (kind,action) not in handlers:raise PermissionDenied
    try:handlers[(kind,action)]();messages.success(request,'عملیات با سند و سابقه ثبت شد.')
    except ValidationError as e:messages.error(request,' / '.join(e.messages))
    return redirect('operation_detail',kind=kind,pk=pk)

@permitted('add_custodyevent')
def material_settle(request,pk):
    d=get_object_or_404(document_for(request.user,'material'),pk=pk)
    form=f.SettlementForm(request.POST or None)
    return submit(request,form,'مصرف یا برگشت از عهده شخص',lambda v:op.settle_material(request.user,pk,v['kind'],v['quantity'],v['reference'],v['operation_key']),hint=str(d.recipient)+' / '+str(d.work_order))

@permitted('add_stockmovement')
def transfer_receive(request,pk):
    d=get_object_or_404(m.StockTransfer,pk=pk,destination__branch_id__in=factory_ids(request.user))
    form=f.TransferReceiveForm(request.POST or None)
    form.fields['location'].queryset=m.StorageLocation.objects.filter(warehouse=d.destination)
    return submit(request,form,'تأیید دریافت در مقصد',lambda v:op.receive_transfer(request.user,pk,v['location']))

@permitted('view_branch')
def alerts(request):
    from .scalable_reports import AtMinimum
    from django.db.models import F
    from django.db.models.functions import Length
    ids=factory_ids(request.user);cfg=m.SystemConfiguration.objects.filter(pk=1).first() or m.SystemConfiguration()
    category=request.GET.get('kind','stock');queries={};titles={};rows=[];check_result=None
    if request.user.has_perm('core.view_stockmovement'):
        queries['stock']=m.StockSummary.objects.filter(warehouse__branch_id__in=ids).annotate(low=AtMinimum(F('milliunits'),F('item__minimum_stock'))).filter(low=True).select_related('item','warehouse__branch__locality__parent__parent__parent__parent__parent','warehouse__parent__parent__parent__parent').order_by('pk')
        queries['custody']=m.MaterialRequest.objects.filter(warehouse__branch_id__in=ids,status='issued',issued_at__lt=timezone_now()-timedelta(days=cfg.overdue_days)).select_related('recipient','work_order').order_by('pk')
        queries['transit']=m.StockTransfer.objects.filter(Q(source__branch_id__in=ids)|Q(destination__branch_id__in=ids),status='transit').select_related('destination__branch__locality__parent__parent__parent__parent__parent','destination__parent__parent__parent__parent').order_by('pk')
        queries['abnormal']=m.StockMovement.objects.filter(warehouse__branch_id__in=ids,quantity__lt=-cfg.abnormal_quantity).select_related('item').order_by('-pk')
        titles.update(stock='کمبود موجودی',custody='عهدهٔ تعیین‌تکلیف‌نشده',transit='کالای در مسیر',abnormal='خروج با مقدار بالا')
    if request.user.has_perm('core.view_contract'):
        threshold=str(cfg.large_contract_amount);digits=len(threshold)
        queries['contracts']=contracts_for(request.user).annotate(amount_digits=Length('total_cached')).filter(Q(amount_digits__gt=digits)|Q(amount_digits=digits,total_cached__gte=threshold)).order_by('-pk')
        titles['contracts']='قرارداد با مبلغ بالا'
    if root(request.user):titles['system']='پشتیبان و بررسی سوابق'
    if category not in titles:category=next(iter(titles),'system')
    selected=page(request,queries[category]) if category in queries else None
    if selected:
        for value in selected:
            if category=='stock':rows.append((titles[category],str(value.item),str(value.warehouse),reverse('inventory')))
            elif category=='custody':rows.append((titles[category],str(value.recipient),str(value.work_order),reverse('operation_detail',args=['material',value.pk])))
            elif category=='transit':rows.append((titles[category],value.reference,str(value.destination),reverse('operation_detail',args=['transfer',value.pk])))
            elif category=='abnormal':rows.append((titles[category],str(value.item),value.reference,reverse('inventory')))
            else:rows.append((titles[category],value.number,value.title,reverse('contract_detail',args=[value.pk])))
    if category=='system' and root(request.user):
        status=m.BackupStatus.objects.filter(pk=1).first()
        if not status or not status.last_success or timezone_now()-status.last_success>timedelta(hours=cfg.backup_hours):rows.append(('پشتیبان نیازمند رسیدگی','نسخهٔ موفق در بازهٔ مقرر موجود نیست','پشتیبان‌گیری را انجام دهید',reverse('backup_center')))
        if status and status.last_error:rows.append(('خطای پشتیبان','آخرین تلاش ناموفق بوده','وضعیت پشتیبان را بررسی کنید',reverse('backup_center')))
        if request.GET.get('verify_audit')=='1':
            check_result=services.verify_audit_chain()
            if not check_result[0]:rows.append(('مغایرت زنجیرهٔ رویداد',f'رویداد #{check_result[1]}','بررسی سوابق لازم است',reverse('audit_log')))
    return render(request,'core/alerts.html',{'page_title':'هشدارها و پیگیری مدیریتی','active_page':'alerts','rows':rows,'objects':selected,'category':category,'categories':list(titles.items()),'check_result':check_result})

def timezone_now():
    from django.utils import timezone
    return timezone.now()

@permitted('view_item')
def item_label(request,pk):
    item=get_object_or_404(m.Item,pk=pk)
    from .barcodes import code39_svg
    barcode=item.barcode or f'ITEM-{item.pk:012d}'
    return render(request,'core/label.html',{'page_title':'برچسب کالا','active_page':'inventory','item':item,'barcode':barcode,'svg':code39_svg(barcode)})


def parse_count_csv(uploaded,warehouse):
    import csv,io
    if uploaded.size>10*1024*1024:raise ValidationError('حجم CSV بیشتر از ۱۰ مگابایت است.')
    try:
        reader=csv.DictReader(io.StringIO(uploaded.read().decode('utf-8-sig')))
        if set(reader.fieldnames or [])!={'sku','location','trace','counted'}:raise ValidationError('ستون‌های CSV باید دقیقاً sku,location,trace,counted باشند.')
        items={i.sku:i for i in m.Item.objects.all()};locations={l.code:l for l in m.StorageLocation.objects.filter(warehouse=warehouse)}
        traces={(t.item_id,t.code):t for t in m.TraceUnit.objects.all()}
        result=[]
        for n,row in enumerate(reader):
            if n>=20000:raise ValidationError('هر CSV حداکثر ۲۰ هزار ردیف دارد.')
            item=items.get(row['sku']);location=locations.get(row['location']) if row['location'] else None
            trace=traces.get((item.pk,row['trace'])) if item and row['trace'] else None
            if not item or (row['location'] and not location) or (row['trace'] and not trace):raise ValidationError(f'کد کالا، محل یا بچ در ردیف {n+2} معتبر نیست.')
            value=Decimal(row['counted'])
            result.append({'item':item,'location':location,'trace':trace,'counted':value})
        return result
    except (UnicodeError,ValueError,ArithmeticError,KeyError,TypeError):raise ValidationError('ساختار یا مقدار CSV معتبر نیست.')

@permitted('view_stockmovement')
def location_inventory(request):
    from .views import common,csv_response
    context=common(request)
    objects=m.StockBalance.objects.filter(warehouse__branch_id__in=factory_ids(request.user)).select_related('warehouse__branch','item','location','trace').order_by('warehouse__branch__name','warehouse__name','item__name','pk')
    if context['selected_branch']:objects=objects.filter(warehouse__branch_id=context['selected_branch'])
    query=context['search']
    if query:
        if query.upper().startswith('TRACE-') and query[6:].isdigit():objects=objects.filter(trace_id=int(query[6:]))
        else:objects=objects.filter(Q(item__name__icontains=query)|Q(item__sku__icontains=query)|Q(item__barcode__icontains=query)|Q(trace__code__icontains=query)|Q(location__code__icontains=query)|Q(warehouse__branch__city__icontains=query)|Q(warehouse__parent__name__icontains=query))
    if request.GET.get('export')=='csv':
        return csv_response('inventory-locations.csv',['موقعیت','انبار','کالا','کد','بارکد','محل','بچ/سریال','موجودی','رزرو','آزاد'],[(b.warehouse.branch.name,b.warehouse.path,b.item.name,b.item.sku,b.item.barcode,str(b.location or 'نامشخص'),str(b.trace or ''),b.quantity,op.reserved(b.warehouse,b.item,b.location,b.trace),b.quantity-op.reserved(b.warehouse,b.item,b.location,b.trace)) for b in objects])
    chosen=page(request,objects)
    rows=[{'balance':b,'reserved':op.reserved(b.warehouse,b.item,b.location,b.trace),'available':b.quantity-op.reserved(b.warehouse,b.item,b.location,b.trace)} for b in chosen]
    return render(request,'core/location_inventory.html',{**context,'page_title':'موجودی تا محل و سریال','active_page':'inventory','objects':chosen,'rows':rows})

@permitted('view_item')
def trace_label(request,pk):
    objects=m.TraceUnit.objects.all()
    if not root(request.user):objects=objects.filter(stockmovement__warehouse__branch_id__in=factory_ids(request.user)).distinct()
    trace=get_object_or_404(objects,pk=pk)
    from .barcodes import code39_svg
    return render(request,'core/label.html',{'page_title':'برچسب بچ یا سریال','active_page':'inventory','item':trace.item,'trace':trace,'barcode':trace.barcode,'svg':code39_svg(trace.barcode)})

@owner
def backup_center(request):
    from django.conf import settings
    from django.core.management import call_command
    from django.http import FileResponse
    import io,os
    if request.method=='POST':
        action=request.POST.get('action')
        if action=='backup':
            call_command('backup_local',stdout=io.StringIO())
            status=m.BackupStatus.objects.get(pk=1)
            services.audit('دریافت پشتیبان توسط حساب ارشد',status.last_file,request.user)
            return FileResponse((settings.DATA_DIR/'backups'/status.last_file).open('rb'),as_attachment=True,filename=status.last_file)
        if action=='open-data':
            if os.name=='nt':os.startfile(str(settings.DATA_DIR))
            else:messages.info(request,'مسیر داده فقط در نسخه ویندوز در پنجره فایل‌ها باز می‌شود.')
        else:raise PermissionDenied
    return render(request,'core/backup_center.html',{'page_title':'پشتیبان و داده‌های محلی','active_page':'settings','status':m.BackupStatus.objects.filter(pk=1).first(),'data_path':str(settings.DATA_DIR)})
