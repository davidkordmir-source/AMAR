import uuid
from django import forms
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db import IntegrityError
from django.shortcuts import get_object_or_404,redirect,render
from . import models as m,forms as base_forms,enterprise_forms as ef,operations as op
from .access import require_permission,scope_form
from .enterprise_views import document_for,document_permission
from . import operation_lifecycle as life
from .lifecycle_views import DeleteEntryForm

@login_required
def operation_delete(request,kind,pk):
    document_permission(request.user,kind);require_permission(request.user,life.permission(kind,'delete'))
    document=get_object_or_404(document_for(request.user,kind),pk=pk);form=DeleteEntryForm(request.POST or None);errors=life.blockers(document,kind)
    if request.method=='POST' and form.is_valid():
        try:
            life.revise(request.user,kind,pk,form.cleaned_data['reason'],form.cleaned_data['operation_key'])
            messages.success(request,'درخواست از فهرست فعال حذف شد و سابقه باقی ماند.');return redirect('control')
        except ValidationError as error:errors=error.messages
    return render(request,'core/record_delete.html',{'page_title':'بررسی حذف درخواست','active_page':'control','record':document,'form':form,'reasons':errors,'back_url':'control'})

@login_required
def operation_edit(request,kind,pk):
    document_permission(request.user,kind);require_permission(request.user,life.permission(kind,'change'))
    document=get_object_or_404(document_for(request.user,kind),pk=pk)
    classes={'material':ef.MaterialForm,'transfer':ef.TransferForm,'correction':ef.CorrectionForm,'count':ef.CountForm,'payment':base_forms.PaymentForm}
    klass=classes[kind]
    initial={name:getattr(document,name,None) for name in klass.base_fields if name not in ['operation_key','csv_file']}
    form=klass(request.POST or None,request.FILES or None,initial=initial)
    if kind=='transfer':form.restrict(request.user)
    else:scope_form(form,request.user)
    form.fields['revision_reason']=forms.CharField(label='علت ویرایش (حداقل ۱۰ حرف)',min_length=10,max_length=240)
    lines=None
    if kind=='count':
        if m.CountScheduleRun.objects.filter(count=document).exists():
            form.fields['warehouse'].disabled=True
            form.fields['warehouse'].help_text='این شمارش به برنامهٔ همین انبار متصل است؛ برای انبار دیگر شمارش تازه بسازید.'
        initial_lines=[{key:getattr(row,key) for key in ['item','location','trace','counted']} for row in document.lines.select_related('item','location','trace')]
        lines=ef.CountFormSet(request.POST or None,prefix='lines',initial=initial_lines)
        for row in lines:scope_form(row,request.user)
        scope_form(lines.empty_form,request.user)
    if request.method=='POST':
        valid=form.is_valid();uploaded=request.FILES.get('csv_file')
        valid_lines=not lines or bool(uploaded) or lines.is_valid()
        if valid and valid_lines:
            d=form.cleaned_data
            def create():
                if kind=='material':return op.request_material(request.user,d['warehouse'],d['item'],d['location'],d['trace'],d['quantity'],d['recipient'],d['work_order'],d['purpose'],d['operation_key'])
                if kind=='transfer':return op.request_transfer(request.user,d['source'],d['destination'],d['item'],d['location'],d['trace'],d['quantity'],d['reference'],d['operation_key'])
                if kind=='correction':return op.request_correction(request.user,d['warehouse'],d['item'],d['location'],d['trace'],d['quantity'],d['reason'],d['operation_key'])
                if kind=='payment':return op.request_payment(request.user,d['allocation'],d['amount'],d['reference'],d['description'],d['operation_key'])
                from .enterprise_views import parse_count_csv
                rows=parse_count_csv(uploaded,d['warehouse']) if uploaded else [row.cleaned_data for row in lines if row.cleaned_data and not row.cleaned_data.get('DELETE')]
                return op.request_count(request.user,d['warehouse'],d['reference'],rows,d['operation_key'])
            try:
                result=life.revise(request.user,kind,pk,d['revision_reason'],d['operation_key'],create)
                messages.success(request,'نسخهٔ جدید درخواست ثبت شد و به تأیید مستقل نیاز دارد.');return redirect('operation_detail',kind=kind,pk=result.pk)
            except ValidationError as error:form.add_error(None,error)
            except IntegrityError:form.add_error(None,'شماره یا شناسهٔ درخواست تکراری است؛ اطلاعات را بررسی کنید.')
    else:
        errors=life.blockers(document,kind,editing=True)
        if errors:form.add_error(None,errors)
    return render(request,'core/contract_form.html' if kind=='count' else 'core/form.html',{'page_title':'ویرایش درخواست با حفظ نسخهٔ پیشین','active_page':'control','form':form,'formset':lines,'generic_count':kind=='count','help_text':'نسخهٔ قبلی در سابقه می‌ماند؛ درخواستِ اجراشده قابل بازنویسی نیست.'})
