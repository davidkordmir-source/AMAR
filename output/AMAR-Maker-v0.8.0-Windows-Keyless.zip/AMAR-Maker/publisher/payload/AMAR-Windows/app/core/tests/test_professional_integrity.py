"""A recorded repair payment remains part of the job's financial history."""
import uuid
from django.contrib.auth.models import Permission
from django.core.exceptions import ValidationError
from django.utils import timezone
from core import models as m, services, pro_services as pro, pro_forms
from .test_enterprise import EnterpriseBase


class MaintenancePaymentHistoryTests(EnterpriseBase):
    def job_with_payment(self):
        contract,_=self.contract('MAINT-PAY',True,True)
        allocation=services.allocate(contract.pk,self.account.pk,1000,uuid.uuid4(),self.owner)
        payment=services.pay(allocation.pk,100,'MAINT-PAY-1',uuid.uuid4())
        equipment=pro.save_equipment(self.owner,{'branch':self.leaf,'code':'PAID-EQUIPMENT','name':'دستگاه دارای تعمیر'})
        job=pro.request_maintenance(self.owner,{'equipment':equipment,'number':'PAID-JOB','title':'تعمیر دارای پرداخت','description':'بازرسی و رفع خرابی','due_on':timezone.localdate()},uuid.uuid4())
        pro.maintenance_result(self.owner,job.pk,'نتیجهٔ نخست تعمیر برای بررسی',100,10,payment=payment,version=job.version)
        pro.review_maintenance(self.approver,job.pk,False,'گزارش نیازمند توضیح و تکمیل است')
        job.refresh_from_db()
        return job,payment,allocation

    def test_existing_posted_payment_cannot_be_cleared_or_replaced_to_enable_deletion(self):
        job,payment,allocation=self.job_with_payment()
        replacement=services.pay(allocation.pk,50,'MAINT-PAY-2',uuid.uuid4())
        for value in [None,replacement]:
            with self.assertRaises(ValidationError):
                pro.maintenance_result(self.owner,job.pk,'تکمیل گزارش نتیجهٔ تعمیر دستگاه',100,10,payment=value,version=job.version)
            job.refresh_from_db()
            self.assertEqual(job.payment_id,payment.pk)
            self.assertEqual(job.status,'working')
        with self.assertRaises(ValidationError):
            pro.archive_record(self.owner,'maintenance',job.pk,'تلاش برای حذف سابقهٔ کار تعمیر')
        self.assertTrue(m.MaintenanceJob.objects.filter(pk=job.pk,archived_at__isnull=True).exists())

    def test_missing_account_visibility_preserves_hidden_payment_and_delete_guard(self):
        job,payment,_=self.job_with_payment()
        technician=self.person('limited-payment-technician','maintenance',self.leaf)
        technician.factory_profile.role.permissions.add(Permission.objects.get(content_type__app_label='core',codename='view_moneyentry'))
        self.assertTrue(technician.has_perm('core.view_moneyentry'))
        self.assertFalse(technician.has_perm('core.view_account'))
        form=pro_forms.MaintenanceResultForm(actor=technician,job=job)
        self.assertNotIn('payment',form.fields)
        pro.maintenance_result(technician,job.pk,'گزارش تکمیلی توسط مسئول فنی موقعیت',100,10,payment=None,version=job.version)
        job.refresh_from_db()
        self.assertEqual(job.payment_id,payment.pk)
        with self.assertRaises(ValidationError):
            pro.archive_record(self.owner,'maintenance',job.pk,'حذف کار با سابقهٔ پرداخت مالی')


class WorkflowVisibilityTests(EnterpriseBase):
    def test_assignee_must_be_able_to_open_underlying_service_warning(self):
        from core import attention
        equipment=pro.save_equipment(self.owner,{'branch':self.leaf,'code':'SERVICE-VIS','name':'دستگاه سرویس'})
        plan=pro.save_maintenance_plan(self.owner,{'equipment':equipment,'title':'سرویس','interval_days':30,'next_due':timezone.localdate(),'active':True})
        self.assertTrue(self.finance.has_perm('core.view_followup'))
        self.assertFalse(self.finance.has_perm('core.view_maintenanceplan'))
        with self.assertRaises(ValidationError):
            attention.follow_up(self.owner,'service:'+str(plan.pk),{'assigned_to':self.finance,'status':'working','note':'بررسی سرویس و تعیین اقدام','due_on':timezone.localdate()},0)
        self.assertFalse(m.FollowUp.objects.exists())

    def test_payment_history_labels_recheck_account_visibility_and_contract_grant(self):
        from .helpers import body
        job,payment,_=MaintenancePaymentHistoryTests.job_with_payment(self)
        record=m.ChangeRecord.objects.filter(kind='maintenancejob',object_id=job.pk,after__payment_id=payment.pk).exclude(before__payment_id=payment.pk).first()
        self.assertIsNotNone(record)
        self.finance.factory_profile.role.permissions.add(Permission.objects.get(content_type__app_label='core',codename='view_maintenancejob'))
        self.client.force_login(self.finance)
        response=self.client.get('/work/changes/'+str(record.pk)+'/')
        self.assertEqual(response.status_code,200)
        self.assertIn(payment.reference,body(response))
        m.ContractGrant.objects.filter(contract=payment.allocation.contract).delete()
        response=self.client.get('/work/changes/'+str(record.pk)+'/')
        self.assertEqual(response.status_code,200)
        self.assertNotIn(payment.reference,body(response))
