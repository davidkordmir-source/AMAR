from django.contrib.auth.models import Group,Permission
from django.core.management.base import BaseCommand
from core.models import AccessRole

class Command(BaseCommand):
    help='Create initial editable roles without resetting user-customized names or permissions.'
    def handle(self,*args,**options):
        basic=['view_organization','view_branch','view_warehouse','view_item','view_contract','view_contractline']
        stock=['view_stockmovement','view_receipt','add_stockmovement','view_materialrequest','add_materialrequest','view_custodyevent','add_custodyevent','view_stocktransfer','add_stocktransfer','view_stockcount','add_stockcount','view_stockcorrection','add_stockcorrection']
        finance=['view_account','view_allocation','view_moneyentry','add_account','change_moneyentry','delete_moneyentry','view_document','add_document','change_document','delete_document','change_account','add_allocation','add_moneyentry']
        directories=['add_organization','add_branch','add_warehouse','add_item']
        exchange=['view_importedsnapshot','add_importedsnapshot','view_trustedsource','add_trustedsource','export_branch_data']
        roles={
            'operations':('راهبر عملیات',basic+stock+finance+directories+exchange+['add_contract','approve_contract','view_auditevent','approve_operations','grant_contract']),
            'contracts':('هماهنگ‌کننده قرارداد',basic+['add_contract','change_contract','delete_contract','approve_contract','view_document','add_document','change_document','delete_document']),
            'stock':('متولی انبار',basic+stock+['change_'+name for name in ['materialrequest','stocktransfer','stockcorrection','stockcount']]+['delete_'+name for name in ['materialrequest','stocktransfer','stockcorrection','stockcount']]),
            'finance':('متولی مالی',basic+finance),
            'observer':('ناظر',list(Permission.objects.filter(content_type__app_label='core',codename__startswith='view_').values_list('codename',flat=True))),
            'approval':('تأییدکننده مستقل',basic+stock+finance+['approve_operations','approve_contract','grant_contract','view_auditevent']),
        }
        tracked=['equipment','maintenanceplan','maintenancejob','countschedule','deliveryinspection','refundrequest','followup']
        extra=[prefix+'_'+name for name in tracked for prefix in ['view','add','change','delete']]
        reviews=['review_deliveryinspection','review_maintenancejob','view_approvalcase','view_approvalvote','view_changerecord']
        roles['operations']=(roles['operations'][0],roles['operations'][1]+extra+reviews)
        roles['approval']=(roles['approval'][0],roles['approval'][1]+['view_'+name for name in tracked]+reviews+['change_followup'])
        roles['finance']=(roles['finance'][0],roles['finance'][1]+['view_refundrequest','add_refundrequest','change_refundrequest','delete_refundrequest','view_followup','change_followup','view_changerecord'])
        roles['stock']=(roles['stock'][0],roles['stock'][1]+[p+'_'+name for name in ['countschedule','deliveryinspection'] for p in ['view','add','change','delete']]+['view_equipment','view_followup','change_followup','view_changerecord'])
        roles['maintenance']=('مسئول سرویس و دارایی',basic+stock+[p+'_'+name for name in ['equipment','maintenanceplan','maintenancejob'] for p in ['view','add','change','delete']]+['view_changerecord','view_followup','change_followup'])
        roles['quality']=('بازرس کیفیت',basic+stock+['view_deliveryinspection','review_deliveryinspection','view_followup','change_followup','view_changerecord'])
        legacy={'operations':'مدیرعامل / مدیر عملیات','contracts':'مسئول قراردادها','stock':'انباردار','finance':'مسئول مالی','observer':'ناظر'}
        for code,(name,codenames) in roles.items():
            permissions=Permission.objects.filter(content_type__app_label='core',codename__in=codenames)
            role,created=AccessRole.objects.get_or_create(code=code,defaults={'name':name})
            if created:role.permissions.set(permissions)
            if code in legacy:
                group,new=Group.objects.get_or_create(name=legacy[code])
                if new:group.permissions.set(permissions)
        self.stdout.write(self.style.SUCCESS('نقش‌های اولیه آماده‌اند؛ نام‌ها و مجوزهای تغییرکرده حفظ شدند.'))
