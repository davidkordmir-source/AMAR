import io
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
from zipfile import ZipFile

from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase, TransactionTestCase, override_settings

from core.models import Account, Contract, Organization, StockMovement
from scripts.restore_backup import restore

class DemoTests(TestCase):
    def test_seed_demo_runs_full_workflow_and_is_repeatable(self):
        call_command("seed_demo", stdout=io.StringIO())
        counts = (Organization.objects.count(), Contract.objects.count(), StockMovement.objects.count())
        call_command("seed_demo", stdout=io.StringIO())
        self.assertEqual(counts, (Organization.objects.count(), Contract.objects.count(), StockMovement.objects.count()))
        self.assertEqual(Contract.objects.filter(status="partial").count(), 1)
        self.assertEqual(Contract.objects.filter(status="received").count(), 1)
        self.assertTrue(all(account.available >= 0 for account in Account.objects.all()))
    def test_demo_does_not_overwrite_existing_user_data(self):
        Organization.objects.create(name="داده واقعی", role="consumer")
        with self.assertRaises(CommandError):
            call_command("seed_demo", stdout=io.StringIO())
        self.assertEqual(Organization.objects.count(), 1)

class BackupTests(TransactionTestCase):
    def test_backup_restore_integrity_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "data"
            data.mkdir()
            # Session key is optional when supplied via environment in real deployments.
            (data / "secret.key").write_text("test-key-only")
            Organization.objects.create(name="بازیابی", role="consumer")
            archive_path = root / "backup.zip"
            with override_settings(DATA_DIR=data):
                from core.secure_exchange import encryption_identity
                encryption_identity()
                call_command("backup_local", output=str(archive_path), stdout=io.StringIO())
            restored = restore(archive_path, root / "restored")
            with closing(sqlite3.connect(restored / "amar.sqlite3")) as db:
                self.assertEqual(db.execute("SELECT name FROM core_organization").fetchone()[0], "بازیابی")
            self.assertEqual((restored / "secret.key").read_text(), "test-key-only")
            self.assertEqual((restored / "transfer-identity.json").read_bytes(), (data / "transfer-identity.json").read_bytes())
            self.assertEqual((restored / "exchange-encryption.key").read_bytes(), (data / "exchange-encryption.key").read_bytes())
            with self.assertRaises(ValueError):
                restore(archive_path, restored)
            with override_settings(DATA_DIR=data), self.assertRaises(CommandError):
                call_command("backup_local", output=str(archive_path), stdout=io.StringIO())
    def test_restore_rejects_unexpected_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / "bad.zip"
            with ZipFile(archive, "w") as z:
                z.writestr("../outside", "bad")
            with self.assertRaises(ValueError):
                restore(archive, Path(tmp) / "target")
            self.assertFalse((Path(tmp) / "outside").exists())
