"""Factory operations added in 0.8; monetary and stock postings stay in core ledgers."""
import uuid
from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.db.models import Q, F
from django.utils import timezone
from .models import ImmutableRecord, OperationLifecycle


class ApprovalPolicy(models.Model):
    version = models.PositiveIntegerField(default=1)
    KINDS = [('contract', 'قرارداد'), ('payment', 'پرداخت'), ('refund', 'برگشت پرداخت')]
    name = models.CharField('نام قاعده', max_length=100)
    kind = models.CharField('نوع سند', max_length=12, choices=KINDS)
    branch = models.ForeignKey('Branch', on_delete=models.PROTECT, null=True, blank=True, verbose_name='موقعیت؛ خالی یعنی همهٔ موقعیت‌ها')
    include_descendants = models.BooleanField('شامل زیرموقعیت‌ها', default=True)
    minimum_amount = models.BigIntegerField('از مبلغ (ریال)', default=1, validators=[MinValueValidator(1)])
    required_votes = models.PositiveSmallIntegerField('تعداد تأیید مستقل', default=2, validators=[MinValueValidator(1), MaxValueValidator(5)])
    roles = models.ManyToManyField('AccessRole', blank=True, verbose_name='نقش‌های مجاز به تأیید؛ خالی یعنی همهٔ تأییدکنندگان مجاز')
    active = models.BooleanField('فعال', default=True)
    class Meta:
        verbose_name = 'قاعدهٔ تأیید'
        ordering = ['name']
        constraints = [models.CheckConstraint(condition=Q(minimum_amount__gte=1, required_votes__gte=1, required_votes__lte=5), name='valid_approval_policy')]
    def __str__(self): return self.name


class ApprovalCase(models.Model):
    document_version = models.PositiveIntegerField(default=0)
    kind = models.CharField(max_length=12, choices=ApprovalPolicy.KINDS)
    object_id = models.PositiveBigIntegerField()
    revision_digest = models.CharField(max_length=64)
    branch = models.ForeignKey('Branch', on_delete=models.PROTECT)
    contract = models.ForeignKey('Contract', on_delete=models.PROTECT, null=True, blank=True)
    title = models.CharField(max_length=200)
    amount = models.BigIntegerField()
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='+')
    required_votes = models.PositiveSmallIntegerField(default=1)
    allowed_roles = models.JSONField(default=list)
    policy_snapshot = models.JSONField(default=list)
    status = models.CharField(max_length=12, default='pending', choices=[('pending','منتظر تأیید'),('approved','تأیید کامل'),('rejected','رد شده')])
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        constraints = [models.UniqueConstraint(fields=['kind','object_id','revision_digest'], name='unique_document_approval_revision')]
        indexes = [models.Index(fields=['branch','status','kind'])]
        verbose_name = 'پروندهٔ تأیید'


class ApprovalVote(ImmutableRecord):
    case = models.ForeignKey(ApprovalCase, on_delete=models.PROTECT, related_name='votes')
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    decision = models.CharField(max_length=8, choices=[('approve','تأیید'),('reject','رد')])
    note = models.CharField('توضیح', max_length=240, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['case','actor'], name='one_independent_vote_per_person')]
        verbose_name = 'رأی مستقل'


class FinancialPeriod(models.Model):
    def __str__(self):return self.name
    version = models.PositiveIntegerField(default=1)
    active = models.BooleanField(default=True)
    name = models.CharField('نام دوره', max_length=100)
    branch = models.ForeignKey('Branch', on_delete=models.PROTECT, null=True, blank=True, verbose_name='موقعیت؛ خالی یعنی کل مجموعه')
    starts_on = models.DateField('شروع دوره')
    ends_on = models.DateField('پایان دوره')
    locked = models.BooleanField('دوره بسته است', default=False)
    reason = models.CharField('علت بستن یا بازکردن', max_length=240)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    changed_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ['-starts_on']
        constraints = [models.CheckConstraint(condition=Q(ends_on__gte=F('starts_on')), name='financial_period_dates_ordered')]
        verbose_name = 'دورهٔ مالی'


class RefundRequest(OperationLifecycle):
    def __str__(self):return self.reference
    version = models.PositiveIntegerField(default=1)
    original = models.ForeignKey('MoneyEntry', on_delete=models.PROTECT, related_name='refund_requests', verbose_name='پرداخت اصلی')
    reference = models.CharField('شماره سند برگشت', max_length=80)
    reason = models.CharField('علت و مستند برگشت', max_length=240)
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='+')
    entry = models.OneToOneField('MoneyEntry', on_delete=models.PROTECT, null=True, blank=True, related_name='+')
    status = models.CharField(max_length=12, default='pending', choices=[('pending','منتظر تأیید'),('approved','برگشت ثبت شد'),('rejected','رد شده'),('cancelled','لغو شده')])
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'درخواست برگشت پرداخت'


class QualityPolicy(models.Model):
    def __str__(self):return f'کنترل کیفیت · {self.branch.name}'
    version = models.PositiveIntegerField(default=1)
    branch = models.OneToOneField('Branch', on_delete=models.PROTECT, verbose_name='موقعیت')
    required = models.BooleanField('تحویل قرارداد پس از تأیید کیفیت', default=True)
    instructions = models.CharField('راهنمای بازرسی', max_length=240, blank=True)
    class Meta: verbose_name = 'قاعدهٔ کنترل کیفیت'


class DeliveryInspection(OperationLifecycle):
    contract_revision = models.PositiveIntegerField(default=0)
    def __str__(self):return f'{self.reference} · {self.contract.number}'
    contract = models.ForeignKey('Contract', on_delete=models.PROTECT, related_name='inspections', verbose_name='قرارداد')
    reference = models.CharField('شماره بازرسی / رسید', max_length=80)
    payload = models.JSONField()
    notes = models.TextField('شرایط و مشاهدات', blank=True)
    decision_note = models.TextField('نتیجه و علت پذیرش یا رد', blank=True)
    status = models.CharField(max_length=12, default='pending', choices=[('pending','منتظر بازرسی'),('accepted','کیفیت تأیید و تحویل ثبت شد'),('rejected','کیفیت رد شد')])
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='+')
    receipt = models.OneToOneField('Receipt', on_delete=models.PROTECT, null=True, blank=True, related_name='inspection')
    document = models.ForeignKey('Document', on_delete=models.PROTECT, null=True, blank=True, verbose_name='سند یا اسکن بازرسی')
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True)
    version = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'بازرسی تحویل'
        permissions = [('review_deliveryinspection','تأیید یا رد کیفیت تحویل')]


class Equipment(OperationLifecycle):
    uid = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    branch = models.ForeignKey('Branch', on_delete=models.PROTECT, verbose_name='موقعیت')
    code = models.CharField('کد دارایی', max_length=50, unique=True)
    name = models.CharField('نام دستگاه یا دارایی', max_length=160)
    item = models.ForeignKey('Item', on_delete=models.PROTECT, null=True, blank=True, verbose_name='کالای مرتبط')
    trace = models.OneToOneField('TraceUnit', on_delete=models.PROTECT, null=True, blank=True, verbose_name='سریال ثبت‌شده در انبار')
    serial = models.CharField('سریال سازنده', max_length=100, blank=True)
    custodian = models.ForeignKey('Custodian', on_delete=models.PROTECT, null=True, blank=True, verbose_name='مسئول نگهداری')
    location = models.ForeignKey('StorageLocation', on_delete=models.PROTECT, null=True, blank=True, verbose_name='محل نگهداری')
    status = models.CharField('وضعیت', max_length=12, default='operating', choices=[('operating','در حال بهره‌برداری'),('down','متوقف / نیازمند تعمیر'),('retired','از رده خارج')])
    installed_on = models.DateField('تاریخ نصب', null=True, blank=True)
    warranty_until = models.DateField('پایان ضمانت', null=True, blank=True)
    critical = models.BooleanField('دستگاه حساس', default=False)
    notes = models.TextField('مشخصات و توضیحات', blank=True)
    version = models.PositiveIntegerField(default=1)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['code']
        verbose_name = 'دستگاه و دارایی'
        indexes = [models.Index(fields=['branch','status'])]
    def __str__(self): return f'{self.code} · {self.name}'


class MaintenancePlan(models.Model):
    def __str__(self):return f'{self.equipment.code} · {self.title}'
    equipment = models.ForeignKey(Equipment, on_delete=models.PROTECT, related_name='plans', verbose_name='دستگاه')
    title = models.CharField('عنوان سرویس دوره‌ای', max_length=140)
    interval_days = models.PositiveIntegerField('فاصلهٔ سرویس (روز)', default=30, validators=[MinValueValidator(1), MaxValueValidator(3650)])
    next_due = models.DateField('موعد بعدی')
    instructions = models.TextField('کارهای لازم و نکات ایمنی', blank=True)
    active = models.BooleanField('فعال', default=True)
    last_completed = models.DateField(null=True, blank=True)
    version = models.PositiveIntegerField(default=1)
    class Meta:
        ordering = ['next_due','pk']
        verbose_name = 'برنامهٔ سرویس'


class MaintenanceJob(OperationLifecycle):
    def __str__(self):return f'{self.number} · {self.title}'
    equipment = models.ForeignKey(Equipment, on_delete=models.PROTECT, related_name='jobs', verbose_name='دستگاه')
    branch = models.ForeignKey('Branch', on_delete=models.PROTECT, verbose_name='موقعیت انجام کار')
    plan = models.ForeignKey(MaintenancePlan, on_delete=models.PROTECT, null=True, blank=True, verbose_name='برنامهٔ سرویس')
    number = models.CharField('شماره کار', max_length=60, unique=True)
    title = models.CharField('عنوان تعمیر یا سرویس', max_length=180)
    description = models.TextField('شرح خرابی و کار لازم')
    due_on = models.DateField('موعد انجام')
    technician = models.ForeignKey('Custodian', on_delete=models.PROTECT, null=True, blank=True, verbose_name='مسئول انجام')
    work_order = models.OneToOneField('WorkOrder', on_delete=models.PROTECT, related_name='maintenance_job')
    status = models.CharField(max_length=16, default='open', choices=[('open','ثبت شده'),('working','در حال انجام'),('review','منتظر تأیید نتیجه'),('closed','پایان‌یافته'),('cancelled','لغو شده')])
    result = models.TextField('کار انجام‌شده و نتیجه', blank=True)
    reported_cost = models.BigIntegerField('هزینهٔ اعلام‌شده (ریال؛ ثبت پرداخت جداست)', default=0, validators=[MinValueValidator(0)])
    downtime_minutes = models.PositiveIntegerField('توقف دستگاه (دقیقه)', default=0)
    payment = models.ForeignKey('MoneyEntry', on_delete=models.PROTECT, null=True, blank=True, verbose_name='سند پرداخت مرتبط')
    document = models.ForeignKey('Document', on_delete=models.PROTECT, null=True, blank=True, verbose_name='گزارش یا اسکن مرتبط')
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='+')
    result_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='+')
    operation_key = models.UUIDField(default=uuid.uuid4, unique=True)
    version = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        ordering = ['-pk']
        verbose_name = 'تعمیر و سرویس'
        permissions = [('review_maintenancejob','تأیید مستقل پایان تعمیر و سرویس')]


class CountSchedule(models.Model):
    def __str__(self):return f'{self.warehouse.name} · {self.title}'
    warehouse = models.ForeignKey('Warehouse', on_delete=models.PROTECT, verbose_name='انبار')
    title = models.CharField('عنوان برنامهٔ انبارگردانی', max_length=140)
    interval_days = models.PositiveIntegerField('فاصلهٔ شمارش (روز)', default=30, validators=[MinValueValidator(1), MaxValueValidator(3650)])
    next_due = models.DateField('موعد شمارش')
    active = models.BooleanField('فعال', default=True)
    last_count = models.ForeignKey('StockCount', on_delete=models.PROTECT, null=True, blank=True)
    version = models.PositiveIntegerField(default=1)
    class Meta:
        ordering = ['next_due','pk']
        verbose_name = 'برنامهٔ انبارگردانی'


class CountScheduleRun(models.Model):
    schedule = models.ForeignKey(CountSchedule, on_delete=models.PROTECT, related_name='runs')
    count = models.OneToOneField('StockCount', on_delete=models.PROTECT, related_name='scheduled_run')


class ChangeRecord(ImmutableRecord):
    kind = models.CharField(max_length=40)
    object_id = models.PositiveBigIntegerField()
    branch = models.ForeignKey('Branch', on_delete=models.PROTECT)
    contract = models.ForeignKey('Contract', on_delete=models.PROTECT, null=True, blank=True)
    title = models.CharField(max_length=200)
    before = models.JSONField(default=dict)
    after = models.JSONField(default=dict)
    reason = models.CharField(max_length=240)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    audit = models.OneToOneField('AuditEvent', on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        indexes = [models.Index(fields=['kind','object_id']), models.Index(fields=['branch','created_at'])]
        verbose_name = 'سابقهٔ تغییر'


class FollowUp(models.Model):
    key = models.CharField(max_length=160, unique=True)
    branch = models.ForeignKey('Branch', on_delete=models.PROTECT)
    contract = models.ForeignKey('Contract', on_delete=models.PROTECT, null=True, blank=True)
    title = models.CharField('موضوع رسیدگی', max_length=200)
    fingerprint = models.CharField(max_length=64)
    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='+', verbose_name='مسئول پیگیری')
    due_on = models.DateField('مهلت پیگیری', null=True, blank=True)
    status = models.CharField('وضعیت', max_length=12, default='open', choices=[('open','باز'),('working','در حال رسیدگی'),('resolved','رسیدگی‌شده')])
    note = models.TextField('شرح اقدام و نتیجه', blank=True)
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    version = models.PositiveIntegerField(default=1)
    class Meta:
        ordering = ['due_on','-pk']
        indexes = [models.Index(fields=['branch','status'])]
        verbose_name = 'پیگیری هشدار'


class ExchangePeer(models.Model):
    source = models.OneToOneField('TrustedSource', on_delete=models.PROTECT, related_name='exchange_peer')
    encryption_key = models.CharField(max_length=100)
    acked_manifest = models.JSONField(default=dict)
    last_sent_hash = models.CharField(max_length=64, blank=True)
    last_received_hash = models.CharField(max_length=64, blank=True)
    last_received_sequence = models.PositiveBigIntegerField(default=0)
    last_received_at = models.DateTimeField(null=True, blank=True)
    last_ack_at = models.DateTimeField(null=True, blank=True)
    last_received_scope = models.JSONField(default=dict)
    class Meta: verbose_name = 'همتای تبادل رمزگذاری‌شده'


class ExchangeOutbox(ImmutableRecord):
    uid = models.UUIDField(default=uuid.uuid4, unique=True)
    peer = models.ForeignKey(ExchangePeer, on_delete=models.PROTECT, related_name='outbox')
    sequence = models.PositiveBigIntegerField()
    digest = models.CharField(max_length=64)
    envelope = models.BinaryField()
    manifest = models.JSONField()
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-pk']
        constraints = [models.UniqueConstraint(fields=['peer','sequence'], name='unique_outgoing_peer_sequence')]
        verbose_name = 'بستهٔ تغییرات ارسالی'


class ExchangeInbox(models.Model):
    uid = models.UUIDField(unique=True)
    peer = models.ForeignKey(ExchangePeer, on_delete=models.PROTECT, related_name='inbox')
    sequence = models.PositiveBigIntegerField()
    digest = models.CharField(max_length=64)
    previous_hash = models.CharField(max_length=64, blank=True)
    status = models.CharField(max_length=12, default='review', choices=[('review','منتظر بررسی'),('applied','ثبت شد'),('conflict','تعارض نسخه'),('rejected','رد شد')])
    reason = models.CharField(max_length=240, blank=True)
    payload = models.JSONField()
    imported_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='+')
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='+')
    imported_at = models.DateTimeField(auto_now_add=True)
    generated_at = models.DateTimeField(default=timezone.now)
    applied_at = models.DateTimeField(null=True, blank=True)
    receipt = models.BinaryField(null=True, blank=True)
    class Meta:
        ordering = ['-pk']
        indexes = [models.Index(fields=['peer','status'])]
        verbose_name = 'بستهٔ تغییرات دریافتی'


class ExchangeAck(ImmutableRecord):
    outbox = models.OneToOneField(ExchangeOutbox, on_delete=models.PROTECT, related_name='ack')
    result = models.CharField(max_length=12, choices=[('applied','ثبت شد'),('rejected','رد شد')])
    digest = models.CharField(max_length=64)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: verbose_name = 'رسید تبادل'


class ExchangeReplica(models.Model):
    peer = models.ForeignKey(ExchangePeer, on_delete=models.PROTECT)
    entity_key = models.CharField(max_length=120)
    digest = models.CharField(max_length=64)
    kind = models.CharField(max_length=20)
    search_key = models.CharField(max_length=120, blank=True, db_index=True)
    data = models.JSONField()
    class Meta:
        constraints = [models.UniqueConstraint(fields=['peer','entity_key'], name='unique_remote_owned_entity')]
        indexes = [models.Index(fields=['peer','kind'])]
