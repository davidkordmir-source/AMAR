"""Load the existing maker identity, unlocking protected downloads when needed."""
import base64
import hashlib
import json
import os
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


class WorkshopKeyError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def _public(root):
    path = root / 'publisher/payload/AMAR-Windows/app/data/developer-public.json'
    try:
        if path.stat().st_size > 8192:
            raise ValueError()
        value = json.loads(path.read_bytes())
        raw = base64.b64decode(value['public_key'], validate=True)
        fingerprint = hashlib.sha256(raw).hexdigest()
        if len(raw) != 32 or fingerprint != value['fingerprint']:
            raise ValueError()
        return raw, fingerprint
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise WorkshopKeyError('incomplete-workshop',
            'هویت کارگاه پیدا نشد یا ناقص است. بسته را با Extract All کامل استخراج کنید و Start-Maker.cmd را از همان پوشه اجرا کنید.') from error


def _validate_key(content, public):
    try:
        key = serialization.load_pem_private_key(content, password=None)
        if not isinstance(key, Ed25519PrivateKey):
            raise ValueError()
        actual = key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        if actual != public:
            raise ValueError()
        return key
    except (ValueError, TypeError) as error:
        raise WorkshopKeyError('identity-mismatch',
            'کلید این پوشه با هویت کارگاه مطابقت ندارد. فایل موجود بازنویسی نشد؛ از کارگاه اصلی استفاده کنید.') from error


def read_key(root, password_provider=None):
    """Never create a replacement identity or overwrite a different existing key."""
    root = Path(root).resolve()
    public, fingerprint = _public(root)
    target = root / 'publisher/private/developer-key.pem'
    encrypted = target.with_name('developer-key.encrypted.json')
    if target.exists():
        try:
            return _validate_key(target.read_bytes(), public)
        except OSError as error:
            raise WorkshopKeyError('key-unreadable', 'دسترسی خواندن کلید کارگاه وجود ندارد؛ کارگاه را در پوشهٔ خصوصی قابل‌نوشتن استخراج کنید.') from error
    if not encrypted.is_file():
        raise WorkshopKeyError('key-files-missing',
            'فایل کلید و فایل رمزگذاری‌شده در این کارگاه پیدا نشد. بستهٔ کامل کارگاه اصلاح‌شده را با Extract All استخراج و Start-Maker.cmd را از همان پوشه اجرا کنید.')
    try:
        if encrypted.stat().st_size > 8192:
            raise ValueError()
        value = json.loads(encrypted.read_bytes())
        if (set(value) != {'format', 'version', 'algorithm', 'issuer', 'salt', 'nonce', 'ciphertext'}
                or value['format'] != 'AMAR-Protected-Developer-Key'
                or type(value['version']) is not int or value['version'] != 1
                or value['algorithm'] != 'scrypt-32768-8-1/AES-256-GCM'
                or value['issuer'] != fingerprint):
            raise ValueError()
        salt = base64.b64decode(value['salt'], validate=True)
        nonce = base64.b64decode(value['nonce'], validate=True)
        ciphertext = base64.b64decode(value['ciphertext'], validate=True)
        if len(salt) != 16 or len(nonce) != 12 or not 32 <= len(ciphertext) <= 4096:
            raise ValueError()
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise WorkshopKeyError('encrypted-key-invalid',
            'فایل کلید رمزگذاری‌شده ناقص است یا با کارگاه مطابقت ندارد. بستهٔ کامل کارگاه را دوباره استخراج کنید.') from error
    if password_provider is None:
        raise WorkshopKeyError('activation-required',
            'کارگاه رمزگذاری‌شده است. Start-Maker.cmd را اجرا و رمز کارگاه را وارد کنید؛ ابزار کلید را فعال می‌کند.')
    password = password_provider()
    if password is None:
        raise WorkshopKeyError('cancelled', 'فعال‌سازی کارگاه لغو شد.')
    try:
        derived = Scrypt(salt=salt, length=32, n=32768, r=8, p=1).derive(password.encode('utf-8'))
        content = AESGCM(derived).decrypt(nonce, ciphertext,
            b'AMAR-Protected-Developer-Key:v1:' + fingerprint.encode('ascii'))
    except InvalidTag as error:
        raise WorkshopKeyError('wrong-password-or-damaged-key',
            'رمز کارگاه اشتباه است یا فایل رمزگذاری‌شده آسیب دیده است. رمز دانلود کارگاه را دوباره وارد کنید.') from error
    key = _validate_key(content, public)
    try:
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(descriptor, 'wb') as stream:
                stream.write(content)
        except BaseException:
            target.unlink(missing_ok=True)
            raise
    except FileExistsError:
        return _validate_key(target.read_bytes(), public)
    except OSError as error:
        raise WorkshopKeyError('key-save-denied',
            'کلید باز شد ولی ذخیرهٔ آن در این پوشه ممکن نیست. کارگاه را با Extract All در پوشهٔ خصوصی قابل‌نوشتن استخراج کنید.') from error
    return key
